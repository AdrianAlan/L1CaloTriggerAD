#include "dense_resource_ap_ufixed_ap_fixed_config2_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1230_fu_106974_p00() {
    mul_ln1118_1230_fu_106974_p00 = esl_zext<12,10>(trunc_ln77_788_reg_139296.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1230_fu_106974_p1() {
    mul_ln1118_1230_fu_106974_p1 = tmp_1773_reg_139301.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1230_fu_106974_p2() {
    mul_ln1118_1230_fu_106974_p2 = (!mul_ln1118_1230_fu_106974_p0.read().is_01() || !mul_ln1118_1230_fu_106974_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1230_fu_106974_p0.read()) * sc_bigint<2>(mul_ln1118_1230_fu_106974_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1231_fu_106998_p0() {
    mul_ln1118_1231_fu_106998_p0 =  (sc_lv<10>) (mul_ln1118_1231_fu_106998_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1231_fu_106998_p00() {
    mul_ln1118_1231_fu_106998_p00 = esl_zext<12,10>(trunc_ln77_789_reg_139306.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1231_fu_106998_p1() {
    mul_ln1118_1231_fu_106998_p1 = tmp_1775_reg_139311.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1231_fu_106998_p2() {
    mul_ln1118_1231_fu_106998_p2 = (!mul_ln1118_1231_fu_106998_p0.read().is_01() || !mul_ln1118_1231_fu_106998_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1231_fu_106998_p0.read()) * sc_bigint<2>(mul_ln1118_1231_fu_106998_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1232_fu_107022_p0() {
    mul_ln1118_1232_fu_107022_p0 =  (sc_lv<10>) (mul_ln1118_1232_fu_107022_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1232_fu_107022_p00() {
    mul_ln1118_1232_fu_107022_p00 = esl_zext<12,10>(trunc_ln77_790_reg_139316.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1232_fu_107022_p1() {
    mul_ln1118_1232_fu_107022_p1 = tmp_1777_reg_139321.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1232_fu_107022_p2() {
    mul_ln1118_1232_fu_107022_p2 = (!mul_ln1118_1232_fu_107022_p0.read().is_01() || !mul_ln1118_1232_fu_107022_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1232_fu_107022_p0.read()) * sc_bigint<2>(mul_ln1118_1232_fu_107022_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1233_fu_107046_p0() {
    mul_ln1118_1233_fu_107046_p0 =  (sc_lv<10>) (mul_ln1118_1233_fu_107046_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1233_fu_107046_p00() {
    mul_ln1118_1233_fu_107046_p00 = esl_zext<12,10>(trunc_ln77_791_reg_139326.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1233_fu_107046_p1() {
    mul_ln1118_1233_fu_107046_p1 = tmp_1779_reg_139331.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1233_fu_107046_p2() {
    mul_ln1118_1233_fu_107046_p2 = (!mul_ln1118_1233_fu_107046_p0.read().is_01() || !mul_ln1118_1233_fu_107046_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1233_fu_107046_p0.read()) * sc_bigint<2>(mul_ln1118_1233_fu_107046_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1234_fu_107070_p0() {
    mul_ln1118_1234_fu_107070_p0 =  (sc_lv<10>) (mul_ln1118_1234_fu_107070_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1234_fu_107070_p00() {
    mul_ln1118_1234_fu_107070_p00 = esl_zext<12,10>(trunc_ln77_792_reg_139336.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1234_fu_107070_p1() {
    mul_ln1118_1234_fu_107070_p1 = tmp_1781_reg_139341.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1234_fu_107070_p2() {
    mul_ln1118_1234_fu_107070_p2 = (!mul_ln1118_1234_fu_107070_p0.read().is_01() || !mul_ln1118_1234_fu_107070_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1234_fu_107070_p0.read()) * sc_bigint<2>(mul_ln1118_1234_fu_107070_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1235_fu_107082_p0() {
    mul_ln1118_1235_fu_107082_p0 =  (sc_lv<10>) (mul_ln1118_1235_fu_107082_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1235_fu_107082_p00() {
    mul_ln1118_1235_fu_107082_p00 = esl_zext<12,10>(trunc_ln77_793_reg_139346.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1235_fu_107082_p1() {
    mul_ln1118_1235_fu_107082_p1 = tmp_1783_reg_139351.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1235_fu_107082_p2() {
    mul_ln1118_1235_fu_107082_p2 = (!mul_ln1118_1235_fu_107082_p0.read().is_01() || !mul_ln1118_1235_fu_107082_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1235_fu_107082_p0.read()) * sc_bigint<2>(mul_ln1118_1235_fu_107082_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1236_fu_107106_p0() {
    mul_ln1118_1236_fu_107106_p0 =  (sc_lv<10>) (mul_ln1118_1236_fu_107106_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1236_fu_107106_p00() {
    mul_ln1118_1236_fu_107106_p00 = esl_zext<12,10>(trunc_ln77_794_reg_139356.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1236_fu_107106_p1() {
    mul_ln1118_1236_fu_107106_p1 = tmp_1785_reg_139361.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1236_fu_107106_p2() {
    mul_ln1118_1236_fu_107106_p2 = (!mul_ln1118_1236_fu_107106_p0.read().is_01() || !mul_ln1118_1236_fu_107106_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1236_fu_107106_p0.read()) * sc_bigint<2>(mul_ln1118_1236_fu_107106_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1237_fu_107130_p0() {
    mul_ln1118_1237_fu_107130_p0 =  (sc_lv<10>) (mul_ln1118_1237_fu_107130_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1237_fu_107130_p00() {
    mul_ln1118_1237_fu_107130_p00 = esl_zext<12,10>(trunc_ln77_795_reg_139366.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1237_fu_107130_p1() {
    mul_ln1118_1237_fu_107130_p1 = tmp_1787_reg_139371.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1237_fu_107130_p2() {
    mul_ln1118_1237_fu_107130_p2 = (!mul_ln1118_1237_fu_107130_p0.read().is_01() || !mul_ln1118_1237_fu_107130_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1237_fu_107130_p0.read()) * sc_bigint<2>(mul_ln1118_1237_fu_107130_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1238_fu_107142_p0() {
    mul_ln1118_1238_fu_107142_p0 =  (sc_lv<10>) (mul_ln1118_1238_fu_107142_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1238_fu_107142_p00() {
    mul_ln1118_1238_fu_107142_p00 = esl_zext<12,10>(trunc_ln77_796_reg_139376.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1238_fu_107142_p1() {
    mul_ln1118_1238_fu_107142_p1 = tmp_1789_reg_139381.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1238_fu_107142_p2() {
    mul_ln1118_1238_fu_107142_p2 = (!mul_ln1118_1238_fu_107142_p0.read().is_01() || !mul_ln1118_1238_fu_107142_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1238_fu_107142_p0.read()) * sc_bigint<2>(mul_ln1118_1238_fu_107142_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1239_fu_107166_p0() {
    mul_ln1118_1239_fu_107166_p0 =  (sc_lv<10>) (mul_ln1118_1239_fu_107166_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1239_fu_107166_p00() {
    mul_ln1118_1239_fu_107166_p00 = esl_zext<12,10>(trunc_ln77_797_reg_139386.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1239_fu_107166_p1() {
    mul_ln1118_1239_fu_107166_p1 = tmp_1791_reg_139391.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1239_fu_107166_p2() {
    mul_ln1118_1239_fu_107166_p2 = (!mul_ln1118_1239_fu_107166_p0.read().is_01() || !mul_ln1118_1239_fu_107166_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1239_fu_107166_p0.read()) * sc_bigint<2>(mul_ln1118_1239_fu_107166_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_123_fu_82395_p0() {
    mul_ln1118_123_fu_82395_p0 =  (sc_lv<10>) (zext_ln1116_122_fu_82389_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_123_fu_82395_p1() {
    mul_ln1118_123_fu_82395_p1 = tmp_239_reg_130461.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_123_fu_82395_p2() {
    mul_ln1118_123_fu_82395_p2 = (!mul_ln1118_123_fu_82395_p0.read().is_01() || !mul_ln1118_123_fu_82395_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_123_fu_82395_p0.read()) * sc_bigint<2>(mul_ln1118_123_fu_82395_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1240_fu_107190_p0() {
    mul_ln1118_1240_fu_107190_p0 =  (sc_lv<10>) (mul_ln1118_1240_fu_107190_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1240_fu_107190_p00() {
    mul_ln1118_1240_fu_107190_p00 = esl_zext<12,10>(trunc_ln77_798_reg_139396.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1240_fu_107190_p1() {
    mul_ln1118_1240_fu_107190_p1 = tmp_1793_reg_139401.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1240_fu_107190_p2() {
    mul_ln1118_1240_fu_107190_p2 = (!mul_ln1118_1240_fu_107190_p0.read().is_01() || !mul_ln1118_1240_fu_107190_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1240_fu_107190_p0.read()) * sc_bigint<2>(mul_ln1118_1240_fu_107190_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1241_fu_107202_p0() {
    mul_ln1118_1241_fu_107202_p0 =  (sc_lv<10>) (mul_ln1118_1241_fu_107202_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1241_fu_107202_p00() {
    mul_ln1118_1241_fu_107202_p00 = esl_zext<12,10>(trunc_ln77_799_reg_139406.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1241_fu_107202_p1() {
    mul_ln1118_1241_fu_107202_p1 = tmp_1795_reg_139411.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1241_fu_107202_p2() {
    mul_ln1118_1241_fu_107202_p2 = (!mul_ln1118_1241_fu_107202_p0.read().is_01() || !mul_ln1118_1241_fu_107202_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1241_fu_107202_p0.read()) * sc_bigint<2>(mul_ln1118_1241_fu_107202_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1242_fu_107226_p0() {
    mul_ln1118_1242_fu_107226_p0 =  (sc_lv<10>) (mul_ln1118_1242_fu_107226_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1242_fu_107226_p00() {
    mul_ln1118_1242_fu_107226_p00 = esl_zext<12,10>(trunc_ln77_800_reg_139416.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1242_fu_107226_p1() {
    mul_ln1118_1242_fu_107226_p1 = tmp_1797_reg_139421.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1242_fu_107226_p2() {
    mul_ln1118_1242_fu_107226_p2 = (!mul_ln1118_1242_fu_107226_p0.read().is_01() || !mul_ln1118_1242_fu_107226_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1242_fu_107226_p0.read()) * sc_bigint<2>(mul_ln1118_1242_fu_107226_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1243_fu_107250_p0() {
    mul_ln1118_1243_fu_107250_p0 =  (sc_lv<10>) (mul_ln1118_1243_fu_107250_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1243_fu_107250_p00() {
    mul_ln1118_1243_fu_107250_p00 = esl_zext<12,10>(trunc_ln77_801_reg_139426.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1243_fu_107250_p1() {
    mul_ln1118_1243_fu_107250_p1 = tmp_1799_reg_139431.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1243_fu_107250_p2() {
    mul_ln1118_1243_fu_107250_p2 = (!mul_ln1118_1243_fu_107250_p0.read().is_01() || !mul_ln1118_1243_fu_107250_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1243_fu_107250_p0.read()) * sc_bigint<2>(mul_ln1118_1243_fu_107250_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1244_fu_107274_p0() {
    mul_ln1118_1244_fu_107274_p0 =  (sc_lv<10>) (mul_ln1118_1244_fu_107274_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1244_fu_107274_p00() {
    mul_ln1118_1244_fu_107274_p00 = esl_zext<12,10>(trunc_ln77_802_reg_139436.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1244_fu_107274_p1() {
    mul_ln1118_1244_fu_107274_p1 = tmp_1801_reg_139441.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1244_fu_107274_p2() {
    mul_ln1118_1244_fu_107274_p2 = (!mul_ln1118_1244_fu_107274_p0.read().is_01() || !mul_ln1118_1244_fu_107274_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1244_fu_107274_p0.read()) * sc_bigint<2>(mul_ln1118_1244_fu_107274_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1245_fu_107298_p0() {
    mul_ln1118_1245_fu_107298_p0 =  (sc_lv<10>) (mul_ln1118_1245_fu_107298_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1245_fu_107298_p00() {
    mul_ln1118_1245_fu_107298_p00 = esl_zext<12,10>(trunc_ln77_803_reg_139446.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1245_fu_107298_p1() {
    mul_ln1118_1245_fu_107298_p1 = tmp_1803_reg_139451.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1245_fu_107298_p2() {
    mul_ln1118_1245_fu_107298_p2 = (!mul_ln1118_1245_fu_107298_p0.read().is_01() || !mul_ln1118_1245_fu_107298_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1245_fu_107298_p0.read()) * sc_bigint<2>(mul_ln1118_1245_fu_107298_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1246_fu_107310_p0() {
    mul_ln1118_1246_fu_107310_p0 =  (sc_lv<10>) (mul_ln1118_1246_fu_107310_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1246_fu_107310_p00() {
    mul_ln1118_1246_fu_107310_p00 = esl_zext<12,10>(trunc_ln77_804_reg_139456.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1246_fu_107310_p1() {
    mul_ln1118_1246_fu_107310_p1 = tmp_1805_reg_139461.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1246_fu_107310_p2() {
    mul_ln1118_1246_fu_107310_p2 = (!mul_ln1118_1246_fu_107310_p0.read().is_01() || !mul_ln1118_1246_fu_107310_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1246_fu_107310_p0.read()) * sc_bigint<2>(mul_ln1118_1246_fu_107310_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1247_fu_107334_p0() {
    mul_ln1118_1247_fu_107334_p0 =  (sc_lv<10>) (mul_ln1118_1247_fu_107334_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1247_fu_107334_p00() {
    mul_ln1118_1247_fu_107334_p00 = esl_zext<12,10>(trunc_ln77_805_reg_139466.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1247_fu_107334_p1() {
    mul_ln1118_1247_fu_107334_p1 = tmp_1807_reg_139471.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1247_fu_107334_p2() {
    mul_ln1118_1247_fu_107334_p2 = (!mul_ln1118_1247_fu_107334_p0.read().is_01() || !mul_ln1118_1247_fu_107334_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1247_fu_107334_p0.read()) * sc_bigint<2>(mul_ln1118_1247_fu_107334_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1248_fu_107358_p0() {
    mul_ln1118_1248_fu_107358_p0 =  (sc_lv<10>) (mul_ln1118_1248_fu_107358_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1248_fu_107358_p00() {
    mul_ln1118_1248_fu_107358_p00 = esl_zext<12,10>(trunc_ln77_806_reg_139476.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1248_fu_107358_p1() {
    mul_ln1118_1248_fu_107358_p1 = tmp_1808_reg_139481.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1248_fu_107358_p2() {
    mul_ln1118_1248_fu_107358_p2 = (!mul_ln1118_1248_fu_107358_p0.read().is_01() || !mul_ln1118_1248_fu_107358_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1248_fu_107358_p0.read()) * sc_bigint<2>(mul_ln1118_1248_fu_107358_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1249_fu_107382_p0() {
    mul_ln1118_1249_fu_107382_p0 =  (sc_lv<10>) (mul_ln1118_1249_fu_107382_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1249_fu_107382_p00() {
    mul_ln1118_1249_fu_107382_p00 = esl_zext<12,10>(trunc_ln77_807_reg_139486.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1249_fu_107382_p1() {
    mul_ln1118_1249_fu_107382_p1 = tmp_1809_reg_139491.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1249_fu_107382_p2() {
    mul_ln1118_1249_fu_107382_p2 = (!mul_ln1118_1249_fu_107382_p0.read().is_01() || !mul_ln1118_1249_fu_107382_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1249_fu_107382_p0.read()) * sc_bigint<2>(mul_ln1118_1249_fu_107382_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_124_fu_82419_p0() {
    mul_ln1118_124_fu_82419_p0 =  (sc_lv<10>) (zext_ln1116_123_fu_82413_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_124_fu_82419_p1() {
    mul_ln1118_124_fu_82419_p1 = tmp_241_reg_130471.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_124_fu_82419_p2() {
    mul_ln1118_124_fu_82419_p2 = (!mul_ln1118_124_fu_82419_p0.read().is_01() || !mul_ln1118_124_fu_82419_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_124_fu_82419_p0.read()) * sc_bigint<2>(mul_ln1118_124_fu_82419_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1250_fu_107406_p0() {
    mul_ln1118_1250_fu_107406_p0 =  (sc_lv<10>) (mul_ln1118_1250_fu_107406_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1250_fu_107406_p00() {
    mul_ln1118_1250_fu_107406_p00 = esl_zext<12,10>(trunc_ln77_808_reg_139496.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1250_fu_107406_p1() {
    mul_ln1118_1250_fu_107406_p1 = tmp_1810_reg_139501.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1250_fu_107406_p2() {
    mul_ln1118_1250_fu_107406_p2 = (!mul_ln1118_1250_fu_107406_p0.read().is_01() || !mul_ln1118_1250_fu_107406_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1250_fu_107406_p0.read()) * sc_bigint<2>(mul_ln1118_1250_fu_107406_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1251_fu_107418_p0() {
    mul_ln1118_1251_fu_107418_p0 =  (sc_lv<10>) (mul_ln1118_1251_fu_107418_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1251_fu_107418_p00() {
    mul_ln1118_1251_fu_107418_p00 = esl_zext<12,10>(trunc_ln77_809_reg_139506.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1251_fu_107418_p1() {
    mul_ln1118_1251_fu_107418_p1 = tmp_1811_reg_139511.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1251_fu_107418_p2() {
    mul_ln1118_1251_fu_107418_p2 = (!mul_ln1118_1251_fu_107418_p0.read().is_01() || !mul_ln1118_1251_fu_107418_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1251_fu_107418_p0.read()) * sc_bigint<2>(mul_ln1118_1251_fu_107418_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1252_fu_107442_p0() {
    mul_ln1118_1252_fu_107442_p0 =  (sc_lv<10>) (mul_ln1118_1252_fu_107442_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1252_fu_107442_p00() {
    mul_ln1118_1252_fu_107442_p00 = esl_zext<12,10>(trunc_ln77_810_reg_139516.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1252_fu_107442_p1() {
    mul_ln1118_1252_fu_107442_p1 = tmp_1812_reg_139521.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1252_fu_107442_p2() {
    mul_ln1118_1252_fu_107442_p2 = (!mul_ln1118_1252_fu_107442_p0.read().is_01() || !mul_ln1118_1252_fu_107442_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1252_fu_107442_p0.read()) * sc_bigint<2>(mul_ln1118_1252_fu_107442_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1253_fu_107466_p0() {
    mul_ln1118_1253_fu_107466_p0 =  (sc_lv<10>) (mul_ln1118_1253_fu_107466_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1253_fu_107466_p00() {
    mul_ln1118_1253_fu_107466_p00 = esl_zext<12,10>(trunc_ln77_811_reg_139526.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1253_fu_107466_p1() {
    mul_ln1118_1253_fu_107466_p1 = tmp_1813_reg_139531.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1253_fu_107466_p2() {
    mul_ln1118_1253_fu_107466_p2 = (!mul_ln1118_1253_fu_107466_p0.read().is_01() || !mul_ln1118_1253_fu_107466_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1253_fu_107466_p0.read()) * sc_bigint<2>(mul_ln1118_1253_fu_107466_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1254_fu_107490_p0() {
    mul_ln1118_1254_fu_107490_p0 =  (sc_lv<10>) (mul_ln1118_1254_fu_107490_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1254_fu_107490_p00() {
    mul_ln1118_1254_fu_107490_p00 = esl_zext<12,10>(trunc_ln77_812_reg_139536.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1254_fu_107490_p1() {
    mul_ln1118_1254_fu_107490_p1 = tmp_1814_reg_139541.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1254_fu_107490_p2() {
    mul_ln1118_1254_fu_107490_p2 = (!mul_ln1118_1254_fu_107490_p0.read().is_01() || !mul_ln1118_1254_fu_107490_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1254_fu_107490_p0.read()) * sc_bigint<2>(mul_ln1118_1254_fu_107490_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1255_fu_107514_p0() {
    mul_ln1118_1255_fu_107514_p0 =  (sc_lv<10>) (mul_ln1118_1255_fu_107514_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1255_fu_107514_p00() {
    mul_ln1118_1255_fu_107514_p00 = esl_zext<12,10>(trunc_ln77_813_reg_139546.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1255_fu_107514_p1() {
    mul_ln1118_1255_fu_107514_p1 = tmp_1815_reg_139551.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1255_fu_107514_p2() {
    mul_ln1118_1255_fu_107514_p2 = (!mul_ln1118_1255_fu_107514_p0.read().is_01() || !mul_ln1118_1255_fu_107514_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1255_fu_107514_p0.read()) * sc_bigint<2>(mul_ln1118_1255_fu_107514_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1256_fu_107526_p0() {
    mul_ln1118_1256_fu_107526_p0 =  (sc_lv<10>) (mul_ln1118_1256_fu_107526_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1256_fu_107526_p00() {
    mul_ln1118_1256_fu_107526_p00 = esl_zext<12,10>(trunc_ln77_814_reg_139556.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1256_fu_107526_p1() {
    mul_ln1118_1256_fu_107526_p1 = tmp_1816_reg_139561.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1256_fu_107526_p2() {
    mul_ln1118_1256_fu_107526_p2 = (!mul_ln1118_1256_fu_107526_p0.read().is_01() || !mul_ln1118_1256_fu_107526_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1256_fu_107526_p0.read()) * sc_bigint<2>(mul_ln1118_1256_fu_107526_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1257_fu_107550_p0() {
    mul_ln1118_1257_fu_107550_p0 =  (sc_lv<10>) (mul_ln1118_1257_fu_107550_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1257_fu_107550_p00() {
    mul_ln1118_1257_fu_107550_p00 = esl_zext<12,10>(trunc_ln77_815_reg_139566.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1257_fu_107550_p1() {
    mul_ln1118_1257_fu_107550_p1 = tmp_1817_reg_139571.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1257_fu_107550_p2() {
    mul_ln1118_1257_fu_107550_p2 = (!mul_ln1118_1257_fu_107550_p0.read().is_01() || !mul_ln1118_1257_fu_107550_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1257_fu_107550_p0.read()) * sc_bigint<2>(mul_ln1118_1257_fu_107550_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1258_fu_107574_p0() {
    mul_ln1118_1258_fu_107574_p0 =  (sc_lv<10>) (mul_ln1118_1258_fu_107574_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1258_fu_107574_p00() {
    mul_ln1118_1258_fu_107574_p00 = esl_zext<12,10>(trunc_ln77_816_reg_139576.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1258_fu_107574_p1() {
    mul_ln1118_1258_fu_107574_p1 = tmp_1818_reg_139581.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1258_fu_107574_p2() {
    mul_ln1118_1258_fu_107574_p2 = (!mul_ln1118_1258_fu_107574_p0.read().is_01() || !mul_ln1118_1258_fu_107574_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1258_fu_107574_p0.read()) * sc_bigint<2>(mul_ln1118_1258_fu_107574_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1259_fu_107586_p0() {
    mul_ln1118_1259_fu_107586_p0 =  (sc_lv<10>) (mul_ln1118_1259_fu_107586_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1259_fu_107586_p00() {
    mul_ln1118_1259_fu_107586_p00 = esl_zext<12,10>(trunc_ln77_817_reg_139586.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1259_fu_107586_p1() {
    mul_ln1118_1259_fu_107586_p1 = tmp_1819_reg_139591.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1259_fu_107586_p2() {
    mul_ln1118_1259_fu_107586_p2 = (!mul_ln1118_1259_fu_107586_p0.read().is_01() || !mul_ln1118_1259_fu_107586_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1259_fu_107586_p0.read()) * sc_bigint<2>(mul_ln1118_1259_fu_107586_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_125_fu_82431_p0() {
    mul_ln1118_125_fu_82431_p0 =  (sc_lv<10>) (zext_ln1116_124_fu_82425_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_125_fu_82431_p1() {
    mul_ln1118_125_fu_82431_p1 = tmp_243_reg_130481.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_125_fu_82431_p2() {
    mul_ln1118_125_fu_82431_p2 = (!mul_ln1118_125_fu_82431_p0.read().is_01() || !mul_ln1118_125_fu_82431_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_125_fu_82431_p0.read()) * sc_bigint<2>(mul_ln1118_125_fu_82431_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1260_fu_107610_p0() {
    mul_ln1118_1260_fu_107610_p0 =  (sc_lv<10>) (mul_ln1118_1260_fu_107610_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1260_fu_107610_p00() {
    mul_ln1118_1260_fu_107610_p00 = esl_zext<12,10>(trunc_ln77_818_reg_139596.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1260_fu_107610_p1() {
    mul_ln1118_1260_fu_107610_p1 = tmp_1820_reg_139601.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1260_fu_107610_p2() {
    mul_ln1118_1260_fu_107610_p2 = (!mul_ln1118_1260_fu_107610_p0.read().is_01() || !mul_ln1118_1260_fu_107610_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1260_fu_107610_p0.read()) * sc_bigint<2>(mul_ln1118_1260_fu_107610_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1261_fu_107634_p0() {
    mul_ln1118_1261_fu_107634_p0 =  (sc_lv<10>) (mul_ln1118_1261_fu_107634_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1261_fu_107634_p00() {
    mul_ln1118_1261_fu_107634_p00 = esl_zext<12,10>(trunc_ln77_819_reg_139606.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1261_fu_107634_p1() {
    mul_ln1118_1261_fu_107634_p1 = tmp_1821_reg_139611.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1261_fu_107634_p2() {
    mul_ln1118_1261_fu_107634_p2 = (!mul_ln1118_1261_fu_107634_p0.read().is_01() || !mul_ln1118_1261_fu_107634_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1261_fu_107634_p0.read()) * sc_bigint<2>(mul_ln1118_1261_fu_107634_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1262_fu_107646_p0() {
    mul_ln1118_1262_fu_107646_p0 =  (sc_lv<10>) (mul_ln1118_1262_fu_107646_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1262_fu_107646_p00() {
    mul_ln1118_1262_fu_107646_p00 = esl_zext<12,10>(trunc_ln77_820_reg_139616.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1262_fu_107646_p1() {
    mul_ln1118_1262_fu_107646_p1 = tmp_1822_reg_139621.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1262_fu_107646_p2() {
    mul_ln1118_1262_fu_107646_p2 = (!mul_ln1118_1262_fu_107646_p0.read().is_01() || !mul_ln1118_1262_fu_107646_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1262_fu_107646_p0.read()) * sc_bigint<2>(mul_ln1118_1262_fu_107646_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1263_fu_107670_p0() {
    mul_ln1118_1263_fu_107670_p0 =  (sc_lv<10>) (mul_ln1118_1263_fu_107670_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1263_fu_107670_p00() {
    mul_ln1118_1263_fu_107670_p00 = esl_zext<12,10>(trunc_ln77_821_reg_139626.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1263_fu_107670_p1() {
    mul_ln1118_1263_fu_107670_p1 = tmp_1823_reg_139631.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1263_fu_107670_p2() {
    mul_ln1118_1263_fu_107670_p2 = (!mul_ln1118_1263_fu_107670_p0.read().is_01() || !mul_ln1118_1263_fu_107670_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1263_fu_107670_p0.read()) * sc_bigint<2>(mul_ln1118_1263_fu_107670_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_126_fu_82455_p0() {
    mul_ln1118_126_fu_82455_p0 =  (sc_lv<10>) (zext_ln1116_125_fu_82449_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_126_fu_82455_p1() {
    mul_ln1118_126_fu_82455_p1 = tmp_245_reg_130491.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_126_fu_82455_p2() {
    mul_ln1118_126_fu_82455_p2 = (!mul_ln1118_126_fu_82455_p0.read().is_01() || !mul_ln1118_126_fu_82455_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_126_fu_82455_p0.read()) * sc_bigint<2>(mul_ln1118_126_fu_82455_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_127_fu_82479_p0() {
    mul_ln1118_127_fu_82479_p0 =  (sc_lv<10>) (zext_ln1116_126_fu_82473_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_127_fu_82479_p1() {
    mul_ln1118_127_fu_82479_p1 = tmp_247_reg_130501.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_127_fu_82479_p2() {
    mul_ln1118_127_fu_82479_p2 = (!mul_ln1118_127_fu_82479_p0.read().is_01() || !mul_ln1118_127_fu_82479_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_127_fu_82479_p0.read()) * sc_bigint<2>(mul_ln1118_127_fu_82479_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_128_fu_82491_p0() {
    mul_ln1118_128_fu_82491_p0 =  (sc_lv<10>) (zext_ln1116_127_fu_82485_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_128_fu_82491_p1() {
    mul_ln1118_128_fu_82491_p1 = tmp_249_reg_130511.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_128_fu_82491_p2() {
    mul_ln1118_128_fu_82491_p2 = (!mul_ln1118_128_fu_82491_p0.read().is_01() || !mul_ln1118_128_fu_82491_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_128_fu_82491_p0.read()) * sc_bigint<2>(mul_ln1118_128_fu_82491_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_129_fu_82515_p0() {
    mul_ln1118_129_fu_82515_p0 =  (sc_lv<10>) (zext_ln1116_128_fu_82509_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_129_fu_82515_p1() {
    mul_ln1118_129_fu_82515_p1 = tmp_251_reg_130521.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_129_fu_82515_p2() {
    mul_ln1118_129_fu_82515_p2 = (!mul_ln1118_129_fu_82515_p0.read().is_01() || !mul_ln1118_129_fu_82515_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_129_fu_82515_p0.read()) * sc_bigint<2>(mul_ln1118_129_fu_82515_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_12_fu_79851_p0() {
    mul_ln1118_12_fu_79851_p0 =  (sc_lv<10>) (mul_ln1118_12_fu_79851_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_12_fu_79851_p00() {
    mul_ln1118_12_fu_79851_p00 = esl_zext<12,10>(trunc_ln77_9_reg_129351.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_12_fu_79851_p1() {
    mul_ln1118_12_fu_79851_p1 = tmp_17_reg_129356.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_12_fu_79851_p2() {
    mul_ln1118_12_fu_79851_p2 = (!mul_ln1118_12_fu_79851_p0.read().is_01() || !mul_ln1118_12_fu_79851_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_12_fu_79851_p0.read()) * sc_bigint<2>(mul_ln1118_12_fu_79851_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_130_fu_82539_p0() {
    mul_ln1118_130_fu_82539_p0 =  (sc_lv<10>) (zext_ln1116_129_fu_82533_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_130_fu_82539_p1() {
    mul_ln1118_130_fu_82539_p1 = tmp_253_reg_130531.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_130_fu_82539_p2() {
    mul_ln1118_130_fu_82539_p2 = (!mul_ln1118_130_fu_82539_p0.read().is_01() || !mul_ln1118_130_fu_82539_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_130_fu_82539_p0.read()) * sc_bigint<2>(mul_ln1118_130_fu_82539_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_131_fu_82563_p0() {
    mul_ln1118_131_fu_82563_p0 =  (sc_lv<10>) (zext_ln1116_130_fu_82557_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_131_fu_82563_p1() {
    mul_ln1118_131_fu_82563_p1 = tmp_255_reg_130541.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_131_fu_82563_p2() {
    mul_ln1118_131_fu_82563_p2 = (!mul_ln1118_131_fu_82563_p0.read().is_01() || !mul_ln1118_131_fu_82563_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_131_fu_82563_p0.read()) * sc_bigint<2>(mul_ln1118_131_fu_82563_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_132_fu_82587_p0() {
    mul_ln1118_132_fu_82587_p0 =  (sc_lv<10>) (zext_ln1116_131_fu_82581_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_132_fu_82587_p1() {
    mul_ln1118_132_fu_82587_p1 = tmp_257_reg_130551.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_132_fu_82587_p2() {
    mul_ln1118_132_fu_82587_p2 = (!mul_ln1118_132_fu_82587_p0.read().is_01() || !mul_ln1118_132_fu_82587_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_132_fu_82587_p0.read()) * sc_bigint<2>(mul_ln1118_132_fu_82587_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_133_fu_82599_p0() {
    mul_ln1118_133_fu_82599_p0 =  (sc_lv<10>) (zext_ln1116_132_fu_82593_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_133_fu_82599_p1() {
    mul_ln1118_133_fu_82599_p1 = tmp_259_reg_130561.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_133_fu_82599_p2() {
    mul_ln1118_133_fu_82599_p2 = (!mul_ln1118_133_fu_82599_p0.read().is_01() || !mul_ln1118_133_fu_82599_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_133_fu_82599_p0.read()) * sc_bigint<2>(mul_ln1118_133_fu_82599_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_134_fu_82623_p0() {
    mul_ln1118_134_fu_82623_p0 =  (sc_lv<10>) (zext_ln1116_133_fu_82617_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_134_fu_82623_p1() {
    mul_ln1118_134_fu_82623_p1 = tmp_261_reg_130571.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_134_fu_82623_p2() {
    mul_ln1118_134_fu_82623_p2 = (!mul_ln1118_134_fu_82623_p0.read().is_01() || !mul_ln1118_134_fu_82623_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_134_fu_82623_p0.read()) * sc_bigint<2>(mul_ln1118_134_fu_82623_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_135_fu_82647_p0() {
    mul_ln1118_135_fu_82647_p0 =  (sc_lv<10>) (zext_ln1116_134_fu_82641_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_135_fu_82647_p1() {
    mul_ln1118_135_fu_82647_p1 = tmp_263_reg_130581.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_135_fu_82647_p2() {
    mul_ln1118_135_fu_82647_p2 = (!mul_ln1118_135_fu_82647_p0.read().is_01() || !mul_ln1118_135_fu_82647_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_135_fu_82647_p0.read()) * sc_bigint<2>(mul_ln1118_135_fu_82647_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_136_fu_82671_p0() {
    mul_ln1118_136_fu_82671_p0 =  (sc_lv<10>) (zext_ln1116_135_fu_82665_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_136_fu_82671_p1() {
    mul_ln1118_136_fu_82671_p1 = tmp_265_reg_130591.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_136_fu_82671_p2() {
    mul_ln1118_136_fu_82671_p2 = (!mul_ln1118_136_fu_82671_p0.read().is_01() || !mul_ln1118_136_fu_82671_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_136_fu_82671_p0.read()) * sc_bigint<2>(mul_ln1118_136_fu_82671_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_137_fu_82695_p0() {
    mul_ln1118_137_fu_82695_p0 =  (sc_lv<10>) (zext_ln1116_136_fu_82689_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_137_fu_82695_p1() {
    mul_ln1118_137_fu_82695_p1 = tmp_267_reg_130601.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_137_fu_82695_p2() {
    mul_ln1118_137_fu_82695_p2 = (!mul_ln1118_137_fu_82695_p0.read().is_01() || !mul_ln1118_137_fu_82695_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_137_fu_82695_p0.read()) * sc_bigint<2>(mul_ln1118_137_fu_82695_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_138_fu_82707_p0() {
    mul_ln1118_138_fu_82707_p0 =  (sc_lv<10>) (zext_ln1116_137_fu_82701_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_138_fu_82707_p1() {
    mul_ln1118_138_fu_82707_p1 = tmp_269_reg_130611.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_138_fu_82707_p2() {
    mul_ln1118_138_fu_82707_p2 = (!mul_ln1118_138_fu_82707_p0.read().is_01() || !mul_ln1118_138_fu_82707_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_138_fu_82707_p0.read()) * sc_bigint<2>(mul_ln1118_138_fu_82707_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_139_fu_82731_p0() {
    mul_ln1118_139_fu_82731_p0 =  (sc_lv<10>) (zext_ln1116_138_fu_82725_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_139_fu_82731_p1() {
    mul_ln1118_139_fu_82731_p1 = tmp_271_reg_130621.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_139_fu_82731_p2() {
    mul_ln1118_139_fu_82731_p2 = (!mul_ln1118_139_fu_82731_p0.read().is_01() || !mul_ln1118_139_fu_82731_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_139_fu_82731_p0.read()) * sc_bigint<2>(mul_ln1118_139_fu_82731_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_13_fu_79875_p0() {
    mul_ln1118_13_fu_79875_p0 =  (sc_lv<10>) (mul_ln1118_13_fu_79875_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_13_fu_79875_p00() {
    mul_ln1118_13_fu_79875_p00 = esl_zext<12,10>(trunc_ln77_10_reg_129361.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_13_fu_79875_p1() {
    mul_ln1118_13_fu_79875_p1 = tmp_19_reg_129366.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_13_fu_79875_p2() {
    mul_ln1118_13_fu_79875_p2 = (!mul_ln1118_13_fu_79875_p0.read().is_01() || !mul_ln1118_13_fu_79875_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_13_fu_79875_p0.read()) * sc_bigint<2>(mul_ln1118_13_fu_79875_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_140_fu_82755_p0() {
    mul_ln1118_140_fu_82755_p0 =  (sc_lv<10>) (zext_ln1116_139_fu_82749_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_140_fu_82755_p1() {
    mul_ln1118_140_fu_82755_p1 = tmp_273_reg_130631.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_140_fu_82755_p2() {
    mul_ln1118_140_fu_82755_p2 = (!mul_ln1118_140_fu_82755_p0.read().is_01() || !mul_ln1118_140_fu_82755_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_140_fu_82755_p0.read()) * sc_bigint<2>(mul_ln1118_140_fu_82755_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_141_fu_82779_p0() {
    mul_ln1118_141_fu_82779_p0 =  (sc_lv<10>) (mul_ln1118_141_fu_82779_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_141_fu_82779_p00() {
    mul_ln1118_141_fu_82779_p00 = esl_zext<12,10>(trunc_ln77_138_reg_130636.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_141_fu_82779_p1() {
    mul_ln1118_141_fu_82779_p1 = tmp_275_reg_130641.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_141_fu_82779_p2() {
    mul_ln1118_141_fu_82779_p2 = (!mul_ln1118_141_fu_82779_p0.read().is_01() || !mul_ln1118_141_fu_82779_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_141_fu_82779_p0.read()) * sc_bigint<2>(mul_ln1118_141_fu_82779_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_142_fu_82803_p0() {
    mul_ln1118_142_fu_82803_p0 =  (sc_lv<10>) (mul_ln1118_142_fu_82803_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_142_fu_82803_p00() {
    mul_ln1118_142_fu_82803_p00 = esl_zext<12,10>(trunc_ln77_139_reg_130646.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_142_fu_82803_p1() {
    mul_ln1118_142_fu_82803_p1 = tmp_277_reg_130651.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_142_fu_82803_p2() {
    mul_ln1118_142_fu_82803_p2 = (!mul_ln1118_142_fu_82803_p0.read().is_01() || !mul_ln1118_142_fu_82803_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_142_fu_82803_p0.read()) * sc_bigint<2>(mul_ln1118_142_fu_82803_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_143_fu_82815_p0() {
    mul_ln1118_143_fu_82815_p0 =  (sc_lv<10>) (mul_ln1118_143_fu_82815_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_143_fu_82815_p00() {
    mul_ln1118_143_fu_82815_p00 = esl_zext<12,10>(trunc_ln77_140_reg_130656.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_143_fu_82815_p1() {
    mul_ln1118_143_fu_82815_p1 = tmp_279_reg_130661.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_143_fu_82815_p2() {
    mul_ln1118_143_fu_82815_p2 = (!mul_ln1118_143_fu_82815_p0.read().is_01() || !mul_ln1118_143_fu_82815_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_143_fu_82815_p0.read()) * sc_bigint<2>(mul_ln1118_143_fu_82815_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_144_fu_82839_p0() {
    mul_ln1118_144_fu_82839_p0 =  (sc_lv<10>) (mul_ln1118_144_fu_82839_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_144_fu_82839_p00() {
    mul_ln1118_144_fu_82839_p00 = esl_zext<12,10>(trunc_ln77_141_reg_130666.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_144_fu_82839_p1() {
    mul_ln1118_144_fu_82839_p1 = tmp_281_reg_130671.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_144_fu_82839_p2() {
    mul_ln1118_144_fu_82839_p2 = (!mul_ln1118_144_fu_82839_p0.read().is_01() || !mul_ln1118_144_fu_82839_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_144_fu_82839_p0.read()) * sc_bigint<2>(mul_ln1118_144_fu_82839_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_145_fu_82863_p0() {
    mul_ln1118_145_fu_82863_p0 =  (sc_lv<10>) (mul_ln1118_145_fu_82863_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_145_fu_82863_p00() {
    mul_ln1118_145_fu_82863_p00 = esl_zext<12,10>(trunc_ln77_142_reg_130676.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_145_fu_82863_p1() {
    mul_ln1118_145_fu_82863_p1 = tmp_283_reg_130681.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_145_fu_82863_p2() {
    mul_ln1118_145_fu_82863_p2 = (!mul_ln1118_145_fu_82863_p0.read().is_01() || !mul_ln1118_145_fu_82863_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_145_fu_82863_p0.read()) * sc_bigint<2>(mul_ln1118_145_fu_82863_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_146_fu_82875_p0() {
    mul_ln1118_146_fu_82875_p0 =  (sc_lv<10>) (mul_ln1118_146_fu_82875_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_146_fu_82875_p00() {
    mul_ln1118_146_fu_82875_p00 = esl_zext<12,10>(trunc_ln77_143_reg_130686.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_146_fu_82875_p1() {
    mul_ln1118_146_fu_82875_p1 = tmp_285_reg_130691.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_146_fu_82875_p2() {
    mul_ln1118_146_fu_82875_p2 = (!mul_ln1118_146_fu_82875_p0.read().is_01() || !mul_ln1118_146_fu_82875_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_146_fu_82875_p0.read()) * sc_bigint<2>(mul_ln1118_146_fu_82875_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_147_fu_82899_p0() {
    mul_ln1118_147_fu_82899_p0 =  (sc_lv<10>) (mul_ln1118_147_fu_82899_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_147_fu_82899_p00() {
    mul_ln1118_147_fu_82899_p00 = esl_zext<12,10>(trunc_ln77_144_reg_130696.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_147_fu_82899_p1() {
    mul_ln1118_147_fu_82899_p1 = tmp_287_reg_130701.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_147_fu_82899_p2() {
    mul_ln1118_147_fu_82899_p2 = (!mul_ln1118_147_fu_82899_p0.read().is_01() || !mul_ln1118_147_fu_82899_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_147_fu_82899_p0.read()) * sc_bigint<2>(mul_ln1118_147_fu_82899_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_148_fu_82923_p0() {
    mul_ln1118_148_fu_82923_p0 =  (sc_lv<10>) (mul_ln1118_148_fu_82923_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_148_fu_82923_p00() {
    mul_ln1118_148_fu_82923_p00 = esl_zext<12,10>(trunc_ln77_145_reg_130706.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_148_fu_82923_p1() {
    mul_ln1118_148_fu_82923_p1 = tmp_289_reg_130711.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_148_fu_82923_p2() {
    mul_ln1118_148_fu_82923_p2 = (!mul_ln1118_148_fu_82923_p0.read().is_01() || !mul_ln1118_148_fu_82923_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_148_fu_82923_p0.read()) * sc_bigint<2>(mul_ln1118_148_fu_82923_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_149_fu_82935_p0() {
    mul_ln1118_149_fu_82935_p0 =  (sc_lv<10>) (mul_ln1118_149_fu_82935_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_149_fu_82935_p00() {
    mul_ln1118_149_fu_82935_p00 = esl_zext<12,10>(trunc_ln77_146_reg_130716.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_149_fu_82935_p1() {
    mul_ln1118_149_fu_82935_p1 = tmp_291_reg_130721.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_149_fu_82935_p2() {
    mul_ln1118_149_fu_82935_p2 = (!mul_ln1118_149_fu_82935_p0.read().is_01() || !mul_ln1118_149_fu_82935_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_149_fu_82935_p0.read()) * sc_bigint<2>(mul_ln1118_149_fu_82935_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_14_fu_79899_p0() {
    mul_ln1118_14_fu_79899_p0 =  (sc_lv<10>) (mul_ln1118_14_fu_79899_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_14_fu_79899_p00() {
    mul_ln1118_14_fu_79899_p00 = esl_zext<12,10>(trunc_ln77_11_reg_129371.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_14_fu_79899_p1() {
    mul_ln1118_14_fu_79899_p1 = tmp_21_reg_129376.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_14_fu_79899_p2() {
    mul_ln1118_14_fu_79899_p2 = (!mul_ln1118_14_fu_79899_p0.read().is_01() || !mul_ln1118_14_fu_79899_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_14_fu_79899_p0.read()) * sc_bigint<2>(mul_ln1118_14_fu_79899_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_150_fu_82959_p0() {
    mul_ln1118_150_fu_82959_p0 =  (sc_lv<10>) (mul_ln1118_150_fu_82959_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_150_fu_82959_p00() {
    mul_ln1118_150_fu_82959_p00 = esl_zext<12,10>(trunc_ln77_147_reg_130726.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_150_fu_82959_p1() {
    mul_ln1118_150_fu_82959_p1 = tmp_293_reg_130731.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_150_fu_82959_p2() {
    mul_ln1118_150_fu_82959_p2 = (!mul_ln1118_150_fu_82959_p0.read().is_01() || !mul_ln1118_150_fu_82959_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_150_fu_82959_p0.read()) * sc_bigint<2>(mul_ln1118_150_fu_82959_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_151_fu_82983_p0() {
    mul_ln1118_151_fu_82983_p0 =  (sc_lv<10>) (mul_ln1118_151_fu_82983_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_151_fu_82983_p00() {
    mul_ln1118_151_fu_82983_p00 = esl_zext<12,10>(trunc_ln77_148_reg_130736.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_151_fu_82983_p1() {
    mul_ln1118_151_fu_82983_p1 = tmp_295_reg_130741.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_151_fu_82983_p2() {
    mul_ln1118_151_fu_82983_p2 = (!mul_ln1118_151_fu_82983_p0.read().is_01() || !mul_ln1118_151_fu_82983_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_151_fu_82983_p0.read()) * sc_bigint<2>(mul_ln1118_151_fu_82983_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_152_fu_83007_p0() {
    mul_ln1118_152_fu_83007_p0 =  (sc_lv<10>) (mul_ln1118_152_fu_83007_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_152_fu_83007_p00() {
    mul_ln1118_152_fu_83007_p00 = esl_zext<12,10>(trunc_ln77_149_reg_130746.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_152_fu_83007_p1() {
    mul_ln1118_152_fu_83007_p1 = tmp_297_reg_130751.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_152_fu_83007_p2() {
    mul_ln1118_152_fu_83007_p2 = (!mul_ln1118_152_fu_83007_p0.read().is_01() || !mul_ln1118_152_fu_83007_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_152_fu_83007_p0.read()) * sc_bigint<2>(mul_ln1118_152_fu_83007_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_153_fu_83031_p0() {
    mul_ln1118_153_fu_83031_p0 =  (sc_lv<10>) (mul_ln1118_153_fu_83031_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_153_fu_83031_p00() {
    mul_ln1118_153_fu_83031_p00 = esl_zext<12,10>(trunc_ln77_150_reg_130756.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_153_fu_83031_p1() {
    mul_ln1118_153_fu_83031_p1 = tmp_299_reg_130761.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_153_fu_83031_p2() {
    mul_ln1118_153_fu_83031_p2 = (!mul_ln1118_153_fu_83031_p0.read().is_01() || !mul_ln1118_153_fu_83031_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_153_fu_83031_p0.read()) * sc_bigint<2>(mul_ln1118_153_fu_83031_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_154_fu_83043_p0() {
    mul_ln1118_154_fu_83043_p0 =  (sc_lv<10>) (mul_ln1118_154_fu_83043_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_154_fu_83043_p00() {
    mul_ln1118_154_fu_83043_p00 = esl_zext<12,10>(trunc_ln77_151_reg_130766.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_154_fu_83043_p1() {
    mul_ln1118_154_fu_83043_p1 = tmp_301_reg_130771.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_154_fu_83043_p2() {
    mul_ln1118_154_fu_83043_p2 = (!mul_ln1118_154_fu_83043_p0.read().is_01() || !mul_ln1118_154_fu_83043_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_154_fu_83043_p0.read()) * sc_bigint<2>(mul_ln1118_154_fu_83043_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_155_fu_83067_p0() {
    mul_ln1118_155_fu_83067_p0 =  (sc_lv<10>) (mul_ln1118_155_fu_83067_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_155_fu_83067_p00() {
    mul_ln1118_155_fu_83067_p00 = esl_zext<12,10>(trunc_ln77_152_reg_130776.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_155_fu_83067_p1() {
    mul_ln1118_155_fu_83067_p1 = tmp_303_reg_130781.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_155_fu_83067_p2() {
    mul_ln1118_155_fu_83067_p2 = (!mul_ln1118_155_fu_83067_p0.read().is_01() || !mul_ln1118_155_fu_83067_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_155_fu_83067_p0.read()) * sc_bigint<2>(mul_ln1118_155_fu_83067_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_156_fu_83091_p0() {
    mul_ln1118_156_fu_83091_p0 =  (sc_lv<10>) (mul_ln1118_156_fu_83091_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_156_fu_83091_p00() {
    mul_ln1118_156_fu_83091_p00 = esl_zext<12,10>(trunc_ln77_153_reg_130786.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_156_fu_83091_p1() {
    mul_ln1118_156_fu_83091_p1 = tmp_305_reg_130791.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_156_fu_83091_p2() {
    mul_ln1118_156_fu_83091_p2 = (!mul_ln1118_156_fu_83091_p0.read().is_01() || !mul_ln1118_156_fu_83091_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_156_fu_83091_p0.read()) * sc_bigint<2>(mul_ln1118_156_fu_83091_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_157_fu_83115_p0() {
    mul_ln1118_157_fu_83115_p0 =  (sc_lv<10>) (mul_ln1118_157_fu_83115_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_157_fu_83115_p00() {
    mul_ln1118_157_fu_83115_p00 = esl_zext<12,10>(trunc_ln77_154_reg_130796.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_157_fu_83115_p1() {
    mul_ln1118_157_fu_83115_p1 = tmp_307_reg_130801.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_157_fu_83115_p2() {
    mul_ln1118_157_fu_83115_p2 = (!mul_ln1118_157_fu_83115_p0.read().is_01() || !mul_ln1118_157_fu_83115_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_157_fu_83115_p0.read()) * sc_bigint<2>(mul_ln1118_157_fu_83115_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_158_fu_83139_p0() {
    mul_ln1118_158_fu_83139_p0 =  (sc_lv<10>) (mul_ln1118_158_fu_83139_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_158_fu_83139_p00() {
    mul_ln1118_158_fu_83139_p00 = esl_zext<12,10>(trunc_ln77_155_reg_130806.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_158_fu_83139_p1() {
    mul_ln1118_158_fu_83139_p1 = tmp_308_reg_130811.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_158_fu_83139_p2() {
    mul_ln1118_158_fu_83139_p2 = (!mul_ln1118_158_fu_83139_p0.read().is_01() || !mul_ln1118_158_fu_83139_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_158_fu_83139_p0.read()) * sc_bigint<2>(mul_ln1118_158_fu_83139_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_159_fu_83151_p0() {
    mul_ln1118_159_fu_83151_p0 =  (sc_lv<10>) (mul_ln1118_159_fu_83151_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_159_fu_83151_p00() {
    mul_ln1118_159_fu_83151_p00 = esl_zext<12,10>(trunc_ln77_156_reg_130816.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_159_fu_83151_p1() {
    mul_ln1118_159_fu_83151_p1 = tmp_309_reg_130821.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_159_fu_83151_p2() {
    mul_ln1118_159_fu_83151_p2 = (!mul_ln1118_159_fu_83151_p0.read().is_01() || !mul_ln1118_159_fu_83151_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_159_fu_83151_p0.read()) * sc_bigint<2>(mul_ln1118_159_fu_83151_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_15_fu_79923_p0() {
    mul_ln1118_15_fu_79923_p0 =  (sc_lv<10>) (mul_ln1118_15_fu_79923_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_15_fu_79923_p00() {
    mul_ln1118_15_fu_79923_p00 = esl_zext<12,10>(trunc_ln77_12_reg_129381.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_15_fu_79923_p1() {
    mul_ln1118_15_fu_79923_p1 = tmp_23_reg_129386.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_15_fu_79923_p2() {
    mul_ln1118_15_fu_79923_p2 = (!mul_ln1118_15_fu_79923_p0.read().is_01() || !mul_ln1118_15_fu_79923_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_15_fu_79923_p0.read()) * sc_bigint<2>(mul_ln1118_15_fu_79923_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_160_fu_83175_p0() {
    mul_ln1118_160_fu_83175_p0 =  (sc_lv<10>) (mul_ln1118_160_fu_83175_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_160_fu_83175_p00() {
    mul_ln1118_160_fu_83175_p00 = esl_zext<12,10>(trunc_ln77_157_reg_130826.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_160_fu_83175_p1() {
    mul_ln1118_160_fu_83175_p1 = tmp_310_reg_130831.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_160_fu_83175_p2() {
    mul_ln1118_160_fu_83175_p2 = (!mul_ln1118_160_fu_83175_p0.read().is_01() || !mul_ln1118_160_fu_83175_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_160_fu_83175_p0.read()) * sc_bigint<2>(mul_ln1118_160_fu_83175_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_161_fu_83199_p0() {
    mul_ln1118_161_fu_83199_p0 =  (sc_lv<10>) (mul_ln1118_161_fu_83199_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_161_fu_83199_p00() {
    mul_ln1118_161_fu_83199_p00 = esl_zext<12,10>(trunc_ln77_158_reg_130836.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_161_fu_83199_p1() {
    mul_ln1118_161_fu_83199_p1 = tmp_311_reg_130841.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_161_fu_83199_p2() {
    mul_ln1118_161_fu_83199_p2 = (!mul_ln1118_161_fu_83199_p0.read().is_01() || !mul_ln1118_161_fu_83199_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_161_fu_83199_p0.read()) * sc_bigint<2>(mul_ln1118_161_fu_83199_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_162_fu_83223_p0() {
    mul_ln1118_162_fu_83223_p0 =  (sc_lv<10>) (mul_ln1118_162_fu_83223_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_162_fu_83223_p00() {
    mul_ln1118_162_fu_83223_p00 = esl_zext<12,10>(trunc_ln77_159_reg_130846.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_162_fu_83223_p1() {
    mul_ln1118_162_fu_83223_p1 = tmp_312_reg_130851.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_162_fu_83223_p2() {
    mul_ln1118_162_fu_83223_p2 = (!mul_ln1118_162_fu_83223_p0.read().is_01() || !mul_ln1118_162_fu_83223_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_162_fu_83223_p0.read()) * sc_bigint<2>(mul_ln1118_162_fu_83223_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_163_fu_83247_p0() {
    mul_ln1118_163_fu_83247_p0 =  (sc_lv<10>) (mul_ln1118_163_fu_83247_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_163_fu_83247_p00() {
    mul_ln1118_163_fu_83247_p00 = esl_zext<12,10>(trunc_ln77_160_reg_130856.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_163_fu_83247_p1() {
    mul_ln1118_163_fu_83247_p1 = tmp_313_reg_130861.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_163_fu_83247_p2() {
    mul_ln1118_163_fu_83247_p2 = (!mul_ln1118_163_fu_83247_p0.read().is_01() || !mul_ln1118_163_fu_83247_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_163_fu_83247_p0.read()) * sc_bigint<2>(mul_ln1118_163_fu_83247_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_164_fu_83259_p0() {
    mul_ln1118_164_fu_83259_p0 =  (sc_lv<10>) (mul_ln1118_164_fu_83259_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_164_fu_83259_p00() {
    mul_ln1118_164_fu_83259_p00 = esl_zext<12,10>(trunc_ln77_161_reg_130866.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_164_fu_83259_p1() {
    mul_ln1118_164_fu_83259_p1 = tmp_314_reg_130871.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_164_fu_83259_p2() {
    mul_ln1118_164_fu_83259_p2 = (!mul_ln1118_164_fu_83259_p0.read().is_01() || !mul_ln1118_164_fu_83259_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_164_fu_83259_p0.read()) * sc_bigint<2>(mul_ln1118_164_fu_83259_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_165_fu_83283_p0() {
    mul_ln1118_165_fu_83283_p0 =  (sc_lv<10>) (mul_ln1118_165_fu_83283_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_165_fu_83283_p00() {
    mul_ln1118_165_fu_83283_p00 = esl_zext<12,10>(trunc_ln77_162_reg_130876.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_165_fu_83283_p1() {
    mul_ln1118_165_fu_83283_p1 = tmp_315_reg_130881.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_165_fu_83283_p2() {
    mul_ln1118_165_fu_83283_p2 = (!mul_ln1118_165_fu_83283_p0.read().is_01() || !mul_ln1118_165_fu_83283_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_165_fu_83283_p0.read()) * sc_bigint<2>(mul_ln1118_165_fu_83283_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_166_fu_83307_p0() {
    mul_ln1118_166_fu_83307_p0 =  (sc_lv<10>) (mul_ln1118_166_fu_83307_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_166_fu_83307_p00() {
    mul_ln1118_166_fu_83307_p00 = esl_zext<12,10>(trunc_ln77_163_reg_130886.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_166_fu_83307_p1() {
    mul_ln1118_166_fu_83307_p1 = tmp_316_reg_130891.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_166_fu_83307_p2() {
    mul_ln1118_166_fu_83307_p2 = (!mul_ln1118_166_fu_83307_p0.read().is_01() || !mul_ln1118_166_fu_83307_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_166_fu_83307_p0.read()) * sc_bigint<2>(mul_ln1118_166_fu_83307_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_167_fu_83319_p0() {
    mul_ln1118_167_fu_83319_p0 =  (sc_lv<10>) (mul_ln1118_167_fu_83319_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_167_fu_83319_p00() {
    mul_ln1118_167_fu_83319_p00 = esl_zext<12,10>(trunc_ln77_164_reg_130896.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_167_fu_83319_p1() {
    mul_ln1118_167_fu_83319_p1 = tmp_317_reg_130901.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_167_fu_83319_p2() {
    mul_ln1118_167_fu_83319_p2 = (!mul_ln1118_167_fu_83319_p0.read().is_01() || !mul_ln1118_167_fu_83319_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_167_fu_83319_p0.read()) * sc_bigint<2>(mul_ln1118_167_fu_83319_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_168_fu_83343_p0() {
    mul_ln1118_168_fu_83343_p0 =  (sc_lv<10>) (mul_ln1118_168_fu_83343_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_168_fu_83343_p00() {
    mul_ln1118_168_fu_83343_p00 = esl_zext<12,10>(trunc_ln77_165_reg_130906.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_168_fu_83343_p1() {
    mul_ln1118_168_fu_83343_p1 = tmp_318_reg_130911.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_168_fu_83343_p2() {
    mul_ln1118_168_fu_83343_p2 = (!mul_ln1118_168_fu_83343_p0.read().is_01() || !mul_ln1118_168_fu_83343_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_168_fu_83343_p0.read()) * sc_bigint<2>(mul_ln1118_168_fu_83343_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_169_fu_83367_p0() {
    mul_ln1118_169_fu_83367_p0 =  (sc_lv<10>) (mul_ln1118_169_fu_83367_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_169_fu_83367_p00() {
    mul_ln1118_169_fu_83367_p00 = esl_zext<12,10>(trunc_ln77_166_reg_130916.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_169_fu_83367_p1() {
    mul_ln1118_169_fu_83367_p1 = tmp_319_reg_130921.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_169_fu_83367_p2() {
    mul_ln1118_169_fu_83367_p2 = (!mul_ln1118_169_fu_83367_p0.read().is_01() || !mul_ln1118_169_fu_83367_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_169_fu_83367_p0.read()) * sc_bigint<2>(mul_ln1118_169_fu_83367_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_16_fu_79947_p0() {
    mul_ln1118_16_fu_79947_p0 =  (sc_lv<10>) (mul_ln1118_16_fu_79947_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_16_fu_79947_p00() {
    mul_ln1118_16_fu_79947_p00 = esl_zext<12,10>(trunc_ln77_13_reg_129391.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_16_fu_79947_p1() {
    mul_ln1118_16_fu_79947_p1 = tmp_25_reg_129396.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_16_fu_79947_p2() {
    mul_ln1118_16_fu_79947_p2 = (!mul_ln1118_16_fu_79947_p0.read().is_01() || !mul_ln1118_16_fu_79947_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_16_fu_79947_p0.read()) * sc_bigint<2>(mul_ln1118_16_fu_79947_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_170_fu_83379_p0() {
    mul_ln1118_170_fu_83379_p0 =  (sc_lv<10>) (mul_ln1118_170_fu_83379_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_170_fu_83379_p00() {
    mul_ln1118_170_fu_83379_p00 = esl_zext<12,10>(trunc_ln77_167_reg_130926.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_170_fu_83379_p1() {
    mul_ln1118_170_fu_83379_p1 = tmp_320_reg_130931.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_170_fu_83379_p2() {
    mul_ln1118_170_fu_83379_p2 = (!mul_ln1118_170_fu_83379_p0.read().is_01() || !mul_ln1118_170_fu_83379_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_170_fu_83379_p0.read()) * sc_bigint<2>(mul_ln1118_170_fu_83379_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_171_fu_83400_p0() {
    mul_ln1118_171_fu_83400_p0 =  (sc_lv<10>) (zext_ln1116_86_fu_81429_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_171_fu_83400_p1() {
    mul_ln1118_171_fu_83400_p1 = tmp_321_reg_130936.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_171_fu_83400_p2() {
    mul_ln1118_171_fu_83400_p2 = (!mul_ln1118_171_fu_83400_p0.read().is_01() || !mul_ln1118_171_fu_83400_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_171_fu_83400_p0.read()) * sc_bigint<2>(mul_ln1118_171_fu_83400_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_172_fu_83613_p0() {
    mul_ln1118_172_fu_83613_p0 =  (sc_lv<10>) (zext_ln1116_87_fu_81645_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_172_fu_83613_p1() {
    mul_ln1118_172_fu_83613_p1 = tmp_322_reg_130941.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_172_fu_83613_p2() {
    mul_ln1118_172_fu_83613_p2 = (!mul_ln1118_172_fu_83613_p0.read().is_01() || !mul_ln1118_172_fu_83613_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_172_fu_83613_p0.read()) * sc_bigint<2>(mul_ln1118_172_fu_83613_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_173_fu_83634_p0() {
    mul_ln1118_173_fu_83634_p0 =  (sc_lv<10>) (zext_ln1116_88_fu_81669_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_173_fu_83634_p1() {
    mul_ln1118_173_fu_83634_p1 = tmp_323_reg_130946.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_173_fu_83634_p2() {
    mul_ln1118_173_fu_83634_p2 = (!mul_ln1118_173_fu_83634_p0.read().is_01() || !mul_ln1118_173_fu_83634_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_173_fu_83634_p0.read()) * sc_bigint<2>(mul_ln1118_173_fu_83634_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_174_fu_83655_p0() {
    mul_ln1118_174_fu_83655_p0 =  (sc_lv<10>) (zext_ln1116_89_fu_81693_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_174_fu_83655_p1() {
    mul_ln1118_174_fu_83655_p1 = tmp_324_reg_130951.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_174_fu_83655_p2() {
    mul_ln1118_174_fu_83655_p2 = (!mul_ln1118_174_fu_83655_p0.read().is_01() || !mul_ln1118_174_fu_83655_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_174_fu_83655_p0.read()) * sc_bigint<2>(mul_ln1118_174_fu_83655_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_175_fu_83664_p0() {
    mul_ln1118_175_fu_83664_p0 =  (sc_lv<10>) (zext_ln1116_90_fu_81705_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_175_fu_83664_p1() {
    mul_ln1118_175_fu_83664_p1 = tmp_325_reg_130956.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_175_fu_83664_p2() {
    mul_ln1118_175_fu_83664_p2 = (!mul_ln1118_175_fu_83664_p0.read().is_01() || !mul_ln1118_175_fu_83664_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_175_fu_83664_p0.read()) * sc_bigint<2>(mul_ln1118_175_fu_83664_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_176_fu_83685_p0() {
    mul_ln1118_176_fu_83685_p0 =  (sc_lv<10>) (zext_ln1116_91_fu_81729_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_176_fu_83685_p1() {
    mul_ln1118_176_fu_83685_p1 = tmp_326_reg_130961.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_176_fu_83685_p2() {
    mul_ln1118_176_fu_83685_p2 = (!mul_ln1118_176_fu_83685_p0.read().is_01() || !mul_ln1118_176_fu_83685_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_176_fu_83685_p0.read()) * sc_bigint<2>(mul_ln1118_176_fu_83685_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_177_fu_83706_p0() {
    mul_ln1118_177_fu_83706_p0 =  (sc_lv<10>) (zext_ln1116_92_fu_81753_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_177_fu_83706_p1() {
    mul_ln1118_177_fu_83706_p1 = tmp_327_reg_130966.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_177_fu_83706_p2() {
    mul_ln1118_177_fu_83706_p2 = (!mul_ln1118_177_fu_83706_p0.read().is_01() || !mul_ln1118_177_fu_83706_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_177_fu_83706_p0.read()) * sc_bigint<2>(mul_ln1118_177_fu_83706_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_178_fu_83727_p0() {
    mul_ln1118_178_fu_83727_p0 =  (sc_lv<10>) (zext_ln1116_93_fu_81777_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_178_fu_83727_p1() {
    mul_ln1118_178_fu_83727_p1 = tmp_328_reg_130971.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_178_fu_83727_p2() {
    mul_ln1118_178_fu_83727_p2 = (!mul_ln1118_178_fu_83727_p0.read().is_01() || !mul_ln1118_178_fu_83727_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_178_fu_83727_p0.read()) * sc_bigint<2>(mul_ln1118_178_fu_83727_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_179_fu_83748_p0() {
    mul_ln1118_179_fu_83748_p0 =  (sc_lv<10>) (zext_ln1116_94_fu_81801_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_179_fu_83748_p1() {
    mul_ln1118_179_fu_83748_p1 = tmp_329_reg_130976.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_179_fu_83748_p2() {
    mul_ln1118_179_fu_83748_p2 = (!mul_ln1118_179_fu_83748_p0.read().is_01() || !mul_ln1118_179_fu_83748_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_179_fu_83748_p0.read()) * sc_bigint<2>(mul_ln1118_179_fu_83748_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_17_fu_79959_p0() {
    mul_ln1118_17_fu_79959_p0 =  (sc_lv<10>) (mul_ln1118_17_fu_79959_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_17_fu_79959_p00() {
    mul_ln1118_17_fu_79959_p00 = esl_zext<12,10>(trunc_ln77_14_reg_129401.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_17_fu_79959_p1() {
    mul_ln1118_17_fu_79959_p1 = tmp_27_reg_129406.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_17_fu_79959_p2() {
    mul_ln1118_17_fu_79959_p2 = (!mul_ln1118_17_fu_79959_p0.read().is_01() || !mul_ln1118_17_fu_79959_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_17_fu_79959_p0.read()) * sc_bigint<2>(mul_ln1118_17_fu_79959_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_180_fu_83757_p0() {
    mul_ln1118_180_fu_83757_p0 =  (sc_lv<10>) (zext_ln1116_95_fu_81813_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_180_fu_83757_p1() {
    mul_ln1118_180_fu_83757_p1 = tmp_330_reg_130981.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_180_fu_83757_p2() {
    mul_ln1118_180_fu_83757_p2 = (!mul_ln1118_180_fu_83757_p0.read().is_01() || !mul_ln1118_180_fu_83757_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_180_fu_83757_p0.read()) * sc_bigint<2>(mul_ln1118_180_fu_83757_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_181_fu_83778_p0() {
    mul_ln1118_181_fu_83778_p0 =  (sc_lv<10>) (zext_ln1116_96_fu_81837_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_181_fu_83778_p1() {
    mul_ln1118_181_fu_83778_p1 = tmp_331_reg_130986.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_181_fu_83778_p2() {
    mul_ln1118_181_fu_83778_p2 = (!mul_ln1118_181_fu_83778_p0.read().is_01() || !mul_ln1118_181_fu_83778_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_181_fu_83778_p0.read()) * sc_bigint<2>(mul_ln1118_181_fu_83778_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_182_fu_83799_p0() {
    mul_ln1118_182_fu_83799_p0 =  (sc_lv<10>) (zext_ln1116_97_fu_81861_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_182_fu_83799_p1() {
    mul_ln1118_182_fu_83799_p1 = tmp_332_reg_130991.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_182_fu_83799_p2() {
    mul_ln1118_182_fu_83799_p2 = (!mul_ln1118_182_fu_83799_p0.read().is_01() || !mul_ln1118_182_fu_83799_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_182_fu_83799_p0.read()) * sc_bigint<2>(mul_ln1118_182_fu_83799_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_183_fu_83820_p0() {
    mul_ln1118_183_fu_83820_p0 =  (sc_lv<10>) (zext_ln1116_98_fu_81885_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_183_fu_83820_p1() {
    mul_ln1118_183_fu_83820_p1 = tmp_333_reg_130996.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_183_fu_83820_p2() {
    mul_ln1118_183_fu_83820_p2 = (!mul_ln1118_183_fu_83820_p0.read().is_01() || !mul_ln1118_183_fu_83820_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_183_fu_83820_p0.read()) * sc_bigint<2>(mul_ln1118_183_fu_83820_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_184_fu_83841_p0() {
    mul_ln1118_184_fu_83841_p0 =  (sc_lv<10>) (zext_ln1116_99_fu_81909_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_184_fu_83841_p1() {
    mul_ln1118_184_fu_83841_p1 = tmp_334_reg_131001.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_184_fu_83841_p2() {
    mul_ln1118_184_fu_83841_p2 = (!mul_ln1118_184_fu_83841_p0.read().is_01() || !mul_ln1118_184_fu_83841_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_184_fu_83841_p0.read()) * sc_bigint<2>(mul_ln1118_184_fu_83841_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_185_fu_83850_p0() {
    mul_ln1118_185_fu_83850_p0 =  (sc_lv<10>) (zext_ln1116_100_fu_81921_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_185_fu_83850_p1() {
    mul_ln1118_185_fu_83850_p1 = tmp_335_reg_131006.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_185_fu_83850_p2() {
    mul_ln1118_185_fu_83850_p2 = (!mul_ln1118_185_fu_83850_p0.read().is_01() || !mul_ln1118_185_fu_83850_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_185_fu_83850_p0.read()) * sc_bigint<2>(mul_ln1118_185_fu_83850_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_186_fu_83871_p0() {
    mul_ln1118_186_fu_83871_p0 =  (sc_lv<10>) (zext_ln1116_101_fu_81945_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_186_fu_83871_p1() {
    mul_ln1118_186_fu_83871_p1 = tmp_336_reg_131011.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_186_fu_83871_p2() {
    mul_ln1118_186_fu_83871_p2 = (!mul_ln1118_186_fu_83871_p0.read().is_01() || !mul_ln1118_186_fu_83871_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_186_fu_83871_p0.read()) * sc_bigint<2>(mul_ln1118_186_fu_83871_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_187_fu_83892_p0() {
    mul_ln1118_187_fu_83892_p0 =  (sc_lv<10>) (zext_ln1116_102_fu_81969_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_187_fu_83892_p1() {
    mul_ln1118_187_fu_83892_p1 = tmp_337_reg_131016.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_187_fu_83892_p2() {
    mul_ln1118_187_fu_83892_p2 = (!mul_ln1118_187_fu_83892_p0.read().is_01() || !mul_ln1118_187_fu_83892_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_187_fu_83892_p0.read()) * sc_bigint<2>(mul_ln1118_187_fu_83892_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_188_fu_83901_p0() {
    mul_ln1118_188_fu_83901_p0 =  (sc_lv<10>) (zext_ln1116_103_fu_81981_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_188_fu_83901_p1() {
    mul_ln1118_188_fu_83901_p1 = tmp_338_reg_131021.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_188_fu_83901_p2() {
    mul_ln1118_188_fu_83901_p2 = (!mul_ln1118_188_fu_83901_p0.read().is_01() || !mul_ln1118_188_fu_83901_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_188_fu_83901_p0.read()) * sc_bigint<2>(mul_ln1118_188_fu_83901_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_189_fu_83922_p0() {
    mul_ln1118_189_fu_83922_p0 =  (sc_lv<10>) (zext_ln1116_104_fu_82005_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_189_fu_83922_p1() {
    mul_ln1118_189_fu_83922_p1 = tmp_339_reg_131026.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_189_fu_83922_p2() {
    mul_ln1118_189_fu_83922_p2 = (!mul_ln1118_189_fu_83922_p0.read().is_01() || !mul_ln1118_189_fu_83922_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_189_fu_83922_p0.read()) * sc_bigint<2>(mul_ln1118_189_fu_83922_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_18_fu_79983_p0() {
    mul_ln1118_18_fu_79983_p0 =  (sc_lv<10>) (mul_ln1118_18_fu_79983_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_18_fu_79983_p00() {
    mul_ln1118_18_fu_79983_p00 = esl_zext<12,10>(trunc_ln77_15_reg_129411.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_18_fu_79983_p1() {
    mul_ln1118_18_fu_79983_p1 = tmp_29_reg_129416.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_18_fu_79983_p2() {
    mul_ln1118_18_fu_79983_p2 = (!mul_ln1118_18_fu_79983_p0.read().is_01() || !mul_ln1118_18_fu_79983_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_18_fu_79983_p0.read()) * sc_bigint<2>(mul_ln1118_18_fu_79983_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_190_fu_83943_p0() {
    mul_ln1118_190_fu_83943_p0 =  (sc_lv<10>) (zext_ln1116_105_fu_82029_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_190_fu_83943_p1() {
    mul_ln1118_190_fu_83943_p1 = tmp_340_reg_131031.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_190_fu_83943_p2() {
    mul_ln1118_190_fu_83943_p2 = (!mul_ln1118_190_fu_83943_p0.read().is_01() || !mul_ln1118_190_fu_83943_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_190_fu_83943_p0.read()) * sc_bigint<2>(mul_ln1118_190_fu_83943_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_191_fu_83952_p0() {
    mul_ln1118_191_fu_83952_p0 =  (sc_lv<10>) (zext_ln1116_106_fu_82041_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_191_fu_83952_p1() {
    mul_ln1118_191_fu_83952_p1 = tmp_341_reg_131036.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_191_fu_83952_p2() {
    mul_ln1118_191_fu_83952_p2 = (!mul_ln1118_191_fu_83952_p0.read().is_01() || !mul_ln1118_191_fu_83952_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_191_fu_83952_p0.read()) * sc_bigint<2>(mul_ln1118_191_fu_83952_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_192_fu_83973_p0() {
    mul_ln1118_192_fu_83973_p0 =  (sc_lv<10>) (zext_ln1116_107_fu_82065_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_192_fu_83973_p1() {
    mul_ln1118_192_fu_83973_p1 = tmp_342_reg_131041.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_192_fu_83973_p2() {
    mul_ln1118_192_fu_83973_p2 = (!mul_ln1118_192_fu_83973_p0.read().is_01() || !mul_ln1118_192_fu_83973_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_192_fu_83973_p0.read()) * sc_bigint<2>(mul_ln1118_192_fu_83973_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_193_fu_83994_p0() {
    mul_ln1118_193_fu_83994_p0 =  (sc_lv<10>) (zext_ln1116_108_fu_82089_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_193_fu_83994_p1() {
    mul_ln1118_193_fu_83994_p1 = tmp_343_reg_131046.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_193_fu_83994_p2() {
    mul_ln1118_193_fu_83994_p2 = (!mul_ln1118_193_fu_83994_p0.read().is_01() || !mul_ln1118_193_fu_83994_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_193_fu_83994_p0.read()) * sc_bigint<2>(mul_ln1118_193_fu_83994_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_194_fu_84015_p0() {
    mul_ln1118_194_fu_84015_p0 =  (sc_lv<10>) (zext_ln1116_109_fu_82113_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_194_fu_84015_p1() {
    mul_ln1118_194_fu_84015_p1 = tmp_344_reg_131051.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_194_fu_84015_p2() {
    mul_ln1118_194_fu_84015_p2 = (!mul_ln1118_194_fu_84015_p0.read().is_01() || !mul_ln1118_194_fu_84015_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_194_fu_84015_p0.read()) * sc_bigint<2>(mul_ln1118_194_fu_84015_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_195_fu_84036_p0() {
    mul_ln1118_195_fu_84036_p0 =  (sc_lv<10>) (zext_ln1116_110_fu_82137_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_195_fu_84036_p1() {
    mul_ln1118_195_fu_84036_p1 = tmp_345_reg_131056.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_195_fu_84036_p2() {
    mul_ln1118_195_fu_84036_p2 = (!mul_ln1118_195_fu_84036_p0.read().is_01() || !mul_ln1118_195_fu_84036_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_195_fu_84036_p0.read()) * sc_bigint<2>(mul_ln1118_195_fu_84036_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_196_fu_84045_p0() {
    mul_ln1118_196_fu_84045_p0 =  (sc_lv<10>) (zext_ln1116_111_fu_82149_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_196_fu_84045_p1() {
    mul_ln1118_196_fu_84045_p1 = tmp_346_reg_131061.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_196_fu_84045_p2() {
    mul_ln1118_196_fu_84045_p2 = (!mul_ln1118_196_fu_84045_p0.read().is_01() || !mul_ln1118_196_fu_84045_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_196_fu_84045_p0.read()) * sc_bigint<2>(mul_ln1118_196_fu_84045_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_197_fu_84066_p0() {
    mul_ln1118_197_fu_84066_p0 =  (sc_lv<10>) (zext_ln1116_112_fu_82173_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_197_fu_84066_p1() {
    mul_ln1118_197_fu_84066_p1 = tmp_347_reg_131066.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_197_fu_84066_p2() {
    mul_ln1118_197_fu_84066_p2 = (!mul_ln1118_197_fu_84066_p0.read().is_01() || !mul_ln1118_197_fu_84066_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_197_fu_84066_p0.read()) * sc_bigint<2>(mul_ln1118_197_fu_84066_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_198_fu_84087_p0() {
    mul_ln1118_198_fu_84087_p0 =  (sc_lv<10>) (zext_ln1116_113_fu_82197_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_198_fu_84087_p1() {
    mul_ln1118_198_fu_84087_p1 = tmp_348_reg_131071.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_198_fu_84087_p2() {
    mul_ln1118_198_fu_84087_p2 = (!mul_ln1118_198_fu_84087_p0.read().is_01() || !mul_ln1118_198_fu_84087_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_198_fu_84087_p0.read()) * sc_bigint<2>(mul_ln1118_198_fu_84087_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_199_fu_84108_p0() {
    mul_ln1118_199_fu_84108_p0 =  (sc_lv<10>) (zext_ln1116_114_fu_82221_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_199_fu_84108_p1() {
    mul_ln1118_199_fu_84108_p1 = tmp_349_reg_131076.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_199_fu_84108_p2() {
    mul_ln1118_199_fu_84108_p2 = (!mul_ln1118_199_fu_84108_p0.read().is_01() || !mul_ln1118_199_fu_84108_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_199_fu_84108_p0.read()) * sc_bigint<2>(mul_ln1118_199_fu_84108_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_19_fu_80007_p0() {
    mul_ln1118_19_fu_80007_p0 =  (sc_lv<10>) (mul_ln1118_19_fu_80007_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_19_fu_80007_p00() {
    mul_ln1118_19_fu_80007_p00 = esl_zext<12,10>(trunc_ln77_16_reg_129421.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_19_fu_80007_p1() {
    mul_ln1118_19_fu_80007_p1 = tmp_31_reg_129426.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_19_fu_80007_p2() {
    mul_ln1118_19_fu_80007_p2 = (!mul_ln1118_19_fu_80007_p0.read().is_01() || !mul_ln1118_19_fu_80007_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_19_fu_80007_p0.read()) * sc_bigint<2>(mul_ln1118_19_fu_80007_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_200_fu_84129_p0() {
    mul_ln1118_200_fu_84129_p0 =  (sc_lv<10>) (zext_ln1116_115_fu_82245_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_200_fu_84129_p1() {
    mul_ln1118_200_fu_84129_p1 = tmp_350_reg_131081.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_200_fu_84129_p2() {
    mul_ln1118_200_fu_84129_p2 = (!mul_ln1118_200_fu_84129_p0.read().is_01() || !mul_ln1118_200_fu_84129_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_200_fu_84129_p0.read()) * sc_bigint<2>(mul_ln1118_200_fu_84129_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_201_fu_84138_p0() {
    mul_ln1118_201_fu_84138_p0 =  (sc_lv<10>) (zext_ln1116_116_fu_82257_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_201_fu_84138_p1() {
    mul_ln1118_201_fu_84138_p1 = tmp_351_reg_131086.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_201_fu_84138_p2() {
    mul_ln1118_201_fu_84138_p2 = (!mul_ln1118_201_fu_84138_p0.read().is_01() || !mul_ln1118_201_fu_84138_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_201_fu_84138_p0.read()) * sc_bigint<2>(mul_ln1118_201_fu_84138_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_202_fu_84159_p0() {
    mul_ln1118_202_fu_84159_p0 =  (sc_lv<10>) (zext_ln1116_117_fu_82281_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_202_fu_84159_p1() {
    mul_ln1118_202_fu_84159_p1 = tmp_352_reg_131091.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_202_fu_84159_p2() {
    mul_ln1118_202_fu_84159_p2 = (!mul_ln1118_202_fu_84159_p0.read().is_01() || !mul_ln1118_202_fu_84159_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_202_fu_84159_p0.read()) * sc_bigint<2>(mul_ln1118_202_fu_84159_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_203_fu_84180_p0() {
    mul_ln1118_203_fu_84180_p0 =  (sc_lv<10>) (zext_ln1116_118_fu_82305_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_203_fu_84180_p1() {
    mul_ln1118_203_fu_84180_p1 = tmp_353_reg_131096.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_203_fu_84180_p2() {
    mul_ln1118_203_fu_84180_p2 = (!mul_ln1118_203_fu_84180_p0.read().is_01() || !mul_ln1118_203_fu_84180_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_203_fu_84180_p0.read()) * sc_bigint<2>(mul_ln1118_203_fu_84180_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_204_fu_84201_p0() {
    mul_ln1118_204_fu_84201_p0 =  (sc_lv<10>) (zext_ln1116_119_fu_82329_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_204_fu_84201_p1() {
    mul_ln1118_204_fu_84201_p1 = tmp_354_reg_131101.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_204_fu_84201_p2() {
    mul_ln1118_204_fu_84201_p2 = (!mul_ln1118_204_fu_84201_p0.read().is_01() || !mul_ln1118_204_fu_84201_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_204_fu_84201_p0.read()) * sc_bigint<2>(mul_ln1118_204_fu_84201_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_205_fu_84222_p0() {
    mul_ln1118_205_fu_84222_p0 =  (sc_lv<10>) (zext_ln1116_120_fu_82353_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_205_fu_84222_p1() {
    mul_ln1118_205_fu_84222_p1 = tmp_355_reg_131106.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_205_fu_84222_p2() {
    mul_ln1118_205_fu_84222_p2 = (!mul_ln1118_205_fu_84222_p0.read().is_01() || !mul_ln1118_205_fu_84222_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_205_fu_84222_p0.read()) * sc_bigint<2>(mul_ln1118_205_fu_84222_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_206_fu_84231_p0() {
    mul_ln1118_206_fu_84231_p0 =  (sc_lv<10>) (zext_ln1116_121_fu_82365_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_206_fu_84231_p1() {
    mul_ln1118_206_fu_84231_p1 = tmp_356_reg_131111.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_206_fu_84231_p2() {
    mul_ln1118_206_fu_84231_p2 = (!mul_ln1118_206_fu_84231_p0.read().is_01() || !mul_ln1118_206_fu_84231_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_206_fu_84231_p0.read()) * sc_bigint<2>(mul_ln1118_206_fu_84231_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_207_fu_84252_p0() {
    mul_ln1118_207_fu_84252_p0 =  (sc_lv<10>) (zext_ln1116_122_fu_82389_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_207_fu_84252_p1() {
    mul_ln1118_207_fu_84252_p1 = tmp_357_reg_131116.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_207_fu_84252_p2() {
    mul_ln1118_207_fu_84252_p2 = (!mul_ln1118_207_fu_84252_p0.read().is_01() || !mul_ln1118_207_fu_84252_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_207_fu_84252_p0.read()) * sc_bigint<2>(mul_ln1118_207_fu_84252_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_208_fu_84273_p0() {
    mul_ln1118_208_fu_84273_p0 =  (sc_lv<10>) (zext_ln1116_123_fu_82413_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_208_fu_84273_p1() {
    mul_ln1118_208_fu_84273_p1 = tmp_358_reg_131121.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_208_fu_84273_p2() {
    mul_ln1118_208_fu_84273_p2 = (!mul_ln1118_208_fu_84273_p0.read().is_01() || !mul_ln1118_208_fu_84273_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_208_fu_84273_p0.read()) * sc_bigint<2>(mul_ln1118_208_fu_84273_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_209_fu_84282_p0() {
    mul_ln1118_209_fu_84282_p0 =  (sc_lv<10>) (zext_ln1116_124_fu_82425_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_209_fu_84282_p1() {
    mul_ln1118_209_fu_84282_p1 = tmp_359_reg_131126.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_209_fu_84282_p2() {
    mul_ln1118_209_fu_84282_p2 = (!mul_ln1118_209_fu_84282_p0.read().is_01() || !mul_ln1118_209_fu_84282_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_209_fu_84282_p0.read()) * sc_bigint<2>(mul_ln1118_209_fu_84282_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_20_fu_80019_p0() {
    mul_ln1118_20_fu_80019_p0 =  (sc_lv<10>) (mul_ln1118_20_fu_80019_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_20_fu_80019_p00() {
    mul_ln1118_20_fu_80019_p00 = esl_zext<12,10>(trunc_ln77_17_reg_129431.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_20_fu_80019_p1() {
    mul_ln1118_20_fu_80019_p1 = tmp_33_reg_129436.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_20_fu_80019_p2() {
    mul_ln1118_20_fu_80019_p2 = (!mul_ln1118_20_fu_80019_p0.read().is_01() || !mul_ln1118_20_fu_80019_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_20_fu_80019_p0.read()) * sc_bigint<2>(mul_ln1118_20_fu_80019_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_210_fu_84303_p0() {
    mul_ln1118_210_fu_84303_p0 =  (sc_lv<10>) (zext_ln1116_125_fu_82449_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_210_fu_84303_p1() {
    mul_ln1118_210_fu_84303_p1 = tmp_360_reg_131131.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_210_fu_84303_p2() {
    mul_ln1118_210_fu_84303_p2 = (!mul_ln1118_210_fu_84303_p0.read().is_01() || !mul_ln1118_210_fu_84303_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_210_fu_84303_p0.read()) * sc_bigint<2>(mul_ln1118_210_fu_84303_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_211_fu_84324_p0() {
    mul_ln1118_211_fu_84324_p0 =  (sc_lv<10>) (zext_ln1116_126_fu_82473_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_211_fu_84324_p1() {
    mul_ln1118_211_fu_84324_p1 = tmp_361_reg_131136.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_211_fu_84324_p2() {
    mul_ln1118_211_fu_84324_p2 = (!mul_ln1118_211_fu_84324_p0.read().is_01() || !mul_ln1118_211_fu_84324_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_211_fu_84324_p0.read()) * sc_bigint<2>(mul_ln1118_211_fu_84324_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_212_fu_84333_p0() {
    mul_ln1118_212_fu_84333_p0 =  (sc_lv<10>) (zext_ln1116_127_fu_82485_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_212_fu_84333_p1() {
    mul_ln1118_212_fu_84333_p1 = tmp_362_reg_131141.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_212_fu_84333_p2() {
    mul_ln1118_212_fu_84333_p2 = (!mul_ln1118_212_fu_84333_p0.read().is_01() || !mul_ln1118_212_fu_84333_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_212_fu_84333_p0.read()) * sc_bigint<2>(mul_ln1118_212_fu_84333_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_213_fu_84354_p0() {
    mul_ln1118_213_fu_84354_p0 =  (sc_lv<10>) (zext_ln1116_128_fu_82509_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_213_fu_84354_p1() {
    mul_ln1118_213_fu_84354_p1 = tmp_363_reg_131146.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_213_fu_84354_p2() {
    mul_ln1118_213_fu_84354_p2 = (!mul_ln1118_213_fu_84354_p0.read().is_01() || !mul_ln1118_213_fu_84354_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_213_fu_84354_p0.read()) * sc_bigint<2>(mul_ln1118_213_fu_84354_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_214_fu_84375_p0() {
    mul_ln1118_214_fu_84375_p0 =  (sc_lv<10>) (zext_ln1116_129_fu_82533_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_214_fu_84375_p1() {
    mul_ln1118_214_fu_84375_p1 = tmp_364_reg_131151.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_214_fu_84375_p2() {
    mul_ln1118_214_fu_84375_p2 = (!mul_ln1118_214_fu_84375_p0.read().is_01() || !mul_ln1118_214_fu_84375_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_214_fu_84375_p0.read()) * sc_bigint<2>(mul_ln1118_214_fu_84375_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_215_fu_84396_p0() {
    mul_ln1118_215_fu_84396_p0 =  (sc_lv<10>) (zext_ln1116_130_fu_82557_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_215_fu_84396_p1() {
    mul_ln1118_215_fu_84396_p1 = tmp_365_reg_131156.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_215_fu_84396_p2() {
    mul_ln1118_215_fu_84396_p2 = (!mul_ln1118_215_fu_84396_p0.read().is_01() || !mul_ln1118_215_fu_84396_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_215_fu_84396_p0.read()) * sc_bigint<2>(mul_ln1118_215_fu_84396_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_216_fu_84417_p0() {
    mul_ln1118_216_fu_84417_p0 =  (sc_lv<10>) (zext_ln1116_131_fu_82581_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_216_fu_84417_p1() {
    mul_ln1118_216_fu_84417_p1 = tmp_366_reg_131161.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_216_fu_84417_p2() {
    mul_ln1118_216_fu_84417_p2 = (!mul_ln1118_216_fu_84417_p0.read().is_01() || !mul_ln1118_216_fu_84417_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_216_fu_84417_p0.read()) * sc_bigint<2>(mul_ln1118_216_fu_84417_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_217_fu_84426_p0() {
    mul_ln1118_217_fu_84426_p0 =  (sc_lv<10>) (zext_ln1116_132_fu_82593_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_217_fu_84426_p1() {
    mul_ln1118_217_fu_84426_p1 = tmp_367_reg_131166.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_217_fu_84426_p2() {
    mul_ln1118_217_fu_84426_p2 = (!mul_ln1118_217_fu_84426_p0.read().is_01() || !mul_ln1118_217_fu_84426_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_217_fu_84426_p0.read()) * sc_bigint<2>(mul_ln1118_217_fu_84426_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_218_fu_84447_p0() {
    mul_ln1118_218_fu_84447_p0 =  (sc_lv<10>) (zext_ln1116_133_fu_82617_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_218_fu_84447_p1() {
    mul_ln1118_218_fu_84447_p1 = tmp_368_reg_131171.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_218_fu_84447_p2() {
    mul_ln1118_218_fu_84447_p2 = (!mul_ln1118_218_fu_84447_p0.read().is_01() || !mul_ln1118_218_fu_84447_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_218_fu_84447_p0.read()) * sc_bigint<2>(mul_ln1118_218_fu_84447_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_219_fu_84468_p0() {
    mul_ln1118_219_fu_84468_p0 =  (sc_lv<10>) (zext_ln1116_134_fu_82641_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_219_fu_84468_p1() {
    mul_ln1118_219_fu_84468_p1 = tmp_369_reg_131176.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_219_fu_84468_p2() {
    mul_ln1118_219_fu_84468_p2 = (!mul_ln1118_219_fu_84468_p0.read().is_01() || !mul_ln1118_219_fu_84468_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_219_fu_84468_p0.read()) * sc_bigint<2>(mul_ln1118_219_fu_84468_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_21_fu_80043_p0() {
    mul_ln1118_21_fu_80043_p0 =  (sc_lv<10>) (mul_ln1118_21_fu_80043_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_21_fu_80043_p00() {
    mul_ln1118_21_fu_80043_p00 = esl_zext<12,10>(trunc_ln77_18_reg_129441.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_21_fu_80043_p1() {
    mul_ln1118_21_fu_80043_p1 = tmp_35_reg_129446.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_21_fu_80043_p2() {
    mul_ln1118_21_fu_80043_p2 = (!mul_ln1118_21_fu_80043_p0.read().is_01() || !mul_ln1118_21_fu_80043_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_21_fu_80043_p0.read()) * sc_bigint<2>(mul_ln1118_21_fu_80043_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_220_fu_84489_p0() {
    mul_ln1118_220_fu_84489_p0 =  (sc_lv<10>) (zext_ln1116_135_fu_82665_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_220_fu_84489_p1() {
    mul_ln1118_220_fu_84489_p1 = tmp_370_reg_131181.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_220_fu_84489_p2() {
    mul_ln1118_220_fu_84489_p2 = (!mul_ln1118_220_fu_84489_p0.read().is_01() || !mul_ln1118_220_fu_84489_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_220_fu_84489_p0.read()) * sc_bigint<2>(mul_ln1118_220_fu_84489_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_221_fu_84510_p0() {
    mul_ln1118_221_fu_84510_p0 =  (sc_lv<10>) (zext_ln1116_136_fu_82689_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_221_fu_84510_p1() {
    mul_ln1118_221_fu_84510_p1 = tmp_371_reg_131186.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_221_fu_84510_p2() {
    mul_ln1118_221_fu_84510_p2 = (!mul_ln1118_221_fu_84510_p0.read().is_01() || !mul_ln1118_221_fu_84510_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_221_fu_84510_p0.read()) * sc_bigint<2>(mul_ln1118_221_fu_84510_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_222_fu_84519_p0() {
    mul_ln1118_222_fu_84519_p0 =  (sc_lv<10>) (zext_ln1116_137_fu_82701_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_222_fu_84519_p1() {
    mul_ln1118_222_fu_84519_p1 = tmp_372_reg_131191.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_222_fu_84519_p2() {
    mul_ln1118_222_fu_84519_p2 = (!mul_ln1118_222_fu_84519_p0.read().is_01() || !mul_ln1118_222_fu_84519_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_222_fu_84519_p0.read()) * sc_bigint<2>(mul_ln1118_222_fu_84519_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_223_fu_84540_p0() {
    mul_ln1118_223_fu_84540_p0 =  (sc_lv<10>) (zext_ln1116_138_fu_82725_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_223_fu_84540_p1() {
    mul_ln1118_223_fu_84540_p1 = tmp_373_reg_131196.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_223_fu_84540_p2() {
    mul_ln1118_223_fu_84540_p2 = (!mul_ln1118_223_fu_84540_p0.read().is_01() || !mul_ln1118_223_fu_84540_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_223_fu_84540_p0.read()) * sc_bigint<2>(mul_ln1118_223_fu_84540_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_224_fu_84561_p0() {
    mul_ln1118_224_fu_84561_p0 =  (sc_lv<10>) (zext_ln1116_139_fu_82749_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_224_fu_84561_p1() {
    mul_ln1118_224_fu_84561_p1 = tmp_374_reg_131201.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_224_fu_84561_p2() {
    mul_ln1118_224_fu_84561_p2 = (!mul_ln1118_224_fu_84561_p0.read().is_01() || !mul_ln1118_224_fu_84561_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_224_fu_84561_p0.read()) * sc_bigint<2>(mul_ln1118_224_fu_84561_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_225_fu_84585_p0() {
    mul_ln1118_225_fu_84585_p0 =  (sc_lv<10>) (zext_ln1116_170_fu_84579_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_225_fu_84585_p1() {
    mul_ln1118_225_fu_84585_p1 = tmp_376_reg_131211.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_225_fu_84585_p2() {
    mul_ln1118_225_fu_84585_p2 = (!mul_ln1118_225_fu_84585_p0.read().is_01() || !mul_ln1118_225_fu_84585_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_225_fu_84585_p0.read()) * sc_bigint<2>(mul_ln1118_225_fu_84585_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_226_fu_84609_p0() {
    mul_ln1118_226_fu_84609_p0 =  (sc_lv<10>) (zext_ln1116_171_fu_84603_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_226_fu_84609_p1() {
    mul_ln1118_226_fu_84609_p1 = tmp_378_reg_131221.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_226_fu_84609_p2() {
    mul_ln1118_226_fu_84609_p2 = (!mul_ln1118_226_fu_84609_p0.read().is_01() || !mul_ln1118_226_fu_84609_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_226_fu_84609_p0.read()) * sc_bigint<2>(mul_ln1118_226_fu_84609_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_227_fu_84621_p0() {
    mul_ln1118_227_fu_84621_p0 =  (sc_lv<10>) (zext_ln1116_172_fu_84615_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_227_fu_84621_p1() {
    mul_ln1118_227_fu_84621_p1 = tmp_380_reg_131231.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_227_fu_84621_p2() {
    mul_ln1118_227_fu_84621_p2 = (!mul_ln1118_227_fu_84621_p0.read().is_01() || !mul_ln1118_227_fu_84621_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_227_fu_84621_p0.read()) * sc_bigint<2>(mul_ln1118_227_fu_84621_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_228_fu_84645_p0() {
    mul_ln1118_228_fu_84645_p0 =  (sc_lv<10>) (zext_ln1116_173_fu_84639_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_228_fu_84645_p1() {
    mul_ln1118_228_fu_84645_p1 = tmp_382_reg_131241.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_228_fu_84645_p2() {
    mul_ln1118_228_fu_84645_p2 = (!mul_ln1118_228_fu_84645_p0.read().is_01() || !mul_ln1118_228_fu_84645_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_228_fu_84645_p0.read()) * sc_bigint<2>(mul_ln1118_228_fu_84645_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_229_fu_84669_p0() {
    mul_ln1118_229_fu_84669_p0 =  (sc_lv<10>) (zext_ln1116_174_fu_84663_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_229_fu_84669_p1() {
    mul_ln1118_229_fu_84669_p1 = tmp_384_reg_131251.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_229_fu_84669_p2() {
    mul_ln1118_229_fu_84669_p2 = (!mul_ln1118_229_fu_84669_p0.read().is_01() || !mul_ln1118_229_fu_84669_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_229_fu_84669_p0.read()) * sc_bigint<2>(mul_ln1118_229_fu_84669_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_22_fu_80067_p0() {
    mul_ln1118_22_fu_80067_p0 =  (sc_lv<10>) (mul_ln1118_22_fu_80067_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_22_fu_80067_p00() {
    mul_ln1118_22_fu_80067_p00 = esl_zext<12,10>(trunc_ln77_19_reg_129451.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_22_fu_80067_p1() {
    mul_ln1118_22_fu_80067_p1 = tmp_37_reg_129456.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_22_fu_80067_p2() {
    mul_ln1118_22_fu_80067_p2 = (!mul_ln1118_22_fu_80067_p0.read().is_01() || !mul_ln1118_22_fu_80067_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_22_fu_80067_p0.read()) * sc_bigint<2>(mul_ln1118_22_fu_80067_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_230_fu_84681_p0() {
    mul_ln1118_230_fu_84681_p0 =  (sc_lv<10>) (zext_ln1116_175_fu_84675_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_230_fu_84681_p1() {
    mul_ln1118_230_fu_84681_p1 = tmp_386_reg_131261.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_230_fu_84681_p2() {
    mul_ln1118_230_fu_84681_p2 = (!mul_ln1118_230_fu_84681_p0.read().is_01() || !mul_ln1118_230_fu_84681_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_230_fu_84681_p0.read()) * sc_bigint<2>(mul_ln1118_230_fu_84681_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_231_fu_84705_p0() {
    mul_ln1118_231_fu_84705_p0 =  (sc_lv<10>) (zext_ln1116_176_fu_84699_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_231_fu_84705_p1() {
    mul_ln1118_231_fu_84705_p1 = tmp_388_reg_131271.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_231_fu_84705_p2() {
    mul_ln1118_231_fu_84705_p2 = (!mul_ln1118_231_fu_84705_p0.read().is_01() || !mul_ln1118_231_fu_84705_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_231_fu_84705_p0.read()) * sc_bigint<2>(mul_ln1118_231_fu_84705_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_232_fu_84729_p0() {
    mul_ln1118_232_fu_84729_p0 =  (sc_lv<10>) (zext_ln1116_177_fu_84723_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_232_fu_84729_p1() {
    mul_ln1118_232_fu_84729_p1 = tmp_390_reg_131281.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_232_fu_84729_p2() {
    mul_ln1118_232_fu_84729_p2 = (!mul_ln1118_232_fu_84729_p0.read().is_01() || !mul_ln1118_232_fu_84729_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_232_fu_84729_p0.read()) * sc_bigint<2>(mul_ln1118_232_fu_84729_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_233_fu_84741_p0() {
    mul_ln1118_233_fu_84741_p0 =  (sc_lv<10>) (zext_ln1116_178_fu_84735_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_233_fu_84741_p1() {
    mul_ln1118_233_fu_84741_p1 = tmp_392_reg_131291.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_233_fu_84741_p2() {
    mul_ln1118_233_fu_84741_p2 = (!mul_ln1118_233_fu_84741_p0.read().is_01() || !mul_ln1118_233_fu_84741_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_233_fu_84741_p0.read()) * sc_bigint<2>(mul_ln1118_233_fu_84741_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_234_fu_84765_p0() {
    mul_ln1118_234_fu_84765_p0 =  (sc_lv<10>) (zext_ln1116_179_fu_84759_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_234_fu_84765_p1() {
    mul_ln1118_234_fu_84765_p1 = tmp_394_reg_131301.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_234_fu_84765_p2() {
    mul_ln1118_234_fu_84765_p2 = (!mul_ln1118_234_fu_84765_p0.read().is_01() || !mul_ln1118_234_fu_84765_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_234_fu_84765_p0.read()) * sc_bigint<2>(mul_ln1118_234_fu_84765_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_235_fu_84789_p0() {
    mul_ln1118_235_fu_84789_p0 =  (sc_lv<10>) (zext_ln1116_180_fu_84783_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_235_fu_84789_p1() {
    mul_ln1118_235_fu_84789_p1 = tmp_396_reg_131311.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_235_fu_84789_p2() {
    mul_ln1118_235_fu_84789_p2 = (!mul_ln1118_235_fu_84789_p0.read().is_01() || !mul_ln1118_235_fu_84789_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_235_fu_84789_p0.read()) * sc_bigint<2>(mul_ln1118_235_fu_84789_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_236_fu_84813_p0() {
    mul_ln1118_236_fu_84813_p0 =  (sc_lv<10>) (zext_ln1116_181_fu_84807_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_236_fu_84813_p1() {
    mul_ln1118_236_fu_84813_p1 = tmp_398_reg_131321.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_236_fu_84813_p2() {
    mul_ln1118_236_fu_84813_p2 = (!mul_ln1118_236_fu_84813_p0.read().is_01() || !mul_ln1118_236_fu_84813_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_236_fu_84813_p0.read()) * sc_bigint<2>(mul_ln1118_236_fu_84813_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_237_fu_84837_p0() {
    mul_ln1118_237_fu_84837_p0 =  (sc_lv<10>) (zext_ln1116_182_fu_84831_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_237_fu_84837_p1() {
    mul_ln1118_237_fu_84837_p1 = tmp_400_reg_131331.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_237_fu_84837_p2() {
    mul_ln1118_237_fu_84837_p2 = (!mul_ln1118_237_fu_84837_p0.read().is_01() || !mul_ln1118_237_fu_84837_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_237_fu_84837_p0.read()) * sc_bigint<2>(mul_ln1118_237_fu_84837_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_238_fu_84849_p0() {
    mul_ln1118_238_fu_84849_p0 =  (sc_lv<10>) (zext_ln1116_183_fu_84843_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_238_fu_84849_p1() {
    mul_ln1118_238_fu_84849_p1 = tmp_402_reg_131341.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_238_fu_84849_p2() {
    mul_ln1118_238_fu_84849_p2 = (!mul_ln1118_238_fu_84849_p0.read().is_01() || !mul_ln1118_238_fu_84849_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_238_fu_84849_p0.read()) * sc_bigint<2>(mul_ln1118_238_fu_84849_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_239_fu_84873_p0() {
    mul_ln1118_239_fu_84873_p0 =  (sc_lv<10>) (zext_ln1116_184_fu_84867_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_239_fu_84873_p1() {
    mul_ln1118_239_fu_84873_p1 = tmp_404_reg_131351.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_239_fu_84873_p2() {
    mul_ln1118_239_fu_84873_p2 = (!mul_ln1118_239_fu_84873_p0.read().is_01() || !mul_ln1118_239_fu_84873_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_239_fu_84873_p0.read()) * sc_bigint<2>(mul_ln1118_239_fu_84873_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_23_fu_80079_p0() {
    mul_ln1118_23_fu_80079_p0 =  (sc_lv<10>) (mul_ln1118_23_fu_80079_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_23_fu_80079_p00() {
    mul_ln1118_23_fu_80079_p00 = esl_zext<12,10>(trunc_ln77_20_reg_129461.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_23_fu_80079_p1() {
    mul_ln1118_23_fu_80079_p1 = tmp_39_reg_129466.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_23_fu_80079_p2() {
    mul_ln1118_23_fu_80079_p2 = (!mul_ln1118_23_fu_80079_p0.read().is_01() || !mul_ln1118_23_fu_80079_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_23_fu_80079_p0.read()) * sc_bigint<2>(mul_ln1118_23_fu_80079_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_240_fu_84897_p0() {
    mul_ln1118_240_fu_84897_p0 =  (sc_lv<10>) (zext_ln1116_185_fu_84891_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_240_fu_84897_p1() {
    mul_ln1118_240_fu_84897_p1 = tmp_405_reg_131361.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_240_fu_84897_p2() {
    mul_ln1118_240_fu_84897_p2 = (!mul_ln1118_240_fu_84897_p0.read().is_01() || !mul_ln1118_240_fu_84897_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_240_fu_84897_p0.read()) * sc_bigint<2>(mul_ln1118_240_fu_84897_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_241_fu_84921_p0() {
    mul_ln1118_241_fu_84921_p0 =  (sc_lv<10>) (zext_ln1116_186_fu_84915_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_241_fu_84921_p1() {
    mul_ln1118_241_fu_84921_p1 = tmp_406_reg_131371.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_241_fu_84921_p2() {
    mul_ln1118_241_fu_84921_p2 = (!mul_ln1118_241_fu_84921_p0.read().is_01() || !mul_ln1118_241_fu_84921_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_241_fu_84921_p0.read()) * sc_bigint<2>(mul_ln1118_241_fu_84921_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_242_fu_84945_p0() {
    mul_ln1118_242_fu_84945_p0 =  (sc_lv<10>) (zext_ln1116_187_fu_84939_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_242_fu_84945_p1() {
    mul_ln1118_242_fu_84945_p1 = tmp_407_reg_131381.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_242_fu_84945_p2() {
    mul_ln1118_242_fu_84945_p2 = (!mul_ln1118_242_fu_84945_p0.read().is_01() || !mul_ln1118_242_fu_84945_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_242_fu_84945_p0.read()) * sc_bigint<2>(mul_ln1118_242_fu_84945_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_243_fu_84957_p0() {
    mul_ln1118_243_fu_84957_p0 =  (sc_lv<10>) (zext_ln1116_188_fu_84951_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_243_fu_84957_p1() {
    mul_ln1118_243_fu_84957_p1 = tmp_408_reg_131391.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_243_fu_84957_p2() {
    mul_ln1118_243_fu_84957_p2 = (!mul_ln1118_243_fu_84957_p0.read().is_01() || !mul_ln1118_243_fu_84957_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_243_fu_84957_p0.read()) * sc_bigint<2>(mul_ln1118_243_fu_84957_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_244_fu_84981_p0() {
    mul_ln1118_244_fu_84981_p0 =  (sc_lv<10>) (zext_ln1116_189_fu_84975_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_244_fu_84981_p1() {
    mul_ln1118_244_fu_84981_p1 = tmp_409_reg_131401.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_244_fu_84981_p2() {
    mul_ln1118_244_fu_84981_p2 = (!mul_ln1118_244_fu_84981_p0.read().is_01() || !mul_ln1118_244_fu_84981_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_244_fu_84981_p0.read()) * sc_bigint<2>(mul_ln1118_244_fu_84981_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_245_fu_85005_p0() {
    mul_ln1118_245_fu_85005_p0 =  (sc_lv<10>) (zext_ln1116_190_fu_84999_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_245_fu_85005_p1() {
    mul_ln1118_245_fu_85005_p1 = tmp_410_reg_131411.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_245_fu_85005_p2() {
    mul_ln1118_245_fu_85005_p2 = (!mul_ln1118_245_fu_85005_p0.read().is_01() || !mul_ln1118_245_fu_85005_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_245_fu_85005_p0.read()) * sc_bigint<2>(mul_ln1118_245_fu_85005_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_246_fu_85029_p0() {
    mul_ln1118_246_fu_85029_p0 =  (sc_lv<10>) (zext_ln1116_191_fu_85023_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_246_fu_85029_p1() {
    mul_ln1118_246_fu_85029_p1 = tmp_411_reg_131421.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_246_fu_85029_p2() {
    mul_ln1118_246_fu_85029_p2 = (!mul_ln1118_246_fu_85029_p0.read().is_01() || !mul_ln1118_246_fu_85029_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_246_fu_85029_p0.read()) * sc_bigint<2>(mul_ln1118_246_fu_85029_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_247_fu_85053_p0() {
    mul_ln1118_247_fu_85053_p0 =  (sc_lv<10>) (zext_ln1116_192_fu_85047_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_247_fu_85053_p1() {
    mul_ln1118_247_fu_85053_p1 = tmp_412_reg_131431.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_247_fu_85053_p2() {
    mul_ln1118_247_fu_85053_p2 = (!mul_ln1118_247_fu_85053_p0.read().is_01() || !mul_ln1118_247_fu_85053_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_247_fu_85053_p0.read()) * sc_bigint<2>(mul_ln1118_247_fu_85053_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_248_fu_85065_p0() {
    mul_ln1118_248_fu_85065_p0 =  (sc_lv<10>) (zext_ln1116_193_fu_85059_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_248_fu_85065_p1() {
    mul_ln1118_248_fu_85065_p1 = tmp_413_reg_131441.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_248_fu_85065_p2() {
    mul_ln1118_248_fu_85065_p2 = (!mul_ln1118_248_fu_85065_p0.read().is_01() || !mul_ln1118_248_fu_85065_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_248_fu_85065_p0.read()) * sc_bigint<2>(mul_ln1118_248_fu_85065_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_249_fu_85089_p0() {
    mul_ln1118_249_fu_85089_p0 =  (sc_lv<10>) (zext_ln1116_194_fu_85083_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_249_fu_85089_p1() {
    mul_ln1118_249_fu_85089_p1 = tmp_414_reg_131451.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_249_fu_85089_p2() {
    mul_ln1118_249_fu_85089_p2 = (!mul_ln1118_249_fu_85089_p0.read().is_01() || !mul_ln1118_249_fu_85089_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_249_fu_85089_p0.read()) * sc_bigint<2>(mul_ln1118_249_fu_85089_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_24_fu_80103_p0() {
    mul_ln1118_24_fu_80103_p0 =  (sc_lv<10>) (mul_ln1118_24_fu_80103_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_24_fu_80103_p00() {
    mul_ln1118_24_fu_80103_p00 = esl_zext<12,10>(trunc_ln77_21_reg_129471.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_24_fu_80103_p1() {
    mul_ln1118_24_fu_80103_p1 = tmp_41_reg_129476.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_24_fu_80103_p2() {
    mul_ln1118_24_fu_80103_p2 = (!mul_ln1118_24_fu_80103_p0.read().is_01() || !mul_ln1118_24_fu_80103_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_24_fu_80103_p0.read()) * sc_bigint<2>(mul_ln1118_24_fu_80103_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_250_fu_85113_p0() {
    mul_ln1118_250_fu_85113_p0 =  (sc_lv<10>) (zext_ln1116_195_fu_85107_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_250_fu_85113_p1() {
    mul_ln1118_250_fu_85113_p1 = tmp_415_reg_131461.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_250_fu_85113_p2() {
    mul_ln1118_250_fu_85113_p2 = (!mul_ln1118_250_fu_85113_p0.read().is_01() || !mul_ln1118_250_fu_85113_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_250_fu_85113_p0.read()) * sc_bigint<2>(mul_ln1118_250_fu_85113_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_251_fu_85125_p0() {
    mul_ln1118_251_fu_85125_p0 =  (sc_lv<10>) (zext_ln1116_196_fu_85119_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_251_fu_85125_p1() {
    mul_ln1118_251_fu_85125_p1 = tmp_416_reg_131471.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_251_fu_85125_p2() {
    mul_ln1118_251_fu_85125_p2 = (!mul_ln1118_251_fu_85125_p0.read().is_01() || !mul_ln1118_251_fu_85125_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_251_fu_85125_p0.read()) * sc_bigint<2>(mul_ln1118_251_fu_85125_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_252_fu_85149_p0() {
    mul_ln1118_252_fu_85149_p0 =  (sc_lv<10>) (zext_ln1116_197_fu_85143_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_252_fu_85149_p1() {
    mul_ln1118_252_fu_85149_p1 = tmp_417_reg_131481.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_252_fu_85149_p2() {
    mul_ln1118_252_fu_85149_p2 = (!mul_ln1118_252_fu_85149_p0.read().is_01() || !mul_ln1118_252_fu_85149_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_252_fu_85149_p0.read()) * sc_bigint<2>(mul_ln1118_252_fu_85149_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_253_fu_85173_p0() {
    mul_ln1118_253_fu_85173_p0 =  (sc_lv<10>) (zext_ln1116_198_fu_85167_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_253_fu_85173_p1() {
    mul_ln1118_253_fu_85173_p1 = tmp_418_reg_131491.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_253_fu_85173_p2() {
    mul_ln1118_253_fu_85173_p2 = (!mul_ln1118_253_fu_85173_p0.read().is_01() || !mul_ln1118_253_fu_85173_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_253_fu_85173_p0.read()) * sc_bigint<2>(mul_ln1118_253_fu_85173_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_254_fu_85185_p0() {
    mul_ln1118_254_fu_85185_p0 =  (sc_lv<10>) (zext_ln1116_199_fu_85179_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_254_fu_85185_p1() {
    mul_ln1118_254_fu_85185_p1 = tmp_419_reg_131501.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_254_fu_85185_p2() {
    mul_ln1118_254_fu_85185_p2 = (!mul_ln1118_254_fu_85185_p0.read().is_01() || !mul_ln1118_254_fu_85185_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_254_fu_85185_p0.read()) * sc_bigint<2>(mul_ln1118_254_fu_85185_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_255_fu_85209_p0() {
    mul_ln1118_255_fu_85209_p0 =  (sc_lv<10>) (zext_ln1116_200_fu_85203_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_255_fu_85209_p1() {
    mul_ln1118_255_fu_85209_p1 = tmp_420_reg_131511.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_255_fu_85209_p2() {
    mul_ln1118_255_fu_85209_p2 = (!mul_ln1118_255_fu_85209_p0.read().is_01() || !mul_ln1118_255_fu_85209_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_255_fu_85209_p0.read()) * sc_bigint<2>(mul_ln1118_255_fu_85209_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_256_fu_85425_p0() {
    mul_ln1118_256_fu_85425_p0 =  (sc_lv<10>) (zext_ln1116_201_fu_85419_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_256_fu_85425_p1() {
    mul_ln1118_256_fu_85425_p1 = tmp_422_reg_131516.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_256_fu_85425_p2() {
    mul_ln1118_256_fu_85425_p2 = (!mul_ln1118_256_fu_85425_p0.read().is_01() || !mul_ln1118_256_fu_85425_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_256_fu_85425_p0.read()) * sc_bigint<2>(mul_ln1118_256_fu_85425_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_257_fu_85449_p0() {
    mul_ln1118_257_fu_85449_p0 =  (sc_lv<10>) (zext_ln1116_202_fu_85443_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_257_fu_85449_p1() {
    mul_ln1118_257_fu_85449_p1 = tmp_424_reg_131526.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_257_fu_85449_p2() {
    mul_ln1118_257_fu_85449_p2 = (!mul_ln1118_257_fu_85449_p0.read().is_01() || !mul_ln1118_257_fu_85449_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_257_fu_85449_p0.read()) * sc_bigint<2>(mul_ln1118_257_fu_85449_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_258_fu_85473_p0() {
    mul_ln1118_258_fu_85473_p0 =  (sc_lv<10>) (zext_ln1116_203_fu_85467_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_258_fu_85473_p1() {
    mul_ln1118_258_fu_85473_p1 = tmp_426_reg_131536.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_258_fu_85473_p2() {
    mul_ln1118_258_fu_85473_p2 = (!mul_ln1118_258_fu_85473_p0.read().is_01() || !mul_ln1118_258_fu_85473_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_258_fu_85473_p0.read()) * sc_bigint<2>(mul_ln1118_258_fu_85473_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_259_fu_85485_p0() {
    mul_ln1118_259_fu_85485_p0 =  (sc_lv<10>) (zext_ln1116_204_fu_85479_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_259_fu_85485_p1() {
    mul_ln1118_259_fu_85485_p1 = tmp_428_reg_131546.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_259_fu_85485_p2() {
    mul_ln1118_259_fu_85485_p2 = (!mul_ln1118_259_fu_85485_p0.read().is_01() || !mul_ln1118_259_fu_85485_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_259_fu_85485_p0.read()) * sc_bigint<2>(mul_ln1118_259_fu_85485_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_25_fu_80127_p0() {
    mul_ln1118_25_fu_80127_p0 =  (sc_lv<10>) (mul_ln1118_25_fu_80127_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_25_fu_80127_p00() {
    mul_ln1118_25_fu_80127_p00 = esl_zext<12,10>(trunc_ln77_22_reg_129481.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_25_fu_80127_p1() {
    mul_ln1118_25_fu_80127_p1 = tmp_43_reg_129486.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_25_fu_80127_p2() {
    mul_ln1118_25_fu_80127_p2 = (!mul_ln1118_25_fu_80127_p0.read().is_01() || !mul_ln1118_25_fu_80127_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_25_fu_80127_p0.read()) * sc_bigint<2>(mul_ln1118_25_fu_80127_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_260_fu_85509_p0() {
    mul_ln1118_260_fu_85509_p0 =  (sc_lv<10>) (zext_ln1116_205_fu_85503_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_260_fu_85509_p1() {
    mul_ln1118_260_fu_85509_p1 = tmp_429_reg_131556.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_260_fu_85509_p2() {
    mul_ln1118_260_fu_85509_p2 = (!mul_ln1118_260_fu_85509_p0.read().is_01() || !mul_ln1118_260_fu_85509_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_260_fu_85509_p0.read()) * sc_bigint<2>(mul_ln1118_260_fu_85509_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_261_fu_85533_p0() {
    mul_ln1118_261_fu_85533_p0 =  (sc_lv<10>) (zext_ln1116_206_fu_85527_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_261_fu_85533_p1() {
    mul_ln1118_261_fu_85533_p1 = tmp_431_reg_131566.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_261_fu_85533_p2() {
    mul_ln1118_261_fu_85533_p2 = (!mul_ln1118_261_fu_85533_p0.read().is_01() || !mul_ln1118_261_fu_85533_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_261_fu_85533_p0.read()) * sc_bigint<2>(mul_ln1118_261_fu_85533_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_262_fu_85557_p0() {
    mul_ln1118_262_fu_85557_p0 =  (sc_lv<10>) (zext_ln1116_207_fu_85551_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_262_fu_85557_p1() {
    mul_ln1118_262_fu_85557_p1 = tmp_433_reg_131576.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_262_fu_85557_p2() {
    mul_ln1118_262_fu_85557_p2 = (!mul_ln1118_262_fu_85557_p0.read().is_01() || !mul_ln1118_262_fu_85557_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_262_fu_85557_p0.read()) * sc_bigint<2>(mul_ln1118_262_fu_85557_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_263_fu_85581_p0() {
    mul_ln1118_263_fu_85581_p0 =  (sc_lv<10>) (zext_ln1116_208_fu_85575_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_263_fu_85581_p1() {
    mul_ln1118_263_fu_85581_p1 = tmp_435_reg_131586.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_263_fu_85581_p2() {
    mul_ln1118_263_fu_85581_p2 = (!mul_ln1118_263_fu_85581_p0.read().is_01() || !mul_ln1118_263_fu_85581_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_263_fu_85581_p0.read()) * sc_bigint<2>(mul_ln1118_263_fu_85581_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_264_fu_85593_p0() {
    mul_ln1118_264_fu_85593_p0 =  (sc_lv<10>) (zext_ln1116_209_fu_85587_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_264_fu_85593_p1() {
    mul_ln1118_264_fu_85593_p1 = tmp_436_reg_131596.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_264_fu_85593_p2() {
    mul_ln1118_264_fu_85593_p2 = (!mul_ln1118_264_fu_85593_p0.read().is_01() || !mul_ln1118_264_fu_85593_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_264_fu_85593_p0.read()) * sc_bigint<2>(mul_ln1118_264_fu_85593_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_265_fu_85617_p0() {
    mul_ln1118_265_fu_85617_p0 =  (sc_lv<10>) (zext_ln1116_210_fu_85611_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_265_fu_85617_p1() {
    mul_ln1118_265_fu_85617_p1 = tmp_437_reg_131606.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_265_fu_85617_p2() {
    mul_ln1118_265_fu_85617_p2 = (!mul_ln1118_265_fu_85617_p0.read().is_01() || !mul_ln1118_265_fu_85617_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_265_fu_85617_p0.read()) * sc_bigint<2>(mul_ln1118_265_fu_85617_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_266_fu_85641_p0() {
    mul_ln1118_266_fu_85641_p0 =  (sc_lv<10>) (zext_ln1116_211_fu_85635_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_266_fu_85641_p1() {
    mul_ln1118_266_fu_85641_p1 = tmp_439_reg_131616.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_266_fu_85641_p2() {
    mul_ln1118_266_fu_85641_p2 = (!mul_ln1118_266_fu_85641_p0.read().is_01() || !mul_ln1118_266_fu_85641_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_266_fu_85641_p0.read()) * sc_bigint<2>(mul_ln1118_266_fu_85641_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_267_fu_85665_p0() {
    mul_ln1118_267_fu_85665_p0 =  (sc_lv<10>) (zext_ln1116_212_fu_85659_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_267_fu_85665_p1() {
    mul_ln1118_267_fu_85665_p1 = tmp_441_reg_131626.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_267_fu_85665_p2() {
    mul_ln1118_267_fu_85665_p2 = (!mul_ln1118_267_fu_85665_p0.read().is_01() || !mul_ln1118_267_fu_85665_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_267_fu_85665_p0.read()) * sc_bigint<2>(mul_ln1118_267_fu_85665_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_268_fu_85689_p0() {
    mul_ln1118_268_fu_85689_p0 =  (sc_lv<10>) (zext_ln1116_213_fu_85683_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_268_fu_85689_p1() {
    mul_ln1118_268_fu_85689_p1 = tmp_443_reg_131636.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_268_fu_85689_p2() {
    mul_ln1118_268_fu_85689_p2 = (!mul_ln1118_268_fu_85689_p0.read().is_01() || !mul_ln1118_268_fu_85689_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_268_fu_85689_p0.read()) * sc_bigint<2>(mul_ln1118_268_fu_85689_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_269_fu_85701_p0() {
    mul_ln1118_269_fu_85701_p0 =  (sc_lv<10>) (zext_ln1116_214_fu_85695_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_269_fu_85701_p1() {
    mul_ln1118_269_fu_85701_p1 = tmp_445_reg_131646.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_269_fu_85701_p2() {
    mul_ln1118_269_fu_85701_p2 = (!mul_ln1118_269_fu_85701_p0.read().is_01() || !mul_ln1118_269_fu_85701_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_269_fu_85701_p0.read()) * sc_bigint<2>(mul_ln1118_269_fu_85701_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_26_fu_80151_p0() {
    mul_ln1118_26_fu_80151_p0 =  (sc_lv<10>) (mul_ln1118_26_fu_80151_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_26_fu_80151_p00() {
    mul_ln1118_26_fu_80151_p00 = esl_zext<12,10>(trunc_ln77_23_reg_129491.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_26_fu_80151_p1() {
    mul_ln1118_26_fu_80151_p1 = tmp_45_reg_129496.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_26_fu_80151_p2() {
    mul_ln1118_26_fu_80151_p2 = (!mul_ln1118_26_fu_80151_p0.read().is_01() || !mul_ln1118_26_fu_80151_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_26_fu_80151_p0.read()) * sc_bigint<2>(mul_ln1118_26_fu_80151_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_270_fu_85725_p0() {
    mul_ln1118_270_fu_85725_p0 =  (sc_lv<10>) (zext_ln1116_215_fu_85719_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_270_fu_85725_p1() {
    mul_ln1118_270_fu_85725_p1 = tmp_447_reg_131656.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_270_fu_85725_p2() {
    mul_ln1118_270_fu_85725_p2 = (!mul_ln1118_270_fu_85725_p0.read().is_01() || !mul_ln1118_270_fu_85725_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_270_fu_85725_p0.read()) * sc_bigint<2>(mul_ln1118_270_fu_85725_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_271_fu_85749_p0() {
    mul_ln1118_271_fu_85749_p0 =  (sc_lv<10>) (zext_ln1116_216_fu_85743_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_271_fu_85749_p1() {
    mul_ln1118_271_fu_85749_p1 = tmp_449_reg_131666.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_271_fu_85749_p2() {
    mul_ln1118_271_fu_85749_p2 = (!mul_ln1118_271_fu_85749_p0.read().is_01() || !mul_ln1118_271_fu_85749_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_271_fu_85749_p0.read()) * sc_bigint<2>(mul_ln1118_271_fu_85749_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_272_fu_85761_p0() {
    mul_ln1118_272_fu_85761_p0 =  (sc_lv<10>) (zext_ln1116_217_fu_85755_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_272_fu_85761_p1() {
    mul_ln1118_272_fu_85761_p1 = tmp_451_reg_131676.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_272_fu_85761_p2() {
    mul_ln1118_272_fu_85761_p2 = (!mul_ln1118_272_fu_85761_p0.read().is_01() || !mul_ln1118_272_fu_85761_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_272_fu_85761_p0.read()) * sc_bigint<2>(mul_ln1118_272_fu_85761_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_273_fu_85785_p0() {
    mul_ln1118_273_fu_85785_p0 =  (sc_lv<10>) (zext_ln1116_218_fu_85779_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_273_fu_85785_p1() {
    mul_ln1118_273_fu_85785_p1 = tmp_452_reg_131686.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_273_fu_85785_p2() {
    mul_ln1118_273_fu_85785_p2 = (!mul_ln1118_273_fu_85785_p0.read().is_01() || !mul_ln1118_273_fu_85785_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_273_fu_85785_p0.read()) * sc_bigint<2>(mul_ln1118_273_fu_85785_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_274_fu_85809_p0() {
    mul_ln1118_274_fu_85809_p0 =  (sc_lv<10>) (zext_ln1116_219_fu_85803_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_274_fu_85809_p1() {
    mul_ln1118_274_fu_85809_p1 = tmp_453_reg_131696.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_274_fu_85809_p2() {
    mul_ln1118_274_fu_85809_p2 = (!mul_ln1118_274_fu_85809_p0.read().is_01() || !mul_ln1118_274_fu_85809_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_274_fu_85809_p0.read()) * sc_bigint<2>(mul_ln1118_274_fu_85809_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_275_fu_85821_p0() {
    mul_ln1118_275_fu_85821_p0 =  (sc_lv<10>) (zext_ln1116_220_fu_85815_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_275_fu_85821_p1() {
    mul_ln1118_275_fu_85821_p1 = tmp_454_reg_131706.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_275_fu_85821_p2() {
    mul_ln1118_275_fu_85821_p2 = (!mul_ln1118_275_fu_85821_p0.read().is_01() || !mul_ln1118_275_fu_85821_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_275_fu_85821_p0.read()) * sc_bigint<2>(mul_ln1118_275_fu_85821_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_276_fu_85845_p0() {
    mul_ln1118_276_fu_85845_p0 =  (sc_lv<10>) (zext_ln1116_221_fu_85839_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_276_fu_85845_p1() {
    mul_ln1118_276_fu_85845_p1 = tmp_455_reg_131716.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_276_fu_85845_p2() {
    mul_ln1118_276_fu_85845_p2 = (!mul_ln1118_276_fu_85845_p0.read().is_01() || !mul_ln1118_276_fu_85845_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_276_fu_85845_p0.read()) * sc_bigint<2>(mul_ln1118_276_fu_85845_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_277_fu_85869_p0() {
    mul_ln1118_277_fu_85869_p0 =  (sc_lv<10>) (zext_ln1116_222_fu_85863_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_277_fu_85869_p1() {
    mul_ln1118_277_fu_85869_p1 = tmp_457_reg_131726.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_277_fu_85869_p2() {
    mul_ln1118_277_fu_85869_p2 = (!mul_ln1118_277_fu_85869_p0.read().is_01() || !mul_ln1118_277_fu_85869_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_277_fu_85869_p0.read()) * sc_bigint<2>(mul_ln1118_277_fu_85869_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_278_fu_85893_p0() {
    mul_ln1118_278_fu_85893_p0 =  (sc_lv<10>) (zext_ln1116_223_fu_85887_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_278_fu_85893_p1() {
    mul_ln1118_278_fu_85893_p1 = tmp_459_reg_131736.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_278_fu_85893_p2() {
    mul_ln1118_278_fu_85893_p2 = (!mul_ln1118_278_fu_85893_p0.read().is_01() || !mul_ln1118_278_fu_85893_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_278_fu_85893_p0.read()) * sc_bigint<2>(mul_ln1118_278_fu_85893_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_279_fu_85917_p0() {
    mul_ln1118_279_fu_85917_p0 =  (sc_lv<10>) (zext_ln1116_224_fu_85911_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_279_fu_85917_p1() {
    mul_ln1118_279_fu_85917_p1 = tmp_461_reg_131746.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_279_fu_85917_p2() {
    mul_ln1118_279_fu_85917_p2 = (!mul_ln1118_279_fu_85917_p0.read().is_01() || !mul_ln1118_279_fu_85917_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_279_fu_85917_p0.read()) * sc_bigint<2>(mul_ln1118_279_fu_85917_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_27_fu_80175_p0() {
    mul_ln1118_27_fu_80175_p0 =  (sc_lv<10>) (mul_ln1118_27_fu_80175_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_27_fu_80175_p00() {
    mul_ln1118_27_fu_80175_p00 = esl_zext<12,10>(trunc_ln77_24_reg_129501.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_27_fu_80175_p1() {
    mul_ln1118_27_fu_80175_p1 = tmp_47_reg_129506.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_27_fu_80175_p2() {
    mul_ln1118_27_fu_80175_p2 = (!mul_ln1118_27_fu_80175_p0.read().is_01() || !mul_ln1118_27_fu_80175_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_27_fu_80175_p0.read()) * sc_bigint<2>(mul_ln1118_27_fu_80175_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_280_fu_85929_p0() {
    mul_ln1118_280_fu_85929_p0 =  (sc_lv<10>) (mul_ln1118_280_fu_85929_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_280_fu_85929_p00() {
    mul_ln1118_280_fu_85929_p00 = esl_zext<12,10>(trunc_ln77_223_reg_131751.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_280_fu_85929_p1() {
    mul_ln1118_280_fu_85929_p1 = tmp_463_reg_131756.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_280_fu_85929_p2() {
    mul_ln1118_280_fu_85929_p2 = (!mul_ln1118_280_fu_85929_p0.read().is_01() || !mul_ln1118_280_fu_85929_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_280_fu_85929_p0.read()) * sc_bigint<2>(mul_ln1118_280_fu_85929_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_281_fu_85953_p0() {
    mul_ln1118_281_fu_85953_p0 =  (sc_lv<10>) (mul_ln1118_281_fu_85953_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_281_fu_85953_p00() {
    mul_ln1118_281_fu_85953_p00 = esl_zext<12,10>(trunc_ln77_224_reg_131761.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_281_fu_85953_p1() {
    mul_ln1118_281_fu_85953_p1 = tmp_465_reg_131766.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_281_fu_85953_p2() {
    mul_ln1118_281_fu_85953_p2 = (!mul_ln1118_281_fu_85953_p0.read().is_01() || !mul_ln1118_281_fu_85953_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_281_fu_85953_p0.read()) * sc_bigint<2>(mul_ln1118_281_fu_85953_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_282_fu_85977_p0() {
    mul_ln1118_282_fu_85977_p0 =  (sc_lv<10>) (mul_ln1118_282_fu_85977_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_282_fu_85977_p00() {
    mul_ln1118_282_fu_85977_p00 = esl_zext<12,10>(trunc_ln77_225_reg_131771.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_282_fu_85977_p1() {
    mul_ln1118_282_fu_85977_p1 = tmp_467_reg_131776.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_282_fu_85977_p2() {
    mul_ln1118_282_fu_85977_p2 = (!mul_ln1118_282_fu_85977_p0.read().is_01() || !mul_ln1118_282_fu_85977_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_282_fu_85977_p0.read()) * sc_bigint<2>(mul_ln1118_282_fu_85977_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_283_fu_86001_p0() {
    mul_ln1118_283_fu_86001_p0 =  (sc_lv<10>) (mul_ln1118_283_fu_86001_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_283_fu_86001_p00() {
    mul_ln1118_283_fu_86001_p00 = esl_zext<12,10>(trunc_ln77_226_reg_131781.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_283_fu_86001_p1() {
    mul_ln1118_283_fu_86001_p1 = tmp_469_reg_131786.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_283_fu_86001_p2() {
    mul_ln1118_283_fu_86001_p2 = (!mul_ln1118_283_fu_86001_p0.read().is_01() || !mul_ln1118_283_fu_86001_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_283_fu_86001_p0.read()) * sc_bigint<2>(mul_ln1118_283_fu_86001_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_284_fu_86025_p0() {
    mul_ln1118_284_fu_86025_p0 =  (sc_lv<10>) (mul_ln1118_284_fu_86025_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_284_fu_86025_p00() {
    mul_ln1118_284_fu_86025_p00 = esl_zext<12,10>(trunc_ln77_227_reg_131791.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_284_fu_86025_p1() {
    mul_ln1118_284_fu_86025_p1 = tmp_471_reg_131796.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_284_fu_86025_p2() {
    mul_ln1118_284_fu_86025_p2 = (!mul_ln1118_284_fu_86025_p0.read().is_01() || !mul_ln1118_284_fu_86025_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_284_fu_86025_p0.read()) * sc_bigint<2>(mul_ln1118_284_fu_86025_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_285_fu_86037_p0() {
    mul_ln1118_285_fu_86037_p0 =  (sc_lv<10>) (mul_ln1118_285_fu_86037_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_285_fu_86037_p00() {
    mul_ln1118_285_fu_86037_p00 = esl_zext<12,10>(trunc_ln77_228_reg_131801.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_285_fu_86037_p1() {
    mul_ln1118_285_fu_86037_p1 = tmp_473_reg_131806.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_285_fu_86037_p2() {
    mul_ln1118_285_fu_86037_p2 = (!mul_ln1118_285_fu_86037_p0.read().is_01() || !mul_ln1118_285_fu_86037_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_285_fu_86037_p0.read()) * sc_bigint<2>(mul_ln1118_285_fu_86037_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_286_fu_86061_p0() {
    mul_ln1118_286_fu_86061_p0 =  (sc_lv<10>) (mul_ln1118_286_fu_86061_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_286_fu_86061_p00() {
    mul_ln1118_286_fu_86061_p00 = esl_zext<12,10>(trunc_ln77_229_reg_131811.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_286_fu_86061_p1() {
    mul_ln1118_286_fu_86061_p1 = tmp_475_reg_131816.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_286_fu_86061_p2() {
    mul_ln1118_286_fu_86061_p2 = (!mul_ln1118_286_fu_86061_p0.read().is_01() || !mul_ln1118_286_fu_86061_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_286_fu_86061_p0.read()) * sc_bigint<2>(mul_ln1118_286_fu_86061_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_287_fu_86085_p0() {
    mul_ln1118_287_fu_86085_p0 =  (sc_lv<10>) (mul_ln1118_287_fu_86085_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_287_fu_86085_p00() {
    mul_ln1118_287_fu_86085_p00 = esl_zext<12,10>(trunc_ln77_230_reg_131821.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_287_fu_86085_p1() {
    mul_ln1118_287_fu_86085_p1 = tmp_477_reg_131826.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_287_fu_86085_p2() {
    mul_ln1118_287_fu_86085_p2 = (!mul_ln1118_287_fu_86085_p0.read().is_01() || !mul_ln1118_287_fu_86085_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_287_fu_86085_p0.read()) * sc_bigint<2>(mul_ln1118_287_fu_86085_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_288_fu_86109_p0() {
    mul_ln1118_288_fu_86109_p0 =  (sc_lv<10>) (mul_ln1118_288_fu_86109_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_288_fu_86109_p00() {
    mul_ln1118_288_fu_86109_p00 = esl_zext<12,10>(trunc_ln77_231_reg_131831.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_288_fu_86109_p1() {
    mul_ln1118_288_fu_86109_p1 = tmp_479_reg_131836.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_288_fu_86109_p2() {
    mul_ln1118_288_fu_86109_p2 = (!mul_ln1118_288_fu_86109_p0.read().is_01() || !mul_ln1118_288_fu_86109_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_288_fu_86109_p0.read()) * sc_bigint<2>(mul_ln1118_288_fu_86109_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_289_fu_86133_p0() {
    mul_ln1118_289_fu_86133_p0 =  (sc_lv<10>) (mul_ln1118_289_fu_86133_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_289_fu_86133_p00() {
    mul_ln1118_289_fu_86133_p00 = esl_zext<12,10>(trunc_ln77_232_reg_131841.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_289_fu_86133_p1() {
    mul_ln1118_289_fu_86133_p1 = tmp_481_reg_131846.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_289_fu_86133_p2() {
    mul_ln1118_289_fu_86133_p2 = (!mul_ln1118_289_fu_86133_p0.read().is_01() || !mul_ln1118_289_fu_86133_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_289_fu_86133_p0.read()) * sc_bigint<2>(mul_ln1118_289_fu_86133_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_28_fu_80187_p0() {
    mul_ln1118_28_fu_80187_p0 =  (sc_lv<10>) (mul_ln1118_28_fu_80187_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_28_fu_80187_p00() {
    mul_ln1118_28_fu_80187_p00 = esl_zext<12,10>(trunc_ln77_25_reg_129511.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_28_fu_80187_p1() {
    mul_ln1118_28_fu_80187_p1 = tmp_49_reg_129516.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_28_fu_80187_p2() {
    mul_ln1118_28_fu_80187_p2 = (!mul_ln1118_28_fu_80187_p0.read().is_01() || !mul_ln1118_28_fu_80187_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_28_fu_80187_p0.read()) * sc_bigint<2>(mul_ln1118_28_fu_80187_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_290_fu_86145_p0() {
    mul_ln1118_290_fu_86145_p0 =  (sc_lv<10>) (mul_ln1118_290_fu_86145_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_290_fu_86145_p00() {
    mul_ln1118_290_fu_86145_p00 = esl_zext<12,10>(trunc_ln77_233_reg_131851.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_290_fu_86145_p1() {
    mul_ln1118_290_fu_86145_p1 = tmp_482_reg_131856.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_290_fu_86145_p2() {
    mul_ln1118_290_fu_86145_p2 = (!mul_ln1118_290_fu_86145_p0.read().is_01() || !mul_ln1118_290_fu_86145_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_290_fu_86145_p0.read()) * sc_bigint<2>(mul_ln1118_290_fu_86145_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_291_fu_86169_p0() {
    mul_ln1118_291_fu_86169_p0 =  (sc_lv<10>) (mul_ln1118_291_fu_86169_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_291_fu_86169_p00() {
    mul_ln1118_291_fu_86169_p00 = esl_zext<12,10>(trunc_ln77_234_reg_131861.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_291_fu_86169_p1() {
    mul_ln1118_291_fu_86169_p1 = tmp_483_reg_131866.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_291_fu_86169_p2() {
    mul_ln1118_291_fu_86169_p2 = (!mul_ln1118_291_fu_86169_p0.read().is_01() || !mul_ln1118_291_fu_86169_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_291_fu_86169_p0.read()) * sc_bigint<2>(mul_ln1118_291_fu_86169_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_292_fu_86193_p0() {
    mul_ln1118_292_fu_86193_p0 =  (sc_lv<10>) (mul_ln1118_292_fu_86193_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_292_fu_86193_p00() {
    mul_ln1118_292_fu_86193_p00 = esl_zext<12,10>(trunc_ln77_235_reg_131871.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_292_fu_86193_p1() {
    mul_ln1118_292_fu_86193_p1 = tmp_484_reg_131876.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_292_fu_86193_p2() {
    mul_ln1118_292_fu_86193_p2 = (!mul_ln1118_292_fu_86193_p0.read().is_01() || !mul_ln1118_292_fu_86193_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_292_fu_86193_p0.read()) * sc_bigint<2>(mul_ln1118_292_fu_86193_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_293_fu_86205_p0() {
    mul_ln1118_293_fu_86205_p0 =  (sc_lv<10>) (mul_ln1118_293_fu_86205_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_293_fu_86205_p00() {
    mul_ln1118_293_fu_86205_p00 = esl_zext<12,10>(trunc_ln77_236_reg_131881.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_293_fu_86205_p1() {
    mul_ln1118_293_fu_86205_p1 = tmp_485_reg_131886.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_293_fu_86205_p2() {
    mul_ln1118_293_fu_86205_p2 = (!mul_ln1118_293_fu_86205_p0.read().is_01() || !mul_ln1118_293_fu_86205_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_293_fu_86205_p0.read()) * sc_bigint<2>(mul_ln1118_293_fu_86205_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_294_fu_86229_p0() {
    mul_ln1118_294_fu_86229_p0 =  (sc_lv<10>) (mul_ln1118_294_fu_86229_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_294_fu_86229_p00() {
    mul_ln1118_294_fu_86229_p00 = esl_zext<12,10>(trunc_ln77_237_reg_131891.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_294_fu_86229_p1() {
    mul_ln1118_294_fu_86229_p1 = tmp_486_reg_131896.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_294_fu_86229_p2() {
    mul_ln1118_294_fu_86229_p2 = (!mul_ln1118_294_fu_86229_p0.read().is_01() || !mul_ln1118_294_fu_86229_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_294_fu_86229_p0.read()) * sc_bigint<2>(mul_ln1118_294_fu_86229_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_295_fu_86253_p0() {
    mul_ln1118_295_fu_86253_p0 =  (sc_lv<10>) (mul_ln1118_295_fu_86253_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_295_fu_86253_p00() {
    mul_ln1118_295_fu_86253_p00 = esl_zext<12,10>(trunc_ln77_238_reg_131901.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_295_fu_86253_p1() {
    mul_ln1118_295_fu_86253_p1 = tmp_487_reg_131906.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_295_fu_86253_p2() {
    mul_ln1118_295_fu_86253_p2 = (!mul_ln1118_295_fu_86253_p0.read().is_01() || !mul_ln1118_295_fu_86253_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_295_fu_86253_p0.read()) * sc_bigint<2>(mul_ln1118_295_fu_86253_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_296_fu_86265_p0() {
    mul_ln1118_296_fu_86265_p0 =  (sc_lv<10>) (mul_ln1118_296_fu_86265_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_296_fu_86265_p00() {
    mul_ln1118_296_fu_86265_p00 = esl_zext<12,10>(trunc_ln77_239_reg_131911.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_296_fu_86265_p1() {
    mul_ln1118_296_fu_86265_p1 = tmp_488_reg_131916.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_296_fu_86265_p2() {
    mul_ln1118_296_fu_86265_p2 = (!mul_ln1118_296_fu_86265_p0.read().is_01() || !mul_ln1118_296_fu_86265_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_296_fu_86265_p0.read()) * sc_bigint<2>(mul_ln1118_296_fu_86265_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_297_fu_86289_p0() {
    mul_ln1118_297_fu_86289_p0 =  (sc_lv<10>) (mul_ln1118_297_fu_86289_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_297_fu_86289_p00() {
    mul_ln1118_297_fu_86289_p00 = esl_zext<12,10>(trunc_ln77_240_reg_131921.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_297_fu_86289_p1() {
    mul_ln1118_297_fu_86289_p1 = tmp_489_reg_131926.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_297_fu_86289_p2() {
    mul_ln1118_297_fu_86289_p2 = (!mul_ln1118_297_fu_86289_p0.read().is_01() || !mul_ln1118_297_fu_86289_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_297_fu_86289_p0.read()) * sc_bigint<2>(mul_ln1118_297_fu_86289_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_298_fu_86313_p0() {
    mul_ln1118_298_fu_86313_p0 =  (sc_lv<10>) (mul_ln1118_298_fu_86313_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_298_fu_86313_p00() {
    mul_ln1118_298_fu_86313_p00 = esl_zext<12,10>(trunc_ln77_241_reg_131931.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_298_fu_86313_p1() {
    mul_ln1118_298_fu_86313_p1 = tmp_491_reg_131936.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_298_fu_86313_p2() {
    mul_ln1118_298_fu_86313_p2 = (!mul_ln1118_298_fu_86313_p0.read().is_01() || !mul_ln1118_298_fu_86313_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_298_fu_86313_p0.read()) * sc_bigint<2>(mul_ln1118_298_fu_86313_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_299_fu_86337_p0() {
    mul_ln1118_299_fu_86337_p0 =  (sc_lv<10>) (mul_ln1118_299_fu_86337_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_299_fu_86337_p00() {
    mul_ln1118_299_fu_86337_p00 = esl_zext<12,10>(trunc_ln77_242_reg_131941.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_299_fu_86337_p1() {
    mul_ln1118_299_fu_86337_p1 = tmp_493_reg_131946.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_299_fu_86337_p2() {
    mul_ln1118_299_fu_86337_p2 = (!mul_ln1118_299_fu_86337_p0.read().is_01() || !mul_ln1118_299_fu_86337_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_299_fu_86337_p0.read()) * sc_bigint<2>(mul_ln1118_299_fu_86337_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_29_fu_80211_p0() {
    mul_ln1118_29_fu_80211_p0 =  (sc_lv<10>) (mul_ln1118_29_fu_80211_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_29_fu_80211_p00() {
    mul_ln1118_29_fu_80211_p00 = esl_zext<12,10>(trunc_ln77_26_reg_129521.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_29_fu_80211_p1() {
    mul_ln1118_29_fu_80211_p1 = tmp_51_reg_129526.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_29_fu_80211_p2() {
    mul_ln1118_29_fu_80211_p2 = (!mul_ln1118_29_fu_80211_p0.read().is_01() || !mul_ln1118_29_fu_80211_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_29_fu_80211_p0.read()) * sc_bigint<2>(mul_ln1118_29_fu_80211_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_300_fu_86361_p0() {
    mul_ln1118_300_fu_86361_p0 =  (sc_lv<10>) (mul_ln1118_300_fu_86361_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_300_fu_86361_p00() {
    mul_ln1118_300_fu_86361_p00 = esl_zext<12,10>(trunc_ln77_243_reg_131951.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_300_fu_86361_p1() {
    mul_ln1118_300_fu_86361_p1 = tmp_495_reg_131956.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_300_fu_86361_p2() {
    mul_ln1118_300_fu_86361_p2 = (!mul_ln1118_300_fu_86361_p0.read().is_01() || !mul_ln1118_300_fu_86361_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_300_fu_86361_p0.read()) * sc_bigint<2>(mul_ln1118_300_fu_86361_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_301_fu_86373_p0() {
    mul_ln1118_301_fu_86373_p0 =  (sc_lv<10>) (mul_ln1118_301_fu_86373_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_301_fu_86373_p00() {
    mul_ln1118_301_fu_86373_p00 = esl_zext<12,10>(trunc_ln77_244_reg_131961.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_301_fu_86373_p1() {
    mul_ln1118_301_fu_86373_p1 = tmp_497_reg_131966.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_301_fu_86373_p2() {
    mul_ln1118_301_fu_86373_p2 = (!mul_ln1118_301_fu_86373_p0.read().is_01() || !mul_ln1118_301_fu_86373_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_301_fu_86373_p0.read()) * sc_bigint<2>(mul_ln1118_301_fu_86373_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_302_fu_86397_p0() {
    mul_ln1118_302_fu_86397_p0 =  (sc_lv<10>) (mul_ln1118_302_fu_86397_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_302_fu_86397_p00() {
    mul_ln1118_302_fu_86397_p00 = esl_zext<12,10>(trunc_ln77_245_reg_131971.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_302_fu_86397_p1() {
    mul_ln1118_302_fu_86397_p1 = tmp_499_reg_131976.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_302_fu_86397_p2() {
    mul_ln1118_302_fu_86397_p2 = (!mul_ln1118_302_fu_86397_p0.read().is_01() || !mul_ln1118_302_fu_86397_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_302_fu_86397_p0.read()) * sc_bigint<2>(mul_ln1118_302_fu_86397_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_303_fu_86421_p0() {
    mul_ln1118_303_fu_86421_p0 =  (sc_lv<10>) (mul_ln1118_303_fu_86421_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_303_fu_86421_p00() {
    mul_ln1118_303_fu_86421_p00 = esl_zext<12,10>(trunc_ln77_246_reg_131981.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_303_fu_86421_p1() {
    mul_ln1118_303_fu_86421_p1 = tmp_501_reg_131986.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_303_fu_86421_p2() {
    mul_ln1118_303_fu_86421_p2 = (!mul_ln1118_303_fu_86421_p0.read().is_01() || !mul_ln1118_303_fu_86421_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_303_fu_86421_p0.read()) * sc_bigint<2>(mul_ln1118_303_fu_86421_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_304_fu_86445_p0() {
    mul_ln1118_304_fu_86445_p0 =  (sc_lv<10>) (mul_ln1118_304_fu_86445_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_304_fu_86445_p00() {
    mul_ln1118_304_fu_86445_p00 = esl_zext<12,10>(trunc_ln77_247_reg_131991.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_304_fu_86445_p1() {
    mul_ln1118_304_fu_86445_p1 = tmp_503_reg_131996.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_304_fu_86445_p2() {
    mul_ln1118_304_fu_86445_p2 = (!mul_ln1118_304_fu_86445_p0.read().is_01() || !mul_ln1118_304_fu_86445_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_304_fu_86445_p0.read()) * sc_bigint<2>(mul_ln1118_304_fu_86445_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_305_fu_86469_p0() {
    mul_ln1118_305_fu_86469_p0 =  (sc_lv<10>) (mul_ln1118_305_fu_86469_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_305_fu_86469_p00() {
    mul_ln1118_305_fu_86469_p00 = esl_zext<12,10>(trunc_ln77_248_reg_132001.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_305_fu_86469_p1() {
    mul_ln1118_305_fu_86469_p1 = tmp_505_reg_132006.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_305_fu_86469_p2() {
    mul_ln1118_305_fu_86469_p2 = (!mul_ln1118_305_fu_86469_p0.read().is_01() || !mul_ln1118_305_fu_86469_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_305_fu_86469_p0.read()) * sc_bigint<2>(mul_ln1118_305_fu_86469_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_306_fu_86481_p0() {
    mul_ln1118_306_fu_86481_p0 =  (sc_lv<10>) (mul_ln1118_306_fu_86481_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_306_fu_86481_p00() {
    mul_ln1118_306_fu_86481_p00 = esl_zext<12,10>(trunc_ln77_249_reg_132011.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_306_fu_86481_p1() {
    mul_ln1118_306_fu_86481_p1 = tmp_507_reg_132016.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_306_fu_86481_p2() {
    mul_ln1118_306_fu_86481_p2 = (!mul_ln1118_306_fu_86481_p0.read().is_01() || !mul_ln1118_306_fu_86481_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_306_fu_86481_p0.read()) * sc_bigint<2>(mul_ln1118_306_fu_86481_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_307_fu_86505_p0() {
    mul_ln1118_307_fu_86505_p0 =  (sc_lv<10>) (mul_ln1118_307_fu_86505_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_307_fu_86505_p00() {
    mul_ln1118_307_fu_86505_p00 = esl_zext<12,10>(trunc_ln77_250_reg_132021.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_307_fu_86505_p1() {
    mul_ln1118_307_fu_86505_p1 = tmp_509_reg_132026.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_307_fu_86505_p2() {
    mul_ln1118_307_fu_86505_p2 = (!mul_ln1118_307_fu_86505_p0.read().is_01() || !mul_ln1118_307_fu_86505_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_307_fu_86505_p0.read()) * sc_bigint<2>(mul_ln1118_307_fu_86505_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_308_fu_86529_p0() {
    mul_ln1118_308_fu_86529_p0 =  (sc_lv<10>) (mul_ln1118_308_fu_86529_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_308_fu_86529_p00() {
    mul_ln1118_308_fu_86529_p00 = esl_zext<12,10>(trunc_ln77_251_reg_132031.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_308_fu_86529_p1() {
    mul_ln1118_308_fu_86529_p1 = tmp_511_reg_132036.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_308_fu_86529_p2() {
    mul_ln1118_308_fu_86529_p2 = (!mul_ln1118_308_fu_86529_p0.read().is_01() || !mul_ln1118_308_fu_86529_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_308_fu_86529_p0.read()) * sc_bigint<2>(mul_ln1118_308_fu_86529_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_309_fu_86550_p0() {
    mul_ln1118_309_fu_86550_p0 =  (sc_lv<10>) (zext_ln1116_170_fu_84579_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_309_fu_86550_p1() {
    mul_ln1118_309_fu_86550_p1 = tmp_512_reg_132041.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_309_fu_86550_p2() {
    mul_ln1118_309_fu_86550_p2 = (!mul_ln1118_309_fu_86550_p0.read().is_01() || !mul_ln1118_309_fu_86550_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_309_fu_86550_p0.read()) * sc_bigint<2>(mul_ln1118_309_fu_86550_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_30_fu_80235_p0() {
    mul_ln1118_30_fu_80235_p0 =  (sc_lv<10>) (mul_ln1118_30_fu_80235_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_30_fu_80235_p00() {
    mul_ln1118_30_fu_80235_p00 = esl_zext<12,10>(trunc_ln77_27_reg_129531.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_30_fu_80235_p1() {
    mul_ln1118_30_fu_80235_p1 = tmp_53_reg_129536.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_30_fu_80235_p2() {
    mul_ln1118_30_fu_80235_p2 = (!mul_ln1118_30_fu_80235_p0.read().is_01() || !mul_ln1118_30_fu_80235_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_30_fu_80235_p0.read()) * sc_bigint<2>(mul_ln1118_30_fu_80235_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_310_fu_86571_p0() {
    mul_ln1118_310_fu_86571_p0 =  (sc_lv<10>) (zext_ln1116_171_fu_84603_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_310_fu_86571_p1() {
    mul_ln1118_310_fu_86571_p1 = tmp_513_reg_132046.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_310_fu_86571_p2() {
    mul_ln1118_310_fu_86571_p2 = (!mul_ln1118_310_fu_86571_p0.read().is_01() || !mul_ln1118_310_fu_86571_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_310_fu_86571_p0.read()) * sc_bigint<2>(mul_ln1118_310_fu_86571_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_311_fu_86580_p0() {
    mul_ln1118_311_fu_86580_p0 =  (sc_lv<10>) (zext_ln1116_172_fu_84615_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_311_fu_86580_p1() {
    mul_ln1118_311_fu_86580_p1 = tmp_514_reg_132051.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_311_fu_86580_p2() {
    mul_ln1118_311_fu_86580_p2 = (!mul_ln1118_311_fu_86580_p0.read().is_01() || !mul_ln1118_311_fu_86580_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_311_fu_86580_p0.read()) * sc_bigint<2>(mul_ln1118_311_fu_86580_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_312_fu_86601_p0() {
    mul_ln1118_312_fu_86601_p0 =  (sc_lv<10>) (zext_ln1116_173_fu_84639_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_312_fu_86601_p1() {
    mul_ln1118_312_fu_86601_p1 = tmp_515_reg_132056.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_312_fu_86601_p2() {
    mul_ln1118_312_fu_86601_p2 = (!mul_ln1118_312_fu_86601_p0.read().is_01() || !mul_ln1118_312_fu_86601_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_312_fu_86601_p0.read()) * sc_bigint<2>(mul_ln1118_312_fu_86601_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_313_fu_86622_p0() {
    mul_ln1118_313_fu_86622_p0 =  (sc_lv<10>) (zext_ln1116_174_fu_84663_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_313_fu_86622_p1() {
    mul_ln1118_313_fu_86622_p1 = tmp_516_reg_132061.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_313_fu_86622_p2() {
    mul_ln1118_313_fu_86622_p2 = (!mul_ln1118_313_fu_86622_p0.read().is_01() || !mul_ln1118_313_fu_86622_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_313_fu_86622_p0.read()) * sc_bigint<2>(mul_ln1118_313_fu_86622_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_314_fu_86631_p0() {
    mul_ln1118_314_fu_86631_p0 =  (sc_lv<10>) (zext_ln1116_175_fu_84675_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_314_fu_86631_p1() {
    mul_ln1118_314_fu_86631_p1 = tmp_517_reg_132066.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_314_fu_86631_p2() {
    mul_ln1118_314_fu_86631_p2 = (!mul_ln1118_314_fu_86631_p0.read().is_01() || !mul_ln1118_314_fu_86631_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_314_fu_86631_p0.read()) * sc_bigint<2>(mul_ln1118_314_fu_86631_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_315_fu_86652_p0() {
    mul_ln1118_315_fu_86652_p0 =  (sc_lv<10>) (zext_ln1116_176_fu_84699_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_315_fu_86652_p1() {
    mul_ln1118_315_fu_86652_p1 = tmp_518_reg_132071.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_315_fu_86652_p2() {
    mul_ln1118_315_fu_86652_p2 = (!mul_ln1118_315_fu_86652_p0.read().is_01() || !mul_ln1118_315_fu_86652_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_315_fu_86652_p0.read()) * sc_bigint<2>(mul_ln1118_315_fu_86652_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_316_fu_86673_p0() {
    mul_ln1118_316_fu_86673_p0 =  (sc_lv<10>) (zext_ln1116_177_fu_84723_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_316_fu_86673_p1() {
    mul_ln1118_316_fu_86673_p1 = tmp_519_reg_132076.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_316_fu_86673_p2() {
    mul_ln1118_316_fu_86673_p2 = (!mul_ln1118_316_fu_86673_p0.read().is_01() || !mul_ln1118_316_fu_86673_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_316_fu_86673_p0.read()) * sc_bigint<2>(mul_ln1118_316_fu_86673_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_317_fu_86682_p0() {
    mul_ln1118_317_fu_86682_p0 =  (sc_lv<10>) (zext_ln1116_178_fu_84735_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_317_fu_86682_p1() {
    mul_ln1118_317_fu_86682_p1 = tmp_520_reg_132081.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_317_fu_86682_p2() {
    mul_ln1118_317_fu_86682_p2 = (!mul_ln1118_317_fu_86682_p0.read().is_01() || !mul_ln1118_317_fu_86682_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_317_fu_86682_p0.read()) * sc_bigint<2>(mul_ln1118_317_fu_86682_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_318_fu_86703_p0() {
    mul_ln1118_318_fu_86703_p0 =  (sc_lv<10>) (zext_ln1116_179_fu_84759_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_318_fu_86703_p1() {
    mul_ln1118_318_fu_86703_p1 = tmp_521_reg_132086.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_318_fu_86703_p2() {
    mul_ln1118_318_fu_86703_p2 = (!mul_ln1118_318_fu_86703_p0.read().is_01() || !mul_ln1118_318_fu_86703_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_318_fu_86703_p0.read()) * sc_bigint<2>(mul_ln1118_318_fu_86703_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_319_fu_86724_p0() {
    mul_ln1118_319_fu_86724_p0 =  (sc_lv<10>) (zext_ln1116_180_fu_84783_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_319_fu_86724_p1() {
    mul_ln1118_319_fu_86724_p1 = tmp_522_reg_132091.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_319_fu_86724_p2() {
    mul_ln1118_319_fu_86724_p2 = (!mul_ln1118_319_fu_86724_p0.read().is_01() || !mul_ln1118_319_fu_86724_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_319_fu_86724_p0.read()) * sc_bigint<2>(mul_ln1118_319_fu_86724_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_31_fu_80259_p0() {
    mul_ln1118_31_fu_80259_p0 =  (sc_lv<10>) (mul_ln1118_31_fu_80259_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_31_fu_80259_p00() {
    mul_ln1118_31_fu_80259_p00 = esl_zext<12,10>(trunc_ln77_28_reg_129541.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_31_fu_80259_p1() {
    mul_ln1118_31_fu_80259_p1 = tmp_55_reg_129546.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_31_fu_80259_p2() {
    mul_ln1118_31_fu_80259_p2 = (!mul_ln1118_31_fu_80259_p0.read().is_01() || !mul_ln1118_31_fu_80259_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_31_fu_80259_p0.read()) * sc_bigint<2>(mul_ln1118_31_fu_80259_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_320_fu_86745_p0() {
    mul_ln1118_320_fu_86745_p0 =  (sc_lv<10>) (zext_ln1116_181_fu_84807_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_320_fu_86745_p1() {
    mul_ln1118_320_fu_86745_p1 = tmp_523_reg_132096.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_320_fu_86745_p2() {
    mul_ln1118_320_fu_86745_p2 = (!mul_ln1118_320_fu_86745_p0.read().is_01() || !mul_ln1118_320_fu_86745_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_320_fu_86745_p0.read()) * sc_bigint<2>(mul_ln1118_320_fu_86745_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_321_fu_86766_p0() {
    mul_ln1118_321_fu_86766_p0 =  (sc_lv<10>) (zext_ln1116_182_fu_84831_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_321_fu_86766_p1() {
    mul_ln1118_321_fu_86766_p1 = tmp_524_reg_132101.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_321_fu_86766_p2() {
    mul_ln1118_321_fu_86766_p2 = (!mul_ln1118_321_fu_86766_p0.read().is_01() || !mul_ln1118_321_fu_86766_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_321_fu_86766_p0.read()) * sc_bigint<2>(mul_ln1118_321_fu_86766_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_322_fu_86775_p0() {
    mul_ln1118_322_fu_86775_p0 =  (sc_lv<10>) (zext_ln1116_183_fu_84843_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_322_fu_86775_p1() {
    mul_ln1118_322_fu_86775_p1 = tmp_525_reg_132106.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_322_fu_86775_p2() {
    mul_ln1118_322_fu_86775_p2 = (!mul_ln1118_322_fu_86775_p0.read().is_01() || !mul_ln1118_322_fu_86775_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_322_fu_86775_p0.read()) * sc_bigint<2>(mul_ln1118_322_fu_86775_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_323_fu_86796_p0() {
    mul_ln1118_323_fu_86796_p0 =  (sc_lv<10>) (zext_ln1116_184_fu_84867_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_323_fu_86796_p1() {
    mul_ln1118_323_fu_86796_p1 = tmp_526_reg_132111.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_323_fu_86796_p2() {
    mul_ln1118_323_fu_86796_p2 = (!mul_ln1118_323_fu_86796_p0.read().is_01() || !mul_ln1118_323_fu_86796_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_323_fu_86796_p0.read()) * sc_bigint<2>(mul_ln1118_323_fu_86796_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_324_fu_86817_p0() {
    mul_ln1118_324_fu_86817_p0 =  (sc_lv<10>) (zext_ln1116_185_fu_84891_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_324_fu_86817_p1() {
    mul_ln1118_324_fu_86817_p1 = tmp_527_reg_132116.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_324_fu_86817_p2() {
    mul_ln1118_324_fu_86817_p2 = (!mul_ln1118_324_fu_86817_p0.read().is_01() || !mul_ln1118_324_fu_86817_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_324_fu_86817_p0.read()) * sc_bigint<2>(mul_ln1118_324_fu_86817_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_325_fu_86838_p0() {
    mul_ln1118_325_fu_86838_p0 =  (sc_lv<10>) (zext_ln1116_186_fu_84915_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_325_fu_86838_p1() {
    mul_ln1118_325_fu_86838_p1 = tmp_528_reg_132121.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_325_fu_86838_p2() {
    mul_ln1118_325_fu_86838_p2 = (!mul_ln1118_325_fu_86838_p0.read().is_01() || !mul_ln1118_325_fu_86838_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_325_fu_86838_p0.read()) * sc_bigint<2>(mul_ln1118_325_fu_86838_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_326_fu_86859_p0() {
    mul_ln1118_326_fu_86859_p0 =  (sc_lv<10>) (zext_ln1116_187_fu_84939_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_326_fu_86859_p1() {
    mul_ln1118_326_fu_86859_p1 = tmp_529_reg_132126.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_326_fu_86859_p2() {
    mul_ln1118_326_fu_86859_p2 = (!mul_ln1118_326_fu_86859_p0.read().is_01() || !mul_ln1118_326_fu_86859_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_326_fu_86859_p0.read()) * sc_bigint<2>(mul_ln1118_326_fu_86859_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_327_fu_86868_p0() {
    mul_ln1118_327_fu_86868_p0 =  (sc_lv<10>) (zext_ln1116_188_fu_84951_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_327_fu_86868_p1() {
    mul_ln1118_327_fu_86868_p1 = tmp_530_reg_132131.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_327_fu_86868_p2() {
    mul_ln1118_327_fu_86868_p2 = (!mul_ln1118_327_fu_86868_p0.read().is_01() || !mul_ln1118_327_fu_86868_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_327_fu_86868_p0.read()) * sc_bigint<2>(mul_ln1118_327_fu_86868_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_328_fu_86889_p0() {
    mul_ln1118_328_fu_86889_p0 =  (sc_lv<10>) (zext_ln1116_189_fu_84975_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_328_fu_86889_p1() {
    mul_ln1118_328_fu_86889_p1 = tmp_531_reg_132136.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_328_fu_86889_p2() {
    mul_ln1118_328_fu_86889_p2 = (!mul_ln1118_328_fu_86889_p0.read().is_01() || !mul_ln1118_328_fu_86889_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_328_fu_86889_p0.read()) * sc_bigint<2>(mul_ln1118_328_fu_86889_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_329_fu_86910_p0() {
    mul_ln1118_329_fu_86910_p0 =  (sc_lv<10>) (zext_ln1116_190_fu_84999_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_329_fu_86910_p1() {
    mul_ln1118_329_fu_86910_p1 = tmp_532_reg_132141.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_329_fu_86910_p2() {
    mul_ln1118_329_fu_86910_p2 = (!mul_ln1118_329_fu_86910_p0.read().is_01() || !mul_ln1118_329_fu_86910_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_329_fu_86910_p0.read()) * sc_bigint<2>(mul_ln1118_329_fu_86910_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_32_fu_80283_p0() {
    mul_ln1118_32_fu_80283_p0 =  (sc_lv<10>) (mul_ln1118_32_fu_80283_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_32_fu_80283_p00() {
    mul_ln1118_32_fu_80283_p00 = esl_zext<12,10>(trunc_ln77_29_reg_129551.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_32_fu_80283_p1() {
    mul_ln1118_32_fu_80283_p1 = tmp_57_reg_129556.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_32_fu_80283_p2() {
    mul_ln1118_32_fu_80283_p2 = (!mul_ln1118_32_fu_80283_p0.read().is_01() || !mul_ln1118_32_fu_80283_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_32_fu_80283_p0.read()) * sc_bigint<2>(mul_ln1118_32_fu_80283_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_330_fu_86931_p0() {
    mul_ln1118_330_fu_86931_p0 =  (sc_lv<10>) (zext_ln1116_191_fu_85023_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_330_fu_86931_p1() {
    mul_ln1118_330_fu_86931_p1 = tmp_533_reg_132146.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_330_fu_86931_p2() {
    mul_ln1118_330_fu_86931_p2 = (!mul_ln1118_330_fu_86931_p0.read().is_01() || !mul_ln1118_330_fu_86931_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_330_fu_86931_p0.read()) * sc_bigint<2>(mul_ln1118_330_fu_86931_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_331_fu_86952_p0() {
    mul_ln1118_331_fu_86952_p0 =  (sc_lv<10>) (zext_ln1116_192_fu_85047_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_331_fu_86952_p1() {
    mul_ln1118_331_fu_86952_p1 = tmp_534_reg_132151.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_331_fu_86952_p2() {
    mul_ln1118_331_fu_86952_p2 = (!mul_ln1118_331_fu_86952_p0.read().is_01() || !mul_ln1118_331_fu_86952_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_331_fu_86952_p0.read()) * sc_bigint<2>(mul_ln1118_331_fu_86952_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_332_fu_86961_p0() {
    mul_ln1118_332_fu_86961_p0 =  (sc_lv<10>) (zext_ln1116_193_fu_85059_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_332_fu_86961_p1() {
    mul_ln1118_332_fu_86961_p1 = tmp_535_reg_132156.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_332_fu_86961_p2() {
    mul_ln1118_332_fu_86961_p2 = (!mul_ln1118_332_fu_86961_p0.read().is_01() || !mul_ln1118_332_fu_86961_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_332_fu_86961_p0.read()) * sc_bigint<2>(mul_ln1118_332_fu_86961_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_333_fu_86982_p0() {
    mul_ln1118_333_fu_86982_p0 =  (sc_lv<10>) (zext_ln1116_194_fu_85083_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_333_fu_86982_p1() {
    mul_ln1118_333_fu_86982_p1 = tmp_536_reg_132161.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_333_fu_86982_p2() {
    mul_ln1118_333_fu_86982_p2 = (!mul_ln1118_333_fu_86982_p0.read().is_01() || !mul_ln1118_333_fu_86982_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_333_fu_86982_p0.read()) * sc_bigint<2>(mul_ln1118_333_fu_86982_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_334_fu_87003_p0() {
    mul_ln1118_334_fu_87003_p0 =  (sc_lv<10>) (zext_ln1116_195_fu_85107_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_334_fu_87003_p1() {
    mul_ln1118_334_fu_87003_p1 = tmp_537_reg_132166.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_334_fu_87003_p2() {
    mul_ln1118_334_fu_87003_p2 = (!mul_ln1118_334_fu_87003_p0.read().is_01() || !mul_ln1118_334_fu_87003_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_334_fu_87003_p0.read()) * sc_bigint<2>(mul_ln1118_334_fu_87003_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_335_fu_87012_p0() {
    mul_ln1118_335_fu_87012_p0 =  (sc_lv<10>) (zext_ln1116_196_fu_85119_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_335_fu_87012_p1() {
    mul_ln1118_335_fu_87012_p1 = tmp_538_reg_132171.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_335_fu_87012_p2() {
    mul_ln1118_335_fu_87012_p2 = (!mul_ln1118_335_fu_87012_p0.read().is_01() || !mul_ln1118_335_fu_87012_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_335_fu_87012_p0.read()) * sc_bigint<2>(mul_ln1118_335_fu_87012_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_336_fu_87033_p0() {
    mul_ln1118_336_fu_87033_p0 =  (sc_lv<10>) (zext_ln1116_197_fu_85143_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_336_fu_87033_p1() {
    mul_ln1118_336_fu_87033_p1 = tmp_539_reg_132176.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_336_fu_87033_p2() {
    mul_ln1118_336_fu_87033_p2 = (!mul_ln1118_336_fu_87033_p0.read().is_01() || !mul_ln1118_336_fu_87033_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_336_fu_87033_p0.read()) * sc_bigint<2>(mul_ln1118_336_fu_87033_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_337_fu_87054_p0() {
    mul_ln1118_337_fu_87054_p0 =  (sc_lv<10>) (zext_ln1116_198_fu_85167_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_337_fu_87054_p1() {
    mul_ln1118_337_fu_87054_p1 = tmp_540_reg_132181.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_337_fu_87054_p2() {
    mul_ln1118_337_fu_87054_p2 = (!mul_ln1118_337_fu_87054_p0.read().is_01() || !mul_ln1118_337_fu_87054_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_337_fu_87054_p0.read()) * sc_bigint<2>(mul_ln1118_337_fu_87054_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_338_fu_87063_p0() {
    mul_ln1118_338_fu_87063_p0 =  (sc_lv<10>) (zext_ln1116_199_fu_85179_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_338_fu_87063_p1() {
    mul_ln1118_338_fu_87063_p1 = tmp_541_reg_132186.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_338_fu_87063_p2() {
    mul_ln1118_338_fu_87063_p2 = (!mul_ln1118_338_fu_87063_p0.read().is_01() || !mul_ln1118_338_fu_87063_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_338_fu_87063_p0.read()) * sc_bigint<2>(mul_ln1118_338_fu_87063_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_339_fu_87084_p0() {
    mul_ln1118_339_fu_87084_p0 =  (sc_lv<10>) (zext_ln1116_200_fu_85203_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_339_fu_87084_p1() {
    mul_ln1118_339_fu_87084_p1 = tmp_542_reg_132191.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_339_fu_87084_p2() {
    mul_ln1118_339_fu_87084_p2 = (!mul_ln1118_339_fu_87084_p0.read().is_01() || !mul_ln1118_339_fu_87084_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_339_fu_87084_p0.read()) * sc_bigint<2>(mul_ln1118_339_fu_87084_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_33_fu_80295_p0() {
    mul_ln1118_33_fu_80295_p0 =  (sc_lv<10>) (mul_ln1118_33_fu_80295_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_33_fu_80295_p00() {
    mul_ln1118_33_fu_80295_p00 = esl_zext<12,10>(trunc_ln77_30_reg_129561.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_33_fu_80295_p1() {
    mul_ln1118_33_fu_80295_p1 = tmp_59_reg_129566.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_33_fu_80295_p2() {
    mul_ln1118_33_fu_80295_p2 = (!mul_ln1118_33_fu_80295_p0.read().is_01() || !mul_ln1118_33_fu_80295_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_33_fu_80295_p0.read()) * sc_bigint<2>(mul_ln1118_33_fu_80295_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_340_fu_87297_p0() {
    mul_ln1118_340_fu_87297_p0 =  (sc_lv<10>) (zext_ln1116_201_fu_85419_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_340_fu_87297_p1() {
    mul_ln1118_340_fu_87297_p1 = tmp_543_reg_132196.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_340_fu_87297_p2() {
    mul_ln1118_340_fu_87297_p2 = (!mul_ln1118_340_fu_87297_p0.read().is_01() || !mul_ln1118_340_fu_87297_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_340_fu_87297_p0.read()) * sc_bigint<2>(mul_ln1118_340_fu_87297_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_341_fu_87318_p0() {
    mul_ln1118_341_fu_87318_p0 =  (sc_lv<10>) (zext_ln1116_202_fu_85443_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_341_fu_87318_p1() {
    mul_ln1118_341_fu_87318_p1 = tmp_544_reg_132201.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_341_fu_87318_p2() {
    mul_ln1118_341_fu_87318_p2 = (!mul_ln1118_341_fu_87318_p0.read().is_01() || !mul_ln1118_341_fu_87318_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_341_fu_87318_p0.read()) * sc_bigint<2>(mul_ln1118_341_fu_87318_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_342_fu_87339_p0() {
    mul_ln1118_342_fu_87339_p0 =  (sc_lv<10>) (zext_ln1116_203_fu_85467_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_342_fu_87339_p1() {
    mul_ln1118_342_fu_87339_p1 = tmp_545_reg_132206.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_342_fu_87339_p2() {
    mul_ln1118_342_fu_87339_p2 = (!mul_ln1118_342_fu_87339_p0.read().is_01() || !mul_ln1118_342_fu_87339_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_342_fu_87339_p0.read()) * sc_bigint<2>(mul_ln1118_342_fu_87339_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_343_fu_87348_p0() {
    mul_ln1118_343_fu_87348_p0 =  (sc_lv<10>) (zext_ln1116_204_fu_85479_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_343_fu_87348_p1() {
    mul_ln1118_343_fu_87348_p1 = tmp_546_reg_132211.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_343_fu_87348_p2() {
    mul_ln1118_343_fu_87348_p2 = (!mul_ln1118_343_fu_87348_p0.read().is_01() || !mul_ln1118_343_fu_87348_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_343_fu_87348_p0.read()) * sc_bigint<2>(mul_ln1118_343_fu_87348_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_344_fu_87369_p0() {
    mul_ln1118_344_fu_87369_p0 =  (sc_lv<10>) (zext_ln1116_205_fu_85503_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_344_fu_87369_p1() {
    mul_ln1118_344_fu_87369_p1 = tmp_547_reg_132216.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_344_fu_87369_p2() {
    mul_ln1118_344_fu_87369_p2 = (!mul_ln1118_344_fu_87369_p0.read().is_01() || !mul_ln1118_344_fu_87369_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_344_fu_87369_p0.read()) * sc_bigint<2>(mul_ln1118_344_fu_87369_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_345_fu_87390_p0() {
    mul_ln1118_345_fu_87390_p0 =  (sc_lv<10>) (zext_ln1116_206_fu_85527_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_345_fu_87390_p1() {
    mul_ln1118_345_fu_87390_p1 = tmp_548_reg_132221.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_345_fu_87390_p2() {
    mul_ln1118_345_fu_87390_p2 = (!mul_ln1118_345_fu_87390_p0.read().is_01() || !mul_ln1118_345_fu_87390_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_345_fu_87390_p0.read()) * sc_bigint<2>(mul_ln1118_345_fu_87390_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_346_fu_87411_p0() {
    mul_ln1118_346_fu_87411_p0 =  (sc_lv<10>) (zext_ln1116_207_fu_85551_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_346_fu_87411_p1() {
    mul_ln1118_346_fu_87411_p1 = tmp_549_reg_132226.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_346_fu_87411_p2() {
    mul_ln1118_346_fu_87411_p2 = (!mul_ln1118_346_fu_87411_p0.read().is_01() || !mul_ln1118_346_fu_87411_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_346_fu_87411_p0.read()) * sc_bigint<2>(mul_ln1118_346_fu_87411_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_347_fu_87432_p0() {
    mul_ln1118_347_fu_87432_p0 =  (sc_lv<10>) (zext_ln1116_208_fu_85575_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_347_fu_87432_p1() {
    mul_ln1118_347_fu_87432_p1 = tmp_550_reg_132231.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_347_fu_87432_p2() {
    mul_ln1118_347_fu_87432_p2 = (!mul_ln1118_347_fu_87432_p0.read().is_01() || !mul_ln1118_347_fu_87432_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_347_fu_87432_p0.read()) * sc_bigint<2>(mul_ln1118_347_fu_87432_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_348_fu_87441_p0() {
    mul_ln1118_348_fu_87441_p0 =  (sc_lv<10>) (zext_ln1116_209_fu_85587_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_348_fu_87441_p1() {
    mul_ln1118_348_fu_87441_p1 = tmp_551_reg_132236.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_348_fu_87441_p2() {
    mul_ln1118_348_fu_87441_p2 = (!mul_ln1118_348_fu_87441_p0.read().is_01() || !mul_ln1118_348_fu_87441_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_348_fu_87441_p0.read()) * sc_bigint<2>(mul_ln1118_348_fu_87441_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_349_fu_87462_p0() {
    mul_ln1118_349_fu_87462_p0 =  (sc_lv<10>) (zext_ln1116_210_fu_85611_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_349_fu_87462_p1() {
    mul_ln1118_349_fu_87462_p1 = tmp_552_reg_132241.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_349_fu_87462_p2() {
    mul_ln1118_349_fu_87462_p2 = (!mul_ln1118_349_fu_87462_p0.read().is_01() || !mul_ln1118_349_fu_87462_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_349_fu_87462_p0.read()) * sc_bigint<2>(mul_ln1118_349_fu_87462_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_34_fu_80319_p0() {
    mul_ln1118_34_fu_80319_p0 =  (sc_lv<10>) (mul_ln1118_34_fu_80319_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_34_fu_80319_p00() {
    mul_ln1118_34_fu_80319_p00 = esl_zext<12,10>(trunc_ln77_31_reg_129571.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_34_fu_80319_p1() {
    mul_ln1118_34_fu_80319_p1 = tmp_61_reg_129576.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_34_fu_80319_p2() {
    mul_ln1118_34_fu_80319_p2 = (!mul_ln1118_34_fu_80319_p0.read().is_01() || !mul_ln1118_34_fu_80319_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_34_fu_80319_p0.read()) * sc_bigint<2>(mul_ln1118_34_fu_80319_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_350_fu_87483_p0() {
    mul_ln1118_350_fu_87483_p0 =  (sc_lv<10>) (zext_ln1116_211_fu_85635_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_350_fu_87483_p1() {
    mul_ln1118_350_fu_87483_p1 = tmp_553_reg_132246.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_350_fu_87483_p2() {
    mul_ln1118_350_fu_87483_p2 = (!mul_ln1118_350_fu_87483_p0.read().is_01() || !mul_ln1118_350_fu_87483_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_350_fu_87483_p0.read()) * sc_bigint<2>(mul_ln1118_350_fu_87483_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_351_fu_87504_p0() {
    mul_ln1118_351_fu_87504_p0 =  (sc_lv<10>) (zext_ln1116_212_fu_85659_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_351_fu_87504_p1() {
    mul_ln1118_351_fu_87504_p1 = tmp_554_reg_132251.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_351_fu_87504_p2() {
    mul_ln1118_351_fu_87504_p2 = (!mul_ln1118_351_fu_87504_p0.read().is_01() || !mul_ln1118_351_fu_87504_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_351_fu_87504_p0.read()) * sc_bigint<2>(mul_ln1118_351_fu_87504_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_352_fu_87525_p0() {
    mul_ln1118_352_fu_87525_p0 =  (sc_lv<10>) (zext_ln1116_213_fu_85683_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_352_fu_87525_p1() {
    mul_ln1118_352_fu_87525_p1 = tmp_555_reg_132256.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_352_fu_87525_p2() {
    mul_ln1118_352_fu_87525_p2 = (!mul_ln1118_352_fu_87525_p0.read().is_01() || !mul_ln1118_352_fu_87525_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_352_fu_87525_p0.read()) * sc_bigint<2>(mul_ln1118_352_fu_87525_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_353_fu_87534_p0() {
    mul_ln1118_353_fu_87534_p0 =  (sc_lv<10>) (zext_ln1116_214_fu_85695_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_353_fu_87534_p1() {
    mul_ln1118_353_fu_87534_p1 = tmp_556_reg_132261.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_353_fu_87534_p2() {
    mul_ln1118_353_fu_87534_p2 = (!mul_ln1118_353_fu_87534_p0.read().is_01() || !mul_ln1118_353_fu_87534_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_353_fu_87534_p0.read()) * sc_bigint<2>(mul_ln1118_353_fu_87534_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_354_fu_87555_p0() {
    mul_ln1118_354_fu_87555_p0 =  (sc_lv<10>) (zext_ln1116_215_fu_85719_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_354_fu_87555_p1() {
    mul_ln1118_354_fu_87555_p1 = tmp_557_reg_132266.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_354_fu_87555_p2() {
    mul_ln1118_354_fu_87555_p2 = (!mul_ln1118_354_fu_87555_p0.read().is_01() || !mul_ln1118_354_fu_87555_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_354_fu_87555_p0.read()) * sc_bigint<2>(mul_ln1118_354_fu_87555_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_355_fu_87576_p0() {
    mul_ln1118_355_fu_87576_p0 =  (sc_lv<10>) (zext_ln1116_216_fu_85743_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_355_fu_87576_p1() {
    mul_ln1118_355_fu_87576_p1 = tmp_558_reg_132271.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_355_fu_87576_p2() {
    mul_ln1118_355_fu_87576_p2 = (!mul_ln1118_355_fu_87576_p0.read().is_01() || !mul_ln1118_355_fu_87576_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_355_fu_87576_p0.read()) * sc_bigint<2>(mul_ln1118_355_fu_87576_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_356_fu_87585_p0() {
    mul_ln1118_356_fu_87585_p0 =  (sc_lv<10>) (zext_ln1116_217_fu_85755_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_356_fu_87585_p1() {
    mul_ln1118_356_fu_87585_p1 = tmp_559_reg_132276.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_356_fu_87585_p2() {
    mul_ln1118_356_fu_87585_p2 = (!mul_ln1118_356_fu_87585_p0.read().is_01() || !mul_ln1118_356_fu_87585_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_356_fu_87585_p0.read()) * sc_bigint<2>(mul_ln1118_356_fu_87585_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_357_fu_87606_p0() {
    mul_ln1118_357_fu_87606_p0 =  (sc_lv<10>) (zext_ln1116_218_fu_85779_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_357_fu_87606_p1() {
    mul_ln1118_357_fu_87606_p1 = tmp_560_reg_132281.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_357_fu_87606_p2() {
    mul_ln1118_357_fu_87606_p2 = (!mul_ln1118_357_fu_87606_p0.read().is_01() || !mul_ln1118_357_fu_87606_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_357_fu_87606_p0.read()) * sc_bigint<2>(mul_ln1118_357_fu_87606_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_358_fu_87627_p0() {
    mul_ln1118_358_fu_87627_p0 =  (sc_lv<10>) (zext_ln1116_219_fu_85803_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_358_fu_87627_p1() {
    mul_ln1118_358_fu_87627_p1 = tmp_561_reg_132286.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_358_fu_87627_p2() {
    mul_ln1118_358_fu_87627_p2 = (!mul_ln1118_358_fu_87627_p0.read().is_01() || !mul_ln1118_358_fu_87627_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_358_fu_87627_p0.read()) * sc_bigint<2>(mul_ln1118_358_fu_87627_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_359_fu_87636_p0() {
    mul_ln1118_359_fu_87636_p0 =  (sc_lv<10>) (zext_ln1116_220_fu_85815_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_359_fu_87636_p1() {
    mul_ln1118_359_fu_87636_p1 = tmp_562_reg_132291.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_359_fu_87636_p2() {
    mul_ln1118_359_fu_87636_p2 = (!mul_ln1118_359_fu_87636_p0.read().is_01() || !mul_ln1118_359_fu_87636_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_359_fu_87636_p0.read()) * sc_bigint<2>(mul_ln1118_359_fu_87636_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_35_fu_80343_p0() {
    mul_ln1118_35_fu_80343_p0 =  (sc_lv<10>) (mul_ln1118_35_fu_80343_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_35_fu_80343_p00() {
    mul_ln1118_35_fu_80343_p00 = esl_zext<12,10>(trunc_ln77_32_reg_129581.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_35_fu_80343_p1() {
    mul_ln1118_35_fu_80343_p1 = tmp_63_reg_129586.read();
}

}


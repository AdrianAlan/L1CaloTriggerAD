#include "dense_resource_ap_ufixed_ap_fixed_config2_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_35_fu_80343_p2() {
    mul_ln1118_35_fu_80343_p2 = (!mul_ln1118_35_fu_80343_p0.read().is_01() || !mul_ln1118_35_fu_80343_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_35_fu_80343_p0.read()) * sc_bigint<2>(mul_ln1118_35_fu_80343_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_360_fu_87657_p0() {
    mul_ln1118_360_fu_87657_p0 =  (sc_lv<10>) (zext_ln1116_221_fu_85839_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_360_fu_87657_p1() {
    mul_ln1118_360_fu_87657_p1 = tmp_563_reg_132296.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_360_fu_87657_p2() {
    mul_ln1118_360_fu_87657_p2 = (!mul_ln1118_360_fu_87657_p0.read().is_01() || !mul_ln1118_360_fu_87657_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_360_fu_87657_p0.read()) * sc_bigint<2>(mul_ln1118_360_fu_87657_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_361_fu_87678_p0() {
    mul_ln1118_361_fu_87678_p0 =  (sc_lv<10>) (zext_ln1116_222_fu_85863_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_361_fu_87678_p1() {
    mul_ln1118_361_fu_87678_p1 = tmp_564_reg_132301.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_361_fu_87678_p2() {
    mul_ln1118_361_fu_87678_p2 = (!mul_ln1118_361_fu_87678_p0.read().is_01() || !mul_ln1118_361_fu_87678_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_361_fu_87678_p0.read()) * sc_bigint<2>(mul_ln1118_361_fu_87678_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_362_fu_87699_p0() {
    mul_ln1118_362_fu_87699_p0 =  (sc_lv<10>) (zext_ln1116_223_fu_85887_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_362_fu_87699_p1() {
    mul_ln1118_362_fu_87699_p1 = tmp_565_reg_132306.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_362_fu_87699_p2() {
    mul_ln1118_362_fu_87699_p2 = (!mul_ln1118_362_fu_87699_p0.read().is_01() || !mul_ln1118_362_fu_87699_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_362_fu_87699_p0.read()) * sc_bigint<2>(mul_ln1118_362_fu_87699_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_363_fu_87720_p0() {
    mul_ln1118_363_fu_87720_p0 =  (sc_lv<10>) (zext_ln1116_224_fu_85911_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_363_fu_87720_p1() {
    mul_ln1118_363_fu_87720_p1 = tmp_566_reg_132311.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_363_fu_87720_p2() {
    mul_ln1118_363_fu_87720_p2 = (!mul_ln1118_363_fu_87720_p0.read().is_01() || !mul_ln1118_363_fu_87720_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_363_fu_87720_p0.read()) * sc_bigint<2>(mul_ln1118_363_fu_87720_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_364_fu_87732_p0() {
    mul_ln1118_364_fu_87732_p0 =  (sc_lv<10>) (zext_ln1116_254_fu_87726_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_364_fu_87732_p1() {
    mul_ln1118_364_fu_87732_p1 = tmp_568_reg_132321.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_364_fu_87732_p2() {
    mul_ln1118_364_fu_87732_p2 = (!mul_ln1118_364_fu_87732_p0.read().is_01() || !mul_ln1118_364_fu_87732_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_364_fu_87732_p0.read()) * sc_bigint<2>(mul_ln1118_364_fu_87732_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_365_fu_87756_p0() {
    mul_ln1118_365_fu_87756_p0 =  (sc_lv<10>) (zext_ln1116_255_fu_87750_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_365_fu_87756_p1() {
    mul_ln1118_365_fu_87756_p1 = tmp_570_reg_132331.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_365_fu_87756_p2() {
    mul_ln1118_365_fu_87756_p2 = (!mul_ln1118_365_fu_87756_p0.read().is_01() || !mul_ln1118_365_fu_87756_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_365_fu_87756_p0.read()) * sc_bigint<2>(mul_ln1118_365_fu_87756_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_366_fu_87780_p0() {
    mul_ln1118_366_fu_87780_p0 =  (sc_lv<10>) (zext_ln1116_256_fu_87774_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_366_fu_87780_p1() {
    mul_ln1118_366_fu_87780_p1 = tmp_572_reg_132341.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_366_fu_87780_p2() {
    mul_ln1118_366_fu_87780_p2 = (!mul_ln1118_366_fu_87780_p0.read().is_01() || !mul_ln1118_366_fu_87780_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_366_fu_87780_p0.read()) * sc_bigint<2>(mul_ln1118_366_fu_87780_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_367_fu_87804_p0() {
    mul_ln1118_367_fu_87804_p0 =  (sc_lv<10>) (zext_ln1116_257_fu_87798_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_367_fu_87804_p1() {
    mul_ln1118_367_fu_87804_p1 = tmp_574_reg_132351.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_367_fu_87804_p2() {
    mul_ln1118_367_fu_87804_p2 = (!mul_ln1118_367_fu_87804_p0.read().is_01() || !mul_ln1118_367_fu_87804_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_367_fu_87804_p0.read()) * sc_bigint<2>(mul_ln1118_367_fu_87804_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_368_fu_87828_p0() {
    mul_ln1118_368_fu_87828_p0 =  (sc_lv<10>) (zext_ln1116_258_fu_87822_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_368_fu_87828_p1() {
    mul_ln1118_368_fu_87828_p1 = tmp_576_reg_132361.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_368_fu_87828_p2() {
    mul_ln1118_368_fu_87828_p2 = (!mul_ln1118_368_fu_87828_p0.read().is_01() || !mul_ln1118_368_fu_87828_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_368_fu_87828_p0.read()) * sc_bigint<2>(mul_ln1118_368_fu_87828_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_369_fu_87840_p0() {
    mul_ln1118_369_fu_87840_p0 =  (sc_lv<10>) (zext_ln1116_259_fu_87834_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_369_fu_87840_p1() {
    mul_ln1118_369_fu_87840_p1 = tmp_578_reg_132371.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_369_fu_87840_p2() {
    mul_ln1118_369_fu_87840_p2 = (!mul_ln1118_369_fu_87840_p0.read().is_01() || !mul_ln1118_369_fu_87840_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_369_fu_87840_p0.read()) * sc_bigint<2>(mul_ln1118_369_fu_87840_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_36_fu_80367_p0() {
    mul_ln1118_36_fu_80367_p0 =  (sc_lv<10>) (mul_ln1118_36_fu_80367_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_36_fu_80367_p00() {
    mul_ln1118_36_fu_80367_p00 = esl_zext<12,10>(trunc_ln77_33_reg_129591.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_36_fu_80367_p1() {
    mul_ln1118_36_fu_80367_p1 = tmp_65_reg_129596.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_36_fu_80367_p2() {
    mul_ln1118_36_fu_80367_p2 = (!mul_ln1118_36_fu_80367_p0.read().is_01() || !mul_ln1118_36_fu_80367_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_36_fu_80367_p0.read()) * sc_bigint<2>(mul_ln1118_36_fu_80367_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_370_fu_87864_p0() {
    mul_ln1118_370_fu_87864_p0 =  (sc_lv<10>) (zext_ln1116_260_fu_87858_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_370_fu_87864_p1() {
    mul_ln1118_370_fu_87864_p1 = tmp_580_reg_132381.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_370_fu_87864_p2() {
    mul_ln1118_370_fu_87864_p2 = (!mul_ln1118_370_fu_87864_p0.read().is_01() || !mul_ln1118_370_fu_87864_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_370_fu_87864_p0.read()) * sc_bigint<2>(mul_ln1118_370_fu_87864_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_371_fu_87888_p0() {
    mul_ln1118_371_fu_87888_p0 =  (sc_lv<10>) (zext_ln1116_261_fu_87882_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_371_fu_87888_p1() {
    mul_ln1118_371_fu_87888_p1 = tmp_582_reg_132391.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_371_fu_87888_p2() {
    mul_ln1118_371_fu_87888_p2 = (!mul_ln1118_371_fu_87888_p0.read().is_01() || !mul_ln1118_371_fu_87888_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_371_fu_87888_p0.read()) * sc_bigint<2>(mul_ln1118_371_fu_87888_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_372_fu_87912_p0() {
    mul_ln1118_372_fu_87912_p0 =  (sc_lv<10>) (zext_ln1116_262_fu_87906_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_372_fu_87912_p1() {
    mul_ln1118_372_fu_87912_p1 = tmp_584_reg_132401.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_372_fu_87912_p2() {
    mul_ln1118_372_fu_87912_p2 = (!mul_ln1118_372_fu_87912_p0.read().is_01() || !mul_ln1118_372_fu_87912_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_372_fu_87912_p0.read()) * sc_bigint<2>(mul_ln1118_372_fu_87912_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_373_fu_87936_p0() {
    mul_ln1118_373_fu_87936_p0 =  (sc_lv<10>) (zext_ln1116_263_fu_87930_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_373_fu_87936_p1() {
    mul_ln1118_373_fu_87936_p1 = tmp_586_reg_132411.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_373_fu_87936_p2() {
    mul_ln1118_373_fu_87936_p2 = (!mul_ln1118_373_fu_87936_p0.read().is_01() || !mul_ln1118_373_fu_87936_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_373_fu_87936_p0.read()) * sc_bigint<2>(mul_ln1118_373_fu_87936_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_374_fu_87948_p0() {
    mul_ln1118_374_fu_87948_p0 =  (sc_lv<10>) (zext_ln1116_264_fu_87942_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_374_fu_87948_p1() {
    mul_ln1118_374_fu_87948_p1 = tmp_587_reg_132421.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_374_fu_87948_p2() {
    mul_ln1118_374_fu_87948_p2 = (!mul_ln1118_374_fu_87948_p0.read().is_01() || !mul_ln1118_374_fu_87948_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_374_fu_87948_p0.read()) * sc_bigint<2>(mul_ln1118_374_fu_87948_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_375_fu_87972_p0() {
    mul_ln1118_375_fu_87972_p0 =  (sc_lv<10>) (zext_ln1116_265_fu_87966_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_375_fu_87972_p1() {
    mul_ln1118_375_fu_87972_p1 = tmp_588_reg_132431.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_375_fu_87972_p2() {
    mul_ln1118_375_fu_87972_p2 = (!mul_ln1118_375_fu_87972_p0.read().is_01() || !mul_ln1118_375_fu_87972_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_375_fu_87972_p0.read()) * sc_bigint<2>(mul_ln1118_375_fu_87972_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_376_fu_87996_p0() {
    mul_ln1118_376_fu_87996_p0 =  (sc_lv<10>) (zext_ln1116_266_fu_87990_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_376_fu_87996_p1() {
    mul_ln1118_376_fu_87996_p1 = tmp_589_reg_132441.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_376_fu_87996_p2() {
    mul_ln1118_376_fu_87996_p2 = (!mul_ln1118_376_fu_87996_p0.read().is_01() || !mul_ln1118_376_fu_87996_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_376_fu_87996_p0.read()) * sc_bigint<2>(mul_ln1118_376_fu_87996_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_377_fu_88008_p0() {
    mul_ln1118_377_fu_88008_p0 =  (sc_lv<10>) (zext_ln1116_267_fu_88002_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_377_fu_88008_p1() {
    mul_ln1118_377_fu_88008_p1 = tmp_590_reg_132451.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_377_fu_88008_p2() {
    mul_ln1118_377_fu_88008_p2 = (!mul_ln1118_377_fu_88008_p0.read().is_01() || !mul_ln1118_377_fu_88008_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_377_fu_88008_p0.read()) * sc_bigint<2>(mul_ln1118_377_fu_88008_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_378_fu_88032_p0() {
    mul_ln1118_378_fu_88032_p0 =  (sc_lv<10>) (zext_ln1116_268_fu_88026_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_378_fu_88032_p1() {
    mul_ln1118_378_fu_88032_p1 = tmp_591_reg_132461.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_378_fu_88032_p2() {
    mul_ln1118_378_fu_88032_p2 = (!mul_ln1118_378_fu_88032_p0.read().is_01() || !mul_ln1118_378_fu_88032_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_378_fu_88032_p0.read()) * sc_bigint<2>(mul_ln1118_378_fu_88032_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_379_fu_88056_p0() {
    mul_ln1118_379_fu_88056_p0 =  (sc_lv<10>) (zext_ln1116_269_fu_88050_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_379_fu_88056_p1() {
    mul_ln1118_379_fu_88056_p1 = tmp_592_reg_132471.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_379_fu_88056_p2() {
    mul_ln1118_379_fu_88056_p2 = (!mul_ln1118_379_fu_88056_p0.read().is_01() || !mul_ln1118_379_fu_88056_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_379_fu_88056_p0.read()) * sc_bigint<2>(mul_ln1118_379_fu_88056_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_37_fu_80391_p0() {
    mul_ln1118_37_fu_80391_p0 =  (sc_lv<10>) (mul_ln1118_37_fu_80391_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_37_fu_80391_p00() {
    mul_ln1118_37_fu_80391_p00 = esl_zext<12,10>(trunc_ln77_34_reg_129601.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_37_fu_80391_p1() {
    mul_ln1118_37_fu_80391_p1 = tmp_67_reg_129606.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_37_fu_80391_p2() {
    mul_ln1118_37_fu_80391_p2 = (!mul_ln1118_37_fu_80391_p0.read().is_01() || !mul_ln1118_37_fu_80391_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_37_fu_80391_p0.read()) * sc_bigint<2>(mul_ln1118_37_fu_80391_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_380_fu_88068_p0() {
    mul_ln1118_380_fu_88068_p0 =  (sc_lv<10>) (zext_ln1116_270_fu_88062_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_380_fu_88068_p1() {
    mul_ln1118_380_fu_88068_p1 = tmp_593_reg_132481.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_380_fu_88068_p2() {
    mul_ln1118_380_fu_88068_p2 = (!mul_ln1118_380_fu_88068_p0.read().is_01() || !mul_ln1118_380_fu_88068_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_380_fu_88068_p0.read()) * sc_bigint<2>(mul_ln1118_380_fu_88068_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_381_fu_88092_p0() {
    mul_ln1118_381_fu_88092_p0 =  (sc_lv<10>) (zext_ln1116_271_fu_88086_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_381_fu_88092_p1() {
    mul_ln1118_381_fu_88092_p1 = tmp_594_reg_132491.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_381_fu_88092_p2() {
    mul_ln1118_381_fu_88092_p2 = (!mul_ln1118_381_fu_88092_p0.read().is_01() || !mul_ln1118_381_fu_88092_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_381_fu_88092_p0.read()) * sc_bigint<2>(mul_ln1118_381_fu_88092_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_382_fu_88116_p0() {
    mul_ln1118_382_fu_88116_p0 =  (sc_lv<10>) (zext_ln1116_272_fu_88110_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_382_fu_88116_p1() {
    mul_ln1118_382_fu_88116_p1 = tmp_596_reg_132501.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_382_fu_88116_p2() {
    mul_ln1118_382_fu_88116_p2 = (!mul_ln1118_382_fu_88116_p0.read().is_01() || !mul_ln1118_382_fu_88116_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_382_fu_88116_p0.read()) * sc_bigint<2>(mul_ln1118_382_fu_88116_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_383_fu_88140_p0() {
    mul_ln1118_383_fu_88140_p0 =  (sc_lv<10>) (zext_ln1116_273_fu_88134_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_383_fu_88140_p1() {
    mul_ln1118_383_fu_88140_p1 = tmp_598_reg_132511.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_383_fu_88140_p2() {
    mul_ln1118_383_fu_88140_p2 = (!mul_ln1118_383_fu_88140_p0.read().is_01() || !mul_ln1118_383_fu_88140_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_383_fu_88140_p0.read()) * sc_bigint<2>(mul_ln1118_383_fu_88140_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_384_fu_88164_p0() {
    mul_ln1118_384_fu_88164_p0 =  (sc_lv<10>) (zext_ln1116_274_fu_88158_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_384_fu_88164_p1() {
    mul_ln1118_384_fu_88164_p1 = tmp_600_reg_132521.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_384_fu_88164_p2() {
    mul_ln1118_384_fu_88164_p2 = (!mul_ln1118_384_fu_88164_p0.read().is_01() || !mul_ln1118_384_fu_88164_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_384_fu_88164_p0.read()) * sc_bigint<2>(mul_ln1118_384_fu_88164_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_385_fu_88176_p0() {
    mul_ln1118_385_fu_88176_p0 =  (sc_lv<10>) (zext_ln1116_275_fu_88170_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_385_fu_88176_p1() {
    mul_ln1118_385_fu_88176_p1 = tmp_602_reg_132531.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_385_fu_88176_p2() {
    mul_ln1118_385_fu_88176_p2 = (!mul_ln1118_385_fu_88176_p0.read().is_01() || !mul_ln1118_385_fu_88176_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_385_fu_88176_p0.read()) * sc_bigint<2>(mul_ln1118_385_fu_88176_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_386_fu_88200_p0() {
    mul_ln1118_386_fu_88200_p0 =  (sc_lv<10>) (zext_ln1116_276_fu_88194_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_386_fu_88200_p1() {
    mul_ln1118_386_fu_88200_p1 = tmp_604_reg_132541.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_386_fu_88200_p2() {
    mul_ln1118_386_fu_88200_p2 = (!mul_ln1118_386_fu_88200_p0.read().is_01() || !mul_ln1118_386_fu_88200_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_386_fu_88200_p0.read()) * sc_bigint<2>(mul_ln1118_386_fu_88200_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_387_fu_88224_p0() {
    mul_ln1118_387_fu_88224_p0 =  (sc_lv<10>) (zext_ln1116_277_fu_88218_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_387_fu_88224_p1() {
    mul_ln1118_387_fu_88224_p1 = tmp_606_reg_132551.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_387_fu_88224_p2() {
    mul_ln1118_387_fu_88224_p2 = (!mul_ln1118_387_fu_88224_p0.read().is_01() || !mul_ln1118_387_fu_88224_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_387_fu_88224_p0.read()) * sc_bigint<2>(mul_ln1118_387_fu_88224_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_388_fu_88248_p0() {
    mul_ln1118_388_fu_88248_p0 =  (sc_lv<10>) (zext_ln1116_278_fu_88242_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_388_fu_88248_p1() {
    mul_ln1118_388_fu_88248_p1 = tmp_608_reg_132561.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_388_fu_88248_p2() {
    mul_ln1118_388_fu_88248_p2 = (!mul_ln1118_388_fu_88248_p0.read().is_01() || !mul_ln1118_388_fu_88248_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_388_fu_88248_p0.read()) * sc_bigint<2>(mul_ln1118_388_fu_88248_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_389_fu_88272_p0() {
    mul_ln1118_389_fu_88272_p0 =  (sc_lv<10>) (zext_ln1116_279_fu_88266_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_389_fu_88272_p1() {
    mul_ln1118_389_fu_88272_p1 = tmp_610_reg_132571.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_389_fu_88272_p2() {
    mul_ln1118_389_fu_88272_p2 = (!mul_ln1118_389_fu_88272_p0.read().is_01() || !mul_ln1118_389_fu_88272_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_389_fu_88272_p0.read()) * sc_bigint<2>(mul_ln1118_389_fu_88272_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_38_fu_80403_p0() {
    mul_ln1118_38_fu_80403_p0 =  (sc_lv<10>) (mul_ln1118_38_fu_80403_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_38_fu_80403_p00() {
    mul_ln1118_38_fu_80403_p00 = esl_zext<12,10>(trunc_ln77_35_reg_129611.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_38_fu_80403_p1() {
    mul_ln1118_38_fu_80403_p1 = tmp_69_reg_129616.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_38_fu_80403_p2() {
    mul_ln1118_38_fu_80403_p2 = (!mul_ln1118_38_fu_80403_p0.read().is_01() || !mul_ln1118_38_fu_80403_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_38_fu_80403_p0.read()) * sc_bigint<2>(mul_ln1118_38_fu_80403_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_390_fu_88284_p0() {
    mul_ln1118_390_fu_88284_p0 =  (sc_lv<10>) (zext_ln1116_280_fu_88278_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_390_fu_88284_p1() {
    mul_ln1118_390_fu_88284_p1 = tmp_612_reg_132581.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_390_fu_88284_p2() {
    mul_ln1118_390_fu_88284_p2 = (!mul_ln1118_390_fu_88284_p0.read().is_01() || !mul_ln1118_390_fu_88284_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_390_fu_88284_p0.read()) * sc_bigint<2>(mul_ln1118_390_fu_88284_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_391_fu_88308_p0() {
    mul_ln1118_391_fu_88308_p0 =  (sc_lv<10>) (zext_ln1116_281_fu_88302_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_391_fu_88308_p1() {
    mul_ln1118_391_fu_88308_p1 = tmp_614_reg_132591.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_391_fu_88308_p2() {
    mul_ln1118_391_fu_88308_p2 = (!mul_ln1118_391_fu_88308_p0.read().is_01() || !mul_ln1118_391_fu_88308_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_391_fu_88308_p0.read()) * sc_bigint<2>(mul_ln1118_391_fu_88308_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_392_fu_88332_p0() {
    mul_ln1118_392_fu_88332_p0 =  (sc_lv<10>) (zext_ln1116_282_fu_88326_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_392_fu_88332_p1() {
    mul_ln1118_392_fu_88332_p1 = tmp_616_reg_132601.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_392_fu_88332_p2() {
    mul_ln1118_392_fu_88332_p2 = (!mul_ln1118_392_fu_88332_p0.read().is_01() || !mul_ln1118_392_fu_88332_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_392_fu_88332_p0.read()) * sc_bigint<2>(mul_ln1118_392_fu_88332_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_393_fu_88356_p0() {
    mul_ln1118_393_fu_88356_p0 =  (sc_lv<10>) (zext_ln1116_283_fu_88350_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_393_fu_88356_p1() {
    mul_ln1118_393_fu_88356_p1 = tmp_618_reg_132611.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_393_fu_88356_p2() {
    mul_ln1118_393_fu_88356_p2 = (!mul_ln1118_393_fu_88356_p0.read().is_01() || !mul_ln1118_393_fu_88356_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_393_fu_88356_p0.read()) * sc_bigint<2>(mul_ln1118_393_fu_88356_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_394_fu_88380_p0() {
    mul_ln1118_394_fu_88380_p0 =  (sc_lv<10>) (zext_ln1116_284_fu_88374_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_394_fu_88380_p1() {
    mul_ln1118_394_fu_88380_p1 = tmp_620_reg_132621.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_394_fu_88380_p2() {
    mul_ln1118_394_fu_88380_p2 = (!mul_ln1118_394_fu_88380_p0.read().is_01() || !mul_ln1118_394_fu_88380_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_394_fu_88380_p0.read()) * sc_bigint<2>(mul_ln1118_394_fu_88380_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_395_fu_88392_p0() {
    mul_ln1118_395_fu_88392_p0 =  (sc_lv<10>) (zext_ln1116_285_fu_88386_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_395_fu_88392_p1() {
    mul_ln1118_395_fu_88392_p1 = tmp_622_reg_132631.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_395_fu_88392_p2() {
    mul_ln1118_395_fu_88392_p2 = (!mul_ln1118_395_fu_88392_p0.read().is_01() || !mul_ln1118_395_fu_88392_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_395_fu_88392_p0.read()) * sc_bigint<2>(mul_ln1118_395_fu_88392_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_396_fu_88416_p0() {
    mul_ln1118_396_fu_88416_p0 =  (sc_lv<10>) (zext_ln1116_286_fu_88410_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_396_fu_88416_p1() {
    mul_ln1118_396_fu_88416_p1 = tmp_624_reg_132641.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_396_fu_88416_p2() {
    mul_ln1118_396_fu_88416_p2 = (!mul_ln1118_396_fu_88416_p0.read().is_01() || !mul_ln1118_396_fu_88416_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_396_fu_88416_p0.read()) * sc_bigint<2>(mul_ln1118_396_fu_88416_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_397_fu_88440_p0() {
    mul_ln1118_397_fu_88440_p0 =  (sc_lv<10>) (zext_ln1116_287_fu_88434_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_397_fu_88440_p1() {
    mul_ln1118_397_fu_88440_p1 = tmp_626_reg_132651.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_397_fu_88440_p2() {
    mul_ln1118_397_fu_88440_p2 = (!mul_ln1118_397_fu_88440_p0.read().is_01() || !mul_ln1118_397_fu_88440_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_397_fu_88440_p0.read()) * sc_bigint<2>(mul_ln1118_397_fu_88440_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_398_fu_88452_p0() {
    mul_ln1118_398_fu_88452_p0 =  (sc_lv<10>) (zext_ln1116_288_fu_88446_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_398_fu_88452_p1() {
    mul_ln1118_398_fu_88452_p1 = tmp_628_reg_132661.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_398_fu_88452_p2() {
    mul_ln1118_398_fu_88452_p2 = (!mul_ln1118_398_fu_88452_p0.read().is_01() || !mul_ln1118_398_fu_88452_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_398_fu_88452_p0.read()) * sc_bigint<2>(mul_ln1118_398_fu_88452_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_399_fu_88476_p0() {
    mul_ln1118_399_fu_88476_p0 =  (sc_lv<10>) (zext_ln1116_289_fu_88470_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_399_fu_88476_p1() {
    mul_ln1118_399_fu_88476_p1 = tmp_630_reg_132671.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_399_fu_88476_p2() {
    mul_ln1118_399_fu_88476_p2 = (!mul_ln1118_399_fu_88476_p0.read().is_01() || !mul_ln1118_399_fu_88476_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_399_fu_88476_p0.read()) * sc_bigint<2>(mul_ln1118_399_fu_88476_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_39_fu_80427_p0() {
    mul_ln1118_39_fu_80427_p0 =  (sc_lv<10>) (mul_ln1118_39_fu_80427_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_39_fu_80427_p00() {
    mul_ln1118_39_fu_80427_p00 = esl_zext<12,10>(trunc_ln77_36_reg_129621.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_39_fu_80427_p1() {
    mul_ln1118_39_fu_80427_p1 = tmp_71_reg_129626.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_39_fu_80427_p2() {
    mul_ln1118_39_fu_80427_p2 = (!mul_ln1118_39_fu_80427_p0.read().is_01() || !mul_ln1118_39_fu_80427_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_39_fu_80427_p0.read()) * sc_bigint<2>(mul_ln1118_39_fu_80427_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_400_fu_88500_p0() {
    mul_ln1118_400_fu_88500_p0 =  (sc_lv<10>) (zext_ln1116_290_fu_88494_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_400_fu_88500_p1() {
    mul_ln1118_400_fu_88500_p1 = tmp_632_reg_132681.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_400_fu_88500_p2() {
    mul_ln1118_400_fu_88500_p2 = (!mul_ln1118_400_fu_88500_p0.read().is_01() || !mul_ln1118_400_fu_88500_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_400_fu_88500_p0.read()) * sc_bigint<2>(mul_ln1118_400_fu_88500_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_401_fu_88512_p0() {
    mul_ln1118_401_fu_88512_p0 =  (sc_lv<10>) (zext_ln1116_291_fu_88506_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_401_fu_88512_p1() {
    mul_ln1118_401_fu_88512_p1 = tmp_634_reg_132691.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_401_fu_88512_p2() {
    mul_ln1118_401_fu_88512_p2 = (!mul_ln1118_401_fu_88512_p0.read().is_01() || !mul_ln1118_401_fu_88512_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_401_fu_88512_p0.read()) * sc_bigint<2>(mul_ln1118_401_fu_88512_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_402_fu_88536_p0() {
    mul_ln1118_402_fu_88536_p0 =  (sc_lv<10>) (zext_ln1116_292_fu_88530_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_402_fu_88536_p1() {
    mul_ln1118_402_fu_88536_p1 = tmp_636_reg_132701.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_402_fu_88536_p2() {
    mul_ln1118_402_fu_88536_p2 = (!mul_ln1118_402_fu_88536_p0.read().is_01() || !mul_ln1118_402_fu_88536_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_402_fu_88536_p0.read()) * sc_bigint<2>(mul_ln1118_402_fu_88536_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_403_fu_88560_p0() {
    mul_ln1118_403_fu_88560_p0 =  (sc_lv<10>) (zext_ln1116_293_fu_88554_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_403_fu_88560_p1() {
    mul_ln1118_403_fu_88560_p1 = tmp_638_reg_132711.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_403_fu_88560_p2() {
    mul_ln1118_403_fu_88560_p2 = (!mul_ln1118_403_fu_88560_p0.read().is_01() || !mul_ln1118_403_fu_88560_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_403_fu_88560_p0.read()) * sc_bigint<2>(mul_ln1118_403_fu_88560_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_404_fu_88584_p0() {
    mul_ln1118_404_fu_88584_p0 =  (sc_lv<10>) (zext_ln1116_294_fu_88578_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_404_fu_88584_p1() {
    mul_ln1118_404_fu_88584_p1 = tmp_640_reg_132721.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_404_fu_88584_p2() {
    mul_ln1118_404_fu_88584_p2 = (!mul_ln1118_404_fu_88584_p0.read().is_01() || !mul_ln1118_404_fu_88584_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_404_fu_88584_p0.read()) * sc_bigint<2>(mul_ln1118_404_fu_88584_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_405_fu_88608_p0() {
    mul_ln1118_405_fu_88608_p0 =  (sc_lv<10>) (zext_ln1116_295_fu_88602_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_405_fu_88608_p1() {
    mul_ln1118_405_fu_88608_p1 = tmp_642_reg_132731.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_405_fu_88608_p2() {
    mul_ln1118_405_fu_88608_p2 = (!mul_ln1118_405_fu_88608_p0.read().is_01() || !mul_ln1118_405_fu_88608_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_405_fu_88608_p0.read()) * sc_bigint<2>(mul_ln1118_405_fu_88608_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_406_fu_88620_p0() {
    mul_ln1118_406_fu_88620_p0 =  (sc_lv<10>) (zext_ln1116_296_fu_88614_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_406_fu_88620_p1() {
    mul_ln1118_406_fu_88620_p1 = tmp_644_reg_132741.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_406_fu_88620_p2() {
    mul_ln1118_406_fu_88620_p2 = (!mul_ln1118_406_fu_88620_p0.read().is_01() || !mul_ln1118_406_fu_88620_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_406_fu_88620_p0.read()) * sc_bigint<2>(mul_ln1118_406_fu_88620_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_407_fu_88644_p0() {
    mul_ln1118_407_fu_88644_p0 =  (sc_lv<10>) (zext_ln1116_297_fu_88638_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_407_fu_88644_p1() {
    mul_ln1118_407_fu_88644_p1 = tmp_646_reg_132751.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_407_fu_88644_p2() {
    mul_ln1118_407_fu_88644_p2 = (!mul_ln1118_407_fu_88644_p0.read().is_01() || !mul_ln1118_407_fu_88644_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_407_fu_88644_p0.read()) * sc_bigint<2>(mul_ln1118_407_fu_88644_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_408_fu_88668_p0() {
    mul_ln1118_408_fu_88668_p0 =  (sc_lv<10>) (zext_ln1116_298_fu_88662_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_408_fu_88668_p1() {
    mul_ln1118_408_fu_88668_p1 = tmp_647_reg_132761.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_408_fu_88668_p2() {
    mul_ln1118_408_fu_88668_p2 = (!mul_ln1118_408_fu_88668_p0.read().is_01() || !mul_ln1118_408_fu_88668_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_408_fu_88668_p0.read()) * sc_bigint<2>(mul_ln1118_408_fu_88668_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_409_fu_88692_p0() {
    mul_ln1118_409_fu_88692_p0 =  (sc_lv<10>) (zext_ln1116_299_fu_88686_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_409_fu_88692_p1() {
    mul_ln1118_409_fu_88692_p1 = tmp_648_reg_132771.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_409_fu_88692_p2() {
    mul_ln1118_409_fu_88692_p2 = (!mul_ln1118_409_fu_88692_p0.read().is_01() || !mul_ln1118_409_fu_88692_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_409_fu_88692_p0.read()) * sc_bigint<2>(mul_ln1118_409_fu_88692_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_40_fu_80451_p0() {
    mul_ln1118_40_fu_80451_p0 =  (sc_lv<10>) (mul_ln1118_40_fu_80451_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_40_fu_80451_p00() {
    mul_ln1118_40_fu_80451_p00 = esl_zext<12,10>(trunc_ln77_37_reg_129631.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_40_fu_80451_p1() {
    mul_ln1118_40_fu_80451_p1 = tmp_73_reg_129636.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_40_fu_80451_p2() {
    mul_ln1118_40_fu_80451_p2 = (!mul_ln1118_40_fu_80451_p0.read().is_01() || !mul_ln1118_40_fu_80451_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_40_fu_80451_p0.read()) * sc_bigint<2>(mul_ln1118_40_fu_80451_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_410_fu_88716_p0() {
    mul_ln1118_410_fu_88716_p0 =  (sc_lv<10>) (zext_ln1116_300_fu_88710_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_410_fu_88716_p1() {
    mul_ln1118_410_fu_88716_p1 = tmp_649_reg_132781.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_410_fu_88716_p2() {
    mul_ln1118_410_fu_88716_p2 = (!mul_ln1118_410_fu_88716_p0.read().is_01() || !mul_ln1118_410_fu_88716_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_410_fu_88716_p0.read()) * sc_bigint<2>(mul_ln1118_410_fu_88716_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_411_fu_88728_p0() {
    mul_ln1118_411_fu_88728_p0 =  (sc_lv<10>) (zext_ln1116_301_fu_88722_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_411_fu_88728_p1() {
    mul_ln1118_411_fu_88728_p1 = tmp_650_reg_132791.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_411_fu_88728_p2() {
    mul_ln1118_411_fu_88728_p2 = (!mul_ln1118_411_fu_88728_p0.read().is_01() || !mul_ln1118_411_fu_88728_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_411_fu_88728_p0.read()) * sc_bigint<2>(mul_ln1118_411_fu_88728_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_412_fu_88752_p0() {
    mul_ln1118_412_fu_88752_p0 =  (sc_lv<10>) (zext_ln1116_302_fu_88746_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_412_fu_88752_p1() {
    mul_ln1118_412_fu_88752_p1 = tmp_651_reg_132801.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_412_fu_88752_p2() {
    mul_ln1118_412_fu_88752_p2 = (!mul_ln1118_412_fu_88752_p0.read().is_01() || !mul_ln1118_412_fu_88752_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_412_fu_88752_p0.read()) * sc_bigint<2>(mul_ln1118_412_fu_88752_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_413_fu_88776_p0() {
    mul_ln1118_413_fu_88776_p0 =  (sc_lv<10>) (zext_ln1116_303_fu_88770_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_413_fu_88776_p1() {
    mul_ln1118_413_fu_88776_p1 = tmp_652_reg_132811.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_413_fu_88776_p2() {
    mul_ln1118_413_fu_88776_p2 = (!mul_ln1118_413_fu_88776_p0.read().is_01() || !mul_ln1118_413_fu_88776_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_413_fu_88776_p0.read()) * sc_bigint<2>(mul_ln1118_413_fu_88776_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_414_fu_88800_p0() {
    mul_ln1118_414_fu_88800_p0 =  (sc_lv<10>) (zext_ln1116_304_fu_88794_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_414_fu_88800_p1() {
    mul_ln1118_414_fu_88800_p1 = tmp_653_reg_132821.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_414_fu_88800_p2() {
    mul_ln1118_414_fu_88800_p2 = (!mul_ln1118_414_fu_88800_p0.read().is_01() || !mul_ln1118_414_fu_88800_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_414_fu_88800_p0.read()) * sc_bigint<2>(mul_ln1118_414_fu_88800_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_415_fu_88824_p0() {
    mul_ln1118_415_fu_88824_p0 =  (sc_lv<10>) (zext_ln1116_305_fu_88818_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_415_fu_88824_p1() {
    mul_ln1118_415_fu_88824_p1 = tmp_654_reg_132831.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_415_fu_88824_p2() {
    mul_ln1118_415_fu_88824_p2 = (!mul_ln1118_415_fu_88824_p0.read().is_01() || !mul_ln1118_415_fu_88824_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_415_fu_88824_p0.read()) * sc_bigint<2>(mul_ln1118_415_fu_88824_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_416_fu_88836_p0() {
    mul_ln1118_416_fu_88836_p0 =  (sc_lv<10>) (zext_ln1116_306_fu_88830_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_416_fu_88836_p1() {
    mul_ln1118_416_fu_88836_p1 = tmp_655_reg_132841.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_416_fu_88836_p2() {
    mul_ln1118_416_fu_88836_p2 = (!mul_ln1118_416_fu_88836_p0.read().is_01() || !mul_ln1118_416_fu_88836_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_416_fu_88836_p0.read()) * sc_bigint<2>(mul_ln1118_416_fu_88836_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_417_fu_88860_p0() {
    mul_ln1118_417_fu_88860_p0 =  (sc_lv<10>) (zext_ln1116_307_fu_88854_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_417_fu_88860_p1() {
    mul_ln1118_417_fu_88860_p1 = tmp_656_reg_132851.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_417_fu_88860_p2() {
    mul_ln1118_417_fu_88860_p2 = (!mul_ln1118_417_fu_88860_p0.read().is_01() || !mul_ln1118_417_fu_88860_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_417_fu_88860_p0.read()) * sc_bigint<2>(mul_ln1118_417_fu_88860_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_418_fu_88884_p0() {
    mul_ln1118_418_fu_88884_p0 =  (sc_lv<10>) (zext_ln1116_308_fu_88878_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_418_fu_88884_p1() {
    mul_ln1118_418_fu_88884_p1 = tmp_657_reg_132861.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_418_fu_88884_p2() {
    mul_ln1118_418_fu_88884_p2 = (!mul_ln1118_418_fu_88884_p0.read().is_01() || !mul_ln1118_418_fu_88884_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_418_fu_88884_p0.read()) * sc_bigint<2>(mul_ln1118_418_fu_88884_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_419_fu_88896_p0() {
    mul_ln1118_419_fu_88896_p0 =  (sc_lv<10>) (mul_ln1118_419_fu_88896_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_419_fu_88896_p00() {
    mul_ln1118_419_fu_88896_p00 = esl_zext<12,10>(trunc_ln77_307_reg_132866.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_419_fu_88896_p1() {
    mul_ln1118_419_fu_88896_p1 = tmp_658_reg_132871.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_419_fu_88896_p2() {
    mul_ln1118_419_fu_88896_p2 = (!mul_ln1118_419_fu_88896_p0.read().is_01() || !mul_ln1118_419_fu_88896_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_419_fu_88896_p0.read()) * sc_bigint<2>(mul_ln1118_419_fu_88896_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_41_fu_80463_p0() {
    mul_ln1118_41_fu_80463_p0 =  (sc_lv<10>) (mul_ln1118_41_fu_80463_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_41_fu_80463_p00() {
    mul_ln1118_41_fu_80463_p00 = esl_zext<12,10>(trunc_ln77_38_reg_129641.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_41_fu_80463_p1() {
    mul_ln1118_41_fu_80463_p1 = tmp_75_reg_129646.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_41_fu_80463_p2() {
    mul_ln1118_41_fu_80463_p2 = (!mul_ln1118_41_fu_80463_p0.read().is_01() || !mul_ln1118_41_fu_80463_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_41_fu_80463_p0.read()) * sc_bigint<2>(mul_ln1118_41_fu_80463_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_420_fu_88920_p0() {
    mul_ln1118_420_fu_88920_p0 =  (sc_lv<10>) (mul_ln1118_420_fu_88920_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_420_fu_88920_p00() {
    mul_ln1118_420_fu_88920_p00 = esl_zext<12,10>(trunc_ln77_308_reg_132876.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_420_fu_88920_p1() {
    mul_ln1118_420_fu_88920_p1 = tmp_659_reg_132881.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_420_fu_88920_p2() {
    mul_ln1118_420_fu_88920_p2 = (!mul_ln1118_420_fu_88920_p0.read().is_01() || !mul_ln1118_420_fu_88920_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_420_fu_88920_p0.read()) * sc_bigint<2>(mul_ln1118_420_fu_88920_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_421_fu_88944_p0() {
    mul_ln1118_421_fu_88944_p0 =  (sc_lv<10>) (mul_ln1118_421_fu_88944_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_421_fu_88944_p00() {
    mul_ln1118_421_fu_88944_p00 = esl_zext<12,10>(trunc_ln77_309_reg_132886.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_421_fu_88944_p1() {
    mul_ln1118_421_fu_88944_p1 = tmp_660_reg_132891.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_421_fu_88944_p2() {
    mul_ln1118_421_fu_88944_p2 = (!mul_ln1118_421_fu_88944_p0.read().is_01() || !mul_ln1118_421_fu_88944_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_421_fu_88944_p0.read()) * sc_bigint<2>(mul_ln1118_421_fu_88944_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_422_fu_88956_p0() {
    mul_ln1118_422_fu_88956_p0 =  (sc_lv<10>) (mul_ln1118_422_fu_88956_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_422_fu_88956_p00() {
    mul_ln1118_422_fu_88956_p00 = esl_zext<12,10>(trunc_ln77_310_reg_132896.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_422_fu_88956_p1() {
    mul_ln1118_422_fu_88956_p1 = tmp_661_reg_132901.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_422_fu_88956_p2() {
    mul_ln1118_422_fu_88956_p2 = (!mul_ln1118_422_fu_88956_p0.read().is_01() || !mul_ln1118_422_fu_88956_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_422_fu_88956_p0.read()) * sc_bigint<2>(mul_ln1118_422_fu_88956_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_423_fu_88980_p0() {
    mul_ln1118_423_fu_88980_p0 =  (sc_lv<10>) (mul_ln1118_423_fu_88980_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_423_fu_88980_p00() {
    mul_ln1118_423_fu_88980_p00 = esl_zext<12,10>(trunc_ln77_311_reg_132906.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_423_fu_88980_p1() {
    mul_ln1118_423_fu_88980_p1 = tmp_662_reg_132911.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_423_fu_88980_p2() {
    mul_ln1118_423_fu_88980_p2 = (!mul_ln1118_423_fu_88980_p0.read().is_01() || !mul_ln1118_423_fu_88980_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_423_fu_88980_p0.read()) * sc_bigint<2>(mul_ln1118_423_fu_88980_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_424_fu_89196_p0() {
    mul_ln1118_424_fu_89196_p0 =  (sc_lv<10>) (mul_ln1118_424_fu_89196_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_424_fu_89196_p00() {
    mul_ln1118_424_fu_89196_p00 = esl_zext<12,10>(trunc_ln77_312_reg_125631_pp0_iter2_reg.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_424_fu_89196_p1() {
    mul_ln1118_424_fu_89196_p1 = tmp_664_reg_132916.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_424_fu_89196_p2() {
    mul_ln1118_424_fu_89196_p2 = (!mul_ln1118_424_fu_89196_p0.read().is_01() || !mul_ln1118_424_fu_89196_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_424_fu_89196_p0.read()) * sc_bigint<2>(mul_ln1118_424_fu_89196_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_425_fu_89220_p0() {
    mul_ln1118_425_fu_89220_p0 =  (sc_lv<10>) (mul_ln1118_425_fu_89220_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_425_fu_89220_p00() {
    mul_ln1118_425_fu_89220_p00 = esl_zext<12,10>(trunc_ln77_313_reg_132921.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_425_fu_89220_p1() {
    mul_ln1118_425_fu_89220_p1 = tmp_666_reg_132926.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_425_fu_89220_p2() {
    mul_ln1118_425_fu_89220_p2 = (!mul_ln1118_425_fu_89220_p0.read().is_01() || !mul_ln1118_425_fu_89220_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_425_fu_89220_p0.read()) * sc_bigint<2>(mul_ln1118_425_fu_89220_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_426_fu_89244_p0() {
    mul_ln1118_426_fu_89244_p0 =  (sc_lv<10>) (mul_ln1118_426_fu_89244_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_426_fu_89244_p00() {
    mul_ln1118_426_fu_89244_p00 = esl_zext<12,10>(trunc_ln77_314_reg_132931.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_426_fu_89244_p1() {
    mul_ln1118_426_fu_89244_p1 = tmp_668_reg_132936.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_426_fu_89244_p2() {
    mul_ln1118_426_fu_89244_p2 = (!mul_ln1118_426_fu_89244_p0.read().is_01() || !mul_ln1118_426_fu_89244_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_426_fu_89244_p0.read()) * sc_bigint<2>(mul_ln1118_426_fu_89244_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_427_fu_89256_p0() {
    mul_ln1118_427_fu_89256_p0 =  (sc_lv<10>) (mul_ln1118_427_fu_89256_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_427_fu_89256_p00() {
    mul_ln1118_427_fu_89256_p00 = esl_zext<12,10>(trunc_ln77_315_reg_132941.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_427_fu_89256_p1() {
    mul_ln1118_427_fu_89256_p1 = tmp_670_reg_132946.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_427_fu_89256_p2() {
    mul_ln1118_427_fu_89256_p2 = (!mul_ln1118_427_fu_89256_p0.read().is_01() || !mul_ln1118_427_fu_89256_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_427_fu_89256_p0.read()) * sc_bigint<2>(mul_ln1118_427_fu_89256_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_428_fu_89280_p0() {
    mul_ln1118_428_fu_89280_p0 =  (sc_lv<10>) (mul_ln1118_428_fu_89280_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_428_fu_89280_p00() {
    mul_ln1118_428_fu_89280_p00 = esl_zext<12,10>(trunc_ln77_316_reg_132951.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_428_fu_89280_p1() {
    mul_ln1118_428_fu_89280_p1 = tmp_671_reg_132956.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_428_fu_89280_p2() {
    mul_ln1118_428_fu_89280_p2 = (!mul_ln1118_428_fu_89280_p0.read().is_01() || !mul_ln1118_428_fu_89280_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_428_fu_89280_p0.read()) * sc_bigint<2>(mul_ln1118_428_fu_89280_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_429_fu_89304_p0() {
    mul_ln1118_429_fu_89304_p0 =  (sc_lv<10>) (mul_ln1118_429_fu_89304_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_429_fu_89304_p00() {
    mul_ln1118_429_fu_89304_p00 = esl_zext<12,10>(trunc_ln77_317_reg_132961.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_429_fu_89304_p1() {
    mul_ln1118_429_fu_89304_p1 = tmp_673_reg_132966.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_429_fu_89304_p2() {
    mul_ln1118_429_fu_89304_p2 = (!mul_ln1118_429_fu_89304_p0.read().is_01() || !mul_ln1118_429_fu_89304_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_429_fu_89304_p0.read()) * sc_bigint<2>(mul_ln1118_429_fu_89304_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_42_fu_80487_p0() {
    mul_ln1118_42_fu_80487_p0 =  (sc_lv<10>) (mul_ln1118_42_fu_80487_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_42_fu_80487_p00() {
    mul_ln1118_42_fu_80487_p00 = esl_zext<12,10>(trunc_ln77_39_reg_129651.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_42_fu_80487_p1() {
    mul_ln1118_42_fu_80487_p1 = tmp_77_reg_129656.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_42_fu_80487_p2() {
    mul_ln1118_42_fu_80487_p2 = (!mul_ln1118_42_fu_80487_p0.read().is_01() || !mul_ln1118_42_fu_80487_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_42_fu_80487_p0.read()) * sc_bigint<2>(mul_ln1118_42_fu_80487_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_430_fu_89328_p0() {
    mul_ln1118_430_fu_89328_p0 =  (sc_lv<10>) (mul_ln1118_430_fu_89328_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_430_fu_89328_p00() {
    mul_ln1118_430_fu_89328_p00 = esl_zext<12,10>(trunc_ln77_318_reg_132971.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_430_fu_89328_p1() {
    mul_ln1118_430_fu_89328_p1 = tmp_675_reg_132976.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_430_fu_89328_p2() {
    mul_ln1118_430_fu_89328_p2 = (!mul_ln1118_430_fu_89328_p0.read().is_01() || !mul_ln1118_430_fu_89328_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_430_fu_89328_p0.read()) * sc_bigint<2>(mul_ln1118_430_fu_89328_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_431_fu_89352_p0() {
    mul_ln1118_431_fu_89352_p0 =  (sc_lv<10>) (mul_ln1118_431_fu_89352_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_431_fu_89352_p00() {
    mul_ln1118_431_fu_89352_p00 = esl_zext<12,10>(trunc_ln77_319_reg_132981.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_431_fu_89352_p1() {
    mul_ln1118_431_fu_89352_p1 = tmp_677_reg_132986.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_431_fu_89352_p2() {
    mul_ln1118_431_fu_89352_p2 = (!mul_ln1118_431_fu_89352_p0.read().is_01() || !mul_ln1118_431_fu_89352_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_431_fu_89352_p0.read()) * sc_bigint<2>(mul_ln1118_431_fu_89352_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_432_fu_89364_p0() {
    mul_ln1118_432_fu_89364_p0 =  (sc_lv<10>) (mul_ln1118_432_fu_89364_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_432_fu_89364_p00() {
    mul_ln1118_432_fu_89364_p00 = esl_zext<12,10>(trunc_ln77_320_reg_132991.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_432_fu_89364_p1() {
    mul_ln1118_432_fu_89364_p1 = tmp_678_reg_132996.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_432_fu_89364_p2() {
    mul_ln1118_432_fu_89364_p2 = (!mul_ln1118_432_fu_89364_p0.read().is_01() || !mul_ln1118_432_fu_89364_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_432_fu_89364_p0.read()) * sc_bigint<2>(mul_ln1118_432_fu_89364_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_433_fu_89388_p0() {
    mul_ln1118_433_fu_89388_p0 =  (sc_lv<10>) (mul_ln1118_433_fu_89388_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_433_fu_89388_p00() {
    mul_ln1118_433_fu_89388_p00 = esl_zext<12,10>(trunc_ln77_321_reg_133001.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_433_fu_89388_p1() {
    mul_ln1118_433_fu_89388_p1 = tmp_679_reg_133006.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_433_fu_89388_p2() {
    mul_ln1118_433_fu_89388_p2 = (!mul_ln1118_433_fu_89388_p0.read().is_01() || !mul_ln1118_433_fu_89388_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_433_fu_89388_p0.read()) * sc_bigint<2>(mul_ln1118_433_fu_89388_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_434_fu_89412_p0() {
    mul_ln1118_434_fu_89412_p0 =  (sc_lv<10>) (mul_ln1118_434_fu_89412_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_434_fu_89412_p00() {
    mul_ln1118_434_fu_89412_p00 = esl_zext<12,10>(trunc_ln77_322_reg_133011.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_434_fu_89412_p1() {
    mul_ln1118_434_fu_89412_p1 = tmp_681_reg_133016.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_434_fu_89412_p2() {
    mul_ln1118_434_fu_89412_p2 = (!mul_ln1118_434_fu_89412_p0.read().is_01() || !mul_ln1118_434_fu_89412_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_434_fu_89412_p0.read()) * sc_bigint<2>(mul_ln1118_434_fu_89412_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_435_fu_89436_p0() {
    mul_ln1118_435_fu_89436_p0 =  (sc_lv<10>) (mul_ln1118_435_fu_89436_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_435_fu_89436_p00() {
    mul_ln1118_435_fu_89436_p00 = esl_zext<12,10>(trunc_ln77_323_reg_133021.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_435_fu_89436_p1() {
    mul_ln1118_435_fu_89436_p1 = tmp_683_reg_133026.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_435_fu_89436_p2() {
    mul_ln1118_435_fu_89436_p2 = (!mul_ln1118_435_fu_89436_p0.read().is_01() || !mul_ln1118_435_fu_89436_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_435_fu_89436_p0.read()) * sc_bigint<2>(mul_ln1118_435_fu_89436_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_436_fu_89460_p0() {
    mul_ln1118_436_fu_89460_p0 =  (sc_lv<10>) (mul_ln1118_436_fu_89460_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_436_fu_89460_p00() {
    mul_ln1118_436_fu_89460_p00 = esl_zext<12,10>(trunc_ln77_324_reg_133031.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_436_fu_89460_p1() {
    mul_ln1118_436_fu_89460_p1 = tmp_685_reg_133036.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_436_fu_89460_p2() {
    mul_ln1118_436_fu_89460_p2 = (!mul_ln1118_436_fu_89460_p0.read().is_01() || !mul_ln1118_436_fu_89460_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_436_fu_89460_p0.read()) * sc_bigint<2>(mul_ln1118_436_fu_89460_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_437_fu_89472_p0() {
    mul_ln1118_437_fu_89472_p0 =  (sc_lv<10>) (mul_ln1118_437_fu_89472_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_437_fu_89472_p00() {
    mul_ln1118_437_fu_89472_p00 = esl_zext<12,10>(trunc_ln77_325_reg_133041.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_437_fu_89472_p1() {
    mul_ln1118_437_fu_89472_p1 = tmp_687_reg_133046.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_437_fu_89472_p2() {
    mul_ln1118_437_fu_89472_p2 = (!mul_ln1118_437_fu_89472_p0.read().is_01() || !mul_ln1118_437_fu_89472_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_437_fu_89472_p0.read()) * sc_bigint<2>(mul_ln1118_437_fu_89472_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_438_fu_89496_p0() {
    mul_ln1118_438_fu_89496_p0 =  (sc_lv<10>) (mul_ln1118_438_fu_89496_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_438_fu_89496_p00() {
    mul_ln1118_438_fu_89496_p00 = esl_zext<12,10>(trunc_ln77_326_reg_133051.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_438_fu_89496_p1() {
    mul_ln1118_438_fu_89496_p1 = tmp_689_reg_133056.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_438_fu_89496_p2() {
    mul_ln1118_438_fu_89496_p2 = (!mul_ln1118_438_fu_89496_p0.read().is_01() || !mul_ln1118_438_fu_89496_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_438_fu_89496_p0.read()) * sc_bigint<2>(mul_ln1118_438_fu_89496_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_439_fu_89520_p0() {
    mul_ln1118_439_fu_89520_p0 =  (sc_lv<10>) (mul_ln1118_439_fu_89520_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_439_fu_89520_p00() {
    mul_ln1118_439_fu_89520_p00 = esl_zext<12,10>(trunc_ln77_327_reg_133061.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_439_fu_89520_p1() {
    mul_ln1118_439_fu_89520_p1 = tmp_691_reg_133066.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_439_fu_89520_p2() {
    mul_ln1118_439_fu_89520_p2 = (!mul_ln1118_439_fu_89520_p0.read().is_01() || !mul_ln1118_439_fu_89520_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_439_fu_89520_p0.read()) * sc_bigint<2>(mul_ln1118_439_fu_89520_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_43_fu_80511_p0() {
    mul_ln1118_43_fu_80511_p0 =  (sc_lv<10>) (mul_ln1118_43_fu_80511_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_43_fu_80511_p00() {
    mul_ln1118_43_fu_80511_p00 = esl_zext<12,10>(trunc_ln77_40_reg_129661.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_43_fu_80511_p1() {
    mul_ln1118_43_fu_80511_p1 = tmp_79_reg_129666.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_43_fu_80511_p2() {
    mul_ln1118_43_fu_80511_p2 = (!mul_ln1118_43_fu_80511_p0.read().is_01() || !mul_ln1118_43_fu_80511_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_43_fu_80511_p0.read()) * sc_bigint<2>(mul_ln1118_43_fu_80511_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_440_fu_89532_p0() {
    mul_ln1118_440_fu_89532_p0 =  (sc_lv<10>) (mul_ln1118_440_fu_89532_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_440_fu_89532_p00() {
    mul_ln1118_440_fu_89532_p00 = esl_zext<12,10>(trunc_ln77_328_reg_133071.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_440_fu_89532_p1() {
    mul_ln1118_440_fu_89532_p1 = tmp_693_reg_133076.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_440_fu_89532_p2() {
    mul_ln1118_440_fu_89532_p2 = (!mul_ln1118_440_fu_89532_p0.read().is_01() || !mul_ln1118_440_fu_89532_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_440_fu_89532_p0.read()) * sc_bigint<2>(mul_ln1118_440_fu_89532_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_441_fu_89556_p0() {
    mul_ln1118_441_fu_89556_p0 =  (sc_lv<10>) (mul_ln1118_441_fu_89556_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_441_fu_89556_p00() {
    mul_ln1118_441_fu_89556_p00 = esl_zext<12,10>(trunc_ln77_329_reg_133081.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_441_fu_89556_p1() {
    mul_ln1118_441_fu_89556_p1 = tmp_694_reg_133086.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_441_fu_89556_p2() {
    mul_ln1118_441_fu_89556_p2 = (!mul_ln1118_441_fu_89556_p0.read().is_01() || !mul_ln1118_441_fu_89556_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_441_fu_89556_p0.read()) * sc_bigint<2>(mul_ln1118_441_fu_89556_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_442_fu_89580_p0() {
    mul_ln1118_442_fu_89580_p0 =  (sc_lv<10>) (mul_ln1118_442_fu_89580_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_442_fu_89580_p00() {
    mul_ln1118_442_fu_89580_p00 = esl_zext<12,10>(trunc_ln77_330_reg_133091.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_442_fu_89580_p1() {
    mul_ln1118_442_fu_89580_p1 = tmp_695_reg_133096.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_442_fu_89580_p2() {
    mul_ln1118_442_fu_89580_p2 = (!mul_ln1118_442_fu_89580_p0.read().is_01() || !mul_ln1118_442_fu_89580_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_442_fu_89580_p0.read()) * sc_bigint<2>(mul_ln1118_442_fu_89580_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_443_fu_89592_p0() {
    mul_ln1118_443_fu_89592_p0 =  (sc_lv<10>) (mul_ln1118_443_fu_89592_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_443_fu_89592_p00() {
    mul_ln1118_443_fu_89592_p00 = esl_zext<12,10>(trunc_ln77_331_reg_133101.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_443_fu_89592_p1() {
    mul_ln1118_443_fu_89592_p1 = tmp_696_reg_133106.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_443_fu_89592_p2() {
    mul_ln1118_443_fu_89592_p2 = (!mul_ln1118_443_fu_89592_p0.read().is_01() || !mul_ln1118_443_fu_89592_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_443_fu_89592_p0.read()) * sc_bigint<2>(mul_ln1118_443_fu_89592_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_444_fu_89616_p0() {
    mul_ln1118_444_fu_89616_p0 =  (sc_lv<10>) (mul_ln1118_444_fu_89616_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_444_fu_89616_p00() {
    mul_ln1118_444_fu_89616_p00 = esl_zext<12,10>(trunc_ln77_332_reg_133111.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_444_fu_89616_p1() {
    mul_ln1118_444_fu_89616_p1 = tmp_697_reg_133116.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_444_fu_89616_p2() {
    mul_ln1118_444_fu_89616_p2 = (!mul_ln1118_444_fu_89616_p0.read().is_01() || !mul_ln1118_444_fu_89616_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_444_fu_89616_p0.read()) * sc_bigint<2>(mul_ln1118_444_fu_89616_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_445_fu_89640_p0() {
    mul_ln1118_445_fu_89640_p0 =  (sc_lv<10>) (mul_ln1118_445_fu_89640_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_445_fu_89640_p00() {
    mul_ln1118_445_fu_89640_p00 = esl_zext<12,10>(trunc_ln77_333_reg_133121.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_445_fu_89640_p1() {
    mul_ln1118_445_fu_89640_p1 = tmp_699_reg_133126.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_445_fu_89640_p2() {
    mul_ln1118_445_fu_89640_p2 = (!mul_ln1118_445_fu_89640_p0.read().is_01() || !mul_ln1118_445_fu_89640_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_445_fu_89640_p0.read()) * sc_bigint<2>(mul_ln1118_445_fu_89640_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_446_fu_89664_p0() {
    mul_ln1118_446_fu_89664_p0 =  (sc_lv<10>) (mul_ln1118_446_fu_89664_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_446_fu_89664_p00() {
    mul_ln1118_446_fu_89664_p00 = esl_zext<12,10>(trunc_ln77_334_reg_133131.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_446_fu_89664_p1() {
    mul_ln1118_446_fu_89664_p1 = tmp_701_reg_133136.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_446_fu_89664_p2() {
    mul_ln1118_446_fu_89664_p2 = (!mul_ln1118_446_fu_89664_p0.read().is_01() || !mul_ln1118_446_fu_89664_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_446_fu_89664_p0.read()) * sc_bigint<2>(mul_ln1118_446_fu_89664_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_447_fu_89688_p0() {
    mul_ln1118_447_fu_89688_p0 =  (sc_lv<10>) (mul_ln1118_447_fu_89688_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_447_fu_89688_p00() {
    mul_ln1118_447_fu_89688_p00 = esl_zext<12,10>(trunc_ln77_335_reg_133141.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_447_fu_89688_p1() {
    mul_ln1118_447_fu_89688_p1 = tmp_703_reg_133146.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_447_fu_89688_p2() {
    mul_ln1118_447_fu_89688_p2 = (!mul_ln1118_447_fu_89688_p0.read().is_01() || !mul_ln1118_447_fu_89688_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_447_fu_89688_p0.read()) * sc_bigint<2>(mul_ln1118_447_fu_89688_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_448_fu_89697_p0() {
    mul_ln1118_448_fu_89697_p0 =  (sc_lv<10>) (zext_ln1116_254_fu_87726_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_448_fu_89697_p1() {
    mul_ln1118_448_fu_89697_p1 = tmp_704_reg_133151.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_448_fu_89697_p2() {
    mul_ln1118_448_fu_89697_p2 = (!mul_ln1118_448_fu_89697_p0.read().is_01() || !mul_ln1118_448_fu_89697_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_448_fu_89697_p0.read()) * sc_bigint<2>(mul_ln1118_448_fu_89697_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_449_fu_89718_p0() {
    mul_ln1118_449_fu_89718_p0 =  (sc_lv<10>) (zext_ln1116_255_fu_87750_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_449_fu_89718_p1() {
    mul_ln1118_449_fu_89718_p1 = tmp_705_reg_133156.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_449_fu_89718_p2() {
    mul_ln1118_449_fu_89718_p2 = (!mul_ln1118_449_fu_89718_p0.read().is_01() || !mul_ln1118_449_fu_89718_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_449_fu_89718_p0.read()) * sc_bigint<2>(mul_ln1118_449_fu_89718_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_44_fu_80523_p0() {
    mul_ln1118_44_fu_80523_p0 =  (sc_lv<10>) (mul_ln1118_44_fu_80523_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_44_fu_80523_p00() {
    mul_ln1118_44_fu_80523_p00 = esl_zext<12,10>(trunc_ln77_41_reg_129671.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_44_fu_80523_p1() {
    mul_ln1118_44_fu_80523_p1 = tmp_81_reg_129676.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_44_fu_80523_p2() {
    mul_ln1118_44_fu_80523_p2 = (!mul_ln1118_44_fu_80523_p0.read().is_01() || !mul_ln1118_44_fu_80523_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_44_fu_80523_p0.read()) * sc_bigint<2>(mul_ln1118_44_fu_80523_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_450_fu_89739_p0() {
    mul_ln1118_450_fu_89739_p0 =  (sc_lv<10>) (zext_ln1116_256_fu_87774_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_450_fu_89739_p1() {
    mul_ln1118_450_fu_89739_p1 = tmp_706_reg_133161.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_450_fu_89739_p2() {
    mul_ln1118_450_fu_89739_p2 = (!mul_ln1118_450_fu_89739_p0.read().is_01() || !mul_ln1118_450_fu_89739_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_450_fu_89739_p0.read()) * sc_bigint<2>(mul_ln1118_450_fu_89739_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_451_fu_89760_p0() {
    mul_ln1118_451_fu_89760_p0 =  (sc_lv<10>) (zext_ln1116_257_fu_87798_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_451_fu_89760_p1() {
    mul_ln1118_451_fu_89760_p1 = tmp_707_reg_133166.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_451_fu_89760_p2() {
    mul_ln1118_451_fu_89760_p2 = (!mul_ln1118_451_fu_89760_p0.read().is_01() || !mul_ln1118_451_fu_89760_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_451_fu_89760_p0.read()) * sc_bigint<2>(mul_ln1118_451_fu_89760_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_452_fu_89781_p0() {
    mul_ln1118_452_fu_89781_p0 =  (sc_lv<10>) (zext_ln1116_258_fu_87822_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_452_fu_89781_p1() {
    mul_ln1118_452_fu_89781_p1 = tmp_708_reg_133171.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_452_fu_89781_p2() {
    mul_ln1118_452_fu_89781_p2 = (!mul_ln1118_452_fu_89781_p0.read().is_01() || !mul_ln1118_452_fu_89781_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_452_fu_89781_p0.read()) * sc_bigint<2>(mul_ln1118_452_fu_89781_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_453_fu_89790_p0() {
    mul_ln1118_453_fu_89790_p0 =  (sc_lv<10>) (zext_ln1116_259_fu_87834_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_453_fu_89790_p1() {
    mul_ln1118_453_fu_89790_p1 = tmp_709_reg_133176.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_453_fu_89790_p2() {
    mul_ln1118_453_fu_89790_p2 = (!mul_ln1118_453_fu_89790_p0.read().is_01() || !mul_ln1118_453_fu_89790_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_453_fu_89790_p0.read()) * sc_bigint<2>(mul_ln1118_453_fu_89790_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_454_fu_89811_p0() {
    mul_ln1118_454_fu_89811_p0 =  (sc_lv<10>) (zext_ln1116_260_fu_87858_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_454_fu_89811_p1() {
    mul_ln1118_454_fu_89811_p1 = tmp_710_reg_133181.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_454_fu_89811_p2() {
    mul_ln1118_454_fu_89811_p2 = (!mul_ln1118_454_fu_89811_p0.read().is_01() || !mul_ln1118_454_fu_89811_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_454_fu_89811_p0.read()) * sc_bigint<2>(mul_ln1118_454_fu_89811_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_455_fu_89832_p0() {
    mul_ln1118_455_fu_89832_p0 =  (sc_lv<10>) (zext_ln1116_261_fu_87882_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_455_fu_89832_p1() {
    mul_ln1118_455_fu_89832_p1 = tmp_711_reg_133186.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_455_fu_89832_p2() {
    mul_ln1118_455_fu_89832_p2 = (!mul_ln1118_455_fu_89832_p0.read().is_01() || !mul_ln1118_455_fu_89832_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_455_fu_89832_p0.read()) * sc_bigint<2>(mul_ln1118_455_fu_89832_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_456_fu_89853_p0() {
    mul_ln1118_456_fu_89853_p0 =  (sc_lv<10>) (zext_ln1116_262_fu_87906_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_456_fu_89853_p1() {
    mul_ln1118_456_fu_89853_p1 = tmp_712_reg_133191.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_456_fu_89853_p2() {
    mul_ln1118_456_fu_89853_p2 = (!mul_ln1118_456_fu_89853_p0.read().is_01() || !mul_ln1118_456_fu_89853_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_456_fu_89853_p0.read()) * sc_bigint<2>(mul_ln1118_456_fu_89853_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_457_fu_89874_p0() {
    mul_ln1118_457_fu_89874_p0 =  (sc_lv<10>) (zext_ln1116_263_fu_87930_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_457_fu_89874_p1() {
    mul_ln1118_457_fu_89874_p1 = tmp_713_reg_133196.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_457_fu_89874_p2() {
    mul_ln1118_457_fu_89874_p2 = (!mul_ln1118_457_fu_89874_p0.read().is_01() || !mul_ln1118_457_fu_89874_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_457_fu_89874_p0.read()) * sc_bigint<2>(mul_ln1118_457_fu_89874_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_458_fu_89883_p0() {
    mul_ln1118_458_fu_89883_p0 =  (sc_lv<10>) (zext_ln1116_264_fu_87942_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_458_fu_89883_p1() {
    mul_ln1118_458_fu_89883_p1 = tmp_714_reg_133201.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_458_fu_89883_p2() {
    mul_ln1118_458_fu_89883_p2 = (!mul_ln1118_458_fu_89883_p0.read().is_01() || !mul_ln1118_458_fu_89883_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_458_fu_89883_p0.read()) * sc_bigint<2>(mul_ln1118_458_fu_89883_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_459_fu_89904_p0() {
    mul_ln1118_459_fu_89904_p0 =  (sc_lv<10>) (zext_ln1116_265_fu_87966_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_459_fu_89904_p1() {
    mul_ln1118_459_fu_89904_p1 = tmp_715_reg_133206.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_459_fu_89904_p2() {
    mul_ln1118_459_fu_89904_p2 = (!mul_ln1118_459_fu_89904_p0.read().is_01() || !mul_ln1118_459_fu_89904_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_459_fu_89904_p0.read()) * sc_bigint<2>(mul_ln1118_459_fu_89904_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_45_fu_80547_p0() {
    mul_ln1118_45_fu_80547_p0 =  (sc_lv<10>) (mul_ln1118_45_fu_80547_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_45_fu_80547_p00() {
    mul_ln1118_45_fu_80547_p00 = esl_zext<12,10>(trunc_ln77_42_reg_129681.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_45_fu_80547_p1() {
    mul_ln1118_45_fu_80547_p1 = tmp_83_reg_129686.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_45_fu_80547_p2() {
    mul_ln1118_45_fu_80547_p2 = (!mul_ln1118_45_fu_80547_p0.read().is_01() || !mul_ln1118_45_fu_80547_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_45_fu_80547_p0.read()) * sc_bigint<2>(mul_ln1118_45_fu_80547_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_460_fu_89925_p0() {
    mul_ln1118_460_fu_89925_p0 =  (sc_lv<10>) (zext_ln1116_266_fu_87990_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_460_fu_89925_p1() {
    mul_ln1118_460_fu_89925_p1 = tmp_716_reg_133211.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_460_fu_89925_p2() {
    mul_ln1118_460_fu_89925_p2 = (!mul_ln1118_460_fu_89925_p0.read().is_01() || !mul_ln1118_460_fu_89925_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_460_fu_89925_p0.read()) * sc_bigint<2>(mul_ln1118_460_fu_89925_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_461_fu_89934_p0() {
    mul_ln1118_461_fu_89934_p0 =  (sc_lv<10>) (zext_ln1116_267_fu_88002_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_461_fu_89934_p1() {
    mul_ln1118_461_fu_89934_p1 = tmp_717_reg_133216.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_461_fu_89934_p2() {
    mul_ln1118_461_fu_89934_p2 = (!mul_ln1118_461_fu_89934_p0.read().is_01() || !mul_ln1118_461_fu_89934_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_461_fu_89934_p0.read()) * sc_bigint<2>(mul_ln1118_461_fu_89934_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_462_fu_89955_p0() {
    mul_ln1118_462_fu_89955_p0 =  (sc_lv<10>) (zext_ln1116_268_fu_88026_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_462_fu_89955_p1() {
    mul_ln1118_462_fu_89955_p1 = tmp_718_reg_133221.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_462_fu_89955_p2() {
    mul_ln1118_462_fu_89955_p2 = (!mul_ln1118_462_fu_89955_p0.read().is_01() || !mul_ln1118_462_fu_89955_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_462_fu_89955_p0.read()) * sc_bigint<2>(mul_ln1118_462_fu_89955_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_463_fu_89976_p0() {
    mul_ln1118_463_fu_89976_p0 =  (sc_lv<10>) (zext_ln1116_269_fu_88050_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_463_fu_89976_p1() {
    mul_ln1118_463_fu_89976_p1 = tmp_719_reg_133226.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_463_fu_89976_p2() {
    mul_ln1118_463_fu_89976_p2 = (!mul_ln1118_463_fu_89976_p0.read().is_01() || !mul_ln1118_463_fu_89976_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_463_fu_89976_p0.read()) * sc_bigint<2>(mul_ln1118_463_fu_89976_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_464_fu_89985_p0() {
    mul_ln1118_464_fu_89985_p0 =  (sc_lv<10>) (zext_ln1116_270_fu_88062_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_464_fu_89985_p1() {
    mul_ln1118_464_fu_89985_p1 = tmp_720_reg_133231.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_464_fu_89985_p2() {
    mul_ln1118_464_fu_89985_p2 = (!mul_ln1118_464_fu_89985_p0.read().is_01() || !mul_ln1118_464_fu_89985_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_464_fu_89985_p0.read()) * sc_bigint<2>(mul_ln1118_464_fu_89985_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_465_fu_90006_p0() {
    mul_ln1118_465_fu_90006_p0 =  (sc_lv<10>) (zext_ln1116_271_fu_88086_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_465_fu_90006_p1() {
    mul_ln1118_465_fu_90006_p1 = tmp_721_reg_133236.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_465_fu_90006_p2() {
    mul_ln1118_465_fu_90006_p2 = (!mul_ln1118_465_fu_90006_p0.read().is_01() || !mul_ln1118_465_fu_90006_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_465_fu_90006_p0.read()) * sc_bigint<2>(mul_ln1118_465_fu_90006_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_466_fu_90027_p0() {
    mul_ln1118_466_fu_90027_p0 =  (sc_lv<10>) (zext_ln1116_272_fu_88110_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_466_fu_90027_p1() {
    mul_ln1118_466_fu_90027_p1 = tmp_722_reg_133241.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_466_fu_90027_p2() {
    mul_ln1118_466_fu_90027_p2 = (!mul_ln1118_466_fu_90027_p0.read().is_01() || !mul_ln1118_466_fu_90027_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_466_fu_90027_p0.read()) * sc_bigint<2>(mul_ln1118_466_fu_90027_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_467_fu_90048_p0() {
    mul_ln1118_467_fu_90048_p0 =  (sc_lv<10>) (zext_ln1116_273_fu_88134_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_467_fu_90048_p1() {
    mul_ln1118_467_fu_90048_p1 = tmp_723_reg_133246.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_467_fu_90048_p2() {
    mul_ln1118_467_fu_90048_p2 = (!mul_ln1118_467_fu_90048_p0.read().is_01() || !mul_ln1118_467_fu_90048_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_467_fu_90048_p0.read()) * sc_bigint<2>(mul_ln1118_467_fu_90048_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_468_fu_90069_p0() {
    mul_ln1118_468_fu_90069_p0 =  (sc_lv<10>) (zext_ln1116_274_fu_88158_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_468_fu_90069_p1() {
    mul_ln1118_468_fu_90069_p1 = tmp_724_reg_133251.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_468_fu_90069_p2() {
    mul_ln1118_468_fu_90069_p2 = (!mul_ln1118_468_fu_90069_p0.read().is_01() || !mul_ln1118_468_fu_90069_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_468_fu_90069_p0.read()) * sc_bigint<2>(mul_ln1118_468_fu_90069_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_469_fu_90078_p0() {
    mul_ln1118_469_fu_90078_p0 =  (sc_lv<10>) (zext_ln1116_275_fu_88170_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_469_fu_90078_p1() {
    mul_ln1118_469_fu_90078_p1 = tmp_725_reg_133256.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_469_fu_90078_p2() {
    mul_ln1118_469_fu_90078_p2 = (!mul_ln1118_469_fu_90078_p0.read().is_01() || !mul_ln1118_469_fu_90078_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_469_fu_90078_p0.read()) * sc_bigint<2>(mul_ln1118_469_fu_90078_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_46_fu_80571_p0() {
    mul_ln1118_46_fu_80571_p0 =  (sc_lv<10>) (mul_ln1118_46_fu_80571_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_46_fu_80571_p00() {
    mul_ln1118_46_fu_80571_p00 = esl_zext<12,10>(trunc_ln77_43_reg_129691.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_46_fu_80571_p1() {
    mul_ln1118_46_fu_80571_p1 = tmp_85_reg_129696.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_46_fu_80571_p2() {
    mul_ln1118_46_fu_80571_p2 = (!mul_ln1118_46_fu_80571_p0.read().is_01() || !mul_ln1118_46_fu_80571_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_46_fu_80571_p0.read()) * sc_bigint<2>(mul_ln1118_46_fu_80571_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_470_fu_90099_p0() {
    mul_ln1118_470_fu_90099_p0 =  (sc_lv<10>) (zext_ln1116_276_fu_88194_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_470_fu_90099_p1() {
    mul_ln1118_470_fu_90099_p1 = tmp_726_reg_133261.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_470_fu_90099_p2() {
    mul_ln1118_470_fu_90099_p2 = (!mul_ln1118_470_fu_90099_p0.read().is_01() || !mul_ln1118_470_fu_90099_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_470_fu_90099_p0.read()) * sc_bigint<2>(mul_ln1118_470_fu_90099_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_471_fu_90120_p0() {
    mul_ln1118_471_fu_90120_p0 =  (sc_lv<10>) (zext_ln1116_277_fu_88218_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_471_fu_90120_p1() {
    mul_ln1118_471_fu_90120_p1 = tmp_727_reg_133266.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_471_fu_90120_p2() {
    mul_ln1118_471_fu_90120_p2 = (!mul_ln1118_471_fu_90120_p0.read().is_01() || !mul_ln1118_471_fu_90120_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_471_fu_90120_p0.read()) * sc_bigint<2>(mul_ln1118_471_fu_90120_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_472_fu_90141_p0() {
    mul_ln1118_472_fu_90141_p0 =  (sc_lv<10>) (zext_ln1116_278_fu_88242_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_472_fu_90141_p1() {
    mul_ln1118_472_fu_90141_p1 = tmp_728_reg_133271.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_472_fu_90141_p2() {
    mul_ln1118_472_fu_90141_p2 = (!mul_ln1118_472_fu_90141_p0.read().is_01() || !mul_ln1118_472_fu_90141_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_472_fu_90141_p0.read()) * sc_bigint<2>(mul_ln1118_472_fu_90141_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_473_fu_90162_p0() {
    mul_ln1118_473_fu_90162_p0 =  (sc_lv<10>) (zext_ln1116_279_fu_88266_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_473_fu_90162_p1() {
    mul_ln1118_473_fu_90162_p1 = tmp_729_reg_133276.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_473_fu_90162_p2() {
    mul_ln1118_473_fu_90162_p2 = (!mul_ln1118_473_fu_90162_p0.read().is_01() || !mul_ln1118_473_fu_90162_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_473_fu_90162_p0.read()) * sc_bigint<2>(mul_ln1118_473_fu_90162_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_474_fu_90171_p0() {
    mul_ln1118_474_fu_90171_p0 =  (sc_lv<10>) (zext_ln1116_280_fu_88278_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_474_fu_90171_p1() {
    mul_ln1118_474_fu_90171_p1 = tmp_730_reg_133281.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_474_fu_90171_p2() {
    mul_ln1118_474_fu_90171_p2 = (!mul_ln1118_474_fu_90171_p0.read().is_01() || !mul_ln1118_474_fu_90171_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_474_fu_90171_p0.read()) * sc_bigint<2>(mul_ln1118_474_fu_90171_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_475_fu_90192_p0() {
    mul_ln1118_475_fu_90192_p0 =  (sc_lv<10>) (zext_ln1116_281_fu_88302_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_475_fu_90192_p1() {
    mul_ln1118_475_fu_90192_p1 = tmp_731_reg_133286.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_475_fu_90192_p2() {
    mul_ln1118_475_fu_90192_p2 = (!mul_ln1118_475_fu_90192_p0.read().is_01() || !mul_ln1118_475_fu_90192_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_475_fu_90192_p0.read()) * sc_bigint<2>(mul_ln1118_475_fu_90192_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_476_fu_90213_p0() {
    mul_ln1118_476_fu_90213_p0 =  (sc_lv<10>) (zext_ln1116_282_fu_88326_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_476_fu_90213_p1() {
    mul_ln1118_476_fu_90213_p1 = tmp_732_reg_133291.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_476_fu_90213_p2() {
    mul_ln1118_476_fu_90213_p2 = (!mul_ln1118_476_fu_90213_p0.read().is_01() || !mul_ln1118_476_fu_90213_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_476_fu_90213_p0.read()) * sc_bigint<2>(mul_ln1118_476_fu_90213_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_477_fu_90234_p0() {
    mul_ln1118_477_fu_90234_p0 =  (sc_lv<10>) (zext_ln1116_283_fu_88350_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_477_fu_90234_p1() {
    mul_ln1118_477_fu_90234_p1 = tmp_733_reg_133296.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_477_fu_90234_p2() {
    mul_ln1118_477_fu_90234_p2 = (!mul_ln1118_477_fu_90234_p0.read().is_01() || !mul_ln1118_477_fu_90234_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_477_fu_90234_p0.read()) * sc_bigint<2>(mul_ln1118_477_fu_90234_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_478_fu_90255_p0() {
    mul_ln1118_478_fu_90255_p0 =  (sc_lv<10>) (zext_ln1116_284_fu_88374_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_478_fu_90255_p1() {
    mul_ln1118_478_fu_90255_p1 = tmp_734_reg_133301.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_478_fu_90255_p2() {
    mul_ln1118_478_fu_90255_p2 = (!mul_ln1118_478_fu_90255_p0.read().is_01() || !mul_ln1118_478_fu_90255_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_478_fu_90255_p0.read()) * sc_bigint<2>(mul_ln1118_478_fu_90255_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_479_fu_90264_p0() {
    mul_ln1118_479_fu_90264_p0 =  (sc_lv<10>) (zext_ln1116_285_fu_88386_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_479_fu_90264_p1() {
    mul_ln1118_479_fu_90264_p1 = tmp_735_reg_133306.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_479_fu_90264_p2() {
    mul_ln1118_479_fu_90264_p2 = (!mul_ln1118_479_fu_90264_p0.read().is_01() || !mul_ln1118_479_fu_90264_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_479_fu_90264_p0.read()) * sc_bigint<2>(mul_ln1118_479_fu_90264_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_47_fu_80595_p0() {
    mul_ln1118_47_fu_80595_p0 =  (sc_lv<10>) (mul_ln1118_47_fu_80595_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_47_fu_80595_p00() {
    mul_ln1118_47_fu_80595_p00 = esl_zext<12,10>(trunc_ln77_44_reg_129701.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_47_fu_80595_p1() {
    mul_ln1118_47_fu_80595_p1 = tmp_87_reg_129706.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_47_fu_80595_p2() {
    mul_ln1118_47_fu_80595_p2 = (!mul_ln1118_47_fu_80595_p0.read().is_01() || !mul_ln1118_47_fu_80595_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_47_fu_80595_p0.read()) * sc_bigint<2>(mul_ln1118_47_fu_80595_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_480_fu_90285_p0() {
    mul_ln1118_480_fu_90285_p0 =  (sc_lv<10>) (zext_ln1116_286_fu_88410_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_480_fu_90285_p1() {
    mul_ln1118_480_fu_90285_p1 = tmp_736_reg_133311.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_480_fu_90285_p2() {
    mul_ln1118_480_fu_90285_p2 = (!mul_ln1118_480_fu_90285_p0.read().is_01() || !mul_ln1118_480_fu_90285_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_480_fu_90285_p0.read()) * sc_bigint<2>(mul_ln1118_480_fu_90285_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_481_fu_90306_p0() {
    mul_ln1118_481_fu_90306_p0 =  (sc_lv<10>) (zext_ln1116_287_fu_88434_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_481_fu_90306_p1() {
    mul_ln1118_481_fu_90306_p1 = tmp_737_reg_133316.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_481_fu_90306_p2() {
    mul_ln1118_481_fu_90306_p2 = (!mul_ln1118_481_fu_90306_p0.read().is_01() || !mul_ln1118_481_fu_90306_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_481_fu_90306_p0.read()) * sc_bigint<2>(mul_ln1118_481_fu_90306_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_482_fu_90315_p0() {
    mul_ln1118_482_fu_90315_p0 =  (sc_lv<10>) (zext_ln1116_288_fu_88446_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_482_fu_90315_p1() {
    mul_ln1118_482_fu_90315_p1 = tmp_738_reg_133321.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_482_fu_90315_p2() {
    mul_ln1118_482_fu_90315_p2 = (!mul_ln1118_482_fu_90315_p0.read().is_01() || !mul_ln1118_482_fu_90315_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_482_fu_90315_p0.read()) * sc_bigint<2>(mul_ln1118_482_fu_90315_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_483_fu_90336_p0() {
    mul_ln1118_483_fu_90336_p0 =  (sc_lv<10>) (zext_ln1116_289_fu_88470_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_483_fu_90336_p1() {
    mul_ln1118_483_fu_90336_p1 = tmp_739_reg_133326.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_483_fu_90336_p2() {
    mul_ln1118_483_fu_90336_p2 = (!mul_ln1118_483_fu_90336_p0.read().is_01() || !mul_ln1118_483_fu_90336_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_483_fu_90336_p0.read()) * sc_bigint<2>(mul_ln1118_483_fu_90336_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_484_fu_90357_p0() {
    mul_ln1118_484_fu_90357_p0 =  (sc_lv<10>) (zext_ln1116_290_fu_88494_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_484_fu_90357_p1() {
    mul_ln1118_484_fu_90357_p1 = tmp_740_reg_133331.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_484_fu_90357_p2() {
    mul_ln1118_484_fu_90357_p2 = (!mul_ln1118_484_fu_90357_p0.read().is_01() || !mul_ln1118_484_fu_90357_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_484_fu_90357_p0.read()) * sc_bigint<2>(mul_ln1118_484_fu_90357_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_485_fu_90366_p0() {
    mul_ln1118_485_fu_90366_p0 =  (sc_lv<10>) (zext_ln1116_291_fu_88506_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_485_fu_90366_p1() {
    mul_ln1118_485_fu_90366_p1 = tmp_741_reg_133336.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_485_fu_90366_p2() {
    mul_ln1118_485_fu_90366_p2 = (!mul_ln1118_485_fu_90366_p0.read().is_01() || !mul_ln1118_485_fu_90366_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_485_fu_90366_p0.read()) * sc_bigint<2>(mul_ln1118_485_fu_90366_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_486_fu_90387_p0() {
    mul_ln1118_486_fu_90387_p0 =  (sc_lv<10>) (zext_ln1116_292_fu_88530_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_486_fu_90387_p1() {
    mul_ln1118_486_fu_90387_p1 = tmp_742_reg_133341.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_486_fu_90387_p2() {
    mul_ln1118_486_fu_90387_p2 = (!mul_ln1118_486_fu_90387_p0.read().is_01() || !mul_ln1118_486_fu_90387_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_486_fu_90387_p0.read()) * sc_bigint<2>(mul_ln1118_486_fu_90387_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_487_fu_90408_p0() {
    mul_ln1118_487_fu_90408_p0 =  (sc_lv<10>) (zext_ln1116_293_fu_88554_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_487_fu_90408_p1() {
    mul_ln1118_487_fu_90408_p1 = tmp_743_reg_133346.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_487_fu_90408_p2() {
    mul_ln1118_487_fu_90408_p2 = (!mul_ln1118_487_fu_90408_p0.read().is_01() || !mul_ln1118_487_fu_90408_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_487_fu_90408_p0.read()) * sc_bigint<2>(mul_ln1118_487_fu_90408_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_488_fu_90429_p0() {
    mul_ln1118_488_fu_90429_p0 =  (sc_lv<10>) (zext_ln1116_294_fu_88578_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_488_fu_90429_p1() {
    mul_ln1118_488_fu_90429_p1 = tmp_744_reg_133351.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_488_fu_90429_p2() {
    mul_ln1118_488_fu_90429_p2 = (!mul_ln1118_488_fu_90429_p0.read().is_01() || !mul_ln1118_488_fu_90429_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_488_fu_90429_p0.read()) * sc_bigint<2>(mul_ln1118_488_fu_90429_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_489_fu_90450_p0() {
    mul_ln1118_489_fu_90450_p0 =  (sc_lv<10>) (zext_ln1116_295_fu_88602_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_489_fu_90450_p1() {
    mul_ln1118_489_fu_90450_p1 = tmp_745_reg_133356.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_489_fu_90450_p2() {
    mul_ln1118_489_fu_90450_p2 = (!mul_ln1118_489_fu_90450_p0.read().is_01() || !mul_ln1118_489_fu_90450_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_489_fu_90450_p0.read()) * sc_bigint<2>(mul_ln1118_489_fu_90450_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_48_fu_80619_p0() {
    mul_ln1118_48_fu_80619_p0 =  (sc_lv<10>) (mul_ln1118_48_fu_80619_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_48_fu_80619_p00() {
    mul_ln1118_48_fu_80619_p00 = esl_zext<12,10>(trunc_ln77_45_reg_129711.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_48_fu_80619_p1() {
    mul_ln1118_48_fu_80619_p1 = tmp_89_reg_129716.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_48_fu_80619_p2() {
    mul_ln1118_48_fu_80619_p2 = (!mul_ln1118_48_fu_80619_p0.read().is_01() || !mul_ln1118_48_fu_80619_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_48_fu_80619_p0.read()) * sc_bigint<2>(mul_ln1118_48_fu_80619_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_490_fu_90459_p0() {
    mul_ln1118_490_fu_90459_p0 =  (sc_lv<10>) (zext_ln1116_296_fu_88614_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_490_fu_90459_p1() {
    mul_ln1118_490_fu_90459_p1 = tmp_746_reg_133361.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_490_fu_90459_p2() {
    mul_ln1118_490_fu_90459_p2 = (!mul_ln1118_490_fu_90459_p0.read().is_01() || !mul_ln1118_490_fu_90459_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_490_fu_90459_p0.read()) * sc_bigint<2>(mul_ln1118_490_fu_90459_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_491_fu_90480_p0() {
    mul_ln1118_491_fu_90480_p0 =  (sc_lv<10>) (zext_ln1116_297_fu_88638_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_491_fu_90480_p1() {
    mul_ln1118_491_fu_90480_p1 = tmp_747_reg_133366.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_491_fu_90480_p2() {
    mul_ln1118_491_fu_90480_p2 = (!mul_ln1118_491_fu_90480_p0.read().is_01() || !mul_ln1118_491_fu_90480_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_491_fu_90480_p0.read()) * sc_bigint<2>(mul_ln1118_491_fu_90480_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_492_fu_90501_p0() {
    mul_ln1118_492_fu_90501_p0 =  (sc_lv<10>) (zext_ln1116_298_fu_88662_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_492_fu_90501_p1() {
    mul_ln1118_492_fu_90501_p1 = tmp_748_reg_133371.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_492_fu_90501_p2() {
    mul_ln1118_492_fu_90501_p2 = (!mul_ln1118_492_fu_90501_p0.read().is_01() || !mul_ln1118_492_fu_90501_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_492_fu_90501_p0.read()) * sc_bigint<2>(mul_ln1118_492_fu_90501_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_493_fu_90522_p0() {
    mul_ln1118_493_fu_90522_p0 =  (sc_lv<10>) (zext_ln1116_299_fu_88686_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_493_fu_90522_p1() {
    mul_ln1118_493_fu_90522_p1 = tmp_749_reg_133376.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_493_fu_90522_p2() {
    mul_ln1118_493_fu_90522_p2 = (!mul_ln1118_493_fu_90522_p0.read().is_01() || !mul_ln1118_493_fu_90522_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_493_fu_90522_p0.read()) * sc_bigint<2>(mul_ln1118_493_fu_90522_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_494_fu_90543_p0() {
    mul_ln1118_494_fu_90543_p0 =  (sc_lv<10>) (zext_ln1116_300_fu_88710_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_494_fu_90543_p1() {
    mul_ln1118_494_fu_90543_p1 = tmp_750_reg_133381.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_494_fu_90543_p2() {
    mul_ln1118_494_fu_90543_p2 = (!mul_ln1118_494_fu_90543_p0.read().is_01() || !mul_ln1118_494_fu_90543_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_494_fu_90543_p0.read()) * sc_bigint<2>(mul_ln1118_494_fu_90543_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_495_fu_90552_p0() {
    mul_ln1118_495_fu_90552_p0 =  (sc_lv<10>) (zext_ln1116_301_fu_88722_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_495_fu_90552_p1() {
    mul_ln1118_495_fu_90552_p1 = tmp_751_reg_133386.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_495_fu_90552_p2() {
    mul_ln1118_495_fu_90552_p2 = (!mul_ln1118_495_fu_90552_p0.read().is_01() || !mul_ln1118_495_fu_90552_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_495_fu_90552_p0.read()) * sc_bigint<2>(mul_ln1118_495_fu_90552_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_496_fu_90573_p0() {
    mul_ln1118_496_fu_90573_p0 =  (sc_lv<10>) (zext_ln1116_302_fu_88746_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_496_fu_90573_p1() {
    mul_ln1118_496_fu_90573_p1 = tmp_752_reg_133391.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_496_fu_90573_p2() {
    mul_ln1118_496_fu_90573_p2 = (!mul_ln1118_496_fu_90573_p0.read().is_01() || !mul_ln1118_496_fu_90573_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_496_fu_90573_p0.read()) * sc_bigint<2>(mul_ln1118_496_fu_90573_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_497_fu_90594_p0() {
    mul_ln1118_497_fu_90594_p0 =  (sc_lv<10>) (zext_ln1116_303_fu_88770_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_497_fu_90594_p1() {
    mul_ln1118_497_fu_90594_p1 = tmp_753_reg_133396.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_497_fu_90594_p2() {
    mul_ln1118_497_fu_90594_p2 = (!mul_ln1118_497_fu_90594_p0.read().is_01() || !mul_ln1118_497_fu_90594_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_497_fu_90594_p0.read()) * sc_bigint<2>(mul_ln1118_497_fu_90594_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_498_fu_90615_p0() {
    mul_ln1118_498_fu_90615_p0 =  (sc_lv<10>) (zext_ln1116_304_fu_88794_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_498_fu_90615_p1() {
    mul_ln1118_498_fu_90615_p1 = tmp_754_reg_133401.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_498_fu_90615_p2() {
    mul_ln1118_498_fu_90615_p2 = (!mul_ln1118_498_fu_90615_p0.read().is_01() || !mul_ln1118_498_fu_90615_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_498_fu_90615_p0.read()) * sc_bigint<2>(mul_ln1118_498_fu_90615_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_499_fu_90636_p0() {
    mul_ln1118_499_fu_90636_p0 =  (sc_lv<10>) (zext_ln1116_305_fu_88818_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_499_fu_90636_p1() {
    mul_ln1118_499_fu_90636_p1 = tmp_755_reg_133406.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_499_fu_90636_p2() {
    mul_ln1118_499_fu_90636_p2 = (!mul_ln1118_499_fu_90636_p0.read().is_01() || !mul_ln1118_499_fu_90636_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_499_fu_90636_p0.read()) * sc_bigint<2>(mul_ln1118_499_fu_90636_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_49_fu_80631_p0() {
    mul_ln1118_49_fu_80631_p0 =  (sc_lv<10>) (mul_ln1118_49_fu_80631_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_49_fu_80631_p00() {
    mul_ln1118_49_fu_80631_p00 = esl_zext<12,10>(trunc_ln77_46_reg_129721.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_49_fu_80631_p1() {
    mul_ln1118_49_fu_80631_p1 = tmp_91_reg_129726.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_49_fu_80631_p2() {
    mul_ln1118_49_fu_80631_p2 = (!mul_ln1118_49_fu_80631_p0.read().is_01() || !mul_ln1118_49_fu_80631_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_49_fu_80631_p0.read()) * sc_bigint<2>(mul_ln1118_49_fu_80631_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_500_fu_90645_p0() {
    mul_ln1118_500_fu_90645_p0 =  (sc_lv<10>) (zext_ln1116_306_fu_88830_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_500_fu_90645_p1() {
    mul_ln1118_500_fu_90645_p1 = tmp_756_reg_133411.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_500_fu_90645_p2() {
    mul_ln1118_500_fu_90645_p2 = (!mul_ln1118_500_fu_90645_p0.read().is_01() || !mul_ln1118_500_fu_90645_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_500_fu_90645_p0.read()) * sc_bigint<2>(mul_ln1118_500_fu_90645_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_501_fu_90666_p0() {
    mul_ln1118_501_fu_90666_p0 =  (sc_lv<10>) (zext_ln1116_307_fu_88854_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_501_fu_90666_p1() {
    mul_ln1118_501_fu_90666_p1 = tmp_757_reg_133416.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_501_fu_90666_p2() {
    mul_ln1118_501_fu_90666_p2 = (!mul_ln1118_501_fu_90666_p0.read().is_01() || !mul_ln1118_501_fu_90666_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_501_fu_90666_p0.read()) * sc_bigint<2>(mul_ln1118_501_fu_90666_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_502_fu_90687_p0() {
    mul_ln1118_502_fu_90687_p0 =  (sc_lv<10>) (zext_ln1116_308_fu_88878_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_502_fu_90687_p1() {
    mul_ln1118_502_fu_90687_p1 = tmp_758_reg_133421.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_502_fu_90687_p2() {
    mul_ln1118_502_fu_90687_p2 = (!mul_ln1118_502_fu_90687_p0.read().is_01() || !mul_ln1118_502_fu_90687_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_502_fu_90687_p0.read()) * sc_bigint<2>(mul_ln1118_502_fu_90687_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_503_fu_90699_p0() {
    mul_ln1118_503_fu_90699_p0 =  (sc_lv<10>) (zext_ln1116_338_fu_90693_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_503_fu_90699_p1() {
    mul_ln1118_503_fu_90699_p1 = tmp_759_reg_133431.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_503_fu_90699_p2() {
    mul_ln1118_503_fu_90699_p2 = (!mul_ln1118_503_fu_90699_p0.read().is_01() || !mul_ln1118_503_fu_90699_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_503_fu_90699_p0.read()) * sc_bigint<2>(mul_ln1118_503_fu_90699_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_504_fu_90723_p0() {
    mul_ln1118_504_fu_90723_p0 =  (sc_lv<10>) (zext_ln1116_339_fu_90717_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_504_fu_90723_p1() {
    mul_ln1118_504_fu_90723_p1 = tmp_760_reg_133441.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_504_fu_90723_p2() {
    mul_ln1118_504_fu_90723_p2 = (!mul_ln1118_504_fu_90723_p0.read().is_01() || !mul_ln1118_504_fu_90723_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_504_fu_90723_p0.read()) * sc_bigint<2>(mul_ln1118_504_fu_90723_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_505_fu_90747_p0() {
    mul_ln1118_505_fu_90747_p0 =  (sc_lv<10>) (zext_ln1116_340_fu_90741_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_505_fu_90747_p1() {
    mul_ln1118_505_fu_90747_p1 = tmp_761_reg_133451.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_505_fu_90747_p2() {
    mul_ln1118_505_fu_90747_p2 = (!mul_ln1118_505_fu_90747_p0.read().is_01() || !mul_ln1118_505_fu_90747_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_505_fu_90747_p0.read()) * sc_bigint<2>(mul_ln1118_505_fu_90747_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_506_fu_90759_p0() {
    mul_ln1118_506_fu_90759_p0 =  (sc_lv<10>) (zext_ln1116_341_fu_90753_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_506_fu_90759_p1() {
    mul_ln1118_506_fu_90759_p1 = tmp_762_reg_133461.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_506_fu_90759_p2() {
    mul_ln1118_506_fu_90759_p2 = (!mul_ln1118_506_fu_90759_p0.read().is_01() || !mul_ln1118_506_fu_90759_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_506_fu_90759_p0.read()) * sc_bigint<2>(mul_ln1118_506_fu_90759_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_507_fu_90783_p0() {
    mul_ln1118_507_fu_90783_p0 =  (sc_lv<10>) (zext_ln1116_342_fu_90777_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_507_fu_90783_p1() {
    mul_ln1118_507_fu_90783_p1 = tmp_763_reg_133471.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_507_fu_90783_p2() {
    mul_ln1118_507_fu_90783_p2 = (!mul_ln1118_507_fu_90783_p0.read().is_01() || !mul_ln1118_507_fu_90783_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_507_fu_90783_p0.read()) * sc_bigint<2>(mul_ln1118_507_fu_90783_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_508_fu_90999_p0() {
    mul_ln1118_508_fu_90999_p0 =  (sc_lv<10>) (zext_ln1116_343_fu_90993_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_508_fu_90999_p1() {
    mul_ln1118_508_fu_90999_p1 = tmp_765_reg_133476.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_508_fu_90999_p2() {
    mul_ln1118_508_fu_90999_p2 = (!mul_ln1118_508_fu_90999_p0.read().is_01() || !mul_ln1118_508_fu_90999_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_508_fu_90999_p0.read()) * sc_bigint<2>(mul_ln1118_508_fu_90999_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_509_fu_91023_p0() {
    mul_ln1118_509_fu_91023_p0 =  (sc_lv<10>) (zext_ln1116_344_fu_91017_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_509_fu_91023_p1() {
    mul_ln1118_509_fu_91023_p1 = tmp_767_reg_133486.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_509_fu_91023_p2() {
    mul_ln1118_509_fu_91023_p2 = (!mul_ln1118_509_fu_91023_p0.read().is_01() || !mul_ln1118_509_fu_91023_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_509_fu_91023_p0.read()) * sc_bigint<2>(mul_ln1118_509_fu_91023_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_50_fu_80655_p0() {
    mul_ln1118_50_fu_80655_p0 =  (sc_lv<10>) (mul_ln1118_50_fu_80655_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_50_fu_80655_p00() {
    mul_ln1118_50_fu_80655_p00 = esl_zext<12,10>(trunc_ln77_47_reg_129731.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_50_fu_80655_p1() {
    mul_ln1118_50_fu_80655_p1 = tmp_93_reg_129736.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_50_fu_80655_p2() {
    mul_ln1118_50_fu_80655_p2 = (!mul_ln1118_50_fu_80655_p0.read().is_01() || !mul_ln1118_50_fu_80655_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_50_fu_80655_p0.read()) * sc_bigint<2>(mul_ln1118_50_fu_80655_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_510_fu_91047_p0() {
    mul_ln1118_510_fu_91047_p0 =  (sc_lv<10>) (zext_ln1116_345_fu_91041_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_510_fu_91047_p1() {
    mul_ln1118_510_fu_91047_p1 = tmp_769_reg_133496.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_510_fu_91047_p2() {
    mul_ln1118_510_fu_91047_p2 = (!mul_ln1118_510_fu_91047_p0.read().is_01() || !mul_ln1118_510_fu_91047_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_510_fu_91047_p0.read()) * sc_bigint<2>(mul_ln1118_510_fu_91047_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_511_fu_91059_p0() {
    mul_ln1118_511_fu_91059_p0 =  (sc_lv<10>) (zext_ln1116_346_fu_91053_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_511_fu_91059_p1() {
    mul_ln1118_511_fu_91059_p1 = tmp_771_reg_133506.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_511_fu_91059_p2() {
    mul_ln1118_511_fu_91059_p2 = (!mul_ln1118_511_fu_91059_p0.read().is_01() || !mul_ln1118_511_fu_91059_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_511_fu_91059_p0.read()) * sc_bigint<2>(mul_ln1118_511_fu_91059_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_512_fu_91083_p0() {
    mul_ln1118_512_fu_91083_p0 =  (sc_lv<10>) (zext_ln1116_347_fu_91077_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_512_fu_91083_p1() {
    mul_ln1118_512_fu_91083_p1 = tmp_772_reg_133516.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_512_fu_91083_p2() {
    mul_ln1118_512_fu_91083_p2 = (!mul_ln1118_512_fu_91083_p0.read().is_01() || !mul_ln1118_512_fu_91083_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_512_fu_91083_p0.read()) * sc_bigint<2>(mul_ln1118_512_fu_91083_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_513_fu_91107_p0() {
    mul_ln1118_513_fu_91107_p0 =  (sc_lv<10>) (zext_ln1116_348_fu_91101_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_513_fu_91107_p1() {
    mul_ln1118_513_fu_91107_p1 = tmp_774_reg_133526.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_513_fu_91107_p2() {
    mul_ln1118_513_fu_91107_p2 = (!mul_ln1118_513_fu_91107_p0.read().is_01() || !mul_ln1118_513_fu_91107_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_513_fu_91107_p0.read()) * sc_bigint<2>(mul_ln1118_513_fu_91107_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_514_fu_91131_p0() {
    mul_ln1118_514_fu_91131_p0 =  (sc_lv<10>) (zext_ln1116_349_fu_91125_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_514_fu_91131_p1() {
    mul_ln1118_514_fu_91131_p1 = tmp_776_reg_133536.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_514_fu_91131_p2() {
    mul_ln1118_514_fu_91131_p2 = (!mul_ln1118_514_fu_91131_p0.read().is_01() || !mul_ln1118_514_fu_91131_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_514_fu_91131_p0.read()) * sc_bigint<2>(mul_ln1118_514_fu_91131_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_515_fu_91155_p0() {
    mul_ln1118_515_fu_91155_p0 =  (sc_lv<10>) (zext_ln1116_350_fu_91149_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_515_fu_91155_p1() {
    mul_ln1118_515_fu_91155_p1 = tmp_778_reg_133546.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_515_fu_91155_p2() {
    mul_ln1118_515_fu_91155_p2 = (!mul_ln1118_515_fu_91155_p0.read().is_01() || !mul_ln1118_515_fu_91155_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_515_fu_91155_p0.read()) * sc_bigint<2>(mul_ln1118_515_fu_91155_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_516_fu_91167_p0() {
    mul_ln1118_516_fu_91167_p0 =  (sc_lv<10>) (zext_ln1116_351_fu_91161_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_516_fu_91167_p1() {
    mul_ln1118_516_fu_91167_p1 = tmp_779_reg_133556.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_516_fu_91167_p2() {
    mul_ln1118_516_fu_91167_p2 = (!mul_ln1118_516_fu_91167_p0.read().is_01() || !mul_ln1118_516_fu_91167_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_516_fu_91167_p0.read()) * sc_bigint<2>(mul_ln1118_516_fu_91167_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_517_fu_91191_p0() {
    mul_ln1118_517_fu_91191_p0 =  (sc_lv<10>) (zext_ln1116_352_fu_91185_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_517_fu_91191_p1() {
    mul_ln1118_517_fu_91191_p1 = tmp_780_reg_133566.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_517_fu_91191_p2() {
    mul_ln1118_517_fu_91191_p2 = (!mul_ln1118_517_fu_91191_p0.read().is_01() || !mul_ln1118_517_fu_91191_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_517_fu_91191_p0.read()) * sc_bigint<2>(mul_ln1118_517_fu_91191_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_518_fu_91215_p0() {
    mul_ln1118_518_fu_91215_p0 =  (sc_lv<10>) (zext_ln1116_353_fu_91209_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_518_fu_91215_p1() {
    mul_ln1118_518_fu_91215_p1 = tmp_782_reg_133576.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_518_fu_91215_p2() {
    mul_ln1118_518_fu_91215_p2 = (!mul_ln1118_518_fu_91215_p0.read().is_01() || !mul_ln1118_518_fu_91215_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_518_fu_91215_p0.read()) * sc_bigint<2>(mul_ln1118_518_fu_91215_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_519_fu_91239_p0() {
    mul_ln1118_519_fu_91239_p0 =  (sc_lv<10>) (zext_ln1116_354_fu_91233_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_519_fu_91239_p1() {
    mul_ln1118_519_fu_91239_p1 = tmp_784_reg_133586.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_519_fu_91239_p2() {
    mul_ln1118_519_fu_91239_p2 = (!mul_ln1118_519_fu_91239_p0.read().is_01() || !mul_ln1118_519_fu_91239_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_519_fu_91239_p0.read()) * sc_bigint<2>(mul_ln1118_519_fu_91239_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_51_fu_80679_p0() {
    mul_ln1118_51_fu_80679_p0 =  (sc_lv<10>) (mul_ln1118_51_fu_80679_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_51_fu_80679_p00() {
    mul_ln1118_51_fu_80679_p00 = esl_zext<12,10>(trunc_ln77_48_reg_129741.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_51_fu_80679_p1() {
    mul_ln1118_51_fu_80679_p1 = tmp_95_reg_129746.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_51_fu_80679_p2() {
    mul_ln1118_51_fu_80679_p2 = (!mul_ln1118_51_fu_80679_p0.read().is_01() || !mul_ln1118_51_fu_80679_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_51_fu_80679_p0.read()) * sc_bigint<2>(mul_ln1118_51_fu_80679_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_520_fu_91263_p0() {
    mul_ln1118_520_fu_91263_p0 =  (sc_lv<10>) (zext_ln1116_355_fu_91257_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_520_fu_91263_p1() {
    mul_ln1118_520_fu_91263_p1 = tmp_786_reg_133596.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_520_fu_91263_p2() {
    mul_ln1118_520_fu_91263_p2 = (!mul_ln1118_520_fu_91263_p0.read().is_01() || !mul_ln1118_520_fu_91263_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_520_fu_91263_p0.read()) * sc_bigint<2>(mul_ln1118_520_fu_91263_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_521_fu_91275_p0() {
    mul_ln1118_521_fu_91275_p0 =  (sc_lv<10>) (zext_ln1116_356_fu_91269_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_521_fu_91275_p1() {
    mul_ln1118_521_fu_91275_p1 = tmp_788_reg_133606.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_521_fu_91275_p2() {
    mul_ln1118_521_fu_91275_p2 = (!mul_ln1118_521_fu_91275_p0.read().is_01() || !mul_ln1118_521_fu_91275_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_521_fu_91275_p0.read()) * sc_bigint<2>(mul_ln1118_521_fu_91275_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_522_fu_91299_p0() {
    mul_ln1118_522_fu_91299_p0 =  (sc_lv<10>) (zext_ln1116_357_fu_91293_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_522_fu_91299_p1() {
    mul_ln1118_522_fu_91299_p1 = tmp_790_reg_133616.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_522_fu_91299_p2() {
    mul_ln1118_522_fu_91299_p2 = (!mul_ln1118_522_fu_91299_p0.read().is_01() || !mul_ln1118_522_fu_91299_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_522_fu_91299_p0.read()) * sc_bigint<2>(mul_ln1118_522_fu_91299_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_523_fu_91323_p0() {
    mul_ln1118_523_fu_91323_p0 =  (sc_lv<10>) (zext_ln1116_358_fu_91317_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_523_fu_91323_p1() {
    mul_ln1118_523_fu_91323_p1 = tmp_792_reg_133626.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_523_fu_91323_p2() {
    mul_ln1118_523_fu_91323_p2 = (!mul_ln1118_523_fu_91323_p0.read().is_01() || !mul_ln1118_523_fu_91323_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_523_fu_91323_p0.read()) * sc_bigint<2>(mul_ln1118_523_fu_91323_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_524_fu_91335_p0() {
    mul_ln1118_524_fu_91335_p0 =  (sc_lv<10>) (zext_ln1116_359_fu_91329_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_524_fu_91335_p1() {
    mul_ln1118_524_fu_91335_p1 = tmp_794_reg_133636.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_524_fu_91335_p2() {
    mul_ln1118_524_fu_91335_p2 = (!mul_ln1118_524_fu_91335_p0.read().is_01() || !mul_ln1118_524_fu_91335_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_524_fu_91335_p0.read()) * sc_bigint<2>(mul_ln1118_524_fu_91335_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_525_fu_91359_p0() {
    mul_ln1118_525_fu_91359_p0 =  (sc_lv<10>) (zext_ln1116_360_fu_91353_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_525_fu_91359_p1() {
    mul_ln1118_525_fu_91359_p1 = tmp_795_reg_133646.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_525_fu_91359_p2() {
    mul_ln1118_525_fu_91359_p2 = (!mul_ln1118_525_fu_91359_p0.read().is_01() || !mul_ln1118_525_fu_91359_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_525_fu_91359_p0.read()) * sc_bigint<2>(mul_ln1118_525_fu_91359_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_526_fu_91383_p0() {
    mul_ln1118_526_fu_91383_p0 =  (sc_lv<10>) (zext_ln1116_361_fu_91377_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_526_fu_91383_p1() {
    mul_ln1118_526_fu_91383_p1 = tmp_796_reg_133656.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_526_fu_91383_p2() {
    mul_ln1118_526_fu_91383_p2 = (!mul_ln1118_526_fu_91383_p0.read().is_01() || !mul_ln1118_526_fu_91383_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_526_fu_91383_p0.read()) * sc_bigint<2>(mul_ln1118_526_fu_91383_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_527_fu_91395_p0() {
    mul_ln1118_527_fu_91395_p0 =  (sc_lv<10>) (zext_ln1116_362_fu_91389_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_527_fu_91395_p1() {
    mul_ln1118_527_fu_91395_p1 = tmp_797_reg_133666.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_527_fu_91395_p2() {
    mul_ln1118_527_fu_91395_p2 = (!mul_ln1118_527_fu_91395_p0.read().is_01() || !mul_ln1118_527_fu_91395_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_527_fu_91395_p0.read()) * sc_bigint<2>(mul_ln1118_527_fu_91395_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_528_fu_91419_p0() {
    mul_ln1118_528_fu_91419_p0 =  (sc_lv<10>) (zext_ln1116_363_fu_91413_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_528_fu_91419_p1() {
    mul_ln1118_528_fu_91419_p1 = tmp_798_reg_133676.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_528_fu_91419_p2() {
    mul_ln1118_528_fu_91419_p2 = (!mul_ln1118_528_fu_91419_p0.read().is_01() || !mul_ln1118_528_fu_91419_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_528_fu_91419_p0.read()) * sc_bigint<2>(mul_ln1118_528_fu_91419_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_529_fu_91443_p0() {
    mul_ln1118_529_fu_91443_p0 =  (sc_lv<10>) (zext_ln1116_364_fu_91437_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_529_fu_91443_p1() {
    mul_ln1118_529_fu_91443_p1 = tmp_800_reg_133686.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_529_fu_91443_p2() {
    mul_ln1118_529_fu_91443_p2 = (!mul_ln1118_529_fu_91443_p0.read().is_01() || !mul_ln1118_529_fu_91443_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_529_fu_91443_p0.read()) * sc_bigint<2>(mul_ln1118_529_fu_91443_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_52_fu_80703_p0() {
    mul_ln1118_52_fu_80703_p0 =  (sc_lv<10>) (mul_ln1118_52_fu_80703_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_52_fu_80703_p00() {
    mul_ln1118_52_fu_80703_p00 = esl_zext<12,10>(trunc_ln77_49_reg_129751.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_52_fu_80703_p1() {
    mul_ln1118_52_fu_80703_p1 = tmp_97_reg_129756.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_52_fu_80703_p2() {
    mul_ln1118_52_fu_80703_p2 = (!mul_ln1118_52_fu_80703_p0.read().is_01() || !mul_ln1118_52_fu_80703_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_52_fu_80703_p0.read()) * sc_bigint<2>(mul_ln1118_52_fu_80703_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_530_fu_91467_p0() {
    mul_ln1118_530_fu_91467_p0 =  (sc_lv<10>) (zext_ln1116_365_fu_91461_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_530_fu_91467_p1() {
    mul_ln1118_530_fu_91467_p1 = tmp_802_reg_133696.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_530_fu_91467_p2() {
    mul_ln1118_530_fu_91467_p2 = (!mul_ln1118_530_fu_91467_p0.read().is_01() || !mul_ln1118_530_fu_91467_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_530_fu_91467_p0.read()) * sc_bigint<2>(mul_ln1118_530_fu_91467_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_531_fu_91491_p0() {
    mul_ln1118_531_fu_91491_p0 =  (sc_lv<10>) (zext_ln1116_366_fu_91485_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_531_fu_91491_p1() {
    mul_ln1118_531_fu_91491_p1 = tmp_804_reg_133706.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_531_fu_91491_p2() {
    mul_ln1118_531_fu_91491_p2 = (!mul_ln1118_531_fu_91491_p0.read().is_01() || !mul_ln1118_531_fu_91491_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_531_fu_91491_p0.read()) * sc_bigint<2>(mul_ln1118_531_fu_91491_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_532_fu_91503_p0() {
    mul_ln1118_532_fu_91503_p0 =  (sc_lv<10>) (zext_ln1116_367_fu_91497_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_532_fu_91503_p1() {
    mul_ln1118_532_fu_91503_p1 = tmp_806_reg_133716.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_532_fu_91503_p2() {
    mul_ln1118_532_fu_91503_p2 = (!mul_ln1118_532_fu_91503_p0.read().is_01() || !mul_ln1118_532_fu_91503_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_532_fu_91503_p0.read()) * sc_bigint<2>(mul_ln1118_532_fu_91503_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_533_fu_91527_p0() {
    mul_ln1118_533_fu_91527_p0 =  (sc_lv<10>) (zext_ln1116_368_fu_91521_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_533_fu_91527_p1() {
    mul_ln1118_533_fu_91527_p1 = tmp_808_reg_133726.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_533_fu_91527_p2() {
    mul_ln1118_533_fu_91527_p2 = (!mul_ln1118_533_fu_91527_p0.read().is_01() || !mul_ln1118_533_fu_91527_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_533_fu_91527_p0.read()) * sc_bigint<2>(mul_ln1118_533_fu_91527_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_534_fu_91551_p0() {
    mul_ln1118_534_fu_91551_p0 =  (sc_lv<10>) (zext_ln1116_369_fu_91545_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_534_fu_91551_p1() {
    mul_ln1118_534_fu_91551_p1 = tmp_810_reg_133736.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_534_fu_91551_p2() {
    mul_ln1118_534_fu_91551_p2 = (!mul_ln1118_534_fu_91551_p0.read().is_01() || !mul_ln1118_534_fu_91551_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_534_fu_91551_p0.read()) * sc_bigint<2>(mul_ln1118_534_fu_91551_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_535_fu_91575_p0() {
    mul_ln1118_535_fu_91575_p0 =  (sc_lv<10>) (zext_ln1116_370_fu_91569_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_535_fu_91575_p1() {
    mul_ln1118_535_fu_91575_p1 = tmp_812_reg_133746.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_535_fu_91575_p2() {
    mul_ln1118_535_fu_91575_p2 = (!mul_ln1118_535_fu_91575_p0.read().is_01() || !mul_ln1118_535_fu_91575_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_535_fu_91575_p0.read()) * sc_bigint<2>(mul_ln1118_535_fu_91575_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_536_fu_91599_p0() {
    mul_ln1118_536_fu_91599_p0 =  (sc_lv<10>) (zext_ln1116_371_fu_91593_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_536_fu_91599_p1() {
    mul_ln1118_536_fu_91599_p1 = tmp_814_reg_133756.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_536_fu_91599_p2() {
    mul_ln1118_536_fu_91599_p2 = (!mul_ln1118_536_fu_91599_p0.read().is_01() || !mul_ln1118_536_fu_91599_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_536_fu_91599_p0.read()) * sc_bigint<2>(mul_ln1118_536_fu_91599_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_537_fu_91611_p0() {
    mul_ln1118_537_fu_91611_p0 =  (sc_lv<10>) (zext_ln1116_372_fu_91605_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_537_fu_91611_p1() {
    mul_ln1118_537_fu_91611_p1 = tmp_816_reg_133766.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_537_fu_91611_p2() {
    mul_ln1118_537_fu_91611_p2 = (!mul_ln1118_537_fu_91611_p0.read().is_01() || !mul_ln1118_537_fu_91611_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_537_fu_91611_p0.read()) * sc_bigint<2>(mul_ln1118_537_fu_91611_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_538_fu_91635_p0() {
    mul_ln1118_538_fu_91635_p0 =  (sc_lv<10>) (zext_ln1116_373_fu_91629_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_538_fu_91635_p1() {
    mul_ln1118_538_fu_91635_p1 = tmp_818_reg_133776.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_538_fu_91635_p2() {
    mul_ln1118_538_fu_91635_p2 = (!mul_ln1118_538_fu_91635_p0.read().is_01() || !mul_ln1118_538_fu_91635_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_538_fu_91635_p0.read()) * sc_bigint<2>(mul_ln1118_538_fu_91635_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_539_fu_91659_p0() {
    mul_ln1118_539_fu_91659_p0 =  (sc_lv<10>) (zext_ln1116_374_fu_91653_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_539_fu_91659_p1() {
    mul_ln1118_539_fu_91659_p1 = tmp_820_reg_133786.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_539_fu_91659_p2() {
    mul_ln1118_539_fu_91659_p2 = (!mul_ln1118_539_fu_91659_p0.read().is_01() || !mul_ln1118_539_fu_91659_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_539_fu_91659_p0.read()) * sc_bigint<2>(mul_ln1118_539_fu_91659_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_53_fu_80727_p0() {
    mul_ln1118_53_fu_80727_p0 =  (sc_lv<10>) (mul_ln1118_53_fu_80727_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_53_fu_80727_p00() {
    mul_ln1118_53_fu_80727_p00 = esl_zext<12,10>(trunc_ln77_50_reg_129761.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_53_fu_80727_p1() {
    mul_ln1118_53_fu_80727_p1 = tmp_99_reg_129766.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_53_fu_80727_p2() {
    mul_ln1118_53_fu_80727_p2 = (!mul_ln1118_53_fu_80727_p0.read().is_01() || !mul_ln1118_53_fu_80727_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_53_fu_80727_p0.read()) * sc_bigint<2>(mul_ln1118_53_fu_80727_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_540_fu_91683_p0() {
    mul_ln1118_540_fu_91683_p0 =  (sc_lv<10>) (zext_ln1116_375_fu_91677_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_540_fu_91683_p1() {
    mul_ln1118_540_fu_91683_p1 = tmp_822_reg_133796.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_540_fu_91683_p2() {
    mul_ln1118_540_fu_91683_p2 = (!mul_ln1118_540_fu_91683_p0.read().is_01() || !mul_ln1118_540_fu_91683_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_540_fu_91683_p0.read()) * sc_bigint<2>(mul_ln1118_540_fu_91683_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_541_fu_91707_p0() {
    mul_ln1118_541_fu_91707_p0 =  (sc_lv<10>) (zext_ln1116_376_fu_91701_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_541_fu_91707_p1() {
    mul_ln1118_541_fu_91707_p1 = tmp_824_reg_133806.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_541_fu_91707_p2() {
    mul_ln1118_541_fu_91707_p2 = (!mul_ln1118_541_fu_91707_p0.read().is_01() || !mul_ln1118_541_fu_91707_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_541_fu_91707_p0.read()) * sc_bigint<2>(mul_ln1118_541_fu_91707_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_542_fu_91719_p0() {
    mul_ln1118_542_fu_91719_p0 =  (sc_lv<10>) (zext_ln1116_377_fu_91713_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_542_fu_91719_p1() {
    mul_ln1118_542_fu_91719_p1 = tmp_825_reg_133816.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_542_fu_91719_p2() {
    mul_ln1118_542_fu_91719_p2 = (!mul_ln1118_542_fu_91719_p0.read().is_01() || !mul_ln1118_542_fu_91719_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_542_fu_91719_p0.read()) * sc_bigint<2>(mul_ln1118_542_fu_91719_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_543_fu_91743_p0() {
    mul_ln1118_543_fu_91743_p0 =  (sc_lv<10>) (zext_ln1116_378_fu_91737_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_543_fu_91743_p1() {
    mul_ln1118_543_fu_91743_p1 = tmp_826_reg_133826.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_543_fu_91743_p2() {
    mul_ln1118_543_fu_91743_p2 = (!mul_ln1118_543_fu_91743_p0.read().is_01() || !mul_ln1118_543_fu_91743_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_543_fu_91743_p0.read()) * sc_bigint<2>(mul_ln1118_543_fu_91743_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_544_fu_91767_p0() {
    mul_ln1118_544_fu_91767_p0 =  (sc_lv<10>) (zext_ln1116_379_fu_91761_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_544_fu_91767_p1() {
    mul_ln1118_544_fu_91767_p1 = tmp_827_reg_133836.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_544_fu_91767_p2() {
    mul_ln1118_544_fu_91767_p2 = (!mul_ln1118_544_fu_91767_p0.read().is_01() || !mul_ln1118_544_fu_91767_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_544_fu_91767_p0.read()) * sc_bigint<2>(mul_ln1118_544_fu_91767_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_545_fu_91779_p0() {
    mul_ln1118_545_fu_91779_p0 =  (sc_lv<10>) (zext_ln1116_380_fu_91773_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_545_fu_91779_p1() {
    mul_ln1118_545_fu_91779_p1 = tmp_828_reg_133846.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_545_fu_91779_p2() {
    mul_ln1118_545_fu_91779_p2 = (!mul_ln1118_545_fu_91779_p0.read().is_01() || !mul_ln1118_545_fu_91779_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_545_fu_91779_p0.read()) * sc_bigint<2>(mul_ln1118_545_fu_91779_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_546_fu_91803_p0() {
    mul_ln1118_546_fu_91803_p0 =  (sc_lv<10>) (zext_ln1116_381_fu_91797_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_546_fu_91803_p1() {
    mul_ln1118_546_fu_91803_p1 = tmp_829_reg_133856.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_546_fu_91803_p2() {
    mul_ln1118_546_fu_91803_p2 = (!mul_ln1118_546_fu_91803_p0.read().is_01() || !mul_ln1118_546_fu_91803_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_546_fu_91803_p0.read()) * sc_bigint<2>(mul_ln1118_546_fu_91803_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_547_fu_91827_p0() {
    mul_ln1118_547_fu_91827_p0 =  (sc_lv<10>) (zext_ln1116_382_fu_91821_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_547_fu_91827_p1() {
    mul_ln1118_547_fu_91827_p1 = tmp_830_reg_133866.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_547_fu_91827_p2() {
    mul_ln1118_547_fu_91827_p2 = (!mul_ln1118_547_fu_91827_p0.read().is_01() || !mul_ln1118_547_fu_91827_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_547_fu_91827_p0.read()) * sc_bigint<2>(mul_ln1118_547_fu_91827_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_548_fu_91839_p0() {
    mul_ln1118_548_fu_91839_p0 =  (sc_lv<10>) (zext_ln1116_383_fu_91833_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_548_fu_91839_p1() {
    mul_ln1118_548_fu_91839_p1 = tmp_831_reg_133876.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_548_fu_91839_p2() {
    mul_ln1118_548_fu_91839_p2 = (!mul_ln1118_548_fu_91839_p0.read().is_01() || !mul_ln1118_548_fu_91839_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_548_fu_91839_p0.read()) * sc_bigint<2>(mul_ln1118_548_fu_91839_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_549_fu_91863_p0() {
    mul_ln1118_549_fu_91863_p0 =  (sc_lv<10>) (zext_ln1116_384_fu_91857_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_549_fu_91863_p1() {
    mul_ln1118_549_fu_91863_p1 = tmp_832_reg_133886.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_549_fu_91863_p2() {
    mul_ln1118_549_fu_91863_p2 = (!mul_ln1118_549_fu_91863_p0.read().is_01() || !mul_ln1118_549_fu_91863_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_549_fu_91863_p0.read()) * sc_bigint<2>(mul_ln1118_549_fu_91863_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_54_fu_80739_p0() {
    mul_ln1118_54_fu_80739_p0 =  (sc_lv<10>) (mul_ln1118_54_fu_80739_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_54_fu_80739_p00() {
    mul_ln1118_54_fu_80739_p00 = esl_zext<12,10>(trunc_ln77_51_reg_129771.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_54_fu_80739_p1() {
    mul_ln1118_54_fu_80739_p1 = tmp_101_reg_129776.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_54_fu_80739_p2() {
    mul_ln1118_54_fu_80739_p2 = (!mul_ln1118_54_fu_80739_p0.read().is_01() || !mul_ln1118_54_fu_80739_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_54_fu_80739_p0.read()) * sc_bigint<2>(mul_ln1118_54_fu_80739_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_550_fu_91887_p0() {
    mul_ln1118_550_fu_91887_p0 =  (sc_lv<10>) (zext_ln1116_385_fu_91881_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_550_fu_91887_p1() {
    mul_ln1118_550_fu_91887_p1 = tmp_834_reg_133896.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_550_fu_91887_p2() {
    mul_ln1118_550_fu_91887_p2 = (!mul_ln1118_550_fu_91887_p0.read().is_01() || !mul_ln1118_550_fu_91887_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_550_fu_91887_p0.read()) * sc_bigint<2>(mul_ln1118_550_fu_91887_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_551_fu_91911_p0() {
    mul_ln1118_551_fu_91911_p0 =  (sc_lv<10>) (zext_ln1116_386_fu_91905_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_551_fu_91911_p1() {
    mul_ln1118_551_fu_91911_p1 = tmp_836_reg_133906.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_551_fu_91911_p2() {
    mul_ln1118_551_fu_91911_p2 = (!mul_ln1118_551_fu_91911_p0.read().is_01() || !mul_ln1118_551_fu_91911_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_551_fu_91911_p0.read()) * sc_bigint<2>(mul_ln1118_551_fu_91911_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_552_fu_91935_p0() {
    mul_ln1118_552_fu_91935_p0 =  (sc_lv<10>) (zext_ln1116_387_fu_91929_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_552_fu_91935_p1() {
    mul_ln1118_552_fu_91935_p1 = tmp_838_reg_133916.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_552_fu_91935_p2() {
    mul_ln1118_552_fu_91935_p2 = (!mul_ln1118_552_fu_91935_p0.read().is_01() || !mul_ln1118_552_fu_91935_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_552_fu_91935_p0.read()) * sc_bigint<2>(mul_ln1118_552_fu_91935_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_553_fu_91947_p0() {
    mul_ln1118_553_fu_91947_p0 =  (sc_lv<10>) (zext_ln1116_388_fu_91941_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_553_fu_91947_p1() {
    mul_ln1118_553_fu_91947_p1 = tmp_840_reg_133926.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_553_fu_91947_p2() {
    mul_ln1118_553_fu_91947_p2 = (!mul_ln1118_553_fu_91947_p0.read().is_01() || !mul_ln1118_553_fu_91947_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_553_fu_91947_p0.read()) * sc_bigint<2>(mul_ln1118_553_fu_91947_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_554_fu_91971_p0() {
    mul_ln1118_554_fu_91971_p0 =  (sc_lv<10>) (zext_ln1116_389_fu_91965_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_554_fu_91971_p1() {
    mul_ln1118_554_fu_91971_p1 = tmp_842_reg_133936.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_554_fu_91971_p2() {
    mul_ln1118_554_fu_91971_p2 = (!mul_ln1118_554_fu_91971_p0.read().is_01() || !mul_ln1118_554_fu_91971_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_554_fu_91971_p0.read()) * sc_bigint<2>(mul_ln1118_554_fu_91971_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_555_fu_91995_p0() {
    mul_ln1118_555_fu_91995_p0 =  (sc_lv<10>) (zext_ln1116_390_fu_91989_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_555_fu_91995_p1() {
    mul_ln1118_555_fu_91995_p1 = tmp_844_reg_133946.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_555_fu_91995_p2() {
    mul_ln1118_555_fu_91995_p2 = (!mul_ln1118_555_fu_91995_p0.read().is_01() || !mul_ln1118_555_fu_91995_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_555_fu_91995_p0.read()) * sc_bigint<2>(mul_ln1118_555_fu_91995_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_556_fu_92019_p0() {
    mul_ln1118_556_fu_92019_p0 =  (sc_lv<10>) (zext_ln1116_391_fu_92013_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_556_fu_92019_p1() {
    mul_ln1118_556_fu_92019_p1 = tmp_846_reg_133956.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_556_fu_92019_p2() {
    mul_ln1118_556_fu_92019_p2 = (!mul_ln1118_556_fu_92019_p0.read().is_01() || !mul_ln1118_556_fu_92019_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_556_fu_92019_p0.read()) * sc_bigint<2>(mul_ln1118_556_fu_92019_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_557_fu_92043_p0() {
    mul_ln1118_557_fu_92043_p0 =  (sc_lv<10>) (zext_ln1116_392_fu_92037_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_557_fu_92043_p1() {
    mul_ln1118_557_fu_92043_p1 = tmp_848_reg_133966.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_557_fu_92043_p2() {
    mul_ln1118_557_fu_92043_p2 = (!mul_ln1118_557_fu_92043_p0.read().is_01() || !mul_ln1118_557_fu_92043_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_557_fu_92043_p0.read()) * sc_bigint<2>(mul_ln1118_557_fu_92043_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_558_fu_92055_p0() {
    mul_ln1118_558_fu_92055_p0 =  (sc_lv<10>) (mul_ln1118_558_fu_92055_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_558_fu_92055_p00() {
    mul_ln1118_558_fu_92055_p00 = esl_zext<12,10>(trunc_ln77_391_reg_133971.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_558_fu_92055_p1() {
    mul_ln1118_558_fu_92055_p1 = tmp_850_reg_133976.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_558_fu_92055_p2() {
    mul_ln1118_558_fu_92055_p2 = (!mul_ln1118_558_fu_92055_p0.read().is_01() || !mul_ln1118_558_fu_92055_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_558_fu_92055_p0.read()) * sc_bigint<2>(mul_ln1118_558_fu_92055_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_559_fu_92079_p0() {
    mul_ln1118_559_fu_92079_p0 =  (sc_lv<10>) (mul_ln1118_559_fu_92079_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_559_fu_92079_p00() {
    mul_ln1118_559_fu_92079_p00 = esl_zext<12,10>(trunc_ln77_392_reg_133981.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_559_fu_92079_p1() {
    mul_ln1118_559_fu_92079_p1 = tmp_852_reg_133986.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_559_fu_92079_p2() {
    mul_ln1118_559_fu_92079_p2 = (!mul_ln1118_559_fu_92079_p0.read().is_01() || !mul_ln1118_559_fu_92079_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_559_fu_92079_p0.read()) * sc_bigint<2>(mul_ln1118_559_fu_92079_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_55_fu_80763_p0() {
    mul_ln1118_55_fu_80763_p0 =  (sc_lv<10>) (mul_ln1118_55_fu_80763_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_55_fu_80763_p00() {
    mul_ln1118_55_fu_80763_p00 = esl_zext<12,10>(trunc_ln77_52_reg_129781.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_55_fu_80763_p1() {
    mul_ln1118_55_fu_80763_p1 = tmp_103_reg_129786.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_55_fu_80763_p2() {
    mul_ln1118_55_fu_80763_p2 = (!mul_ln1118_55_fu_80763_p0.read().is_01() || !mul_ln1118_55_fu_80763_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_55_fu_80763_p0.read()) * sc_bigint<2>(mul_ln1118_55_fu_80763_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_560_fu_92103_p0() {
    mul_ln1118_560_fu_92103_p0 =  (sc_lv<10>) (mul_ln1118_560_fu_92103_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_560_fu_92103_p00() {
    mul_ln1118_560_fu_92103_p00 = esl_zext<12,10>(trunc_ln77_393_reg_133991.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_560_fu_92103_p1() {
    mul_ln1118_560_fu_92103_p1 = tmp_854_reg_133996.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_560_fu_92103_p2() {
    mul_ln1118_560_fu_92103_p2 = (!mul_ln1118_560_fu_92103_p0.read().is_01() || !mul_ln1118_560_fu_92103_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_560_fu_92103_p0.read()) * sc_bigint<2>(mul_ln1118_560_fu_92103_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_561_fu_92127_p0() {
    mul_ln1118_561_fu_92127_p0 =  (sc_lv<10>) (mul_ln1118_561_fu_92127_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_561_fu_92127_p00() {
    mul_ln1118_561_fu_92127_p00 = esl_zext<12,10>(trunc_ln77_394_reg_134001.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_561_fu_92127_p1() {
    mul_ln1118_561_fu_92127_p1 = tmp_856_reg_134006.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_561_fu_92127_p2() {
    mul_ln1118_561_fu_92127_p2 = (!mul_ln1118_561_fu_92127_p0.read().is_01() || !mul_ln1118_561_fu_92127_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_561_fu_92127_p0.read()) * sc_bigint<2>(mul_ln1118_561_fu_92127_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_562_fu_92151_p0() {
    mul_ln1118_562_fu_92151_p0 =  (sc_lv<10>) (mul_ln1118_562_fu_92151_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_562_fu_92151_p00() {
    mul_ln1118_562_fu_92151_p00 = esl_zext<12,10>(trunc_ln77_395_reg_134011.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_562_fu_92151_p1() {
    mul_ln1118_562_fu_92151_p1 = tmp_858_reg_134016.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_562_fu_92151_p2() {
    mul_ln1118_562_fu_92151_p2 = (!mul_ln1118_562_fu_92151_p0.read().is_01() || !mul_ln1118_562_fu_92151_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_562_fu_92151_p0.read()) * sc_bigint<2>(mul_ln1118_562_fu_92151_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_563_fu_92163_p0() {
    mul_ln1118_563_fu_92163_p0 =  (sc_lv<10>) (mul_ln1118_563_fu_92163_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_563_fu_92163_p00() {
    mul_ln1118_563_fu_92163_p00 = esl_zext<12,10>(trunc_ln77_396_reg_134021.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_563_fu_92163_p1() {
    mul_ln1118_563_fu_92163_p1 = tmp_860_reg_134026.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_563_fu_92163_p2() {
    mul_ln1118_563_fu_92163_p2 = (!mul_ln1118_563_fu_92163_p0.read().is_01() || !mul_ln1118_563_fu_92163_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_563_fu_92163_p0.read()) * sc_bigint<2>(mul_ln1118_563_fu_92163_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_564_fu_92187_p0() {
    mul_ln1118_564_fu_92187_p0 =  (sc_lv<10>) (mul_ln1118_564_fu_92187_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_564_fu_92187_p00() {
    mul_ln1118_564_fu_92187_p00 = esl_zext<12,10>(trunc_ln77_397_reg_134031.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_564_fu_92187_p1() {
    mul_ln1118_564_fu_92187_p1 = tmp_862_reg_134036.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_564_fu_92187_p2() {
    mul_ln1118_564_fu_92187_p2 = (!mul_ln1118_564_fu_92187_p0.read().is_01() || !mul_ln1118_564_fu_92187_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_564_fu_92187_p0.read()) * sc_bigint<2>(mul_ln1118_564_fu_92187_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_565_fu_92211_p0() {
    mul_ln1118_565_fu_92211_p0 =  (sc_lv<10>) (mul_ln1118_565_fu_92211_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_565_fu_92211_p00() {
    mul_ln1118_565_fu_92211_p00 = esl_zext<12,10>(trunc_ln77_398_reg_134041.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_565_fu_92211_p1() {
    mul_ln1118_565_fu_92211_p1 = tmp_864_reg_134046.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_565_fu_92211_p2() {
    mul_ln1118_565_fu_92211_p2 = (!mul_ln1118_565_fu_92211_p0.read().is_01() || !mul_ln1118_565_fu_92211_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_565_fu_92211_p0.read()) * sc_bigint<2>(mul_ln1118_565_fu_92211_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_566_fu_92223_p0() {
    mul_ln1118_566_fu_92223_p0 =  (sc_lv<10>) (mul_ln1118_566_fu_92223_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_566_fu_92223_p00() {
    mul_ln1118_566_fu_92223_p00 = esl_zext<12,10>(trunc_ln77_399_reg_134051.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_566_fu_92223_p1() {
    mul_ln1118_566_fu_92223_p1 = tmp_866_reg_134056.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_566_fu_92223_p2() {
    mul_ln1118_566_fu_92223_p2 = (!mul_ln1118_566_fu_92223_p0.read().is_01() || !mul_ln1118_566_fu_92223_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_566_fu_92223_p0.read()) * sc_bigint<2>(mul_ln1118_566_fu_92223_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_567_fu_92247_p0() {
    mul_ln1118_567_fu_92247_p0 =  (sc_lv<10>) (mul_ln1118_567_fu_92247_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_567_fu_92247_p00() {
    mul_ln1118_567_fu_92247_p00 = esl_zext<12,10>(trunc_ln77_400_reg_134061.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_567_fu_92247_p1() {
    mul_ln1118_567_fu_92247_p1 = tmp_868_reg_134066.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_567_fu_92247_p2() {
    mul_ln1118_567_fu_92247_p2 = (!mul_ln1118_567_fu_92247_p0.read().is_01() || !mul_ln1118_567_fu_92247_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_567_fu_92247_p0.read()) * sc_bigint<2>(mul_ln1118_567_fu_92247_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_568_fu_92271_p0() {
    mul_ln1118_568_fu_92271_p0 =  (sc_lv<10>) (mul_ln1118_568_fu_92271_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_568_fu_92271_p00() {
    mul_ln1118_568_fu_92271_p00 = esl_zext<12,10>(trunc_ln77_401_reg_134071.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_568_fu_92271_p1() {
    mul_ln1118_568_fu_92271_p1 = tmp_870_reg_134076.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_568_fu_92271_p2() {
    mul_ln1118_568_fu_92271_p2 = (!mul_ln1118_568_fu_92271_p0.read().is_01() || !mul_ln1118_568_fu_92271_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_568_fu_92271_p0.read()) * sc_bigint<2>(mul_ln1118_568_fu_92271_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_569_fu_92283_p0() {
    mul_ln1118_569_fu_92283_p0 =  (sc_lv<10>) (mul_ln1118_569_fu_92283_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_569_fu_92283_p00() {
    mul_ln1118_569_fu_92283_p00 = esl_zext<12,10>(trunc_ln77_402_reg_134081.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_569_fu_92283_p1() {
    mul_ln1118_569_fu_92283_p1 = tmp_872_reg_134086.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_569_fu_92283_p2() {
    mul_ln1118_569_fu_92283_p2 = (!mul_ln1118_569_fu_92283_p0.read().is_01() || !mul_ln1118_569_fu_92283_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_569_fu_92283_p0.read()) * sc_bigint<2>(mul_ln1118_569_fu_92283_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_56_fu_80787_p0() {
    mul_ln1118_56_fu_80787_p0 =  (sc_lv<10>) (mul_ln1118_56_fu_80787_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_56_fu_80787_p00() {
    mul_ln1118_56_fu_80787_p00 = esl_zext<12,10>(trunc_ln77_53_reg_129791.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_56_fu_80787_p1() {
    mul_ln1118_56_fu_80787_p1 = tmp_105_reg_129796.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_56_fu_80787_p2() {
    mul_ln1118_56_fu_80787_p2 = (!mul_ln1118_56_fu_80787_p0.read().is_01() || !mul_ln1118_56_fu_80787_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_56_fu_80787_p0.read()) * sc_bigint<2>(mul_ln1118_56_fu_80787_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_570_fu_92307_p0() {
    mul_ln1118_570_fu_92307_p0 =  (sc_lv<10>) (mul_ln1118_570_fu_92307_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_570_fu_92307_p00() {
    mul_ln1118_570_fu_92307_p00 = esl_zext<12,10>(trunc_ln77_403_reg_134091.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_570_fu_92307_p1() {
    mul_ln1118_570_fu_92307_p1 = tmp_874_reg_134096.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_570_fu_92307_p2() {
    mul_ln1118_570_fu_92307_p2 = (!mul_ln1118_570_fu_92307_p0.read().is_01() || !mul_ln1118_570_fu_92307_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_570_fu_92307_p0.read()) * sc_bigint<2>(mul_ln1118_570_fu_92307_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_571_fu_92331_p0() {
    mul_ln1118_571_fu_92331_p0 =  (sc_lv<10>) (mul_ln1118_571_fu_92331_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_571_fu_92331_p00() {
    mul_ln1118_571_fu_92331_p00 = esl_zext<12,10>(trunc_ln77_404_reg_134101.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_571_fu_92331_p1() {
    mul_ln1118_571_fu_92331_p1 = tmp_876_reg_134106.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_571_fu_92331_p2() {
    mul_ln1118_571_fu_92331_p2 = (!mul_ln1118_571_fu_92331_p0.read().is_01() || !mul_ln1118_571_fu_92331_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_571_fu_92331_p0.read()) * sc_bigint<2>(mul_ln1118_571_fu_92331_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_572_fu_92355_p0() {
    mul_ln1118_572_fu_92355_p0 =  (sc_lv<10>) (mul_ln1118_572_fu_92355_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_572_fu_92355_p00() {
    mul_ln1118_572_fu_92355_p00 = esl_zext<12,10>(trunc_ln77_405_reg_134111.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_572_fu_92355_p1() {
    mul_ln1118_572_fu_92355_p1 = tmp_878_reg_134116.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_572_fu_92355_p2() {
    mul_ln1118_572_fu_92355_p2 = (!mul_ln1118_572_fu_92355_p0.read().is_01() || !mul_ln1118_572_fu_92355_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_572_fu_92355_p0.read()) * sc_bigint<2>(mul_ln1118_572_fu_92355_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_573_fu_92379_p0() {
    mul_ln1118_573_fu_92379_p0 =  (sc_lv<10>) (mul_ln1118_573_fu_92379_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_573_fu_92379_p00() {
    mul_ln1118_573_fu_92379_p00 = esl_zext<12,10>(trunc_ln77_406_reg_134121.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_573_fu_92379_p1() {
    mul_ln1118_573_fu_92379_p1 = tmp_880_reg_134126.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_573_fu_92379_p2() {
    mul_ln1118_573_fu_92379_p2 = (!mul_ln1118_573_fu_92379_p0.read().is_01() || !mul_ln1118_573_fu_92379_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_573_fu_92379_p0.read()) * sc_bigint<2>(mul_ln1118_573_fu_92379_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_574_fu_92391_p0() {
    mul_ln1118_574_fu_92391_p0 =  (sc_lv<10>) (mul_ln1118_574_fu_92391_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_574_fu_92391_p00() {
    mul_ln1118_574_fu_92391_p00 = esl_zext<12,10>(trunc_ln77_407_reg_134131.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_574_fu_92391_p1() {
    mul_ln1118_574_fu_92391_p1 = tmp_882_reg_134136.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_574_fu_92391_p2() {
    mul_ln1118_574_fu_92391_p2 = (!mul_ln1118_574_fu_92391_p0.read().is_01() || !mul_ln1118_574_fu_92391_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_574_fu_92391_p0.read()) * sc_bigint<2>(mul_ln1118_574_fu_92391_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_575_fu_92415_p0() {
    mul_ln1118_575_fu_92415_p0 =  (sc_lv<10>) (mul_ln1118_575_fu_92415_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_575_fu_92415_p00() {
    mul_ln1118_575_fu_92415_p00 = esl_zext<12,10>(trunc_ln77_408_reg_134141.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_575_fu_92415_p1() {
    mul_ln1118_575_fu_92415_p1 = tmp_884_reg_134146.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_575_fu_92415_p2() {
    mul_ln1118_575_fu_92415_p2 = (!mul_ln1118_575_fu_92415_p0.read().is_01() || !mul_ln1118_575_fu_92415_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_575_fu_92415_p0.read()) * sc_bigint<2>(mul_ln1118_575_fu_92415_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_576_fu_92439_p0() {
    mul_ln1118_576_fu_92439_p0 =  (sc_lv<10>) (mul_ln1118_576_fu_92439_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_576_fu_92439_p00() {
    mul_ln1118_576_fu_92439_p00 = esl_zext<12,10>(trunc_ln77_409_reg_134151.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_576_fu_92439_p1() {
    mul_ln1118_576_fu_92439_p1 = tmp_885_reg_134156.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_576_fu_92439_p2() {
    mul_ln1118_576_fu_92439_p2 = (!mul_ln1118_576_fu_92439_p0.read().is_01() || !mul_ln1118_576_fu_92439_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_576_fu_92439_p0.read()) * sc_bigint<2>(mul_ln1118_576_fu_92439_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_577_fu_92463_p0() {
    mul_ln1118_577_fu_92463_p0 =  (sc_lv<10>) (mul_ln1118_577_fu_92463_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_577_fu_92463_p00() {
    mul_ln1118_577_fu_92463_p00 = esl_zext<12,10>(trunc_ln77_410_reg_134161.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_577_fu_92463_p1() {
    mul_ln1118_577_fu_92463_p1 = tmp_886_reg_134166.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_577_fu_92463_p2() {
    mul_ln1118_577_fu_92463_p2 = (!mul_ln1118_577_fu_92463_p0.read().is_01() || !mul_ln1118_577_fu_92463_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_577_fu_92463_p0.read()) * sc_bigint<2>(mul_ln1118_577_fu_92463_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_578_fu_92487_p0() {
    mul_ln1118_578_fu_92487_p0 =  (sc_lv<10>) (mul_ln1118_578_fu_92487_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_578_fu_92487_p00() {
    mul_ln1118_578_fu_92487_p00 = esl_zext<12,10>(trunc_ln77_411_reg_134171.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_578_fu_92487_p1() {
    mul_ln1118_578_fu_92487_p1 = tmp_887_reg_134176.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_578_fu_92487_p2() {
    mul_ln1118_578_fu_92487_p2 = (!mul_ln1118_578_fu_92487_p0.read().is_01() || !mul_ln1118_578_fu_92487_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_578_fu_92487_p0.read()) * sc_bigint<2>(mul_ln1118_578_fu_92487_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_579_fu_92499_p0() {
    mul_ln1118_579_fu_92499_p0 =  (sc_lv<10>) (mul_ln1118_579_fu_92499_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_579_fu_92499_p00() {
    mul_ln1118_579_fu_92499_p00 = esl_zext<12,10>(trunc_ln77_412_reg_134181.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_579_fu_92499_p1() {
    mul_ln1118_579_fu_92499_p1 = tmp_888_reg_134186.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_579_fu_92499_p2() {
    mul_ln1118_579_fu_92499_p2 = (!mul_ln1118_579_fu_92499_p0.read().is_01() || !mul_ln1118_579_fu_92499_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_579_fu_92499_p0.read()) * sc_bigint<2>(mul_ln1118_579_fu_92499_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_57_fu_80811_p0() {
    mul_ln1118_57_fu_80811_p0 =  (sc_lv<10>) (mul_ln1118_57_fu_80811_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_57_fu_80811_p00() {
    mul_ln1118_57_fu_80811_p00 = esl_zext<12,10>(trunc_ln77_54_reg_129801.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_57_fu_80811_p1() {
    mul_ln1118_57_fu_80811_p1 = tmp_107_reg_129806.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_57_fu_80811_p2() {
    mul_ln1118_57_fu_80811_p2 = (!mul_ln1118_57_fu_80811_p0.read().is_01() || !mul_ln1118_57_fu_80811_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_57_fu_80811_p0.read()) * sc_bigint<2>(mul_ln1118_57_fu_80811_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_580_fu_92523_p0() {
    mul_ln1118_580_fu_92523_p0 =  (sc_lv<10>) (mul_ln1118_580_fu_92523_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_580_fu_92523_p00() {
    mul_ln1118_580_fu_92523_p00 = esl_zext<12,10>(trunc_ln77_413_reg_134191.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_580_fu_92523_p1() {
    mul_ln1118_580_fu_92523_p1 = tmp_889_reg_134196.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_580_fu_92523_p2() {
    mul_ln1118_580_fu_92523_p2 = (!mul_ln1118_580_fu_92523_p0.read().is_01() || !mul_ln1118_580_fu_92523_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_580_fu_92523_p0.read()) * sc_bigint<2>(mul_ln1118_580_fu_92523_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_581_fu_92547_p0() {
    mul_ln1118_581_fu_92547_p0 =  (sc_lv<10>) (mul_ln1118_581_fu_92547_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_581_fu_92547_p00() {
    mul_ln1118_581_fu_92547_p00 = esl_zext<12,10>(trunc_ln77_414_reg_134201.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_581_fu_92547_p1() {
    mul_ln1118_581_fu_92547_p1 = tmp_890_reg_134206.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_581_fu_92547_p2() {
    mul_ln1118_581_fu_92547_p2 = (!mul_ln1118_581_fu_92547_p0.read().is_01() || !mul_ln1118_581_fu_92547_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_581_fu_92547_p0.read()) * sc_bigint<2>(mul_ln1118_581_fu_92547_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_582_fu_92571_p0() {
    mul_ln1118_582_fu_92571_p0 =  (sc_lv<10>) (mul_ln1118_582_fu_92571_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_582_fu_92571_p00() {
    mul_ln1118_582_fu_92571_p00 = esl_zext<12,10>(trunc_ln77_415_reg_134211.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_582_fu_92571_p1() {
    mul_ln1118_582_fu_92571_p1 = tmp_891_reg_134216.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_582_fu_92571_p2() {
    mul_ln1118_582_fu_92571_p2 = (!mul_ln1118_582_fu_92571_p0.read().is_01() || !mul_ln1118_582_fu_92571_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_582_fu_92571_p0.read()) * sc_bigint<2>(mul_ln1118_582_fu_92571_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_583_fu_92595_p0() {
    mul_ln1118_583_fu_92595_p0 =  (sc_lv<10>) (mul_ln1118_583_fu_92595_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_583_fu_92595_p00() {
    mul_ln1118_583_fu_92595_p00 = esl_zext<12,10>(trunc_ln77_416_reg_134221.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_583_fu_92595_p1() {
    mul_ln1118_583_fu_92595_p1 = tmp_892_reg_134226.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_583_fu_92595_p2() {
    mul_ln1118_583_fu_92595_p2 = (!mul_ln1118_583_fu_92595_p0.read().is_01() || !mul_ln1118_583_fu_92595_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_583_fu_92595_p0.read()) * sc_bigint<2>(mul_ln1118_583_fu_92595_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_584_fu_92607_p0() {
    mul_ln1118_584_fu_92607_p0 =  (sc_lv<10>) (mul_ln1118_584_fu_92607_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_584_fu_92607_p00() {
    mul_ln1118_584_fu_92607_p00 = esl_zext<12,10>(trunc_ln77_417_reg_134231.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_584_fu_92607_p1() {
    mul_ln1118_584_fu_92607_p1 = tmp_893_reg_134236.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_584_fu_92607_p2() {
    mul_ln1118_584_fu_92607_p2 = (!mul_ln1118_584_fu_92607_p0.read().is_01() || !mul_ln1118_584_fu_92607_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_584_fu_92607_p0.read()) * sc_bigint<2>(mul_ln1118_584_fu_92607_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_585_fu_92631_p0() {
    mul_ln1118_585_fu_92631_p0 =  (sc_lv<10>) (mul_ln1118_585_fu_92631_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_585_fu_92631_p00() {
    mul_ln1118_585_fu_92631_p00 = esl_zext<12,10>(trunc_ln77_418_reg_134241.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_585_fu_92631_p1() {
    mul_ln1118_585_fu_92631_p1 = tmp_894_reg_134246.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_585_fu_92631_p2() {
    mul_ln1118_585_fu_92631_p2 = (!mul_ln1118_585_fu_92631_p0.read().is_01() || !mul_ln1118_585_fu_92631_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_585_fu_92631_p0.read()) * sc_bigint<2>(mul_ln1118_585_fu_92631_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_586_fu_92655_p0() {
    mul_ln1118_586_fu_92655_p0 =  (sc_lv<10>) (mul_ln1118_586_fu_92655_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_586_fu_92655_p00() {
    mul_ln1118_586_fu_92655_p00 = esl_zext<12,10>(trunc_ln77_419_reg_134251.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_586_fu_92655_p1() {
    mul_ln1118_586_fu_92655_p1 = tmp_895_reg_134256.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_586_fu_92655_p2() {
    mul_ln1118_586_fu_92655_p2 = (!mul_ln1118_586_fu_92655_p0.read().is_01() || !mul_ln1118_586_fu_92655_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_586_fu_92655_p0.read()) * sc_bigint<2>(mul_ln1118_586_fu_92655_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_587_fu_92664_p0() {
    mul_ln1118_587_fu_92664_p0 =  (sc_lv<10>) (zext_ln1116_338_fu_90693_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_587_fu_92664_p1() {
    mul_ln1118_587_fu_92664_p1 = tmp_896_reg_134261.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_587_fu_92664_p2() {
    mul_ln1118_587_fu_92664_p2 = (!mul_ln1118_587_fu_92664_p0.read().is_01() || !mul_ln1118_587_fu_92664_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_587_fu_92664_p0.read()) * sc_bigint<2>(mul_ln1118_587_fu_92664_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_588_fu_92685_p0() {
    mul_ln1118_588_fu_92685_p0 =  (sc_lv<10>) (zext_ln1116_339_fu_90717_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_588_fu_92685_p1() {
    mul_ln1118_588_fu_92685_p1 = tmp_897_reg_134266.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_588_fu_92685_p2() {
    mul_ln1118_588_fu_92685_p2 = (!mul_ln1118_588_fu_92685_p0.read().is_01() || !mul_ln1118_588_fu_92685_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_588_fu_92685_p0.read()) * sc_bigint<2>(mul_ln1118_588_fu_92685_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_589_fu_92706_p0() {
    mul_ln1118_589_fu_92706_p0 =  (sc_lv<10>) (zext_ln1116_340_fu_90741_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_589_fu_92706_p1() {
    mul_ln1118_589_fu_92706_p1 = tmp_898_reg_134271.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_589_fu_92706_p2() {
    mul_ln1118_589_fu_92706_p2 = (!mul_ln1118_589_fu_92706_p0.read().is_01() || !mul_ln1118_589_fu_92706_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_589_fu_92706_p0.read()) * sc_bigint<2>(mul_ln1118_589_fu_92706_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_58_fu_80835_p0() {
    mul_ln1118_58_fu_80835_p0 =  (sc_lv<10>) (mul_ln1118_58_fu_80835_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_58_fu_80835_p00() {
    mul_ln1118_58_fu_80835_p00 = esl_zext<12,10>(trunc_ln77_55_reg_129811.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_58_fu_80835_p1() {
    mul_ln1118_58_fu_80835_p1 = tmp_109_reg_129816.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_58_fu_80835_p2() {
    mul_ln1118_58_fu_80835_p2 = (!mul_ln1118_58_fu_80835_p0.read().is_01() || !mul_ln1118_58_fu_80835_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_58_fu_80835_p0.read()) * sc_bigint<2>(mul_ln1118_58_fu_80835_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_590_fu_92715_p0() {
    mul_ln1118_590_fu_92715_p0 =  (sc_lv<10>) (zext_ln1116_341_fu_90753_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_590_fu_92715_p1() {
    mul_ln1118_590_fu_92715_p1 = tmp_899_reg_134276.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_590_fu_92715_p2() {
    mul_ln1118_590_fu_92715_p2 = (!mul_ln1118_590_fu_92715_p0.read().is_01() || !mul_ln1118_590_fu_92715_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_590_fu_92715_p0.read()) * sc_bigint<2>(mul_ln1118_590_fu_92715_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_591_fu_92736_p0() {
    mul_ln1118_591_fu_92736_p0 =  (sc_lv<10>) (zext_ln1116_342_fu_90777_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_591_fu_92736_p1() {
    mul_ln1118_591_fu_92736_p1 = tmp_900_reg_134281.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_591_fu_92736_p2() {
    mul_ln1118_591_fu_92736_p2 = (!mul_ln1118_591_fu_92736_p0.read().is_01() || !mul_ln1118_591_fu_92736_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_591_fu_92736_p0.read()) * sc_bigint<2>(mul_ln1118_591_fu_92736_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_592_fu_92949_p0() {
    mul_ln1118_592_fu_92949_p0 =  (sc_lv<10>) (zext_ln1116_343_fu_90993_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_592_fu_92949_p1() {
    mul_ln1118_592_fu_92949_p1 = tmp_901_reg_134286.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_592_fu_92949_p2() {
    mul_ln1118_592_fu_92949_p2 = (!mul_ln1118_592_fu_92949_p0.read().is_01() || !mul_ln1118_592_fu_92949_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_592_fu_92949_p0.read()) * sc_bigint<2>(mul_ln1118_592_fu_92949_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_593_fu_92970_p0() {
    mul_ln1118_593_fu_92970_p0 =  (sc_lv<10>) (zext_ln1116_344_fu_91017_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_593_fu_92970_p1() {
    mul_ln1118_593_fu_92970_p1 = tmp_902_reg_134291.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_593_fu_92970_p2() {
    mul_ln1118_593_fu_92970_p2 = (!mul_ln1118_593_fu_92970_p0.read().is_01() || !mul_ln1118_593_fu_92970_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_593_fu_92970_p0.read()) * sc_bigint<2>(mul_ln1118_593_fu_92970_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_594_fu_92991_p0() {
    mul_ln1118_594_fu_92991_p0 =  (sc_lv<10>) (zext_ln1116_345_fu_91041_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_594_fu_92991_p1() {
    mul_ln1118_594_fu_92991_p1 = tmp_903_reg_134296.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_594_fu_92991_p2() {
    mul_ln1118_594_fu_92991_p2 = (!mul_ln1118_594_fu_92991_p0.read().is_01() || !mul_ln1118_594_fu_92991_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_594_fu_92991_p0.read()) * sc_bigint<2>(mul_ln1118_594_fu_92991_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_595_fu_93000_p0() {
    mul_ln1118_595_fu_93000_p0 =  (sc_lv<10>) (zext_ln1116_346_fu_91053_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_595_fu_93000_p1() {
    mul_ln1118_595_fu_93000_p1 = tmp_904_reg_134301.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_595_fu_93000_p2() {
    mul_ln1118_595_fu_93000_p2 = (!mul_ln1118_595_fu_93000_p0.read().is_01() || !mul_ln1118_595_fu_93000_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_595_fu_93000_p0.read()) * sc_bigint<2>(mul_ln1118_595_fu_93000_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_596_fu_93021_p0() {
    mul_ln1118_596_fu_93021_p0 =  (sc_lv<10>) (zext_ln1116_347_fu_91077_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_596_fu_93021_p1() {
    mul_ln1118_596_fu_93021_p1 = tmp_905_reg_134306.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_596_fu_93021_p2() {
    mul_ln1118_596_fu_93021_p2 = (!mul_ln1118_596_fu_93021_p0.read().is_01() || !mul_ln1118_596_fu_93021_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_596_fu_93021_p0.read()) * sc_bigint<2>(mul_ln1118_596_fu_93021_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_597_fu_93042_p0() {
    mul_ln1118_597_fu_93042_p0 =  (sc_lv<10>) (zext_ln1116_348_fu_91101_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_597_fu_93042_p1() {
    mul_ln1118_597_fu_93042_p1 = tmp_906_reg_134311.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_597_fu_93042_p2() {
    mul_ln1118_597_fu_93042_p2 = (!mul_ln1118_597_fu_93042_p0.read().is_01() || !mul_ln1118_597_fu_93042_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_597_fu_93042_p0.read()) * sc_bigint<2>(mul_ln1118_597_fu_93042_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_598_fu_93063_p0() {
    mul_ln1118_598_fu_93063_p0 =  (sc_lv<10>) (zext_ln1116_349_fu_91125_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_598_fu_93063_p1() {
    mul_ln1118_598_fu_93063_p1 = tmp_907_reg_134316.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_598_fu_93063_p2() {
    mul_ln1118_598_fu_93063_p2 = (!mul_ln1118_598_fu_93063_p0.read().is_01() || !mul_ln1118_598_fu_93063_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_598_fu_93063_p0.read()) * sc_bigint<2>(mul_ln1118_598_fu_93063_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_599_fu_93084_p0() {
    mul_ln1118_599_fu_93084_p0 =  (sc_lv<10>) (zext_ln1116_350_fu_91149_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_599_fu_93084_p1() {
    mul_ln1118_599_fu_93084_p1 = tmp_908_reg_134321.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_599_fu_93084_p2() {
    mul_ln1118_599_fu_93084_p2 = (!mul_ln1118_599_fu_93084_p0.read().is_01() || !mul_ln1118_599_fu_93084_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_599_fu_93084_p0.read()) * sc_bigint<2>(mul_ln1118_599_fu_93084_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_59_fu_80847_p0() {
    mul_ln1118_59_fu_80847_p0 =  (sc_lv<10>) (mul_ln1118_59_fu_80847_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_59_fu_80847_p00() {
    mul_ln1118_59_fu_80847_p00 = esl_zext<12,10>(trunc_ln77_56_reg_129821.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_59_fu_80847_p1() {
    mul_ln1118_59_fu_80847_p1 = tmp_111_reg_129826.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_59_fu_80847_p2() {
    mul_ln1118_59_fu_80847_p2 = (!mul_ln1118_59_fu_80847_p0.read().is_01() || !mul_ln1118_59_fu_80847_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_59_fu_80847_p0.read()) * sc_bigint<2>(mul_ln1118_59_fu_80847_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_5_fu_79707_p0() {
    mul_ln1118_5_fu_79707_p0 =  (sc_lv<10>) (mul_ln1118_5_fu_79707_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_5_fu_79707_p00() {
    mul_ln1118_5_fu_79707_p00 = esl_zext<12,10>(trunc_ln77_2_reg_129281.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_5_fu_79707_p1() {
    mul_ln1118_5_fu_79707_p1 = tmp_9_reg_129286.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_5_fu_79707_p2() {
    mul_ln1118_5_fu_79707_p2 = (!mul_ln1118_5_fu_79707_p0.read().is_01() || !mul_ln1118_5_fu_79707_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_5_fu_79707_p0.read()) * sc_bigint<2>(mul_ln1118_5_fu_79707_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_600_fu_93093_p0() {
    mul_ln1118_600_fu_93093_p0 =  (sc_lv<10>) (zext_ln1116_351_fu_91161_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_600_fu_93093_p1() {
    mul_ln1118_600_fu_93093_p1 = tmp_909_reg_134326.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_600_fu_93093_p2() {
    mul_ln1118_600_fu_93093_p2 = (!mul_ln1118_600_fu_93093_p0.read().is_01() || !mul_ln1118_600_fu_93093_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_600_fu_93093_p0.read()) * sc_bigint<2>(mul_ln1118_600_fu_93093_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_601_fu_93114_p0() {
    mul_ln1118_601_fu_93114_p0 =  (sc_lv<10>) (zext_ln1116_352_fu_91185_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_601_fu_93114_p1() {
    mul_ln1118_601_fu_93114_p1 = tmp_910_reg_134331.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_601_fu_93114_p2() {
    mul_ln1118_601_fu_93114_p2 = (!mul_ln1118_601_fu_93114_p0.read().is_01() || !mul_ln1118_601_fu_93114_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_601_fu_93114_p0.read()) * sc_bigint<2>(mul_ln1118_601_fu_93114_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_602_fu_93135_p0() {
    mul_ln1118_602_fu_93135_p0 =  (sc_lv<10>) (zext_ln1116_353_fu_91209_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_602_fu_93135_p1() {
    mul_ln1118_602_fu_93135_p1 = tmp_911_reg_134336.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_602_fu_93135_p2() {
    mul_ln1118_602_fu_93135_p2 = (!mul_ln1118_602_fu_93135_p0.read().is_01() || !mul_ln1118_602_fu_93135_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_602_fu_93135_p0.read()) * sc_bigint<2>(mul_ln1118_602_fu_93135_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_603_fu_93156_p0() {
    mul_ln1118_603_fu_93156_p0 =  (sc_lv<10>) (zext_ln1116_354_fu_91233_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_603_fu_93156_p1() {
    mul_ln1118_603_fu_93156_p1 = tmp_912_reg_134341.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_603_fu_93156_p2() {
    mul_ln1118_603_fu_93156_p2 = (!mul_ln1118_603_fu_93156_p0.read().is_01() || !mul_ln1118_603_fu_93156_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_603_fu_93156_p0.read()) * sc_bigint<2>(mul_ln1118_603_fu_93156_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_604_fu_93177_p0() {
    mul_ln1118_604_fu_93177_p0 =  (sc_lv<10>) (zext_ln1116_355_fu_91257_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_604_fu_93177_p1() {
    mul_ln1118_604_fu_93177_p1 = tmp_913_reg_134346.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_604_fu_93177_p2() {
    mul_ln1118_604_fu_93177_p2 = (!mul_ln1118_604_fu_93177_p0.read().is_01() || !mul_ln1118_604_fu_93177_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_604_fu_93177_p0.read()) * sc_bigint<2>(mul_ln1118_604_fu_93177_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_605_fu_93186_p0() {
    mul_ln1118_605_fu_93186_p0 =  (sc_lv<10>) (zext_ln1116_356_fu_91269_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_605_fu_93186_p1() {
    mul_ln1118_605_fu_93186_p1 = tmp_914_reg_134351.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_605_fu_93186_p2() {
    mul_ln1118_605_fu_93186_p2 = (!mul_ln1118_605_fu_93186_p0.read().is_01() || !mul_ln1118_605_fu_93186_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_605_fu_93186_p0.read()) * sc_bigint<2>(mul_ln1118_605_fu_93186_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_606_fu_93207_p0() {
    mul_ln1118_606_fu_93207_p0 =  (sc_lv<10>) (zext_ln1116_357_fu_91293_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_606_fu_93207_p1() {
    mul_ln1118_606_fu_93207_p1 = tmp_915_reg_134356.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_606_fu_93207_p2() {
    mul_ln1118_606_fu_93207_p2 = (!mul_ln1118_606_fu_93207_p0.read().is_01() || !mul_ln1118_606_fu_93207_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_606_fu_93207_p0.read()) * sc_bigint<2>(mul_ln1118_606_fu_93207_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_607_fu_93228_p0() {
    mul_ln1118_607_fu_93228_p0 =  (sc_lv<10>) (zext_ln1116_358_fu_91317_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_607_fu_93228_p1() {
    mul_ln1118_607_fu_93228_p1 = tmp_916_reg_134361.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_607_fu_93228_p2() {
    mul_ln1118_607_fu_93228_p2 = (!mul_ln1118_607_fu_93228_p0.read().is_01() || !mul_ln1118_607_fu_93228_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_607_fu_93228_p0.read()) * sc_bigint<2>(mul_ln1118_607_fu_93228_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_608_fu_93237_p0() {
    mul_ln1118_608_fu_93237_p0 =  (sc_lv<10>) (zext_ln1116_359_fu_91329_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_608_fu_93237_p1() {
    mul_ln1118_608_fu_93237_p1 = tmp_917_reg_134366.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_608_fu_93237_p2() {
    mul_ln1118_608_fu_93237_p2 = (!mul_ln1118_608_fu_93237_p0.read().is_01() || !mul_ln1118_608_fu_93237_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_608_fu_93237_p0.read()) * sc_bigint<2>(mul_ln1118_608_fu_93237_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_609_fu_93258_p0() {
    mul_ln1118_609_fu_93258_p0 =  (sc_lv<10>) (zext_ln1116_360_fu_91353_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_609_fu_93258_p1() {
    mul_ln1118_609_fu_93258_p1 = tmp_918_reg_134371.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_609_fu_93258_p2() {
    mul_ln1118_609_fu_93258_p2 = (!mul_ln1118_609_fu_93258_p0.read().is_01() || !mul_ln1118_609_fu_93258_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_609_fu_93258_p0.read()) * sc_bigint<2>(mul_ln1118_609_fu_93258_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_60_fu_80871_p0() {
    mul_ln1118_60_fu_80871_p0 =  (sc_lv<10>) (mul_ln1118_60_fu_80871_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_60_fu_80871_p00() {
    mul_ln1118_60_fu_80871_p00 = esl_zext<12,10>(trunc_ln77_57_reg_129831.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_60_fu_80871_p1() {
    mul_ln1118_60_fu_80871_p1 = tmp_113_reg_129836.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_60_fu_80871_p2() {
    mul_ln1118_60_fu_80871_p2 = (!mul_ln1118_60_fu_80871_p0.read().is_01() || !mul_ln1118_60_fu_80871_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_60_fu_80871_p0.read()) * sc_bigint<2>(mul_ln1118_60_fu_80871_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_610_fu_93279_p0() {
    mul_ln1118_610_fu_93279_p0 =  (sc_lv<10>) (zext_ln1116_361_fu_91377_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_610_fu_93279_p1() {
    mul_ln1118_610_fu_93279_p1 = tmp_919_reg_134376.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_610_fu_93279_p2() {
    mul_ln1118_610_fu_93279_p2 = (!mul_ln1118_610_fu_93279_p0.read().is_01() || !mul_ln1118_610_fu_93279_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_610_fu_93279_p0.read()) * sc_bigint<2>(mul_ln1118_610_fu_93279_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_611_fu_93288_p0() {
    mul_ln1118_611_fu_93288_p0 =  (sc_lv<10>) (zext_ln1116_362_fu_91389_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_611_fu_93288_p1() {
    mul_ln1118_611_fu_93288_p1 = tmp_920_reg_134381.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_611_fu_93288_p2() {
    mul_ln1118_611_fu_93288_p2 = (!mul_ln1118_611_fu_93288_p0.read().is_01() || !mul_ln1118_611_fu_93288_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_611_fu_93288_p0.read()) * sc_bigint<2>(mul_ln1118_611_fu_93288_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_612_fu_93309_p0() {
    mul_ln1118_612_fu_93309_p0 =  (sc_lv<10>) (zext_ln1116_363_fu_91413_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_612_fu_93309_p1() {
    mul_ln1118_612_fu_93309_p1 = tmp_921_reg_134386.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_612_fu_93309_p2() {
    mul_ln1118_612_fu_93309_p2 = (!mul_ln1118_612_fu_93309_p0.read().is_01() || !mul_ln1118_612_fu_93309_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_612_fu_93309_p0.read()) * sc_bigint<2>(mul_ln1118_612_fu_93309_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_613_fu_93330_p0() {
    mul_ln1118_613_fu_93330_p0 =  (sc_lv<10>) (zext_ln1116_364_fu_91437_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_613_fu_93330_p1() {
    mul_ln1118_613_fu_93330_p1 = tmp_922_reg_134391.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_613_fu_93330_p2() {
    mul_ln1118_613_fu_93330_p2 = (!mul_ln1118_613_fu_93330_p0.read().is_01() || !mul_ln1118_613_fu_93330_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_613_fu_93330_p0.read()) * sc_bigint<2>(mul_ln1118_613_fu_93330_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_614_fu_93351_p0() {
    mul_ln1118_614_fu_93351_p0 =  (sc_lv<10>) (zext_ln1116_365_fu_91461_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_614_fu_93351_p1() {
    mul_ln1118_614_fu_93351_p1 = tmp_923_reg_134396.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_614_fu_93351_p2() {
    mul_ln1118_614_fu_93351_p2 = (!mul_ln1118_614_fu_93351_p0.read().is_01() || !mul_ln1118_614_fu_93351_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_614_fu_93351_p0.read()) * sc_bigint<2>(mul_ln1118_614_fu_93351_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_615_fu_93372_p0() {
    mul_ln1118_615_fu_93372_p0 =  (sc_lv<10>) (zext_ln1116_366_fu_91485_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_615_fu_93372_p1() {
    mul_ln1118_615_fu_93372_p1 = tmp_924_reg_134401.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_615_fu_93372_p2() {
    mul_ln1118_615_fu_93372_p2 = (!mul_ln1118_615_fu_93372_p0.read().is_01() || !mul_ln1118_615_fu_93372_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_615_fu_93372_p0.read()) * sc_bigint<2>(mul_ln1118_615_fu_93372_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_616_fu_93381_p0() {
    mul_ln1118_616_fu_93381_p0 =  (sc_lv<10>) (zext_ln1116_367_fu_91497_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_616_fu_93381_p1() {
    mul_ln1118_616_fu_93381_p1 = tmp_925_reg_134406.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_616_fu_93381_p2() {
    mul_ln1118_616_fu_93381_p2 = (!mul_ln1118_616_fu_93381_p0.read().is_01() || !mul_ln1118_616_fu_93381_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_616_fu_93381_p0.read()) * sc_bigint<2>(mul_ln1118_616_fu_93381_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_617_fu_93402_p0() {
    mul_ln1118_617_fu_93402_p0 =  (sc_lv<10>) (zext_ln1116_368_fu_91521_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_617_fu_93402_p1() {
    mul_ln1118_617_fu_93402_p1 = tmp_926_reg_134411.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_617_fu_93402_p2() {
    mul_ln1118_617_fu_93402_p2 = (!mul_ln1118_617_fu_93402_p0.read().is_01() || !mul_ln1118_617_fu_93402_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_617_fu_93402_p0.read()) * sc_bigint<2>(mul_ln1118_617_fu_93402_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_618_fu_93423_p0() {
    mul_ln1118_618_fu_93423_p0 =  (sc_lv<10>) (zext_ln1116_369_fu_91545_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_618_fu_93423_p1() {
    mul_ln1118_618_fu_93423_p1 = tmp_927_reg_134416.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_618_fu_93423_p2() {
    mul_ln1118_618_fu_93423_p2 = (!mul_ln1118_618_fu_93423_p0.read().is_01() || !mul_ln1118_618_fu_93423_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_618_fu_93423_p0.read()) * sc_bigint<2>(mul_ln1118_618_fu_93423_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_619_fu_93444_p0() {
    mul_ln1118_619_fu_93444_p0 =  (sc_lv<10>) (zext_ln1116_370_fu_91569_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_619_fu_93444_p1() {
    mul_ln1118_619_fu_93444_p1 = tmp_928_reg_134421.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_619_fu_93444_p2() {
    mul_ln1118_619_fu_93444_p2 = (!mul_ln1118_619_fu_93444_p0.read().is_01() || !mul_ln1118_619_fu_93444_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_619_fu_93444_p0.read()) * sc_bigint<2>(mul_ln1118_619_fu_93444_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_61_fu_80895_p0() {
    mul_ln1118_61_fu_80895_p0 =  (sc_lv<10>) (mul_ln1118_61_fu_80895_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_61_fu_80895_p00() {
    mul_ln1118_61_fu_80895_p00 = esl_zext<12,10>(trunc_ln77_58_reg_129841.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_61_fu_80895_p1() {
    mul_ln1118_61_fu_80895_p1 = tmp_115_reg_129846.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_61_fu_80895_p2() {
    mul_ln1118_61_fu_80895_p2 = (!mul_ln1118_61_fu_80895_p0.read().is_01() || !mul_ln1118_61_fu_80895_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_61_fu_80895_p0.read()) * sc_bigint<2>(mul_ln1118_61_fu_80895_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_620_fu_93465_p0() {
    mul_ln1118_620_fu_93465_p0 =  (sc_lv<10>) (zext_ln1116_371_fu_91593_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_620_fu_93465_p1() {
    mul_ln1118_620_fu_93465_p1 = tmp_929_reg_134426.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_620_fu_93465_p2() {
    mul_ln1118_620_fu_93465_p2 = (!mul_ln1118_620_fu_93465_p0.read().is_01() || !mul_ln1118_620_fu_93465_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_620_fu_93465_p0.read()) * sc_bigint<2>(mul_ln1118_620_fu_93465_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_621_fu_93474_p0() {
    mul_ln1118_621_fu_93474_p0 =  (sc_lv<10>) (zext_ln1116_372_fu_91605_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_621_fu_93474_p1() {
    mul_ln1118_621_fu_93474_p1 = tmp_930_reg_134431.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_621_fu_93474_p2() {
    mul_ln1118_621_fu_93474_p2 = (!mul_ln1118_621_fu_93474_p0.read().is_01() || !mul_ln1118_621_fu_93474_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_621_fu_93474_p0.read()) * sc_bigint<2>(mul_ln1118_621_fu_93474_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_622_fu_93495_p0() {
    mul_ln1118_622_fu_93495_p0 =  (sc_lv<10>) (zext_ln1116_373_fu_91629_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_622_fu_93495_p1() {
    mul_ln1118_622_fu_93495_p1 = tmp_931_reg_134436.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_622_fu_93495_p2() {
    mul_ln1118_622_fu_93495_p2 = (!mul_ln1118_622_fu_93495_p0.read().is_01() || !mul_ln1118_622_fu_93495_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_622_fu_93495_p0.read()) * sc_bigint<2>(mul_ln1118_622_fu_93495_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_623_fu_93516_p0() {
    mul_ln1118_623_fu_93516_p0 =  (sc_lv<10>) (zext_ln1116_374_fu_91653_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_623_fu_93516_p1() {
    mul_ln1118_623_fu_93516_p1 = tmp_932_reg_134441.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_623_fu_93516_p2() {
    mul_ln1118_623_fu_93516_p2 = (!mul_ln1118_623_fu_93516_p0.read().is_01() || !mul_ln1118_623_fu_93516_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_623_fu_93516_p0.read()) * sc_bigint<2>(mul_ln1118_623_fu_93516_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_624_fu_93537_p0() {
    mul_ln1118_624_fu_93537_p0 =  (sc_lv<10>) (zext_ln1116_375_fu_91677_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_624_fu_93537_p1() {
    mul_ln1118_624_fu_93537_p1 = tmp_933_reg_134446.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_624_fu_93537_p2() {
    mul_ln1118_624_fu_93537_p2 = (!mul_ln1118_624_fu_93537_p0.read().is_01() || !mul_ln1118_624_fu_93537_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_624_fu_93537_p0.read()) * sc_bigint<2>(mul_ln1118_624_fu_93537_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_625_fu_93558_p0() {
    mul_ln1118_625_fu_93558_p0 =  (sc_lv<10>) (zext_ln1116_376_fu_91701_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_625_fu_93558_p1() {
    mul_ln1118_625_fu_93558_p1 = tmp_934_reg_134451.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_625_fu_93558_p2() {
    mul_ln1118_625_fu_93558_p2 = (!mul_ln1118_625_fu_93558_p0.read().is_01() || !mul_ln1118_625_fu_93558_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_625_fu_93558_p0.read()) * sc_bigint<2>(mul_ln1118_625_fu_93558_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_626_fu_93567_p0() {
    mul_ln1118_626_fu_93567_p0 =  (sc_lv<10>) (zext_ln1116_377_fu_91713_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_626_fu_93567_p1() {
    mul_ln1118_626_fu_93567_p1 = tmp_935_reg_134456.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_626_fu_93567_p2() {
    mul_ln1118_626_fu_93567_p2 = (!mul_ln1118_626_fu_93567_p0.read().is_01() || !mul_ln1118_626_fu_93567_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_626_fu_93567_p0.read()) * sc_bigint<2>(mul_ln1118_626_fu_93567_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_627_fu_93588_p0() {
    mul_ln1118_627_fu_93588_p0 =  (sc_lv<10>) (zext_ln1116_378_fu_91737_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_627_fu_93588_p1() {
    mul_ln1118_627_fu_93588_p1 = tmp_936_reg_134461.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_627_fu_93588_p2() {
    mul_ln1118_627_fu_93588_p2 = (!mul_ln1118_627_fu_93588_p0.read().is_01() || !mul_ln1118_627_fu_93588_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_627_fu_93588_p0.read()) * sc_bigint<2>(mul_ln1118_627_fu_93588_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_628_fu_93609_p0() {
    mul_ln1118_628_fu_93609_p0 =  (sc_lv<10>) (zext_ln1116_379_fu_91761_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_628_fu_93609_p1() {
    mul_ln1118_628_fu_93609_p1 = tmp_937_reg_134466.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_628_fu_93609_p2() {
    mul_ln1118_628_fu_93609_p2 = (!mul_ln1118_628_fu_93609_p0.read().is_01() || !mul_ln1118_628_fu_93609_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_628_fu_93609_p0.read()) * sc_bigint<2>(mul_ln1118_628_fu_93609_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_629_fu_93618_p0() {
    mul_ln1118_629_fu_93618_p0 =  (sc_lv<10>) (zext_ln1116_380_fu_91773_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_629_fu_93618_p1() {
    mul_ln1118_629_fu_93618_p1 = tmp_938_reg_134471.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_629_fu_93618_p2() {
    mul_ln1118_629_fu_93618_p2 = (!mul_ln1118_629_fu_93618_p0.read().is_01() || !mul_ln1118_629_fu_93618_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_629_fu_93618_p0.read()) * sc_bigint<2>(mul_ln1118_629_fu_93618_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_62_fu_80907_p0() {
    mul_ln1118_62_fu_80907_p0 =  (sc_lv<10>) (mul_ln1118_62_fu_80907_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_62_fu_80907_p00() {
    mul_ln1118_62_fu_80907_p00 = esl_zext<12,10>(trunc_ln77_59_reg_129851.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_62_fu_80907_p1() {
    mul_ln1118_62_fu_80907_p1 = tmp_117_reg_129856.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_62_fu_80907_p2() {
    mul_ln1118_62_fu_80907_p2 = (!mul_ln1118_62_fu_80907_p0.read().is_01() || !mul_ln1118_62_fu_80907_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_62_fu_80907_p0.read()) * sc_bigint<2>(mul_ln1118_62_fu_80907_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_630_fu_93639_p0() {
    mul_ln1118_630_fu_93639_p0 =  (sc_lv<10>) (zext_ln1116_381_fu_91797_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_630_fu_93639_p1() {
    mul_ln1118_630_fu_93639_p1 = tmp_939_reg_134476.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_630_fu_93639_p2() {
    mul_ln1118_630_fu_93639_p2 = (!mul_ln1118_630_fu_93639_p0.read().is_01() || !mul_ln1118_630_fu_93639_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_630_fu_93639_p0.read()) * sc_bigint<2>(mul_ln1118_630_fu_93639_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_631_fu_93660_p0() {
    mul_ln1118_631_fu_93660_p0 =  (sc_lv<10>) (zext_ln1116_382_fu_91821_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_631_fu_93660_p1() {
    mul_ln1118_631_fu_93660_p1 = tmp_940_reg_134481.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_631_fu_93660_p2() {
    mul_ln1118_631_fu_93660_p2 = (!mul_ln1118_631_fu_93660_p0.read().is_01() || !mul_ln1118_631_fu_93660_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_631_fu_93660_p0.read()) * sc_bigint<2>(mul_ln1118_631_fu_93660_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_632_fu_93669_p0() {
    mul_ln1118_632_fu_93669_p0 =  (sc_lv<10>) (zext_ln1116_383_fu_91833_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_632_fu_93669_p1() {
    mul_ln1118_632_fu_93669_p1 = tmp_941_reg_134486.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_632_fu_93669_p2() {
    mul_ln1118_632_fu_93669_p2 = (!mul_ln1118_632_fu_93669_p0.read().is_01() || !mul_ln1118_632_fu_93669_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_632_fu_93669_p0.read()) * sc_bigint<2>(mul_ln1118_632_fu_93669_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_633_fu_93690_p0() {
    mul_ln1118_633_fu_93690_p0 =  (sc_lv<10>) (zext_ln1116_384_fu_91857_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_633_fu_93690_p1() {
    mul_ln1118_633_fu_93690_p1 = tmp_942_reg_134491.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_633_fu_93690_p2() {
    mul_ln1118_633_fu_93690_p2 = (!mul_ln1118_633_fu_93690_p0.read().is_01() || !mul_ln1118_633_fu_93690_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_633_fu_93690_p0.read()) * sc_bigint<2>(mul_ln1118_633_fu_93690_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_634_fu_93711_p0() {
    mul_ln1118_634_fu_93711_p0 =  (sc_lv<10>) (zext_ln1116_385_fu_91881_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_634_fu_93711_p1() {
    mul_ln1118_634_fu_93711_p1 = tmp_943_reg_134496.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_634_fu_93711_p2() {
    mul_ln1118_634_fu_93711_p2 = (!mul_ln1118_634_fu_93711_p0.read().is_01() || !mul_ln1118_634_fu_93711_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_634_fu_93711_p0.read()) * sc_bigint<2>(mul_ln1118_634_fu_93711_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_635_fu_93732_p0() {
    mul_ln1118_635_fu_93732_p0 =  (sc_lv<10>) (zext_ln1116_386_fu_91905_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_635_fu_93732_p1() {
    mul_ln1118_635_fu_93732_p1 = tmp_944_reg_134501.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_635_fu_93732_p2() {
    mul_ln1118_635_fu_93732_p2 = (!mul_ln1118_635_fu_93732_p0.read().is_01() || !mul_ln1118_635_fu_93732_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_635_fu_93732_p0.read()) * sc_bigint<2>(mul_ln1118_635_fu_93732_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_636_fu_93753_p0() {
    mul_ln1118_636_fu_93753_p0 =  (sc_lv<10>) (zext_ln1116_387_fu_91929_p1.read());
}

}


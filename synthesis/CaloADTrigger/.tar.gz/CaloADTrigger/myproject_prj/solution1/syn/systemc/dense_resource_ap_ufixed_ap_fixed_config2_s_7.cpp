#include "dense_resource_ap_ufixed_ap_fixed_config2_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_851_fu_67556_p2() {
    lshr_ln77_851_fu_67556_p2 = (!zext_ln77_1616_fu_67550_p1.read().is_01())? sc_lv<2520>(): data_V_read_5_reg_122673_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1616_fu_67550_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_852_fu_67561_p2() {
    lshr_ln77_852_fu_67561_p2 = (!zext_ln77_1617_fu_67553_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1617_fu_67553_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_853_fu_33623_p2() {
    lshr_ln77_853_fu_33623_p2 = (!zext_ln77_1620_fu_33619_p1.read().is_01())? sc_lv<2520>(): select_ln77_892_fu_33598_p3.read() >> (unsigned short)zext_ln77_1620_fu_33619_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_854_fu_67590_p2() {
    lshr_ln77_854_fu_67590_p2 = (!zext_ln77_1621_fu_67587_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1621_fu_67587_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_855_fu_33701_p2() {
    lshr_ln77_855_fu_33701_p2 = (!zext_ln77_1624_fu_33697_p1.read().is_01())? sc_lv<2520>(): select_ln77_895_fu_33676_p3.read() >> (unsigned short)zext_ln77_1624_fu_33697_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_856_fu_67618_p2() {
    lshr_ln77_856_fu_67618_p2 = (!zext_ln77_1625_fu_67615_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1625_fu_67615_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_857_fu_33779_p2() {
    lshr_ln77_857_fu_33779_p2 = (!zext_ln77_1628_fu_33775_p1.read().is_01())? sc_lv<2520>(): select_ln77_898_fu_33754_p3.read() >> (unsigned short)zext_ln77_1628_fu_33775_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_858_fu_67646_p2() {
    lshr_ln77_858_fu_67646_p2 = (!zext_ln77_1629_fu_67643_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1629_fu_67643_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_859_fu_33857_p2() {
    lshr_ln77_859_fu_33857_p2 = (!zext_ln77_1632_fu_33853_p1.read().is_01())? sc_lv<2520>(): select_ln77_901_fu_33832_p3.read() >> (unsigned short)zext_ln77_1632_fu_33853_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_85_fu_52993_p2() {
    lshr_ln77_85_fu_52993_p2 = (!zext_ln77_178_fu_52990_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_178_fu_52990_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_860_fu_67674_p2() {
    lshr_ln77_860_fu_67674_p2 = (!zext_ln77_1633_fu_67671_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1633_fu_67671_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_861_fu_33935_p2() {
    lshr_ln77_861_fu_33935_p2 = (!zext_ln77_1636_fu_33931_p1.read().is_01())? sc_lv<2520>(): select_ln77_904_fu_33910_p3.read() >> (unsigned short)zext_ln77_1636_fu_33931_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_862_fu_67702_p2() {
    lshr_ln77_862_fu_67702_p2 = (!zext_ln77_1637_fu_67699_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1637_fu_67699_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_863_fu_34013_p2() {
    lshr_ln77_863_fu_34013_p2 = (!zext_ln77_1640_fu_34009_p1.read().is_01())? sc_lv<2520>(): select_ln77_907_fu_33988_p3.read() >> (unsigned short)zext_ln77_1640_fu_34009_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_864_fu_67730_p2() {
    lshr_ln77_864_fu_67730_p2 = (!zext_ln77_1641_fu_67727_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1641_fu_67727_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_865_fu_34091_p2() {
    lshr_ln77_865_fu_34091_p2 = (!zext_ln77_1644_fu_34087_p1.read().is_01())? sc_lv<2520>(): select_ln77_910_fu_34066_p3.read() >> (unsigned short)zext_ln77_1644_fu_34087_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_866_fu_67758_p2() {
    lshr_ln77_866_fu_67758_p2 = (!zext_ln77_1645_fu_67755_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1645_fu_67755_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_867_fu_34169_p2() {
    lshr_ln77_867_fu_34169_p2 = (!zext_ln77_1648_fu_34165_p1.read().is_01())? sc_lv<2520>(): select_ln77_913_fu_34144_p3.read() >> (unsigned short)zext_ln77_1648_fu_34165_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_868_fu_67786_p2() {
    lshr_ln77_868_fu_67786_p2 = (!zext_ln77_1649_fu_67783_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1649_fu_67783_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_869_fu_34247_p2() {
    lshr_ln77_869_fu_34247_p2 = (!zext_ln77_1652_fu_34243_p1.read().is_01())? sc_lv<2520>(): select_ln77_916_fu_34222_p3.read() >> (unsigned short)zext_ln77_1652_fu_34243_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_86_fu_11463_p2() {
    lshr_ln77_86_fu_11463_p2 = (!zext_ln77_181_fu_11459_p1.read().is_01())? sc_lv<2520>(): select_ln77_85_fu_11438_p3.read() >> (unsigned short)zext_ln77_181_fu_11459_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_870_fu_67814_p2() {
    lshr_ln77_870_fu_67814_p2 = (!zext_ln77_1653_fu_67811_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1653_fu_67811_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_871_fu_34325_p2() {
    lshr_ln77_871_fu_34325_p2 = (!zext_ln77_1656_fu_34321_p1.read().is_01())? sc_lv<2520>(): select_ln77_919_fu_34300_p3.read() >> (unsigned short)zext_ln77_1656_fu_34321_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_872_fu_67842_p2() {
    lshr_ln77_872_fu_67842_p2 = (!zext_ln77_1657_fu_67839_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1657_fu_67839_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_873_fu_34403_p2() {
    lshr_ln77_873_fu_34403_p2 = (!zext_ln77_1660_fu_34399_p1.read().is_01())? sc_lv<2520>(): select_ln77_922_fu_34378_p3.read() >> (unsigned short)zext_ln77_1660_fu_34399_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_874_fu_67870_p2() {
    lshr_ln77_874_fu_67870_p2 = (!zext_ln77_1661_fu_67867_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1661_fu_67867_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_875_fu_34483_p2() {
    lshr_ln77_875_fu_34483_p2 = (!zext_ln77_1664_fu_34479_p1.read().is_01())? sc_lv<2520>(): select_ln77_925_fu_34458_p3.read() >> (unsigned short)zext_ln77_1664_fu_34479_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_876_fu_67898_p2() {
    lshr_ln77_876_fu_67898_p2 = (!zext_ln77_1665_fu_67895_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1665_fu_67895_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_877_fu_34561_p2() {
    lshr_ln77_877_fu_34561_p2 = (!zext_ln77_1668_fu_34557_p1.read().is_01())? sc_lv<2520>(): select_ln77_928_fu_34536_p3.read() >> (unsigned short)zext_ln77_1668_fu_34557_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_878_fu_67926_p2() {
    lshr_ln77_878_fu_67926_p2 = (!zext_ln77_1669_fu_67923_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1669_fu_67923_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_879_fu_67957_p2() {
    lshr_ln77_879_fu_67957_p2 = (!zext_ln77_1672_fu_67951_p1.read().is_01())? sc_lv<2520>(): data_V_read_5_reg_122673_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1672_fu_67951_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_87_fu_53021_p2() {
    lshr_ln77_87_fu_53021_p2 = (!zext_ln77_182_fu_53018_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_182_fu_53018_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_880_fu_67962_p2() {
    lshr_ln77_880_fu_67962_p2 = (!zext_ln77_1673_fu_67954_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1673_fu_67954_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_881_fu_67994_p2() {
    lshr_ln77_881_fu_67994_p2 = (!zext_ln77_1676_fu_67988_p1.read().is_01())? sc_lv<2520>(): data_V_read_5_reg_122673_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1676_fu_67988_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_882_fu_67999_p2() {
    lshr_ln77_882_fu_67999_p2 = (!zext_ln77_1677_fu_67991_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1677_fu_67991_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_883_fu_68031_p2() {
    lshr_ln77_883_fu_68031_p2 = (!zext_ln77_1680_fu_68025_p1.read().is_01())? sc_lv<2520>(): data_V_read_5_reg_122673_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1680_fu_68025_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_884_fu_68036_p2() {
    lshr_ln77_884_fu_68036_p2 = (!zext_ln77_1681_fu_68028_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1681_fu_68028_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_885_fu_68068_p2() {
    lshr_ln77_885_fu_68068_p2 = (!zext_ln77_1684_fu_68062_p1.read().is_01())? sc_lv<2520>(): data_V_read_5_reg_122673_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1684_fu_68062_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_886_fu_68073_p2() {
    lshr_ln77_886_fu_68073_p2 = (!zext_ln77_1685_fu_68065_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1685_fu_68065_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_887_fu_68105_p2() {
    lshr_ln77_887_fu_68105_p2 = (!zext_ln77_1688_fu_68099_p1.read().is_01())? sc_lv<2520>(): data_V_read_5_reg_122673_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1688_fu_68099_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_888_fu_68110_p2() {
    lshr_ln77_888_fu_68110_p2 = (!zext_ln77_1689_fu_68102_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1689_fu_68102_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_889_fu_68142_p2() {
    lshr_ln77_889_fu_68142_p2 = (!zext_ln77_1692_fu_68136_p1.read().is_01())? sc_lv<2520>(): data_V_read_5_reg_122673_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1692_fu_68136_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_88_fu_11546_p2() {
    lshr_ln77_88_fu_11546_p2 = (!zext_ln77_185_fu_11542_p1.read().is_01())? sc_lv<2520>(): select_ln77_88_fu_11521_p3.read() >> (unsigned short)zext_ln77_185_fu_11542_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_890_fu_68147_p2() {
    lshr_ln77_890_fu_68147_p2 = (!zext_ln77_1693_fu_68139_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1693_fu_68139_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_891_fu_68179_p2() {
    lshr_ln77_891_fu_68179_p2 = (!zext_ln77_1696_fu_68173_p1.read().is_01())? sc_lv<2520>(): data_V_read_5_reg_122673_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1696_fu_68173_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_892_fu_68184_p2() {
    lshr_ln77_892_fu_68184_p2 = (!zext_ln77_1697_fu_68176_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1697_fu_68176_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_893_fu_68216_p2() {
    lshr_ln77_893_fu_68216_p2 = (!zext_ln77_1700_fu_68210_p1.read().is_01())? sc_lv<2520>(): data_V_read_5_reg_122673_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1700_fu_68210_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_894_fu_68221_p2() {
    lshr_ln77_894_fu_68221_p2 = (!zext_ln77_1701_fu_68213_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1701_fu_68213_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_895_fu_34791_p2() {
    lshr_ln77_895_fu_34791_p2 = (!zext_ln77_1704_fu_34787_p1.read().is_01())? sc_lv<2520>(): select_ln77_931_fu_34766_p3.read() >> (unsigned short)zext_ln77_1704_fu_34787_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_896_fu_68250_p2() {
    lshr_ln77_896_fu_68250_p2 = (!zext_ln77_1705_fu_68247_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1705_fu_68247_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_897_fu_34869_p2() {
    lshr_ln77_897_fu_34869_p2 = (!zext_ln77_1708_fu_34865_p1.read().is_01())? sc_lv<2520>(): select_ln77_934_fu_34844_p3.read() >> (unsigned short)zext_ln77_1708_fu_34865_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_898_fu_68278_p2() {
    lshr_ln77_898_fu_68278_p2 = (!zext_ln77_1709_fu_68275_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1709_fu_68275_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_899_fu_34947_p2() {
    lshr_ln77_899_fu_34947_p2 = (!zext_ln77_1712_fu_34943_p1.read().is_01())? sc_lv<2520>(): select_ln77_937_fu_34922_p3.read() >> (unsigned short)zext_ln77_1712_fu_34943_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_89_fu_53049_p2() {
    lshr_ln77_89_fu_53049_p2 = (!zext_ln77_186_fu_53046_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_186_fu_53046_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_8_fu_51797_p2() {
    lshr_ln77_8_fu_51797_p2 = (!zext_ln77_25_fu_51791_p1.read().is_01())? sc_lv<2520>(): data_V_read_reg_120253_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_25_fu_51791_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_900_fu_68306_p2() {
    lshr_ln77_900_fu_68306_p2 = (!zext_ln77_1713_fu_68303_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1713_fu_68303_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_901_fu_35025_p2() {
    lshr_ln77_901_fu_35025_p2 = (!zext_ln77_1716_fu_35021_p1.read().is_01())? sc_lv<2520>(): select_ln77_940_fu_35000_p3.read() >> (unsigned short)zext_ln77_1716_fu_35021_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_902_fu_68334_p2() {
    lshr_ln77_902_fu_68334_p2 = (!zext_ln77_1717_fu_68331_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1717_fu_68331_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_903_fu_35103_p2() {
    lshr_ln77_903_fu_35103_p2 = (!zext_ln77_1720_fu_35099_p1.read().is_01())? sc_lv<2520>(): select_ln77_943_fu_35078_p3.read() >> (unsigned short)zext_ln77_1720_fu_35099_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_904_fu_68362_p2() {
    lshr_ln77_904_fu_68362_p2 = (!zext_ln77_1721_fu_68359_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1721_fu_68359_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_905_fu_35181_p2() {
    lshr_ln77_905_fu_35181_p2 = (!zext_ln77_1724_fu_35177_p1.read().is_01())? sc_lv<2520>(): select_ln77_946_fu_35156_p3.read() >> (unsigned short)zext_ln77_1724_fu_35177_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_906_fu_68390_p2() {
    lshr_ln77_906_fu_68390_p2 = (!zext_ln77_1725_fu_68387_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1725_fu_68387_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_907_fu_35261_p2() {
    lshr_ln77_907_fu_35261_p2 = (!zext_ln77_1728_fu_35257_p1.read().is_01())? sc_lv<2520>(): select_ln77_949_fu_35236_p3.read() >> (unsigned short)zext_ln77_1728_fu_35257_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_908_fu_68418_p2() {
    lshr_ln77_908_fu_68418_p2 = (!zext_ln77_1729_fu_68415_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1729_fu_68415_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_909_fu_35339_p2() {
    lshr_ln77_909_fu_35339_p2 = (!zext_ln77_1732_fu_35335_p1.read().is_01())? sc_lv<2520>(): select_ln77_952_fu_35314_p3.read() >> (unsigned short)zext_ln77_1732_fu_35335_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_90_fu_11629_p2() {
    lshr_ln77_90_fu_11629_p2 = (!zext_ln77_189_fu_11625_p1.read().is_01())? sc_lv<2520>(): select_ln77_91_fu_11604_p3.read() >> (unsigned short)zext_ln77_189_fu_11625_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_910_fu_68446_p2() {
    lshr_ln77_910_fu_68446_p2 = (!zext_ln77_1733_fu_68443_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1733_fu_68443_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_911_fu_35417_p2() {
    lshr_ln77_911_fu_35417_p2 = (!zext_ln77_1736_fu_35413_p1.read().is_01())? sc_lv<2520>(): select_ln77_955_fu_35392_p3.read() >> (unsigned short)zext_ln77_1736_fu_35413_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_912_fu_69024_p2() {
    lshr_ln77_912_fu_69024_p2 = (!zext_ln77_1737_fu_69021_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1737_fu_69021_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_913_fu_35495_p2() {
    lshr_ln77_913_fu_35495_p2 = (!zext_ln77_1740_fu_35491_p1.read().is_01())? sc_lv<2520>(): select_ln77_958_fu_35470_p3.read() >> (unsigned short)zext_ln77_1740_fu_35491_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_914_fu_69052_p2() {
    lshr_ln77_914_fu_69052_p2 = (!zext_ln77_1741_fu_69049_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1741_fu_69049_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_915_fu_35573_p2() {
    lshr_ln77_915_fu_35573_p2 = (!zext_ln77_1744_fu_35569_p1.read().is_01())? sc_lv<2520>(): select_ln77_961_fu_35548_p3.read() >> (unsigned short)zext_ln77_1744_fu_35569_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_916_fu_69080_p2() {
    lshr_ln77_916_fu_69080_p2 = (!zext_ln77_1745_fu_69077_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1745_fu_69077_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_917_fu_35651_p2() {
    lshr_ln77_917_fu_35651_p2 = (!zext_ln77_1748_fu_35647_p1.read().is_01())? sc_lv<2520>(): select_ln77_964_fu_35626_p3.read() >> (unsigned short)zext_ln77_1748_fu_35647_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_918_fu_69108_p2() {
    lshr_ln77_918_fu_69108_p2 = (!zext_ln77_1749_fu_69105_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1749_fu_69105_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_919_fu_35729_p2() {
    lshr_ln77_919_fu_35729_p2 = (!zext_ln77_1752_fu_35725_p1.read().is_01())? sc_lv<2520>(): select_ln77_967_fu_35704_p3.read() >> (unsigned short)zext_ln77_1752_fu_35725_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_91_fu_53077_p2() {
    lshr_ln77_91_fu_53077_p2 = (!zext_ln77_190_fu_53074_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_190_fu_53074_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_920_fu_69136_p2() {
    lshr_ln77_920_fu_69136_p2 = (!zext_ln77_1753_fu_69133_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1753_fu_69133_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_921_fu_35807_p2() {
    lshr_ln77_921_fu_35807_p2 = (!zext_ln77_1756_fu_35803_p1.read().is_01())? sc_lv<2520>(): select_ln77_970_fu_35782_p3.read() >> (unsigned short)zext_ln77_1756_fu_35803_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_922_fu_69164_p2() {
    lshr_ln77_922_fu_69164_p2 = (!zext_ln77_1757_fu_69161_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1757_fu_69161_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_923_fu_35885_p2() {
    lshr_ln77_923_fu_35885_p2 = (!zext_ln77_1760_fu_35881_p1.read().is_01())? sc_lv<2520>(): select_ln77_973_fu_35860_p3.read() >> (unsigned short)zext_ln77_1760_fu_35881_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_924_fu_69192_p2() {
    lshr_ln77_924_fu_69192_p2 = (!zext_ln77_1761_fu_69189_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1761_fu_69189_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_925_fu_35963_p2() {
    lshr_ln77_925_fu_35963_p2 = (!zext_ln77_1764_fu_35959_p1.read().is_01())? sc_lv<2520>(): select_ln77_976_fu_35938_p3.read() >> (unsigned short)zext_ln77_1764_fu_35959_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_926_fu_69220_p2() {
    lshr_ln77_926_fu_69220_p2 = (!zext_ln77_1765_fu_69217_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1765_fu_69217_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_927_fu_36041_p2() {
    lshr_ln77_927_fu_36041_p2 = (!zext_ln77_1768_fu_36037_p1.read().is_01())? sc_lv<2520>(): select_ln77_979_fu_36016_p3.read() >> (unsigned short)zext_ln77_1768_fu_36037_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_928_fu_69248_p2() {
    lshr_ln77_928_fu_69248_p2 = (!zext_ln77_1769_fu_69245_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1769_fu_69245_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_929_fu_36119_p2() {
    lshr_ln77_929_fu_36119_p2 = (!zext_ln77_1772_fu_36115_p1.read().is_01())? sc_lv<2520>(): select_ln77_982_fu_36094_p3.read() >> (unsigned short)zext_ln77_1772_fu_36115_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_92_fu_11712_p2() {
    lshr_ln77_92_fu_11712_p2 = (!zext_ln77_193_fu_11708_p1.read().is_01())? sc_lv<2520>(): select_ln77_94_fu_11687_p3.read() >> (unsigned short)zext_ln77_193_fu_11708_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_930_fu_69276_p2() {
    lshr_ln77_930_fu_69276_p2 = (!zext_ln77_1773_fu_69273_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1773_fu_69273_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_931_fu_36197_p2() {
    lshr_ln77_931_fu_36197_p2 = (!zext_ln77_1776_fu_36193_p1.read().is_01())? sc_lv<2520>(): select_ln77_985_fu_36172_p3.read() >> (unsigned short)zext_ln77_1776_fu_36193_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_932_fu_69304_p2() {
    lshr_ln77_932_fu_69304_p2 = (!zext_ln77_1777_fu_69301_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1777_fu_69301_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_933_fu_36277_p2() {
    lshr_ln77_933_fu_36277_p2 = (!zext_ln77_1780_fu_36273_p1.read().is_01())? sc_lv<2520>(): select_ln77_988_fu_36252_p3.read() >> (unsigned short)zext_ln77_1780_fu_36273_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_934_fu_69332_p2() {
    lshr_ln77_934_fu_69332_p2 = (!zext_ln77_1781_fu_69329_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1781_fu_69329_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_935_fu_36355_p2() {
    lshr_ln77_935_fu_36355_p2 = (!zext_ln77_1784_fu_36351_p1.read().is_01())? sc_lv<2520>(): select_ln77_991_fu_36330_p3.read() >> (unsigned short)zext_ln77_1784_fu_36351_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_936_fu_69360_p2() {
    lshr_ln77_936_fu_69360_p2 = (!zext_ln77_1785_fu_69357_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1785_fu_69357_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_937_fu_69391_p2() {
    lshr_ln77_937_fu_69391_p2 = (!zext_ln77_1788_fu_69385_p1.read().is_01())? sc_lv<2520>(): data_V_read_6_reg_122822_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1788_fu_69385_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_938_fu_69396_p2() {
    lshr_ln77_938_fu_69396_p2 = (!zext_ln77_1789_fu_69388_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1789_fu_69388_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_939_fu_69428_p2() {
    lshr_ln77_939_fu_69428_p2 = (!zext_ln77_1792_fu_69422_p1.read().is_01())? sc_lv<2520>(): data_V_read_6_reg_122822_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1792_fu_69422_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_93_fu_53105_p2() {
    lshr_ln77_93_fu_53105_p2 = (!zext_ln77_194_fu_53102_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_194_fu_53102_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_940_fu_69433_p2() {
    lshr_ln77_940_fu_69433_p2 = (!zext_ln77_1793_fu_69425_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1793_fu_69425_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_941_fu_69465_p2() {
    lshr_ln77_941_fu_69465_p2 = (!zext_ln77_1796_fu_69459_p1.read().is_01())? sc_lv<2520>(): data_V_read_6_reg_122822_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1796_fu_69459_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_942_fu_69470_p2() {
    lshr_ln77_942_fu_69470_p2 = (!zext_ln77_1797_fu_69462_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1797_fu_69462_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_943_fu_69502_p2() {
    lshr_ln77_943_fu_69502_p2 = (!zext_ln77_1800_fu_69496_p1.read().is_01())? sc_lv<2520>(): data_V_read_6_reg_122822_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1800_fu_69496_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_944_fu_69507_p2() {
    lshr_ln77_944_fu_69507_p2 = (!zext_ln77_1801_fu_69499_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1801_fu_69499_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_945_fu_69539_p2() {
    lshr_ln77_945_fu_69539_p2 = (!zext_ln77_1804_fu_69533_p1.read().is_01())? sc_lv<2520>(): data_V_read_6_reg_122822_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1804_fu_69533_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_946_fu_69544_p2() {
    lshr_ln77_946_fu_69544_p2 = (!zext_ln77_1805_fu_69536_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1805_fu_69536_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_947_fu_69576_p2() {
    lshr_ln77_947_fu_69576_p2 = (!zext_ln77_1808_fu_69570_p1.read().is_01())? sc_lv<2520>(): data_V_read_6_reg_122822_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1808_fu_69570_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_948_fu_69581_p2() {
    lshr_ln77_948_fu_69581_p2 = (!zext_ln77_1809_fu_69573_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1809_fu_69573_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_949_fu_69613_p2() {
    lshr_ln77_949_fu_69613_p2 = (!zext_ln77_1812_fu_69607_p1.read().is_01())? sc_lv<2520>(): data_V_read_6_reg_122822_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1812_fu_69607_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_94_fu_11795_p2() {
    lshr_ln77_94_fu_11795_p2 = (!zext_ln77_197_fu_11791_p1.read().is_01())? sc_lv<2520>(): select_ln77_97_fu_11770_p3.read() >> (unsigned short)zext_ln77_197_fu_11791_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_950_fu_69618_p2() {
    lshr_ln77_950_fu_69618_p2 = (!zext_ln77_1813_fu_69610_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1813_fu_69610_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_951_fu_69650_p2() {
    lshr_ln77_951_fu_69650_p2 = (!zext_ln77_1816_fu_69644_p1.read().is_01())? sc_lv<2520>(): data_V_read_6_reg_122822_pp0_iter1_reg.read() >> (unsigned short)zext_ln77_1816_fu_69644_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_952_fu_69655_p2() {
    lshr_ln77_952_fu_69655_p2 = (!zext_ln77_1817_fu_69647_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1817_fu_69647_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_953_fu_36585_p2() {
    lshr_ln77_953_fu_36585_p2 = (!zext_ln77_1820_fu_36581_p1.read().is_01())? sc_lv<2520>(): select_ln77_994_fu_36560_p3.read() >> (unsigned short)zext_ln77_1820_fu_36581_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_954_fu_69684_p2() {
    lshr_ln77_954_fu_69684_p2 = (!zext_ln77_1821_fu_69681_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1821_fu_69681_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_955_fu_36663_p2() {
    lshr_ln77_955_fu_36663_p2 = (!zext_ln77_1824_fu_36659_p1.read().is_01())? sc_lv<2520>(): select_ln77_997_fu_36638_p3.read() >> (unsigned short)zext_ln77_1824_fu_36659_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_956_fu_69712_p2() {
    lshr_ln77_956_fu_69712_p2 = (!zext_ln77_1825_fu_69709_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1825_fu_69709_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_957_fu_36741_p2() {
    lshr_ln77_957_fu_36741_p2 = (!zext_ln77_1828_fu_36737_p1.read().is_01())? sc_lv<2520>(): select_ln77_1000_fu_36716_p3.read() >> (unsigned short)zext_ln77_1828_fu_36737_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_958_fu_69740_p2() {
    lshr_ln77_958_fu_69740_p2 = (!zext_ln77_1829_fu_69737_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1829_fu_69737_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_959_fu_36819_p2() {
    lshr_ln77_959_fu_36819_p2 = (!zext_ln77_1832_fu_36815_p1.read().is_01())? sc_lv<2520>(): select_ln77_1003_fu_36794_p3.read() >> (unsigned short)zext_ln77_1832_fu_36815_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_95_fu_53133_p2() {
    lshr_ln77_95_fu_53133_p2 = (!zext_ln77_198_fu_53130_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_198_fu_53130_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_960_fu_69768_p2() {
    lshr_ln77_960_fu_69768_p2 = (!zext_ln77_1833_fu_69765_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1833_fu_69765_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_961_fu_36897_p2() {
    lshr_ln77_961_fu_36897_p2 = (!zext_ln77_1836_fu_36893_p1.read().is_01())? sc_lv<2520>(): select_ln77_1006_fu_36872_p3.read() >> (unsigned short)zext_ln77_1836_fu_36893_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_962_fu_69796_p2() {
    lshr_ln77_962_fu_69796_p2 = (!zext_ln77_1837_fu_69793_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1837_fu_69793_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_963_fu_36975_p2() {
    lshr_ln77_963_fu_36975_p2 = (!zext_ln77_1840_fu_36971_p1.read().is_01())? sc_lv<2520>(): select_ln77_1009_fu_36950_p3.read() >> (unsigned short)zext_ln77_1840_fu_36971_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_964_fu_69824_p2() {
    lshr_ln77_964_fu_69824_p2 = (!zext_ln77_1841_fu_69821_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1841_fu_69821_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_965_fu_37055_p2() {
    lshr_ln77_965_fu_37055_p2 = (!zext_ln77_1844_fu_37051_p1.read().is_01())? sc_lv<2520>(): select_ln77_1012_fu_37030_p3.read() >> (unsigned short)zext_ln77_1844_fu_37051_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_966_fu_69852_p2() {
    lshr_ln77_966_fu_69852_p2 = (!zext_ln77_1845_fu_69849_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1845_fu_69849_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_967_fu_37133_p2() {
    lshr_ln77_967_fu_37133_p2 = (!zext_ln77_1848_fu_37129_p1.read().is_01())? sc_lv<2520>(): select_ln77_1015_fu_37108_p3.read() >> (unsigned short)zext_ln77_1848_fu_37129_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_968_fu_69880_p2() {
    lshr_ln77_968_fu_69880_p2 = (!zext_ln77_1849_fu_69877_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1849_fu_69877_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_969_fu_37211_p2() {
    lshr_ln77_969_fu_37211_p2 = (!zext_ln77_1852_fu_37207_p1.read().is_01())? sc_lv<2520>(): select_ln77_1018_fu_37186_p3.read() >> (unsigned short)zext_ln77_1852_fu_37207_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_96_fu_11888_p2() {
    lshr_ln77_96_fu_11888_p2 = (!zext_ln77_201_fu_11884_p1.read().is_01())? sc_lv<2520>(): select_ln77_100_fu_11863_p3.read() >> (unsigned short)zext_ln77_201_fu_11884_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_970_fu_69908_p2() {
    lshr_ln77_970_fu_69908_p2 = (!zext_ln77_1853_fu_69905_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1853_fu_69905_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_971_fu_37289_p2() {
    lshr_ln77_971_fu_37289_p2 = (!zext_ln77_1856_fu_37285_p1.read().is_01())? sc_lv<2520>(): select_ln77_1021_fu_37264_p3.read() >> (unsigned short)zext_ln77_1856_fu_37285_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_972_fu_69936_p2() {
    lshr_ln77_972_fu_69936_p2 = (!zext_ln77_1857_fu_69933_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1857_fu_69933_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_973_fu_37367_p2() {
    lshr_ln77_973_fu_37367_p2 = (!zext_ln77_1860_fu_37363_p1.read().is_01())? sc_lv<2520>(): select_ln77_1024_fu_37342_p3.read() >> (unsigned short)zext_ln77_1860_fu_37363_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_974_fu_69964_p2() {
    lshr_ln77_974_fu_69964_p2 = (!zext_ln77_1861_fu_69961_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1861_fu_69961_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_975_fu_37445_p2() {
    lshr_ln77_975_fu_37445_p2 = (!zext_ln77_1864_fu_37441_p1.read().is_01())? sc_lv<2520>(): select_ln77_1027_fu_37420_p3.read() >> (unsigned short)zext_ln77_1864_fu_37441_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_976_fu_69992_p2() {
    lshr_ln77_976_fu_69992_p2 = (!zext_ln77_1865_fu_69989_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1865_fu_69989_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_977_fu_37523_p2() {
    lshr_ln77_977_fu_37523_p2 = (!zext_ln77_1868_fu_37519_p1.read().is_01())? sc_lv<2520>(): select_ln77_1030_fu_37498_p3.read() >> (unsigned short)zext_ln77_1868_fu_37519_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_978_fu_70020_p2() {
    lshr_ln77_978_fu_70020_p2 = (!zext_ln77_1869_fu_70017_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1869_fu_70017_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_979_fu_37601_p2() {
    lshr_ln77_979_fu_37601_p2 = (!zext_ln77_1872_fu_37597_p1.read().is_01())? sc_lv<2520>(): select_ln77_1033_fu_37576_p3.read() >> (unsigned short)zext_ln77_1872_fu_37597_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_97_fu_53161_p2() {
    lshr_ln77_97_fu_53161_p2 = (!zext_ln77_202_fu_53158_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_202_fu_53158_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_980_fu_70048_p2() {
    lshr_ln77_980_fu_70048_p2 = (!zext_ln77_1873_fu_70045_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1873_fu_70045_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_981_fu_37679_p2() {
    lshr_ln77_981_fu_37679_p2 = (!zext_ln77_1876_fu_37675_p1.read().is_01())? sc_lv<2520>(): select_ln77_1036_fu_37654_p3.read() >> (unsigned short)zext_ln77_1876_fu_37675_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_982_fu_70076_p2() {
    lshr_ln77_982_fu_70076_p2 = (!zext_ln77_1877_fu_70073_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1877_fu_70073_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_983_fu_37757_p2() {
    lshr_ln77_983_fu_37757_p2 = (!zext_ln77_1880_fu_37753_p1.read().is_01())? sc_lv<2520>(): select_ln77_1039_fu_37732_p3.read() >> (unsigned short)zext_ln77_1880_fu_37753_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_984_fu_70104_p2() {
    lshr_ln77_984_fu_70104_p2 = (!zext_ln77_1881_fu_70101_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1881_fu_70101_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_985_fu_37835_p2() {
    lshr_ln77_985_fu_37835_p2 = (!zext_ln77_1884_fu_37831_p1.read().is_01())? sc_lv<2520>(): select_ln77_1042_fu_37810_p3.read() >> (unsigned short)zext_ln77_1884_fu_37831_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_986_fu_70132_p2() {
    lshr_ln77_986_fu_70132_p2 = (!zext_ln77_1885_fu_70129_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1885_fu_70129_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_987_fu_37913_p2() {
    lshr_ln77_987_fu_37913_p2 = (!zext_ln77_1888_fu_37909_p1.read().is_01())? sc_lv<2520>(): select_ln77_1045_fu_37888_p3.read() >> (unsigned short)zext_ln77_1888_fu_37909_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_988_fu_70160_p2() {
    lshr_ln77_988_fu_70160_p2 = (!zext_ln77_1889_fu_70157_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1889_fu_70157_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_989_fu_37991_p2() {
    lshr_ln77_989_fu_37991_p2 = (!zext_ln77_1892_fu_37987_p1.read().is_01())? sc_lv<2520>(): select_ln77_1048_fu_37966_p3.read() >> (unsigned short)zext_ln77_1892_fu_37987_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_98_fu_11971_p2() {
    lshr_ln77_98_fu_11971_p2 = (!zext_ln77_205_fu_11967_p1.read().is_01())? sc_lv<2520>(): select_ln77_103_fu_11946_p3.read() >> (unsigned short)zext_ln77_205_fu_11967_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_990_fu_70188_p2() {
    lshr_ln77_990_fu_70188_p2 = (!zext_ln77_1893_fu_70185_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1893_fu_70185_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_991_fu_38069_p2() {
    lshr_ln77_991_fu_38069_p2 = (!zext_ln77_1896_fu_38065_p1.read().is_01())? sc_lv<2520>(): select_ln77_1051_fu_38044_p3.read() >> (unsigned short)zext_ln77_1896_fu_38065_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_992_fu_70216_p2() {
    lshr_ln77_992_fu_70216_p2 = (!zext_ln77_1897_fu_70213_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1897_fu_70213_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_993_fu_38147_p2() {
    lshr_ln77_993_fu_38147_p2 = (!zext_ln77_1900_fu_38143_p1.read().is_01())? sc_lv<2520>(): select_ln77_1054_fu_38122_p3.read() >> (unsigned short)zext_ln77_1900_fu_38143_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_994_fu_70244_p2() {
    lshr_ln77_994_fu_70244_p2 = (!zext_ln77_1901_fu_70241_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1901_fu_70241_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_995_fu_38225_p2() {
    lshr_ln77_995_fu_38225_p2 = (!zext_ln77_1904_fu_38221_p1.read().is_01())? sc_lv<2520>(): select_ln77_1057_fu_38200_p3.read() >> (unsigned short)zext_ln77_1904_fu_38221_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_996_fu_70272_p2() {
    lshr_ln77_996_fu_70272_p2 = (!zext_ln77_1905_fu_70269_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1905_fu_70269_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_997_fu_38305_p2() {
    lshr_ln77_997_fu_38305_p2 = (!zext_ln77_1908_fu_38301_p1.read().is_01())? sc_lv<2520>(): select_ln77_1060_fu_38280_p3.read() >> (unsigned short)zext_ln77_1908_fu_38301_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_998_fu_70300_p2() {
    lshr_ln77_998_fu_70300_p2 = (!zext_ln77_1909_fu_70297_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_1909_fu_70297_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_999_fu_38383_p2() {
    lshr_ln77_999_fu_38383_p2 = (!zext_ln77_1912_fu_38379_p1.read().is_01())? sc_lv<2520>(): select_ln77_1063_fu_38358_p3.read() >> (unsigned short)zext_ln77_1912_fu_38379_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_99_fu_53189_p2() {
    lshr_ln77_99_fu_53189_p2 = (!zext_ln77_206_fu_53186_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_206_fu_53186_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_9_fu_51802_p2() {
    lshr_ln77_9_fu_51802_p2 = (!zext_ln77_26_fu_51794_p1.read().is_01())? sc_lv<2520>(): ap_const_lv2520_lc_1 >> (unsigned short)zext_ln77_26_fu_51794_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_lshr_ln77_fu_5714_p2() {
    lshr_ln77_fu_5714_p2 = (!zext_ln77_9_fu_5710_p1.read().is_01())? sc_lv<2520>(): select_ln77_1_fu_5688_p3.read() >> (unsigned short)zext_ln77_9_fu_5710_p1.read().to_uint();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1000_fu_101868_p0() {
    mul_ln1118_1000_fu_101868_p0 =  (sc_lv<10>) (mul_ln1118_1000_fu_101868_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1000_fu_101868_p00() {
    mul_ln1118_1000_fu_101868_p00 = esl_zext<12,10>(trunc_ln77_668_reg_137551.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1000_fu_101868_p1() {
    mul_ln1118_1000_fu_101868_p1 = tmp_1468_reg_137556.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1000_fu_101868_p2() {
    mul_ln1118_1000_fu_101868_p2 = (!mul_ln1118_1000_fu_101868_p0.read().is_01() || !mul_ln1118_1000_fu_101868_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1000_fu_101868_p0.read()) * sc_bigint<2>(mul_ln1118_1000_fu_101868_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1001_fu_101892_p0() {
    mul_ln1118_1001_fu_101892_p0 =  (sc_lv<10>) (mul_ln1118_1001_fu_101892_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1001_fu_101892_p00() {
    mul_ln1118_1001_fu_101892_p00 = esl_zext<12,10>(trunc_ln77_669_reg_137561.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1001_fu_101892_p1() {
    mul_ln1118_1001_fu_101892_p1 = tmp_1469_reg_137566.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1001_fu_101892_p2() {
    mul_ln1118_1001_fu_101892_p2 = (!mul_ln1118_1001_fu_101892_p0.read().is_01() || !mul_ln1118_1001_fu_101892_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1001_fu_101892_p0.read()) * sc_bigint<2>(mul_ln1118_1001_fu_101892_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1002_fu_101916_p0() {
    mul_ln1118_1002_fu_101916_p0 =  (sc_lv<10>) (mul_ln1118_1002_fu_101916_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1002_fu_101916_p00() {
    mul_ln1118_1002_fu_101916_p00 = esl_zext<12,10>(trunc_ln77_670_reg_137571.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1002_fu_101916_p1() {
    mul_ln1118_1002_fu_101916_p1 = tmp_1470_reg_137576.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1002_fu_101916_p2() {
    mul_ln1118_1002_fu_101916_p2 = (!mul_ln1118_1002_fu_101916_p0.read().is_01() || !mul_ln1118_1002_fu_101916_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1002_fu_101916_p0.read()) * sc_bigint<2>(mul_ln1118_1002_fu_101916_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1003_fu_101940_p0() {
    mul_ln1118_1003_fu_101940_p0 =  (sc_lv<10>) (mul_ln1118_1003_fu_101940_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1003_fu_101940_p00() {
    mul_ln1118_1003_fu_101940_p00 = esl_zext<12,10>(trunc_ln77_671_reg_137581.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1003_fu_101940_p1() {
    mul_ln1118_1003_fu_101940_p1 = tmp_1471_reg_137586.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1003_fu_101940_p2() {
    mul_ln1118_1003_fu_101940_p2 = (!mul_ln1118_1003_fu_101940_p0.read().is_01() || !mul_ln1118_1003_fu_101940_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1003_fu_101940_p0.read()) * sc_bigint<2>(mul_ln1118_1003_fu_101940_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1004_fu_101949_p0() {
    mul_ln1118_1004_fu_101949_p0 =  (sc_lv<10>) (zext_ln1116_590_fu_99978_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1004_fu_101949_p1() {
    mul_ln1118_1004_fu_101949_p1 = tmp_1472_reg_137591.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1004_fu_101949_p2() {
    mul_ln1118_1004_fu_101949_p2 = (!mul_ln1118_1004_fu_101949_p0.read().is_01() || !mul_ln1118_1004_fu_101949_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1004_fu_101949_p0.read()) * sc_bigint<2>(mul_ln1118_1004_fu_101949_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1005_fu_101970_p0() {
    mul_ln1118_1005_fu_101970_p0 =  (sc_lv<10>) (zext_ln1116_591_fu_100002_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1005_fu_101970_p1() {
    mul_ln1118_1005_fu_101970_p1 = tmp_1473_reg_137596.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1005_fu_101970_p2() {
    mul_ln1118_1005_fu_101970_p2 = (!mul_ln1118_1005_fu_101970_p0.read().is_01() || !mul_ln1118_1005_fu_101970_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1005_fu_101970_p0.read()) * sc_bigint<2>(mul_ln1118_1005_fu_101970_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1006_fu_101991_p0() {
    mul_ln1118_1006_fu_101991_p0 =  (sc_lv<10>) (zext_ln1116_592_fu_100026_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1006_fu_101991_p1() {
    mul_ln1118_1006_fu_101991_p1 = tmp_1474_reg_137601.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1006_fu_101991_p2() {
    mul_ln1118_1006_fu_101991_p2 = (!mul_ln1118_1006_fu_101991_p0.read().is_01() || !mul_ln1118_1006_fu_101991_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1006_fu_101991_p0.read()) * sc_bigint<2>(mul_ln1118_1006_fu_101991_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1007_fu_102000_p0() {
    mul_ln1118_1007_fu_102000_p0 =  (sc_lv<10>) (zext_ln1116_593_fu_100038_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1007_fu_102000_p1() {
    mul_ln1118_1007_fu_102000_p1 = tmp_1475_reg_137606.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1007_fu_102000_p2() {
    mul_ln1118_1007_fu_102000_p2 = (!mul_ln1118_1007_fu_102000_p0.read().is_01() || !mul_ln1118_1007_fu_102000_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1007_fu_102000_p0.read()) * sc_bigint<2>(mul_ln1118_1007_fu_102000_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1008_fu_102021_p0() {
    mul_ln1118_1008_fu_102021_p0 =  (sc_lv<10>) (zext_ln1116_594_fu_100062_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1008_fu_102021_p1() {
    mul_ln1118_1008_fu_102021_p1 = tmp_1476_reg_137611.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1008_fu_102021_p2() {
    mul_ln1118_1008_fu_102021_p2 = (!mul_ln1118_1008_fu_102021_p0.read().is_01() || !mul_ln1118_1008_fu_102021_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1008_fu_102021_p0.read()) * sc_bigint<2>(mul_ln1118_1008_fu_102021_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1009_fu_102042_p0() {
    mul_ln1118_1009_fu_102042_p0 =  (sc_lv<10>) (zext_ln1116_595_fu_100086_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1009_fu_102042_p1() {
    mul_ln1118_1009_fu_102042_p1 = tmp_1477_reg_137616.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1009_fu_102042_p2() {
    mul_ln1118_1009_fu_102042_p2 = (!mul_ln1118_1009_fu_102042_p0.read().is_01() || !mul_ln1118_1009_fu_102042_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1009_fu_102042_p0.read()) * sc_bigint<2>(mul_ln1118_1009_fu_102042_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_100_fu_81915_p0() {
    mul_ln1118_100_fu_81915_p0 =  (sc_lv<10>) (zext_ln1116_99_fu_81909_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_100_fu_81915_p1() {
    mul_ln1118_100_fu_81915_p1 = tmp_193_reg_130231.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_100_fu_81915_p2() {
    mul_ln1118_100_fu_81915_p2 = (!mul_ln1118_100_fu_81915_p0.read().is_01() || !mul_ln1118_100_fu_81915_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_100_fu_81915_p0.read()) * sc_bigint<2>(mul_ln1118_100_fu_81915_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1010_fu_102051_p0() {
    mul_ln1118_1010_fu_102051_p0 =  (sc_lv<10>) (zext_ln1116_596_fu_100098_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1010_fu_102051_p1() {
    mul_ln1118_1010_fu_102051_p1 = tmp_1478_reg_137621.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1010_fu_102051_p2() {
    mul_ln1118_1010_fu_102051_p2 = (!mul_ln1118_1010_fu_102051_p0.read().is_01() || !mul_ln1118_1010_fu_102051_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1010_fu_102051_p0.read()) * sc_bigint<2>(mul_ln1118_1010_fu_102051_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1011_fu_102072_p0() {
    mul_ln1118_1011_fu_102072_p0 =  (sc_lv<10>) (zext_ln1116_597_fu_100122_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1011_fu_102072_p1() {
    mul_ln1118_1011_fu_102072_p1 = tmp_1479_reg_137626.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1011_fu_102072_p2() {
    mul_ln1118_1011_fu_102072_p2 = (!mul_ln1118_1011_fu_102072_p0.read().is_01() || !mul_ln1118_1011_fu_102072_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1011_fu_102072_p0.read()) * sc_bigint<2>(mul_ln1118_1011_fu_102072_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1012_fu_102285_p0() {
    mul_ln1118_1012_fu_102285_p0 =  (sc_lv<10>) (zext_ln1116_598_fu_100338_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1012_fu_102285_p1() {
    mul_ln1118_1012_fu_102285_p1 = tmp_1480_reg_137631.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1012_fu_102285_p2() {
    mul_ln1118_1012_fu_102285_p2 = (!mul_ln1118_1012_fu_102285_p0.read().is_01() || !mul_ln1118_1012_fu_102285_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1012_fu_102285_p0.read()) * sc_bigint<2>(mul_ln1118_1012_fu_102285_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1013_fu_102306_p0() {
    mul_ln1118_1013_fu_102306_p0 =  (sc_lv<10>) (zext_ln1116_599_fu_100362_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1013_fu_102306_p1() {
    mul_ln1118_1013_fu_102306_p1 = tmp_1481_reg_137636.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1013_fu_102306_p2() {
    mul_ln1118_1013_fu_102306_p2 = (!mul_ln1118_1013_fu_102306_p0.read().is_01() || !mul_ln1118_1013_fu_102306_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1013_fu_102306_p0.read()) * sc_bigint<2>(mul_ln1118_1013_fu_102306_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1014_fu_102327_p0() {
    mul_ln1118_1014_fu_102327_p0 =  (sc_lv<10>) (zext_ln1116_600_fu_100386_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1014_fu_102327_p1() {
    mul_ln1118_1014_fu_102327_p1 = tmp_1482_reg_137641.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1014_fu_102327_p2() {
    mul_ln1118_1014_fu_102327_p2 = (!mul_ln1118_1014_fu_102327_p0.read().is_01() || !mul_ln1118_1014_fu_102327_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1014_fu_102327_p0.read()) * sc_bigint<2>(mul_ln1118_1014_fu_102327_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1015_fu_102336_p0() {
    mul_ln1118_1015_fu_102336_p0 =  (sc_lv<10>) (zext_ln1116_601_fu_100398_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1015_fu_102336_p1() {
    mul_ln1118_1015_fu_102336_p1 = tmp_1483_reg_137646.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1015_fu_102336_p2() {
    mul_ln1118_1015_fu_102336_p2 = (!mul_ln1118_1015_fu_102336_p0.read().is_01() || !mul_ln1118_1015_fu_102336_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1015_fu_102336_p0.read()) * sc_bigint<2>(mul_ln1118_1015_fu_102336_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1016_fu_102357_p0() {
    mul_ln1118_1016_fu_102357_p0 =  (sc_lv<10>) (zext_ln1116_602_fu_100422_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1016_fu_102357_p1() {
    mul_ln1118_1016_fu_102357_p1 = tmp_1484_reg_137651.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1016_fu_102357_p2() {
    mul_ln1118_1016_fu_102357_p2 = (!mul_ln1118_1016_fu_102357_p0.read().is_01() || !mul_ln1118_1016_fu_102357_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1016_fu_102357_p0.read()) * sc_bigint<2>(mul_ln1118_1016_fu_102357_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1017_fu_102378_p0() {
    mul_ln1118_1017_fu_102378_p0 =  (sc_lv<10>) (zext_ln1116_603_fu_100446_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1017_fu_102378_p1() {
    mul_ln1118_1017_fu_102378_p1 = tmp_1485_reg_137656.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1017_fu_102378_p2() {
    mul_ln1118_1017_fu_102378_p2 = (!mul_ln1118_1017_fu_102378_p0.read().is_01() || !mul_ln1118_1017_fu_102378_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1017_fu_102378_p0.read()) * sc_bigint<2>(mul_ln1118_1017_fu_102378_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1018_fu_102399_p0() {
    mul_ln1118_1018_fu_102399_p0 =  (sc_lv<10>) (zext_ln1116_604_fu_100470_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1018_fu_102399_p1() {
    mul_ln1118_1018_fu_102399_p1 = tmp_1486_reg_137661.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1018_fu_102399_p2() {
    mul_ln1118_1018_fu_102399_p2 = (!mul_ln1118_1018_fu_102399_p0.read().is_01() || !mul_ln1118_1018_fu_102399_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1018_fu_102399_p0.read()) * sc_bigint<2>(mul_ln1118_1018_fu_102399_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1019_fu_102420_p0() {
    mul_ln1118_1019_fu_102420_p0 =  (sc_lv<10>) (zext_ln1116_605_fu_100494_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1019_fu_102420_p1() {
    mul_ln1118_1019_fu_102420_p1 = tmp_1487_reg_137666.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1019_fu_102420_p2() {
    mul_ln1118_1019_fu_102420_p2 = (!mul_ln1118_1019_fu_102420_p0.read().is_01() || !mul_ln1118_1019_fu_102420_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1019_fu_102420_p0.read()) * sc_bigint<2>(mul_ln1118_1019_fu_102420_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_101_fu_81927_p0() {
    mul_ln1118_101_fu_81927_p0 =  (sc_lv<10>) (zext_ln1116_100_fu_81921_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_101_fu_81927_p1() {
    mul_ln1118_101_fu_81927_p1 = tmp_195_reg_130241.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_101_fu_81927_p2() {
    mul_ln1118_101_fu_81927_p2 = (!mul_ln1118_101_fu_81927_p0.read().is_01() || !mul_ln1118_101_fu_81927_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_101_fu_81927_p0.read()) * sc_bigint<2>(mul_ln1118_101_fu_81927_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1020_fu_102429_p0() {
    mul_ln1118_1020_fu_102429_p0 =  (sc_lv<10>) (zext_ln1116_606_fu_100506_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1020_fu_102429_p1() {
    mul_ln1118_1020_fu_102429_p1 = tmp_1488_reg_137671.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1020_fu_102429_p2() {
    mul_ln1118_1020_fu_102429_p2 = (!mul_ln1118_1020_fu_102429_p0.read().is_01() || !mul_ln1118_1020_fu_102429_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1020_fu_102429_p0.read()) * sc_bigint<2>(mul_ln1118_1020_fu_102429_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1021_fu_102450_p0() {
    mul_ln1118_1021_fu_102450_p0 =  (sc_lv<10>) (zext_ln1116_607_fu_100530_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1021_fu_102450_p1() {
    mul_ln1118_1021_fu_102450_p1 = tmp_1489_reg_137676.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1021_fu_102450_p2() {
    mul_ln1118_1021_fu_102450_p2 = (!mul_ln1118_1021_fu_102450_p0.read().is_01() || !mul_ln1118_1021_fu_102450_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1021_fu_102450_p0.read()) * sc_bigint<2>(mul_ln1118_1021_fu_102450_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1022_fu_102471_p0() {
    mul_ln1118_1022_fu_102471_p0 =  (sc_lv<10>) (zext_ln1116_608_fu_100554_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1022_fu_102471_p1() {
    mul_ln1118_1022_fu_102471_p1 = tmp_1490_reg_137681.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1022_fu_102471_p2() {
    mul_ln1118_1022_fu_102471_p2 = (!mul_ln1118_1022_fu_102471_p0.read().is_01() || !mul_ln1118_1022_fu_102471_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1022_fu_102471_p0.read()) * sc_bigint<2>(mul_ln1118_1022_fu_102471_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1023_fu_102492_p0() {
    mul_ln1118_1023_fu_102492_p0 =  (sc_lv<10>) (zext_ln1116_609_fu_100578_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1023_fu_102492_p1() {
    mul_ln1118_1023_fu_102492_p1 = tmp_1491_reg_137686.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1023_fu_102492_p2() {
    mul_ln1118_1023_fu_102492_p2 = (!mul_ln1118_1023_fu_102492_p0.read().is_01() || !mul_ln1118_1023_fu_102492_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1023_fu_102492_p0.read()) * sc_bigint<2>(mul_ln1118_1023_fu_102492_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1024_fu_102513_p0() {
    mul_ln1118_1024_fu_102513_p0 =  (sc_lv<10>) (zext_ln1116_610_fu_100602_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1024_fu_102513_p1() {
    mul_ln1118_1024_fu_102513_p1 = tmp_1492_reg_137691.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1024_fu_102513_p2() {
    mul_ln1118_1024_fu_102513_p2 = (!mul_ln1118_1024_fu_102513_p0.read().is_01() || !mul_ln1118_1024_fu_102513_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1024_fu_102513_p0.read()) * sc_bigint<2>(mul_ln1118_1024_fu_102513_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1025_fu_102522_p0() {
    mul_ln1118_1025_fu_102522_p0 =  (sc_lv<10>) (zext_ln1116_611_fu_100614_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1025_fu_102522_p1() {
    mul_ln1118_1025_fu_102522_p1 = tmp_1493_reg_137696.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1025_fu_102522_p2() {
    mul_ln1118_1025_fu_102522_p2 = (!mul_ln1118_1025_fu_102522_p0.read().is_01() || !mul_ln1118_1025_fu_102522_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1025_fu_102522_p0.read()) * sc_bigint<2>(mul_ln1118_1025_fu_102522_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1026_fu_102543_p0() {
    mul_ln1118_1026_fu_102543_p0 =  (sc_lv<10>) (zext_ln1116_612_fu_100638_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1026_fu_102543_p1() {
    mul_ln1118_1026_fu_102543_p1 = tmp_1494_reg_137701.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1026_fu_102543_p2() {
    mul_ln1118_1026_fu_102543_p2 = (!mul_ln1118_1026_fu_102543_p0.read().is_01() || !mul_ln1118_1026_fu_102543_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1026_fu_102543_p0.read()) * sc_bigint<2>(mul_ln1118_1026_fu_102543_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1027_fu_102564_p0() {
    mul_ln1118_1027_fu_102564_p0 =  (sc_lv<10>) (zext_ln1116_613_fu_100662_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1027_fu_102564_p1() {
    mul_ln1118_1027_fu_102564_p1 = tmp_1495_reg_137706.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1027_fu_102564_p2() {
    mul_ln1118_1027_fu_102564_p2 = (!mul_ln1118_1027_fu_102564_p0.read().is_01() || !mul_ln1118_1027_fu_102564_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1027_fu_102564_p0.read()) * sc_bigint<2>(mul_ln1118_1027_fu_102564_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1028_fu_102573_p0() {
    mul_ln1118_1028_fu_102573_p0 =  (sc_lv<10>) (zext_ln1116_614_fu_100674_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1028_fu_102573_p1() {
    mul_ln1118_1028_fu_102573_p1 = tmp_1496_reg_137711.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1028_fu_102573_p2() {
    mul_ln1118_1028_fu_102573_p2 = (!mul_ln1118_1028_fu_102573_p0.read().is_01() || !mul_ln1118_1028_fu_102573_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1028_fu_102573_p0.read()) * sc_bigint<2>(mul_ln1118_1028_fu_102573_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1029_fu_102594_p0() {
    mul_ln1118_1029_fu_102594_p0 =  (sc_lv<10>) (zext_ln1116_615_fu_100698_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1029_fu_102594_p1() {
    mul_ln1118_1029_fu_102594_p1 = tmp_1497_reg_137716.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1029_fu_102594_p2() {
    mul_ln1118_1029_fu_102594_p2 = (!mul_ln1118_1029_fu_102594_p0.read().is_01() || !mul_ln1118_1029_fu_102594_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1029_fu_102594_p0.read()) * sc_bigint<2>(mul_ln1118_1029_fu_102594_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_102_fu_81951_p0() {
    mul_ln1118_102_fu_81951_p0 =  (sc_lv<10>) (zext_ln1116_101_fu_81945_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_102_fu_81951_p1() {
    mul_ln1118_102_fu_81951_p1 = tmp_197_reg_130251.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_102_fu_81951_p2() {
    mul_ln1118_102_fu_81951_p2 = (!mul_ln1118_102_fu_81951_p0.read().is_01() || !mul_ln1118_102_fu_81951_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_102_fu_81951_p0.read()) * sc_bigint<2>(mul_ln1118_102_fu_81951_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1030_fu_102615_p0() {
    mul_ln1118_1030_fu_102615_p0 =  (sc_lv<10>) (zext_ln1116_616_fu_100722_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1030_fu_102615_p1() {
    mul_ln1118_1030_fu_102615_p1 = tmp_1498_reg_137721.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1030_fu_102615_p2() {
    mul_ln1118_1030_fu_102615_p2 = (!mul_ln1118_1030_fu_102615_p0.read().is_01() || !mul_ln1118_1030_fu_102615_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1030_fu_102615_p0.read()) * sc_bigint<2>(mul_ln1118_1030_fu_102615_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1031_fu_102624_p0() {
    mul_ln1118_1031_fu_102624_p0 =  (sc_lv<10>) (zext_ln1116_617_fu_100734_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1031_fu_102624_p1() {
    mul_ln1118_1031_fu_102624_p1 = tmp_1499_reg_137726.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1031_fu_102624_p2() {
    mul_ln1118_1031_fu_102624_p2 = (!mul_ln1118_1031_fu_102624_p0.read().is_01() || !mul_ln1118_1031_fu_102624_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1031_fu_102624_p0.read()) * sc_bigint<2>(mul_ln1118_1031_fu_102624_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1032_fu_102645_p0() {
    mul_ln1118_1032_fu_102645_p0 =  (sc_lv<10>) (zext_ln1116_618_fu_100758_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1032_fu_102645_p1() {
    mul_ln1118_1032_fu_102645_p1 = tmp_1500_reg_137731.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1032_fu_102645_p2() {
    mul_ln1118_1032_fu_102645_p2 = (!mul_ln1118_1032_fu_102645_p0.read().is_01() || !mul_ln1118_1032_fu_102645_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1032_fu_102645_p0.read()) * sc_bigint<2>(mul_ln1118_1032_fu_102645_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1033_fu_102666_p0() {
    mul_ln1118_1033_fu_102666_p0 =  (sc_lv<10>) (zext_ln1116_619_fu_100782_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1033_fu_102666_p1() {
    mul_ln1118_1033_fu_102666_p1 = tmp_1501_reg_137736.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1033_fu_102666_p2() {
    mul_ln1118_1033_fu_102666_p2 = (!mul_ln1118_1033_fu_102666_p0.read().is_01() || !mul_ln1118_1033_fu_102666_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1033_fu_102666_p0.read()) * sc_bigint<2>(mul_ln1118_1033_fu_102666_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1034_fu_102687_p0() {
    mul_ln1118_1034_fu_102687_p0 =  (sc_lv<10>) (zext_ln1116_620_fu_100806_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1034_fu_102687_p1() {
    mul_ln1118_1034_fu_102687_p1 = tmp_1502_reg_137741.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1034_fu_102687_p2() {
    mul_ln1118_1034_fu_102687_p2 = (!mul_ln1118_1034_fu_102687_p0.read().is_01() || !mul_ln1118_1034_fu_102687_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1034_fu_102687_p0.read()) * sc_bigint<2>(mul_ln1118_1034_fu_102687_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1035_fu_102708_p0() {
    mul_ln1118_1035_fu_102708_p0 =  (sc_lv<10>) (zext_ln1116_621_fu_100830_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1035_fu_102708_p1() {
    mul_ln1118_1035_fu_102708_p1 = tmp_1503_reg_137746.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1035_fu_102708_p2() {
    mul_ln1118_1035_fu_102708_p2 = (!mul_ln1118_1035_fu_102708_p0.read().is_01() || !mul_ln1118_1035_fu_102708_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1035_fu_102708_p0.read()) * sc_bigint<2>(mul_ln1118_1035_fu_102708_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1036_fu_102717_p0() {
    mul_ln1118_1036_fu_102717_p0 =  (sc_lv<10>) (zext_ln1116_622_fu_100842_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1036_fu_102717_p1() {
    mul_ln1118_1036_fu_102717_p1 = tmp_1504_reg_137751.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1036_fu_102717_p2() {
    mul_ln1118_1036_fu_102717_p2 = (!mul_ln1118_1036_fu_102717_p0.read().is_01() || !mul_ln1118_1036_fu_102717_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1036_fu_102717_p0.read()) * sc_bigint<2>(mul_ln1118_1036_fu_102717_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1037_fu_102738_p0() {
    mul_ln1118_1037_fu_102738_p0 =  (sc_lv<10>) (zext_ln1116_623_fu_100866_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1037_fu_102738_p1() {
    mul_ln1118_1037_fu_102738_p1 = tmp_1505_reg_137756.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1037_fu_102738_p2() {
    mul_ln1118_1037_fu_102738_p2 = (!mul_ln1118_1037_fu_102738_p0.read().is_01() || !mul_ln1118_1037_fu_102738_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1037_fu_102738_p0.read()) * sc_bigint<2>(mul_ln1118_1037_fu_102738_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1038_fu_102759_p0() {
    mul_ln1118_1038_fu_102759_p0 =  (sc_lv<10>) (zext_ln1116_624_fu_100890_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1038_fu_102759_p1() {
    mul_ln1118_1038_fu_102759_p1 = tmp_1506_reg_137761.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1038_fu_102759_p2() {
    mul_ln1118_1038_fu_102759_p2 = (!mul_ln1118_1038_fu_102759_p0.read().is_01() || !mul_ln1118_1038_fu_102759_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1038_fu_102759_p0.read()) * sc_bigint<2>(mul_ln1118_1038_fu_102759_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1039_fu_102780_p0() {
    mul_ln1118_1039_fu_102780_p0 =  (sc_lv<10>) (zext_ln1116_625_fu_100914_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1039_fu_102780_p1() {
    mul_ln1118_1039_fu_102780_p1 = tmp_1507_reg_137766.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1039_fu_102780_p2() {
    mul_ln1118_1039_fu_102780_p2 = (!mul_ln1118_1039_fu_102780_p0.read().is_01() || !mul_ln1118_1039_fu_102780_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1039_fu_102780_p0.read()) * sc_bigint<2>(mul_ln1118_1039_fu_102780_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_103_fu_81975_p0() {
    mul_ln1118_103_fu_81975_p0 =  (sc_lv<10>) (zext_ln1116_102_fu_81969_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_103_fu_81975_p1() {
    mul_ln1118_103_fu_81975_p1 = tmp_199_reg_130261.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_103_fu_81975_p2() {
    mul_ln1118_103_fu_81975_p2 = (!mul_ln1118_103_fu_81975_p0.read().is_01() || !mul_ln1118_103_fu_81975_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_103_fu_81975_p0.read()) * sc_bigint<2>(mul_ln1118_103_fu_81975_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1040_fu_102801_p0() {
    mul_ln1118_1040_fu_102801_p0 =  (sc_lv<10>) (zext_ln1116_626_fu_100938_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1040_fu_102801_p1() {
    mul_ln1118_1040_fu_102801_p1 = tmp_1508_reg_137771.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1040_fu_102801_p2() {
    mul_ln1118_1040_fu_102801_p2 = (!mul_ln1118_1040_fu_102801_p0.read().is_01() || !mul_ln1118_1040_fu_102801_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1040_fu_102801_p0.read()) * sc_bigint<2>(mul_ln1118_1040_fu_102801_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1041_fu_102810_p0() {
    mul_ln1118_1041_fu_102810_p0 =  (sc_lv<10>) (zext_ln1116_627_fu_100950_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1041_fu_102810_p1() {
    mul_ln1118_1041_fu_102810_p1 = tmp_1509_reg_137776.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1041_fu_102810_p2() {
    mul_ln1118_1041_fu_102810_p2 = (!mul_ln1118_1041_fu_102810_p0.read().is_01() || !mul_ln1118_1041_fu_102810_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1041_fu_102810_p0.read()) * sc_bigint<2>(mul_ln1118_1041_fu_102810_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1042_fu_102831_p0() {
    mul_ln1118_1042_fu_102831_p0 =  (sc_lv<10>) (zext_ln1116_628_fu_100974_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1042_fu_102831_p1() {
    mul_ln1118_1042_fu_102831_p1 = tmp_1510_reg_137781.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1042_fu_102831_p2() {
    mul_ln1118_1042_fu_102831_p2 = (!mul_ln1118_1042_fu_102831_p0.read().is_01() || !mul_ln1118_1042_fu_102831_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1042_fu_102831_p0.read()) * sc_bigint<2>(mul_ln1118_1042_fu_102831_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1043_fu_102852_p0() {
    mul_ln1118_1043_fu_102852_p0 =  (sc_lv<10>) (zext_ln1116_629_fu_100998_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1043_fu_102852_p1() {
    mul_ln1118_1043_fu_102852_p1 = tmp_1511_reg_137786.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1043_fu_102852_p2() {
    mul_ln1118_1043_fu_102852_p2 = (!mul_ln1118_1043_fu_102852_p0.read().is_01() || !mul_ln1118_1043_fu_102852_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1043_fu_102852_p0.read()) * sc_bigint<2>(mul_ln1118_1043_fu_102852_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1044_fu_102873_p0() {
    mul_ln1118_1044_fu_102873_p0 =  (sc_lv<10>) (zext_ln1116_630_fu_101022_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1044_fu_102873_p1() {
    mul_ln1118_1044_fu_102873_p1 = tmp_1512_reg_137791.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1044_fu_102873_p2() {
    mul_ln1118_1044_fu_102873_p2 = (!mul_ln1118_1044_fu_102873_p0.read().is_01() || !mul_ln1118_1044_fu_102873_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1044_fu_102873_p0.read()) * sc_bigint<2>(mul_ln1118_1044_fu_102873_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1045_fu_102894_p0() {
    mul_ln1118_1045_fu_102894_p0 =  (sc_lv<10>) (zext_ln1116_631_fu_101046_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1045_fu_102894_p1() {
    mul_ln1118_1045_fu_102894_p1 = tmp_1513_reg_137796.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1045_fu_102894_p2() {
    mul_ln1118_1045_fu_102894_p2 = (!mul_ln1118_1045_fu_102894_p0.read().is_01() || !mul_ln1118_1045_fu_102894_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1045_fu_102894_p0.read()) * sc_bigint<2>(mul_ln1118_1045_fu_102894_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1046_fu_102903_p0() {
    mul_ln1118_1046_fu_102903_p0 =  (sc_lv<10>) (zext_ln1116_632_fu_101058_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1046_fu_102903_p1() {
    mul_ln1118_1046_fu_102903_p1 = tmp_1514_reg_137801.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1046_fu_102903_p2() {
    mul_ln1118_1046_fu_102903_p2 = (!mul_ln1118_1046_fu_102903_p0.read().is_01() || !mul_ln1118_1046_fu_102903_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1046_fu_102903_p0.read()) * sc_bigint<2>(mul_ln1118_1046_fu_102903_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1047_fu_102924_p0() {
    mul_ln1118_1047_fu_102924_p0 =  (sc_lv<10>) (zext_ln1116_633_fu_101082_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1047_fu_102924_p1() {
    mul_ln1118_1047_fu_102924_p1 = tmp_1515_reg_137806.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1047_fu_102924_p2() {
    mul_ln1118_1047_fu_102924_p2 = (!mul_ln1118_1047_fu_102924_p0.read().is_01() || !mul_ln1118_1047_fu_102924_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1047_fu_102924_p0.read()) * sc_bigint<2>(mul_ln1118_1047_fu_102924_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1048_fu_102945_p0() {
    mul_ln1118_1048_fu_102945_p0 =  (sc_lv<10>) (zext_ln1116_634_fu_101106_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1048_fu_102945_p1() {
    mul_ln1118_1048_fu_102945_p1 = tmp_1516_reg_137811.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1048_fu_102945_p2() {
    mul_ln1118_1048_fu_102945_p2 = (!mul_ln1118_1048_fu_102945_p0.read().is_01() || !mul_ln1118_1048_fu_102945_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1048_fu_102945_p0.read()) * sc_bigint<2>(mul_ln1118_1048_fu_102945_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1049_fu_102954_p0() {
    mul_ln1118_1049_fu_102954_p0 =  (sc_lv<10>) (zext_ln1116_635_fu_101118_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1049_fu_102954_p1() {
    mul_ln1118_1049_fu_102954_p1 = tmp_1517_reg_137816.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1049_fu_102954_p2() {
    mul_ln1118_1049_fu_102954_p2 = (!mul_ln1118_1049_fu_102954_p0.read().is_01() || !mul_ln1118_1049_fu_102954_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1049_fu_102954_p0.read()) * sc_bigint<2>(mul_ln1118_1049_fu_102954_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_104_fu_81987_p0() {
    mul_ln1118_104_fu_81987_p0 =  (sc_lv<10>) (zext_ln1116_103_fu_81981_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_104_fu_81987_p1() {
    mul_ln1118_104_fu_81987_p1 = tmp_201_reg_130271.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_104_fu_81987_p2() {
    mul_ln1118_104_fu_81987_p2 = (!mul_ln1118_104_fu_81987_p0.read().is_01() || !mul_ln1118_104_fu_81987_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_104_fu_81987_p0.read()) * sc_bigint<2>(mul_ln1118_104_fu_81987_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1050_fu_102975_p0() {
    mul_ln1118_1050_fu_102975_p0 =  (sc_lv<10>) (zext_ln1116_636_fu_101142_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1050_fu_102975_p1() {
    mul_ln1118_1050_fu_102975_p1 = tmp_1518_reg_137821.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1050_fu_102975_p2() {
    mul_ln1118_1050_fu_102975_p2 = (!mul_ln1118_1050_fu_102975_p0.read().is_01() || !mul_ln1118_1050_fu_102975_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1050_fu_102975_p0.read()) * sc_bigint<2>(mul_ln1118_1050_fu_102975_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1051_fu_102996_p0() {
    mul_ln1118_1051_fu_102996_p0 =  (sc_lv<10>) (zext_ln1116_637_fu_101166_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1051_fu_102996_p1() {
    mul_ln1118_1051_fu_102996_p1 = tmp_1519_reg_137826.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1051_fu_102996_p2() {
    mul_ln1118_1051_fu_102996_p2 = (!mul_ln1118_1051_fu_102996_p0.read().is_01() || !mul_ln1118_1051_fu_102996_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1051_fu_102996_p0.read()) * sc_bigint<2>(mul_ln1118_1051_fu_102996_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1052_fu_103005_p0() {
    mul_ln1118_1052_fu_103005_p0 =  (sc_lv<10>) (zext_ln1116_638_fu_101178_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1052_fu_103005_p1() {
    mul_ln1118_1052_fu_103005_p1 = tmp_1520_reg_137831.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1052_fu_103005_p2() {
    mul_ln1118_1052_fu_103005_p2 = (!mul_ln1118_1052_fu_103005_p0.read().is_01() || !mul_ln1118_1052_fu_103005_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1052_fu_103005_p0.read()) * sc_bigint<2>(mul_ln1118_1052_fu_103005_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1053_fu_103026_p0() {
    mul_ln1118_1053_fu_103026_p0 =  (sc_lv<10>) (zext_ln1116_639_fu_101202_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1053_fu_103026_p1() {
    mul_ln1118_1053_fu_103026_p1 = tmp_1521_reg_137836.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1053_fu_103026_p2() {
    mul_ln1118_1053_fu_103026_p2 = (!mul_ln1118_1053_fu_103026_p0.read().is_01() || !mul_ln1118_1053_fu_103026_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1053_fu_103026_p0.read()) * sc_bigint<2>(mul_ln1118_1053_fu_103026_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1054_fu_103047_p0() {
    mul_ln1118_1054_fu_103047_p0 =  (sc_lv<10>) (zext_ln1116_640_fu_101226_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1054_fu_103047_p1() {
    mul_ln1118_1054_fu_103047_p1 = tmp_1522_reg_137841.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1054_fu_103047_p2() {
    mul_ln1118_1054_fu_103047_p2 = (!mul_ln1118_1054_fu_103047_p0.read().is_01() || !mul_ln1118_1054_fu_103047_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1054_fu_103047_p0.read()) * sc_bigint<2>(mul_ln1118_1054_fu_103047_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1055_fu_103068_p0() {
    mul_ln1118_1055_fu_103068_p0 =  (sc_lv<10>) (zext_ln1116_641_fu_101250_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1055_fu_103068_p1() {
    mul_ln1118_1055_fu_103068_p1 = tmp_1523_reg_137846.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1055_fu_103068_p2() {
    mul_ln1118_1055_fu_103068_p2 = (!mul_ln1118_1055_fu_103068_p0.read().is_01() || !mul_ln1118_1055_fu_103068_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1055_fu_103068_p0.read()) * sc_bigint<2>(mul_ln1118_1055_fu_103068_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1056_fu_103089_p0() {
    mul_ln1118_1056_fu_103089_p0 =  (sc_lv<10>) (zext_ln1116_642_fu_101274_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1056_fu_103089_p1() {
    mul_ln1118_1056_fu_103089_p1 = tmp_1524_reg_137851.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1056_fu_103089_p2() {
    mul_ln1118_1056_fu_103089_p2 = (!mul_ln1118_1056_fu_103089_p0.read().is_01() || !mul_ln1118_1056_fu_103089_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1056_fu_103089_p0.read()) * sc_bigint<2>(mul_ln1118_1056_fu_103089_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1057_fu_103098_p0() {
    mul_ln1118_1057_fu_103098_p0 =  (sc_lv<10>) (zext_ln1116_643_fu_101286_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1057_fu_103098_p1() {
    mul_ln1118_1057_fu_103098_p1 = tmp_1525_reg_137856.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1057_fu_103098_p2() {
    mul_ln1118_1057_fu_103098_p2 = (!mul_ln1118_1057_fu_103098_p0.read().is_01() || !mul_ln1118_1057_fu_103098_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1057_fu_103098_p0.read()) * sc_bigint<2>(mul_ln1118_1057_fu_103098_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1058_fu_103119_p0() {
    mul_ln1118_1058_fu_103119_p0 =  (sc_lv<10>) (zext_ln1116_644_fu_101310_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1058_fu_103119_p1() {
    mul_ln1118_1058_fu_103119_p1 = tmp_1526_reg_137861.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1058_fu_103119_p2() {
    mul_ln1118_1058_fu_103119_p2 = (!mul_ln1118_1058_fu_103119_p0.read().is_01() || !mul_ln1118_1058_fu_103119_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1058_fu_103119_p0.read()) * sc_bigint<2>(mul_ln1118_1058_fu_103119_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1059_fu_103143_p0() {
    mul_ln1118_1059_fu_103143_p0 =  (sc_lv<10>) (zext_ln1116_674_fu_103137_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1059_fu_103143_p1() {
    mul_ln1118_1059_fu_103143_p1 = tmp_1528_reg_137871.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1059_fu_103143_p2() {
    mul_ln1118_1059_fu_103143_p2 = (!mul_ln1118_1059_fu_103143_p0.read().is_01() || !mul_ln1118_1059_fu_103143_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1059_fu_103143_p0.read()) * sc_bigint<2>(mul_ln1118_1059_fu_103143_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_105_fu_82011_p0() {
    mul_ln1118_105_fu_82011_p0 =  (sc_lv<10>) (zext_ln1116_104_fu_82005_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_105_fu_82011_p1() {
    mul_ln1118_105_fu_82011_p1 = tmp_203_reg_130281.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_105_fu_82011_p2() {
    mul_ln1118_105_fu_82011_p2 = (!mul_ln1118_105_fu_82011_p0.read().is_01() || !mul_ln1118_105_fu_82011_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_105_fu_82011_p0.read()) * sc_bigint<2>(mul_ln1118_105_fu_82011_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1060_fu_103167_p0() {
    mul_ln1118_1060_fu_103167_p0 =  (sc_lv<10>) (zext_ln1116_675_fu_103161_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1060_fu_103167_p1() {
    mul_ln1118_1060_fu_103167_p1 = tmp_1530_reg_137881.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1060_fu_103167_p2() {
    mul_ln1118_1060_fu_103167_p2 = (!mul_ln1118_1060_fu_103167_p0.read().is_01() || !mul_ln1118_1060_fu_103167_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1060_fu_103167_p0.read()) * sc_bigint<2>(mul_ln1118_1060_fu_103167_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1061_fu_103191_p0() {
    mul_ln1118_1061_fu_103191_p0 =  (sc_lv<10>) (zext_ln1116_676_fu_103185_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1061_fu_103191_p1() {
    mul_ln1118_1061_fu_103191_p1 = tmp_1532_reg_137891.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1061_fu_103191_p2() {
    mul_ln1118_1061_fu_103191_p2 = (!mul_ln1118_1061_fu_103191_p0.read().is_01() || !mul_ln1118_1061_fu_103191_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1061_fu_103191_p0.read()) * sc_bigint<2>(mul_ln1118_1061_fu_103191_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1062_fu_103203_p0() {
    mul_ln1118_1062_fu_103203_p0 =  (sc_lv<10>) (zext_ln1116_677_fu_103197_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1062_fu_103203_p1() {
    mul_ln1118_1062_fu_103203_p1 = tmp_1534_reg_137901.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1062_fu_103203_p2() {
    mul_ln1118_1062_fu_103203_p2 = (!mul_ln1118_1062_fu_103203_p0.read().is_01() || !mul_ln1118_1062_fu_103203_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1062_fu_103203_p0.read()) * sc_bigint<2>(mul_ln1118_1062_fu_103203_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1063_fu_103227_p0() {
    mul_ln1118_1063_fu_103227_p0 =  (sc_lv<10>) (zext_ln1116_678_fu_103221_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1063_fu_103227_p1() {
    mul_ln1118_1063_fu_103227_p1 = tmp_1536_reg_137911.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1063_fu_103227_p2() {
    mul_ln1118_1063_fu_103227_p2 = (!mul_ln1118_1063_fu_103227_p0.read().is_01() || !mul_ln1118_1063_fu_103227_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1063_fu_103227_p0.read()) * sc_bigint<2>(mul_ln1118_1063_fu_103227_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1064_fu_103251_p0() {
    mul_ln1118_1064_fu_103251_p0 =  (sc_lv<10>) (zext_ln1116_679_fu_103245_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1064_fu_103251_p1() {
    mul_ln1118_1064_fu_103251_p1 = tmp_1538_reg_137921.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1064_fu_103251_p2() {
    mul_ln1118_1064_fu_103251_p2 = (!mul_ln1118_1064_fu_103251_p0.read().is_01() || !mul_ln1118_1064_fu_103251_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1064_fu_103251_p0.read()) * sc_bigint<2>(mul_ln1118_1064_fu_103251_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1065_fu_103275_p0() {
    mul_ln1118_1065_fu_103275_p0 =  (sc_lv<10>) (zext_ln1116_680_fu_103269_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1065_fu_103275_p1() {
    mul_ln1118_1065_fu_103275_p1 = tmp_1540_reg_137931.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1065_fu_103275_p2() {
    mul_ln1118_1065_fu_103275_p2 = (!mul_ln1118_1065_fu_103275_p0.read().is_01() || !mul_ln1118_1065_fu_103275_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1065_fu_103275_p0.read()) * sc_bigint<2>(mul_ln1118_1065_fu_103275_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1066_fu_103299_p0() {
    mul_ln1118_1066_fu_103299_p0 =  (sc_lv<10>) (zext_ln1116_681_fu_103293_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1066_fu_103299_p1() {
    mul_ln1118_1066_fu_103299_p1 = tmp_1542_reg_137941.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1066_fu_103299_p2() {
    mul_ln1118_1066_fu_103299_p2 = (!mul_ln1118_1066_fu_103299_p0.read().is_01() || !mul_ln1118_1066_fu_103299_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1066_fu_103299_p0.read()) * sc_bigint<2>(mul_ln1118_1066_fu_103299_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1067_fu_103311_p0() {
    mul_ln1118_1067_fu_103311_p0 =  (sc_lv<10>) (zext_ln1116_682_fu_103305_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1067_fu_103311_p1() {
    mul_ln1118_1067_fu_103311_p1 = tmp_1544_reg_137951.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1067_fu_103311_p2() {
    mul_ln1118_1067_fu_103311_p2 = (!mul_ln1118_1067_fu_103311_p0.read().is_01() || !mul_ln1118_1067_fu_103311_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1067_fu_103311_p0.read()) * sc_bigint<2>(mul_ln1118_1067_fu_103311_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1068_fu_103335_p0() {
    mul_ln1118_1068_fu_103335_p0 =  (sc_lv<10>) (zext_ln1116_683_fu_103329_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1068_fu_103335_p1() {
    mul_ln1118_1068_fu_103335_p1 = tmp_1546_reg_137961.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1068_fu_103335_p2() {
    mul_ln1118_1068_fu_103335_p2 = (!mul_ln1118_1068_fu_103335_p0.read().is_01() || !mul_ln1118_1068_fu_103335_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1068_fu_103335_p0.read()) * sc_bigint<2>(mul_ln1118_1068_fu_103335_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1069_fu_103359_p0() {
    mul_ln1118_1069_fu_103359_p0 =  (sc_lv<10>) (zext_ln1116_684_fu_103353_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1069_fu_103359_p1() {
    mul_ln1118_1069_fu_103359_p1 = tmp_1548_reg_137971.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1069_fu_103359_p2() {
    mul_ln1118_1069_fu_103359_p2 = (!mul_ln1118_1069_fu_103359_p0.read().is_01() || !mul_ln1118_1069_fu_103359_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1069_fu_103359_p0.read()) * sc_bigint<2>(mul_ln1118_1069_fu_103359_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_106_fu_82035_p0() {
    mul_ln1118_106_fu_82035_p0 =  (sc_lv<10>) (zext_ln1116_105_fu_82029_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_106_fu_82035_p1() {
    mul_ln1118_106_fu_82035_p1 = tmp_205_reg_130291.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_106_fu_82035_p2() {
    mul_ln1118_106_fu_82035_p2 = (!mul_ln1118_106_fu_82035_p0.read().is_01() || !mul_ln1118_106_fu_82035_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_106_fu_82035_p0.read()) * sc_bigint<2>(mul_ln1118_106_fu_82035_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1070_fu_103371_p0() {
    mul_ln1118_1070_fu_103371_p0 =  (sc_lv<10>) (zext_ln1116_685_fu_103365_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1070_fu_103371_p1() {
    mul_ln1118_1070_fu_103371_p1 = tmp_1550_reg_137981.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1070_fu_103371_p2() {
    mul_ln1118_1070_fu_103371_p2 = (!mul_ln1118_1070_fu_103371_p0.read().is_01() || !mul_ln1118_1070_fu_103371_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1070_fu_103371_p0.read()) * sc_bigint<2>(mul_ln1118_1070_fu_103371_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1071_fu_103395_p0() {
    mul_ln1118_1071_fu_103395_p0 =  (sc_lv<10>) (zext_ln1116_686_fu_103389_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1071_fu_103395_p1() {
    mul_ln1118_1071_fu_103395_p1 = tmp_1552_reg_137991.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1071_fu_103395_p2() {
    mul_ln1118_1071_fu_103395_p2 = (!mul_ln1118_1071_fu_103395_p0.read().is_01() || !mul_ln1118_1071_fu_103395_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1071_fu_103395_p0.read()) * sc_bigint<2>(mul_ln1118_1071_fu_103395_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1072_fu_103419_p0() {
    mul_ln1118_1072_fu_103419_p0 =  (sc_lv<10>) (zext_ln1116_687_fu_103413_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1072_fu_103419_p1() {
    mul_ln1118_1072_fu_103419_p1 = tmp_1554_reg_138001.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1072_fu_103419_p2() {
    mul_ln1118_1072_fu_103419_p2 = (!mul_ln1118_1072_fu_103419_p0.read().is_01() || !mul_ln1118_1072_fu_103419_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1072_fu_103419_p0.read()) * sc_bigint<2>(mul_ln1118_1072_fu_103419_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1073_fu_103431_p0() {
    mul_ln1118_1073_fu_103431_p0 =  (sc_lv<10>) (zext_ln1116_688_fu_103425_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1073_fu_103431_p1() {
    mul_ln1118_1073_fu_103431_p1 = tmp_1556_reg_138011.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1073_fu_103431_p2() {
    mul_ln1118_1073_fu_103431_p2 = (!mul_ln1118_1073_fu_103431_p0.read().is_01() || !mul_ln1118_1073_fu_103431_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1073_fu_103431_p0.read()) * sc_bigint<2>(mul_ln1118_1073_fu_103431_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1074_fu_103455_p0() {
    mul_ln1118_1074_fu_103455_p0 =  (sc_lv<10>) (zext_ln1116_689_fu_103449_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1074_fu_103455_p1() {
    mul_ln1118_1074_fu_103455_p1 = tmp_1558_reg_138021.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1074_fu_103455_p2() {
    mul_ln1118_1074_fu_103455_p2 = (!mul_ln1118_1074_fu_103455_p0.read().is_01() || !mul_ln1118_1074_fu_103455_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1074_fu_103455_p0.read()) * sc_bigint<2>(mul_ln1118_1074_fu_103455_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1075_fu_103479_p0() {
    mul_ln1118_1075_fu_103479_p0 =  (sc_lv<10>) (zext_ln1116_690_fu_103473_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1075_fu_103479_p1() {
    mul_ln1118_1075_fu_103479_p1 = tmp_1560_reg_138031.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1075_fu_103479_p2() {
    mul_ln1118_1075_fu_103479_p2 = (!mul_ln1118_1075_fu_103479_p0.read().is_01() || !mul_ln1118_1075_fu_103479_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1075_fu_103479_p0.read()) * sc_bigint<2>(mul_ln1118_1075_fu_103479_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1076_fu_103503_p0() {
    mul_ln1118_1076_fu_103503_p0 =  (sc_lv<10>) (zext_ln1116_691_fu_103497_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1076_fu_103503_p1() {
    mul_ln1118_1076_fu_103503_p1 = tmp_1562_reg_138041.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1076_fu_103503_p2() {
    mul_ln1118_1076_fu_103503_p2 = (!mul_ln1118_1076_fu_103503_p0.read().is_01() || !mul_ln1118_1076_fu_103503_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1076_fu_103503_p0.read()) * sc_bigint<2>(mul_ln1118_1076_fu_103503_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1077_fu_103527_p0() {
    mul_ln1118_1077_fu_103527_p0 =  (sc_lv<10>) (zext_ln1116_692_fu_103521_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1077_fu_103527_p1() {
    mul_ln1118_1077_fu_103527_p1 = tmp_1564_reg_138051.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1077_fu_103527_p2() {
    mul_ln1118_1077_fu_103527_p2 = (!mul_ln1118_1077_fu_103527_p0.read().is_01() || !mul_ln1118_1077_fu_103527_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1077_fu_103527_p0.read()) * sc_bigint<2>(mul_ln1118_1077_fu_103527_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1078_fu_103539_p0() {
    mul_ln1118_1078_fu_103539_p0 =  (sc_lv<10>) (zext_ln1116_693_fu_103533_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1078_fu_103539_p1() {
    mul_ln1118_1078_fu_103539_p1 = tmp_1566_reg_138061.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1078_fu_103539_p2() {
    mul_ln1118_1078_fu_103539_p2 = (!mul_ln1118_1078_fu_103539_p0.read().is_01() || !mul_ln1118_1078_fu_103539_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1078_fu_103539_p0.read()) * sc_bigint<2>(mul_ln1118_1078_fu_103539_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1079_fu_103563_p0() {
    mul_ln1118_1079_fu_103563_p0 =  (sc_lv<10>) (zext_ln1116_694_fu_103557_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1079_fu_103563_p1() {
    mul_ln1118_1079_fu_103563_p1 = tmp_1568_reg_138071.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1079_fu_103563_p2() {
    mul_ln1118_1079_fu_103563_p2 = (!mul_ln1118_1079_fu_103563_p0.read().is_01() || !mul_ln1118_1079_fu_103563_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1079_fu_103563_p0.read()) * sc_bigint<2>(mul_ln1118_1079_fu_103563_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_107_fu_82047_p0() {
    mul_ln1118_107_fu_82047_p0 =  (sc_lv<10>) (zext_ln1116_106_fu_82041_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_107_fu_82047_p1() {
    mul_ln1118_107_fu_82047_p1 = tmp_207_reg_130301.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_107_fu_82047_p2() {
    mul_ln1118_107_fu_82047_p2 = (!mul_ln1118_107_fu_82047_p0.read().is_01() || !mul_ln1118_107_fu_82047_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_107_fu_82047_p0.read()) * sc_bigint<2>(mul_ln1118_107_fu_82047_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1080_fu_103587_p0() {
    mul_ln1118_1080_fu_103587_p0 =  (sc_lv<10>) (zext_ln1116_695_fu_103581_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1080_fu_103587_p1() {
    mul_ln1118_1080_fu_103587_p1 = tmp_1569_reg_138081.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1080_fu_103587_p2() {
    mul_ln1118_1080_fu_103587_p2 = (!mul_ln1118_1080_fu_103587_p0.read().is_01() || !mul_ln1118_1080_fu_103587_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1080_fu_103587_p0.read()) * sc_bigint<2>(mul_ln1118_1080_fu_103587_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1081_fu_103611_p0() {
    mul_ln1118_1081_fu_103611_p0 =  (sc_lv<10>) (zext_ln1116_696_fu_103605_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1081_fu_103611_p1() {
    mul_ln1118_1081_fu_103611_p1 = tmp_1570_reg_138091.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1081_fu_103611_p2() {
    mul_ln1118_1081_fu_103611_p2 = (!mul_ln1118_1081_fu_103611_p0.read().is_01() || !mul_ln1118_1081_fu_103611_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1081_fu_103611_p0.read()) * sc_bigint<2>(mul_ln1118_1081_fu_103611_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1082_fu_103635_p0() {
    mul_ln1118_1082_fu_103635_p0 =  (sc_lv<10>) (zext_ln1116_697_fu_103629_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1082_fu_103635_p1() {
    mul_ln1118_1082_fu_103635_p1 = tmp_1571_reg_138101.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1082_fu_103635_p2() {
    mul_ln1118_1082_fu_103635_p2 = (!mul_ln1118_1082_fu_103635_p0.read().is_01() || !mul_ln1118_1082_fu_103635_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1082_fu_103635_p0.read()) * sc_bigint<2>(mul_ln1118_1082_fu_103635_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1083_fu_103647_p0() {
    mul_ln1118_1083_fu_103647_p0 =  (sc_lv<10>) (zext_ln1116_698_fu_103641_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1083_fu_103647_p1() {
    mul_ln1118_1083_fu_103647_p1 = tmp_1572_reg_138111.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1083_fu_103647_p2() {
    mul_ln1118_1083_fu_103647_p2 = (!mul_ln1118_1083_fu_103647_p0.read().is_01() || !mul_ln1118_1083_fu_103647_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1083_fu_103647_p0.read()) * sc_bigint<2>(mul_ln1118_1083_fu_103647_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1084_fu_103671_p0() {
    mul_ln1118_1084_fu_103671_p0 =  (sc_lv<10>) (zext_ln1116_699_fu_103665_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1084_fu_103671_p1() {
    mul_ln1118_1084_fu_103671_p1 = tmp_1573_reg_138121.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1084_fu_103671_p2() {
    mul_ln1118_1084_fu_103671_p2 = (!mul_ln1118_1084_fu_103671_p0.read().is_01() || !mul_ln1118_1084_fu_103671_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1084_fu_103671_p0.read()) * sc_bigint<2>(mul_ln1118_1084_fu_103671_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1085_fu_103695_p0() {
    mul_ln1118_1085_fu_103695_p0 =  (sc_lv<10>) (zext_ln1116_700_fu_103689_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1085_fu_103695_p1() {
    mul_ln1118_1085_fu_103695_p1 = tmp_1574_reg_138131.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1085_fu_103695_p2() {
    mul_ln1118_1085_fu_103695_p2 = (!mul_ln1118_1085_fu_103695_p0.read().is_01() || !mul_ln1118_1085_fu_103695_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1085_fu_103695_p0.read()) * sc_bigint<2>(mul_ln1118_1085_fu_103695_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1086_fu_103719_p0() {
    mul_ln1118_1086_fu_103719_p0 =  (sc_lv<10>) (zext_ln1116_701_fu_103713_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1086_fu_103719_p1() {
    mul_ln1118_1086_fu_103719_p1 = tmp_1575_reg_138141.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1086_fu_103719_p2() {
    mul_ln1118_1086_fu_103719_p2 = (!mul_ln1118_1086_fu_103719_p0.read().is_01() || !mul_ln1118_1086_fu_103719_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1086_fu_103719_p0.read()) * sc_bigint<2>(mul_ln1118_1086_fu_103719_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1087_fu_103743_p0() {
    mul_ln1118_1087_fu_103743_p0 =  (sc_lv<10>) (zext_ln1116_702_fu_103737_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1087_fu_103743_p1() {
    mul_ln1118_1087_fu_103743_p1 = tmp_1576_reg_138151.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1087_fu_103743_p2() {
    mul_ln1118_1087_fu_103743_p2 = (!mul_ln1118_1087_fu_103743_p0.read().is_01() || !mul_ln1118_1087_fu_103743_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1087_fu_103743_p0.read()) * sc_bigint<2>(mul_ln1118_1087_fu_103743_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1088_fu_103755_p0() {
    mul_ln1118_1088_fu_103755_p0 =  (sc_lv<10>) (zext_ln1116_703_fu_103749_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1088_fu_103755_p1() {
    mul_ln1118_1088_fu_103755_p1 = tmp_1577_reg_138161.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1088_fu_103755_p2() {
    mul_ln1118_1088_fu_103755_p2 = (!mul_ln1118_1088_fu_103755_p0.read().is_01() || !mul_ln1118_1088_fu_103755_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1088_fu_103755_p0.read()) * sc_bigint<2>(mul_ln1118_1088_fu_103755_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1089_fu_103779_p0() {
    mul_ln1118_1089_fu_103779_p0 =  (sc_lv<10>) (zext_ln1116_704_fu_103773_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1089_fu_103779_p1() {
    mul_ln1118_1089_fu_103779_p1 = tmp_1578_reg_138171.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1089_fu_103779_p2() {
    mul_ln1118_1089_fu_103779_p2 = (!mul_ln1118_1089_fu_103779_p0.read().is_01() || !mul_ln1118_1089_fu_103779_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1089_fu_103779_p0.read()) * sc_bigint<2>(mul_ln1118_1089_fu_103779_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_108_fu_82071_p0() {
    mul_ln1118_108_fu_82071_p0 =  (sc_lv<10>) (zext_ln1116_107_fu_82065_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_108_fu_82071_p1() {
    mul_ln1118_108_fu_82071_p1 = tmp_209_reg_130311.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_108_fu_82071_p2() {
    mul_ln1118_108_fu_82071_p2 = (!mul_ln1118_108_fu_82071_p0.read().is_01() || !mul_ln1118_108_fu_82071_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_108_fu_82071_p0.read()) * sc_bigint<2>(mul_ln1118_108_fu_82071_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1090_fu_103803_p0() {
    mul_ln1118_1090_fu_103803_p0 =  (sc_lv<10>) (zext_ln1116_705_fu_103797_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1090_fu_103803_p1() {
    mul_ln1118_1090_fu_103803_p1 = tmp_1579_reg_138181.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1090_fu_103803_p2() {
    mul_ln1118_1090_fu_103803_p2 = (!mul_ln1118_1090_fu_103803_p0.read().is_01() || !mul_ln1118_1090_fu_103803_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1090_fu_103803_p0.read()) * sc_bigint<2>(mul_ln1118_1090_fu_103803_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1091_fu_103815_p0() {
    mul_ln1118_1091_fu_103815_p0 =  (sc_lv<10>) (zext_ln1116_706_fu_103809_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1091_fu_103815_p1() {
    mul_ln1118_1091_fu_103815_p1 = tmp_1580_reg_138191.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1091_fu_103815_p2() {
    mul_ln1118_1091_fu_103815_p2 = (!mul_ln1118_1091_fu_103815_p0.read().is_01() || !mul_ln1118_1091_fu_103815_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1091_fu_103815_p0.read()) * sc_bigint<2>(mul_ln1118_1091_fu_103815_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1092_fu_103839_p0() {
    mul_ln1118_1092_fu_103839_p0 =  (sc_lv<10>) (zext_ln1116_707_fu_103833_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1092_fu_103839_p1() {
    mul_ln1118_1092_fu_103839_p1 = tmp_1581_reg_138201.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1092_fu_103839_p2() {
    mul_ln1118_1092_fu_103839_p2 = (!mul_ln1118_1092_fu_103839_p0.read().is_01() || !mul_ln1118_1092_fu_103839_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1092_fu_103839_p0.read()) * sc_bigint<2>(mul_ln1118_1092_fu_103839_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1093_fu_103863_p0() {
    mul_ln1118_1093_fu_103863_p0 =  (sc_lv<10>) (zext_ln1116_708_fu_103857_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1093_fu_103863_p1() {
    mul_ln1118_1093_fu_103863_p1 = tmp_1582_reg_138211.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1093_fu_103863_p2() {
    mul_ln1118_1093_fu_103863_p2 = (!mul_ln1118_1093_fu_103863_p0.read().is_01() || !mul_ln1118_1093_fu_103863_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1093_fu_103863_p0.read()) * sc_bigint<2>(mul_ln1118_1093_fu_103863_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1094_fu_103875_p0() {
    mul_ln1118_1094_fu_103875_p0 =  (sc_lv<10>) (zext_ln1116_709_fu_103869_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1094_fu_103875_p1() {
    mul_ln1118_1094_fu_103875_p1 = tmp_1583_reg_138221.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1094_fu_103875_p2() {
    mul_ln1118_1094_fu_103875_p2 = (!mul_ln1118_1094_fu_103875_p0.read().is_01() || !mul_ln1118_1094_fu_103875_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1094_fu_103875_p0.read()) * sc_bigint<2>(mul_ln1118_1094_fu_103875_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1095_fu_103899_p0() {
    mul_ln1118_1095_fu_103899_p0 =  (sc_lv<10>) (zext_ln1116_710_fu_103893_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1095_fu_103899_p1() {
    mul_ln1118_1095_fu_103899_p1 = tmp_1584_reg_138231.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1095_fu_103899_p2() {
    mul_ln1118_1095_fu_103899_p2 = (!mul_ln1118_1095_fu_103899_p0.read().is_01() || !mul_ln1118_1095_fu_103899_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1095_fu_103899_p0.read()) * sc_bigint<2>(mul_ln1118_1095_fu_103899_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1096_fu_104115_p0() {
    mul_ln1118_1096_fu_104115_p0 =  (sc_lv<10>) (zext_ln1116_711_fu_104109_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1096_fu_104115_p1() {
    mul_ln1118_1096_fu_104115_p1 = tmp_1586_reg_138236.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1096_fu_104115_p2() {
    mul_ln1118_1096_fu_104115_p2 = (!mul_ln1118_1096_fu_104115_p0.read().is_01() || !mul_ln1118_1096_fu_104115_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1096_fu_104115_p0.read()) * sc_bigint<2>(mul_ln1118_1096_fu_104115_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1097_fu_104139_p0() {
    mul_ln1118_1097_fu_104139_p0 =  (sc_lv<10>) (zext_ln1116_712_fu_104133_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1097_fu_104139_p1() {
    mul_ln1118_1097_fu_104139_p1 = tmp_1588_reg_138246.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1097_fu_104139_p2() {
    mul_ln1118_1097_fu_104139_p2 = (!mul_ln1118_1097_fu_104139_p0.read().is_01() || !mul_ln1118_1097_fu_104139_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1097_fu_104139_p0.read()) * sc_bigint<2>(mul_ln1118_1097_fu_104139_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1098_fu_104163_p0() {
    mul_ln1118_1098_fu_104163_p0 =  (sc_lv<10>) (zext_ln1116_713_fu_104157_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1098_fu_104163_p1() {
    mul_ln1118_1098_fu_104163_p1 = tmp_1590_reg_138256.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1098_fu_104163_p2() {
    mul_ln1118_1098_fu_104163_p2 = (!mul_ln1118_1098_fu_104163_p0.read().is_01() || !mul_ln1118_1098_fu_104163_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1098_fu_104163_p0.read()) * sc_bigint<2>(mul_ln1118_1098_fu_104163_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1099_fu_104175_p0() {
    mul_ln1118_1099_fu_104175_p0 =  (sc_lv<10>) (zext_ln1116_714_fu_104169_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1099_fu_104175_p1() {
    mul_ln1118_1099_fu_104175_p1 = tmp_1592_reg_138266.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1099_fu_104175_p2() {
    mul_ln1118_1099_fu_104175_p2 = (!mul_ln1118_1099_fu_104175_p0.read().is_01() || !mul_ln1118_1099_fu_104175_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1099_fu_104175_p0.read()) * sc_bigint<2>(mul_ln1118_1099_fu_104175_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_109_fu_82095_p0() {
    mul_ln1118_109_fu_82095_p0 =  (sc_lv<10>) (zext_ln1116_108_fu_82089_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_109_fu_82095_p1() {
    mul_ln1118_109_fu_82095_p1 = tmp_211_reg_130321.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_109_fu_82095_p2() {
    mul_ln1118_109_fu_82095_p2 = (!mul_ln1118_109_fu_82095_p0.read().is_01() || !mul_ln1118_109_fu_82095_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_109_fu_82095_p0.read()) * sc_bigint<2>(mul_ln1118_109_fu_82095_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_10_fu_79815_p0() {
    mul_ln1118_10_fu_79815_p0 =  (sc_lv<10>) (mul_ln1118_10_fu_79815_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_10_fu_79815_p00() {
    mul_ln1118_10_fu_79815_p00 = esl_zext<12,10>(trunc_ln77_7_reg_129331.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_10_fu_79815_p1() {
    mul_ln1118_10_fu_79815_p1 = tmp_13_reg_129336.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_10_fu_79815_p2() {
    mul_ln1118_10_fu_79815_p2 = (!mul_ln1118_10_fu_79815_p0.read().is_01() || !mul_ln1118_10_fu_79815_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_10_fu_79815_p0.read()) * sc_bigint<2>(mul_ln1118_10_fu_79815_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1100_fu_104199_p0() {
    mul_ln1118_1100_fu_104199_p0 =  (sc_lv<10>) (zext_ln1116_715_fu_104193_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1100_fu_104199_p1() {
    mul_ln1118_1100_fu_104199_p1 = tmp_1593_reg_138276.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1100_fu_104199_p2() {
    mul_ln1118_1100_fu_104199_p2 = (!mul_ln1118_1100_fu_104199_p0.read().is_01() || !mul_ln1118_1100_fu_104199_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1100_fu_104199_p0.read()) * sc_bigint<2>(mul_ln1118_1100_fu_104199_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1101_fu_104223_p0() {
    mul_ln1118_1101_fu_104223_p0 =  (sc_lv<10>) (zext_ln1116_716_fu_104217_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1101_fu_104223_p1() {
    mul_ln1118_1101_fu_104223_p1 = tmp_1595_reg_138286.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1101_fu_104223_p2() {
    mul_ln1118_1101_fu_104223_p2 = (!mul_ln1118_1101_fu_104223_p0.read().is_01() || !mul_ln1118_1101_fu_104223_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1101_fu_104223_p0.read()) * sc_bigint<2>(mul_ln1118_1101_fu_104223_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1102_fu_104247_p0() {
    mul_ln1118_1102_fu_104247_p0 =  (sc_lv<10>) (zext_ln1116_717_fu_104241_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1102_fu_104247_p1() {
    mul_ln1118_1102_fu_104247_p1 = tmp_1597_reg_138296.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1102_fu_104247_p2() {
    mul_ln1118_1102_fu_104247_p2 = (!mul_ln1118_1102_fu_104247_p0.read().is_01() || !mul_ln1118_1102_fu_104247_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1102_fu_104247_p0.read()) * sc_bigint<2>(mul_ln1118_1102_fu_104247_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1103_fu_104271_p0() {
    mul_ln1118_1103_fu_104271_p0 =  (sc_lv<10>) (zext_ln1116_718_fu_104265_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1103_fu_104271_p1() {
    mul_ln1118_1103_fu_104271_p1 = tmp_1599_reg_138306.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1103_fu_104271_p2() {
    mul_ln1118_1103_fu_104271_p2 = (!mul_ln1118_1103_fu_104271_p0.read().is_01() || !mul_ln1118_1103_fu_104271_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1103_fu_104271_p0.read()) * sc_bigint<2>(mul_ln1118_1103_fu_104271_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1104_fu_104283_p0() {
    mul_ln1118_1104_fu_104283_p0 =  (sc_lv<10>) (zext_ln1116_719_fu_104277_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1104_fu_104283_p1() {
    mul_ln1118_1104_fu_104283_p1 = tmp_1600_reg_138316.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1104_fu_104283_p2() {
    mul_ln1118_1104_fu_104283_p2 = (!mul_ln1118_1104_fu_104283_p0.read().is_01() || !mul_ln1118_1104_fu_104283_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1104_fu_104283_p0.read()) * sc_bigint<2>(mul_ln1118_1104_fu_104283_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1105_fu_104307_p0() {
    mul_ln1118_1105_fu_104307_p0 =  (sc_lv<10>) (zext_ln1116_720_fu_104301_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1105_fu_104307_p1() {
    mul_ln1118_1105_fu_104307_p1 = tmp_1601_reg_138326.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1105_fu_104307_p2() {
    mul_ln1118_1105_fu_104307_p2 = (!mul_ln1118_1105_fu_104307_p0.read().is_01() || !mul_ln1118_1105_fu_104307_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1105_fu_104307_p0.read()) * sc_bigint<2>(mul_ln1118_1105_fu_104307_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1106_fu_104331_p0() {
    mul_ln1118_1106_fu_104331_p0 =  (sc_lv<10>) (zext_ln1116_721_fu_104325_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1106_fu_104331_p1() {
    mul_ln1118_1106_fu_104331_p1 = tmp_1603_reg_138336.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1106_fu_104331_p2() {
    mul_ln1118_1106_fu_104331_p2 = (!mul_ln1118_1106_fu_104331_p0.read().is_01() || !mul_ln1118_1106_fu_104331_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1106_fu_104331_p0.read()) * sc_bigint<2>(mul_ln1118_1106_fu_104331_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1107_fu_104355_p0() {
    mul_ln1118_1107_fu_104355_p0 =  (sc_lv<10>) (zext_ln1116_722_fu_104349_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1107_fu_104355_p1() {
    mul_ln1118_1107_fu_104355_p1 = tmp_1605_reg_138346.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1107_fu_104355_p2() {
    mul_ln1118_1107_fu_104355_p2 = (!mul_ln1118_1107_fu_104355_p0.read().is_01() || !mul_ln1118_1107_fu_104355_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1107_fu_104355_p0.read()) * sc_bigint<2>(mul_ln1118_1107_fu_104355_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1108_fu_104379_p0() {
    mul_ln1118_1108_fu_104379_p0 =  (sc_lv<10>) (zext_ln1116_723_fu_104373_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1108_fu_104379_p1() {
    mul_ln1118_1108_fu_104379_p1 = tmp_1607_reg_138356.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1108_fu_104379_p2() {
    mul_ln1118_1108_fu_104379_p2 = (!mul_ln1118_1108_fu_104379_p0.read().is_01() || !mul_ln1118_1108_fu_104379_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1108_fu_104379_p0.read()) * sc_bigint<2>(mul_ln1118_1108_fu_104379_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1109_fu_104391_p0() {
    mul_ln1118_1109_fu_104391_p0 =  (sc_lv<10>) (zext_ln1116_724_fu_104385_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1109_fu_104391_p1() {
    mul_ln1118_1109_fu_104391_p1 = tmp_1609_reg_138366.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1109_fu_104391_p2() {
    mul_ln1118_1109_fu_104391_p2 = (!mul_ln1118_1109_fu_104391_p0.read().is_01() || !mul_ln1118_1109_fu_104391_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1109_fu_104391_p0.read()) * sc_bigint<2>(mul_ln1118_1109_fu_104391_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_110_fu_82119_p0() {
    mul_ln1118_110_fu_82119_p0 =  (sc_lv<10>) (zext_ln1116_109_fu_82113_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_110_fu_82119_p1() {
    mul_ln1118_110_fu_82119_p1 = tmp_213_reg_130331.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_110_fu_82119_p2() {
    mul_ln1118_110_fu_82119_p2 = (!mul_ln1118_110_fu_82119_p0.read().is_01() || !mul_ln1118_110_fu_82119_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_110_fu_82119_p0.read()) * sc_bigint<2>(mul_ln1118_110_fu_82119_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1110_fu_104415_p0() {
    mul_ln1118_1110_fu_104415_p0 =  (sc_lv<10>) (zext_ln1116_725_fu_104409_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1110_fu_104415_p1() {
    mul_ln1118_1110_fu_104415_p1 = tmp_1611_reg_138376.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1110_fu_104415_p2() {
    mul_ln1118_1110_fu_104415_p2 = (!mul_ln1118_1110_fu_104415_p0.read().is_01() || !mul_ln1118_1110_fu_104415_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1110_fu_104415_p0.read()) * sc_bigint<2>(mul_ln1118_1110_fu_104415_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1111_fu_104439_p0() {
    mul_ln1118_1111_fu_104439_p0 =  (sc_lv<10>) (zext_ln1116_726_fu_104433_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1111_fu_104439_p1() {
    mul_ln1118_1111_fu_104439_p1 = tmp_1613_reg_138386.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1111_fu_104439_p2() {
    mul_ln1118_1111_fu_104439_p2 = (!mul_ln1118_1111_fu_104439_p0.read().is_01() || !mul_ln1118_1111_fu_104439_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1111_fu_104439_p0.read()) * sc_bigint<2>(mul_ln1118_1111_fu_104439_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1112_fu_104451_p0() {
    mul_ln1118_1112_fu_104451_p0 =  (sc_lv<10>) (zext_ln1116_727_fu_104445_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1112_fu_104451_p1() {
    mul_ln1118_1112_fu_104451_p1 = tmp_1615_reg_138396.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1112_fu_104451_p2() {
    mul_ln1118_1112_fu_104451_p2 = (!mul_ln1118_1112_fu_104451_p0.read().is_01() || !mul_ln1118_1112_fu_104451_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1112_fu_104451_p0.read()) * sc_bigint<2>(mul_ln1118_1112_fu_104451_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1113_fu_104475_p0() {
    mul_ln1118_1113_fu_104475_p0 =  (sc_lv<10>) (zext_ln1116_728_fu_104469_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1113_fu_104475_p1() {
    mul_ln1118_1113_fu_104475_p1 = tmp_1616_reg_138406.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1113_fu_104475_p2() {
    mul_ln1118_1113_fu_104475_p2 = (!mul_ln1118_1113_fu_104475_p0.read().is_01() || !mul_ln1118_1113_fu_104475_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1113_fu_104475_p0.read()) * sc_bigint<2>(mul_ln1118_1113_fu_104475_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1114_fu_104499_p0() {
    mul_ln1118_1114_fu_104499_p0 =  (sc_lv<10>) (mul_ln1118_1114_fu_104499_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1114_fu_104499_p00() {
    mul_ln1118_1114_fu_104499_p00 = esl_zext<12,10>(trunc_ln77_727_reg_138411.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1114_fu_104499_p1() {
    mul_ln1118_1114_fu_104499_p1 = tmp_1617_reg_138416.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1114_fu_104499_p2() {
    mul_ln1118_1114_fu_104499_p2 = (!mul_ln1118_1114_fu_104499_p0.read().is_01() || !mul_ln1118_1114_fu_104499_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1114_fu_104499_p0.read()) * sc_bigint<2>(mul_ln1118_1114_fu_104499_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1115_fu_104511_p0() {
    mul_ln1118_1115_fu_104511_p0 =  (sc_lv<10>) (mul_ln1118_1115_fu_104511_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1115_fu_104511_p00() {
    mul_ln1118_1115_fu_104511_p00 = esl_zext<12,10>(trunc_ln77_728_reg_138421.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1115_fu_104511_p1() {
    mul_ln1118_1115_fu_104511_p1 = tmp_1618_reg_138426.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1115_fu_104511_p2() {
    mul_ln1118_1115_fu_104511_p2 = (!mul_ln1118_1115_fu_104511_p0.read().is_01() || !mul_ln1118_1115_fu_104511_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1115_fu_104511_p0.read()) * sc_bigint<2>(mul_ln1118_1115_fu_104511_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1116_fu_104535_p0() {
    mul_ln1118_1116_fu_104535_p0 =  (sc_lv<10>) (mul_ln1118_1116_fu_104535_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1116_fu_104535_p00() {
    mul_ln1118_1116_fu_104535_p00 = esl_zext<12,10>(trunc_ln77_729_reg_138431.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1116_fu_104535_p1() {
    mul_ln1118_1116_fu_104535_p1 = tmp_1619_reg_138436.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1116_fu_104535_p2() {
    mul_ln1118_1116_fu_104535_p2 = (!mul_ln1118_1116_fu_104535_p0.read().is_01() || !mul_ln1118_1116_fu_104535_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1116_fu_104535_p0.read()) * sc_bigint<2>(mul_ln1118_1116_fu_104535_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1117_fu_104559_p0() {
    mul_ln1118_1117_fu_104559_p0 =  (sc_lv<10>) (mul_ln1118_1117_fu_104559_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1117_fu_104559_p00() {
    mul_ln1118_1117_fu_104559_p00 = esl_zext<12,10>(trunc_ln77_730_reg_138441.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1117_fu_104559_p1() {
    mul_ln1118_1117_fu_104559_p1 = tmp_1621_reg_138446.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1117_fu_104559_p2() {
    mul_ln1118_1117_fu_104559_p2 = (!mul_ln1118_1117_fu_104559_p0.read().is_01() || !mul_ln1118_1117_fu_104559_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1117_fu_104559_p0.read()) * sc_bigint<2>(mul_ln1118_1117_fu_104559_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1118_fu_104583_p0() {
    mul_ln1118_1118_fu_104583_p0 =  (sc_lv<10>) (mul_ln1118_1118_fu_104583_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1118_fu_104583_p00() {
    mul_ln1118_1118_fu_104583_p00 = esl_zext<12,10>(trunc_ln77_731_reg_138451.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1118_fu_104583_p1() {
    mul_ln1118_1118_fu_104583_p1 = tmp_1623_reg_138456.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1118_fu_104583_p2() {
    mul_ln1118_1118_fu_104583_p2 = (!mul_ln1118_1118_fu_104583_p0.read().is_01() || !mul_ln1118_1118_fu_104583_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1118_fu_104583_p0.read()) * sc_bigint<2>(mul_ln1118_1118_fu_104583_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1119_fu_104607_p0() {
    mul_ln1118_1119_fu_104607_p0 =  (sc_lv<10>) (mul_ln1118_1119_fu_104607_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1119_fu_104607_p00() {
    mul_ln1118_1119_fu_104607_p00 = esl_zext<12,10>(trunc_ln77_732_reg_138461.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1119_fu_104607_p1() {
    mul_ln1118_1119_fu_104607_p1 = tmp_1625_reg_138466.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1119_fu_104607_p2() {
    mul_ln1118_1119_fu_104607_p2 = (!mul_ln1118_1119_fu_104607_p0.read().is_01() || !mul_ln1118_1119_fu_104607_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1119_fu_104607_p0.read()) * sc_bigint<2>(mul_ln1118_1119_fu_104607_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_111_fu_82143_p0() {
    mul_ln1118_111_fu_82143_p0 =  (sc_lv<10>) (zext_ln1116_110_fu_82137_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_111_fu_82143_p1() {
    mul_ln1118_111_fu_82143_p1 = tmp_215_reg_130341.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_111_fu_82143_p2() {
    mul_ln1118_111_fu_82143_p2 = (!mul_ln1118_111_fu_82143_p0.read().is_01() || !mul_ln1118_111_fu_82143_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_111_fu_82143_p0.read()) * sc_bigint<2>(mul_ln1118_111_fu_82143_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1120_fu_104619_p0() {
    mul_ln1118_1120_fu_104619_p0 =  (sc_lv<10>) (mul_ln1118_1120_fu_104619_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1120_fu_104619_p00() {
    mul_ln1118_1120_fu_104619_p00 = esl_zext<12,10>(trunc_ln77_733_reg_138471.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1120_fu_104619_p1() {
    mul_ln1118_1120_fu_104619_p1 = tmp_1627_reg_138476.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1120_fu_104619_p2() {
    mul_ln1118_1120_fu_104619_p2 = (!mul_ln1118_1120_fu_104619_p0.read().is_01() || !mul_ln1118_1120_fu_104619_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1120_fu_104619_p0.read()) * sc_bigint<2>(mul_ln1118_1120_fu_104619_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1121_fu_104643_p0() {
    mul_ln1118_1121_fu_104643_p0 =  (sc_lv<10>) (mul_ln1118_1121_fu_104643_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1121_fu_104643_p00() {
    mul_ln1118_1121_fu_104643_p00 = esl_zext<12,10>(trunc_ln77_734_reg_138481.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1121_fu_104643_p1() {
    mul_ln1118_1121_fu_104643_p1 = tmp_1629_reg_138486.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1121_fu_104643_p2() {
    mul_ln1118_1121_fu_104643_p2 = (!mul_ln1118_1121_fu_104643_p0.read().is_01() || !mul_ln1118_1121_fu_104643_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1121_fu_104643_p0.read()) * sc_bigint<2>(mul_ln1118_1121_fu_104643_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1122_fu_104667_p0() {
    mul_ln1118_1122_fu_104667_p0 =  (sc_lv<10>) (mul_ln1118_1122_fu_104667_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1122_fu_104667_p00() {
    mul_ln1118_1122_fu_104667_p00 = esl_zext<12,10>(trunc_ln77_735_reg_138491.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1122_fu_104667_p1() {
    mul_ln1118_1122_fu_104667_p1 = tmp_1631_reg_138496.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1122_fu_104667_p2() {
    mul_ln1118_1122_fu_104667_p2 = (!mul_ln1118_1122_fu_104667_p0.read().is_01() || !mul_ln1118_1122_fu_104667_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1122_fu_104667_p0.read()) * sc_bigint<2>(mul_ln1118_1122_fu_104667_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1123_fu_104691_p0() {
    mul_ln1118_1123_fu_104691_p0 =  (sc_lv<10>) (mul_ln1118_1123_fu_104691_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1123_fu_104691_p00() {
    mul_ln1118_1123_fu_104691_p00 = esl_zext<12,10>(trunc_ln77_736_reg_138501.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1123_fu_104691_p1() {
    mul_ln1118_1123_fu_104691_p1 = tmp_1633_reg_138506.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1123_fu_104691_p2() {
    mul_ln1118_1123_fu_104691_p2 = (!mul_ln1118_1123_fu_104691_p0.read().is_01() || !mul_ln1118_1123_fu_104691_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1123_fu_104691_p0.read()) * sc_bigint<2>(mul_ln1118_1123_fu_104691_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1124_fu_104715_p0() {
    mul_ln1118_1124_fu_104715_p0 =  (sc_lv<10>) (mul_ln1118_1124_fu_104715_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1124_fu_104715_p00() {
    mul_ln1118_1124_fu_104715_p00 = esl_zext<12,10>(trunc_ln77_737_reg_138511.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1124_fu_104715_p1() {
    mul_ln1118_1124_fu_104715_p1 = tmp_1635_reg_138516.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1124_fu_104715_p2() {
    mul_ln1118_1124_fu_104715_p2 = (!mul_ln1118_1124_fu_104715_p0.read().is_01() || !mul_ln1118_1124_fu_104715_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1124_fu_104715_p0.read()) * sc_bigint<2>(mul_ln1118_1124_fu_104715_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1125_fu_104727_p0() {
    mul_ln1118_1125_fu_104727_p0 =  (sc_lv<10>) (mul_ln1118_1125_fu_104727_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1125_fu_104727_p00() {
    mul_ln1118_1125_fu_104727_p00 = esl_zext<12,10>(trunc_ln77_738_reg_138521.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1125_fu_104727_p1() {
    mul_ln1118_1125_fu_104727_p1 = tmp_1637_reg_138526.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1125_fu_104727_p2() {
    mul_ln1118_1125_fu_104727_p2 = (!mul_ln1118_1125_fu_104727_p0.read().is_01() || !mul_ln1118_1125_fu_104727_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1125_fu_104727_p0.read()) * sc_bigint<2>(mul_ln1118_1125_fu_104727_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1126_fu_104751_p0() {
    mul_ln1118_1126_fu_104751_p0 =  (sc_lv<10>) (mul_ln1118_1126_fu_104751_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1126_fu_104751_p00() {
    mul_ln1118_1126_fu_104751_p00 = esl_zext<12,10>(trunc_ln77_739_reg_138531.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1126_fu_104751_p1() {
    mul_ln1118_1126_fu_104751_p1 = tmp_1639_reg_138536.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1126_fu_104751_p2() {
    mul_ln1118_1126_fu_104751_p2 = (!mul_ln1118_1126_fu_104751_p0.read().is_01() || !mul_ln1118_1126_fu_104751_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1126_fu_104751_p0.read()) * sc_bigint<2>(mul_ln1118_1126_fu_104751_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1127_fu_104775_p0() {
    mul_ln1118_1127_fu_104775_p0 =  (sc_lv<10>) (mul_ln1118_1127_fu_104775_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1127_fu_104775_p00() {
    mul_ln1118_1127_fu_104775_p00 = esl_zext<12,10>(trunc_ln77_740_reg_138541.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1127_fu_104775_p1() {
    mul_ln1118_1127_fu_104775_p1 = tmp_1641_reg_138546.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1127_fu_104775_p2() {
    mul_ln1118_1127_fu_104775_p2 = (!mul_ln1118_1127_fu_104775_p0.read().is_01() || !mul_ln1118_1127_fu_104775_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1127_fu_104775_p0.read()) * sc_bigint<2>(mul_ln1118_1127_fu_104775_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1128_fu_104799_p0() {
    mul_ln1118_1128_fu_104799_p0 =  (sc_lv<10>) (mul_ln1118_1128_fu_104799_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1128_fu_104799_p00() {
    mul_ln1118_1128_fu_104799_p00 = esl_zext<12,10>(trunc_ln77_741_reg_138551.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1128_fu_104799_p1() {
    mul_ln1118_1128_fu_104799_p1 = tmp_1643_reg_138556.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1128_fu_104799_p2() {
    mul_ln1118_1128_fu_104799_p2 = (!mul_ln1118_1128_fu_104799_p0.read().is_01() || !mul_ln1118_1128_fu_104799_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1128_fu_104799_p0.read()) * sc_bigint<2>(mul_ln1118_1128_fu_104799_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1129_fu_104823_p0() {
    mul_ln1118_1129_fu_104823_p0 =  (sc_lv<10>) (mul_ln1118_1129_fu_104823_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1129_fu_104823_p00() {
    mul_ln1118_1129_fu_104823_p00 = esl_zext<12,10>(trunc_ln77_742_reg_138561.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1129_fu_104823_p1() {
    mul_ln1118_1129_fu_104823_p1 = tmp_1645_reg_138566.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1129_fu_104823_p2() {
    mul_ln1118_1129_fu_104823_p2 = (!mul_ln1118_1129_fu_104823_p0.read().is_01() || !mul_ln1118_1129_fu_104823_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1129_fu_104823_p0.read()) * sc_bigint<2>(mul_ln1118_1129_fu_104823_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_112_fu_82155_p0() {
    mul_ln1118_112_fu_82155_p0 =  (sc_lv<10>) (zext_ln1116_111_fu_82149_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_112_fu_82155_p1() {
    mul_ln1118_112_fu_82155_p1 = tmp_217_reg_130351.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_112_fu_82155_p2() {
    mul_ln1118_112_fu_82155_p2 = (!mul_ln1118_112_fu_82155_p0.read().is_01() || !mul_ln1118_112_fu_82155_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_112_fu_82155_p0.read()) * sc_bigint<2>(mul_ln1118_112_fu_82155_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1130_fu_104835_p0() {
    mul_ln1118_1130_fu_104835_p0 =  (sc_lv<10>) (mul_ln1118_1130_fu_104835_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1130_fu_104835_p00() {
    mul_ln1118_1130_fu_104835_p00 = esl_zext<12,10>(trunc_ln77_743_reg_138571.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1130_fu_104835_p1() {
    mul_ln1118_1130_fu_104835_p1 = tmp_1646_reg_138576.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1130_fu_104835_p2() {
    mul_ln1118_1130_fu_104835_p2 = (!mul_ln1118_1130_fu_104835_p0.read().is_01() || !mul_ln1118_1130_fu_104835_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1130_fu_104835_p0.read()) * sc_bigint<2>(mul_ln1118_1130_fu_104835_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1131_fu_104859_p0() {
    mul_ln1118_1131_fu_104859_p0 =  (sc_lv<10>) (mul_ln1118_1131_fu_104859_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1131_fu_104859_p00() {
    mul_ln1118_1131_fu_104859_p00 = esl_zext<12,10>(trunc_ln77_744_reg_138581.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1131_fu_104859_p1() {
    mul_ln1118_1131_fu_104859_p1 = tmp_1647_reg_138586.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1131_fu_104859_p2() {
    mul_ln1118_1131_fu_104859_p2 = (!mul_ln1118_1131_fu_104859_p0.read().is_01() || !mul_ln1118_1131_fu_104859_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1131_fu_104859_p0.read()) * sc_bigint<2>(mul_ln1118_1131_fu_104859_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1132_fu_104883_p0() {
    mul_ln1118_1132_fu_104883_p0 =  (sc_lv<10>) (mul_ln1118_1132_fu_104883_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1132_fu_104883_p00() {
    mul_ln1118_1132_fu_104883_p00 = esl_zext<12,10>(trunc_ln77_745_reg_138591.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1132_fu_104883_p1() {
    mul_ln1118_1132_fu_104883_p1 = tmp_1648_reg_138596.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1132_fu_104883_p2() {
    mul_ln1118_1132_fu_104883_p2 = (!mul_ln1118_1132_fu_104883_p0.read().is_01() || !mul_ln1118_1132_fu_104883_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1132_fu_104883_p0.read()) * sc_bigint<2>(mul_ln1118_1132_fu_104883_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1133_fu_104895_p0() {
    mul_ln1118_1133_fu_104895_p0 =  (sc_lv<10>) (mul_ln1118_1133_fu_104895_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1133_fu_104895_p00() {
    mul_ln1118_1133_fu_104895_p00 = esl_zext<12,10>(trunc_ln77_746_reg_138601.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1133_fu_104895_p1() {
    mul_ln1118_1133_fu_104895_p1 = tmp_1649_reg_138606.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1133_fu_104895_p2() {
    mul_ln1118_1133_fu_104895_p2 = (!mul_ln1118_1133_fu_104895_p0.read().is_01() || !mul_ln1118_1133_fu_104895_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1133_fu_104895_p0.read()) * sc_bigint<2>(mul_ln1118_1133_fu_104895_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1134_fu_104919_p0() {
    mul_ln1118_1134_fu_104919_p0 =  (sc_lv<10>) (mul_ln1118_1134_fu_104919_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1134_fu_104919_p00() {
    mul_ln1118_1134_fu_104919_p00 = esl_zext<12,10>(trunc_ln77_747_reg_138611.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1134_fu_104919_p1() {
    mul_ln1118_1134_fu_104919_p1 = tmp_1650_reg_138616.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1134_fu_104919_p2() {
    mul_ln1118_1134_fu_104919_p2 = (!mul_ln1118_1134_fu_104919_p0.read().is_01() || !mul_ln1118_1134_fu_104919_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1134_fu_104919_p0.read()) * sc_bigint<2>(mul_ln1118_1134_fu_104919_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1135_fu_104943_p0() {
    mul_ln1118_1135_fu_104943_p0 =  (sc_lv<10>) (mul_ln1118_1135_fu_104943_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1135_fu_104943_p00() {
    mul_ln1118_1135_fu_104943_p00 = esl_zext<12,10>(trunc_ln77_748_reg_138621.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1135_fu_104943_p1() {
    mul_ln1118_1135_fu_104943_p1 = tmp_1651_reg_138626.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1135_fu_104943_p2() {
    mul_ln1118_1135_fu_104943_p2 = (!mul_ln1118_1135_fu_104943_p0.read().is_01() || !mul_ln1118_1135_fu_104943_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1135_fu_104943_p0.read()) * sc_bigint<2>(mul_ln1118_1135_fu_104943_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1136_fu_104955_p0() {
    mul_ln1118_1136_fu_104955_p0 =  (sc_lv<10>) (mul_ln1118_1136_fu_104955_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1136_fu_104955_p00() {
    mul_ln1118_1136_fu_104955_p00 = esl_zext<12,10>(trunc_ln77_749_reg_138631.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1136_fu_104955_p1() {
    mul_ln1118_1136_fu_104955_p1 = tmp_1652_reg_138636.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1136_fu_104955_p2() {
    mul_ln1118_1136_fu_104955_p2 = (!mul_ln1118_1136_fu_104955_p0.read().is_01() || !mul_ln1118_1136_fu_104955_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1136_fu_104955_p0.read()) * sc_bigint<2>(mul_ln1118_1136_fu_104955_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1137_fu_104979_p0() {
    mul_ln1118_1137_fu_104979_p0 =  (sc_lv<10>) (mul_ln1118_1137_fu_104979_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1137_fu_104979_p00() {
    mul_ln1118_1137_fu_104979_p00 = esl_zext<12,10>(trunc_ln77_750_reg_138641.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1137_fu_104979_p1() {
    mul_ln1118_1137_fu_104979_p1 = tmp_1653_reg_138646.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1137_fu_104979_p2() {
    mul_ln1118_1137_fu_104979_p2 = (!mul_ln1118_1137_fu_104979_p0.read().is_01() || !mul_ln1118_1137_fu_104979_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1137_fu_104979_p0.read()) * sc_bigint<2>(mul_ln1118_1137_fu_104979_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1138_fu_105003_p0() {
    mul_ln1118_1138_fu_105003_p0 =  (sc_lv<10>) (mul_ln1118_1138_fu_105003_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1138_fu_105003_p00() {
    mul_ln1118_1138_fu_105003_p00 = esl_zext<12,10>(trunc_ln77_751_reg_138651.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1138_fu_105003_p1() {
    mul_ln1118_1138_fu_105003_p1 = tmp_1655_reg_138656.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1138_fu_105003_p2() {
    mul_ln1118_1138_fu_105003_p2 = (!mul_ln1118_1138_fu_105003_p0.read().is_01() || !mul_ln1118_1138_fu_105003_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1138_fu_105003_p0.read()) * sc_bigint<2>(mul_ln1118_1138_fu_105003_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1139_fu_105027_p0() {
    mul_ln1118_1139_fu_105027_p0 =  (sc_lv<10>) (mul_ln1118_1139_fu_105027_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1139_fu_105027_p00() {
    mul_ln1118_1139_fu_105027_p00 = esl_zext<12,10>(trunc_ln77_752_reg_138661.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1139_fu_105027_p1() {
    mul_ln1118_1139_fu_105027_p1 = tmp_1657_reg_138666.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1139_fu_105027_p2() {
    mul_ln1118_1139_fu_105027_p2 = (!mul_ln1118_1139_fu_105027_p0.read().is_01() || !mul_ln1118_1139_fu_105027_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1139_fu_105027_p0.read()) * sc_bigint<2>(mul_ln1118_1139_fu_105027_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_113_fu_82179_p0() {
    mul_ln1118_113_fu_82179_p0 =  (sc_lv<10>) (zext_ln1116_112_fu_82173_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_113_fu_82179_p1() {
    mul_ln1118_113_fu_82179_p1 = tmp_219_reg_130361.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_113_fu_82179_p2() {
    mul_ln1118_113_fu_82179_p2 = (!mul_ln1118_113_fu_82179_p0.read().is_01() || !mul_ln1118_113_fu_82179_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_113_fu_82179_p0.read()) * sc_bigint<2>(mul_ln1118_113_fu_82179_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1140_fu_105051_p0() {
    mul_ln1118_1140_fu_105051_p0 =  (sc_lv<10>) (mul_ln1118_1140_fu_105051_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1140_fu_105051_p00() {
    mul_ln1118_1140_fu_105051_p00 = esl_zext<12,10>(trunc_ln77_753_reg_138671.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1140_fu_105051_p1() {
    mul_ln1118_1140_fu_105051_p1 = tmp_1659_reg_138676.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1140_fu_105051_p2() {
    mul_ln1118_1140_fu_105051_p2 = (!mul_ln1118_1140_fu_105051_p0.read().is_01() || !mul_ln1118_1140_fu_105051_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1140_fu_105051_p0.read()) * sc_bigint<2>(mul_ln1118_1140_fu_105051_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1141_fu_105063_p0() {
    mul_ln1118_1141_fu_105063_p0 =  (sc_lv<10>) (mul_ln1118_1141_fu_105063_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1141_fu_105063_p00() {
    mul_ln1118_1141_fu_105063_p00 = esl_zext<12,10>(trunc_ln77_754_reg_138681.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1141_fu_105063_p1() {
    mul_ln1118_1141_fu_105063_p1 = tmp_1661_reg_138686.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1141_fu_105063_p2() {
    mul_ln1118_1141_fu_105063_p2 = (!mul_ln1118_1141_fu_105063_p0.read().is_01() || !mul_ln1118_1141_fu_105063_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1141_fu_105063_p0.read()) * sc_bigint<2>(mul_ln1118_1141_fu_105063_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1142_fu_105087_p0() {
    mul_ln1118_1142_fu_105087_p0 =  (sc_lv<10>) (mul_ln1118_1142_fu_105087_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1142_fu_105087_p00() {
    mul_ln1118_1142_fu_105087_p00 = esl_zext<12,10>(trunc_ln77_755_reg_138691.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1142_fu_105087_p1() {
    mul_ln1118_1142_fu_105087_p1 = tmp_1663_reg_138696.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1142_fu_105087_p2() {
    mul_ln1118_1142_fu_105087_p2 = (!mul_ln1118_1142_fu_105087_p0.read().is_01() || !mul_ln1118_1142_fu_105087_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1142_fu_105087_p0.read()) * sc_bigint<2>(mul_ln1118_1142_fu_105087_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1143_fu_105108_p0() {
    mul_ln1118_1143_fu_105108_p0 =  (sc_lv<10>) (zext_ln1116_674_fu_103137_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1143_fu_105108_p1() {
    mul_ln1118_1143_fu_105108_p1 = tmp_1664_reg_138701.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1143_fu_105108_p2() {
    mul_ln1118_1143_fu_105108_p2 = (!mul_ln1118_1143_fu_105108_p0.read().is_01() || !mul_ln1118_1143_fu_105108_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1143_fu_105108_p0.read()) * sc_bigint<2>(mul_ln1118_1143_fu_105108_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1144_fu_105129_p0() {
    mul_ln1118_1144_fu_105129_p0 =  (sc_lv<10>) (zext_ln1116_675_fu_103161_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1144_fu_105129_p1() {
    mul_ln1118_1144_fu_105129_p1 = tmp_1665_reg_138706.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1144_fu_105129_p2() {
    mul_ln1118_1144_fu_105129_p2 = (!mul_ln1118_1144_fu_105129_p0.read().is_01() || !mul_ln1118_1144_fu_105129_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1144_fu_105129_p0.read()) * sc_bigint<2>(mul_ln1118_1144_fu_105129_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1145_fu_105150_p0() {
    mul_ln1118_1145_fu_105150_p0 =  (sc_lv<10>) (zext_ln1116_676_fu_103185_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1145_fu_105150_p1() {
    mul_ln1118_1145_fu_105150_p1 = tmp_1666_reg_138711.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1145_fu_105150_p2() {
    mul_ln1118_1145_fu_105150_p2 = (!mul_ln1118_1145_fu_105150_p0.read().is_01() || !mul_ln1118_1145_fu_105150_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1145_fu_105150_p0.read()) * sc_bigint<2>(mul_ln1118_1145_fu_105150_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1146_fu_105159_p0() {
    mul_ln1118_1146_fu_105159_p0 =  (sc_lv<10>) (zext_ln1116_677_fu_103197_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1146_fu_105159_p1() {
    mul_ln1118_1146_fu_105159_p1 = tmp_1667_reg_138716.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1146_fu_105159_p2() {
    mul_ln1118_1146_fu_105159_p2 = (!mul_ln1118_1146_fu_105159_p0.read().is_01() || !mul_ln1118_1146_fu_105159_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1146_fu_105159_p0.read()) * sc_bigint<2>(mul_ln1118_1146_fu_105159_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1147_fu_105180_p0() {
    mul_ln1118_1147_fu_105180_p0 =  (sc_lv<10>) (zext_ln1116_678_fu_103221_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1147_fu_105180_p1() {
    mul_ln1118_1147_fu_105180_p1 = tmp_1668_reg_138721.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1147_fu_105180_p2() {
    mul_ln1118_1147_fu_105180_p2 = (!mul_ln1118_1147_fu_105180_p0.read().is_01() || !mul_ln1118_1147_fu_105180_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1147_fu_105180_p0.read()) * sc_bigint<2>(mul_ln1118_1147_fu_105180_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1148_fu_105201_p0() {
    mul_ln1118_1148_fu_105201_p0 =  (sc_lv<10>) (zext_ln1116_679_fu_103245_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1148_fu_105201_p1() {
    mul_ln1118_1148_fu_105201_p1 = tmp_1669_reg_138726.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1148_fu_105201_p2() {
    mul_ln1118_1148_fu_105201_p2 = (!mul_ln1118_1148_fu_105201_p0.read().is_01() || !mul_ln1118_1148_fu_105201_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1148_fu_105201_p0.read()) * sc_bigint<2>(mul_ln1118_1148_fu_105201_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1149_fu_105222_p0() {
    mul_ln1118_1149_fu_105222_p0 =  (sc_lv<10>) (zext_ln1116_680_fu_103269_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1149_fu_105222_p1() {
    mul_ln1118_1149_fu_105222_p1 = tmp_1670_reg_138731.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1149_fu_105222_p2() {
    mul_ln1118_1149_fu_105222_p2 = (!mul_ln1118_1149_fu_105222_p0.read().is_01() || !mul_ln1118_1149_fu_105222_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1149_fu_105222_p0.read()) * sc_bigint<2>(mul_ln1118_1149_fu_105222_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_114_fu_82203_p0() {
    mul_ln1118_114_fu_82203_p0 =  (sc_lv<10>) (zext_ln1116_113_fu_82197_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_114_fu_82203_p1() {
    mul_ln1118_114_fu_82203_p1 = tmp_221_reg_130371.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_114_fu_82203_p2() {
    mul_ln1118_114_fu_82203_p2 = (!mul_ln1118_114_fu_82203_p0.read().is_01() || !mul_ln1118_114_fu_82203_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_114_fu_82203_p0.read()) * sc_bigint<2>(mul_ln1118_114_fu_82203_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1150_fu_105243_p0() {
    mul_ln1118_1150_fu_105243_p0 =  (sc_lv<10>) (zext_ln1116_681_fu_103293_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1150_fu_105243_p1() {
    mul_ln1118_1150_fu_105243_p1 = tmp_1671_reg_138736.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1150_fu_105243_p2() {
    mul_ln1118_1150_fu_105243_p2 = (!mul_ln1118_1150_fu_105243_p0.read().is_01() || !mul_ln1118_1150_fu_105243_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1150_fu_105243_p0.read()) * sc_bigint<2>(mul_ln1118_1150_fu_105243_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1151_fu_105252_p0() {
    mul_ln1118_1151_fu_105252_p0 =  (sc_lv<10>) (zext_ln1116_682_fu_103305_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1151_fu_105252_p1() {
    mul_ln1118_1151_fu_105252_p1 = tmp_1672_reg_138741.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1151_fu_105252_p2() {
    mul_ln1118_1151_fu_105252_p2 = (!mul_ln1118_1151_fu_105252_p0.read().is_01() || !mul_ln1118_1151_fu_105252_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1151_fu_105252_p0.read()) * sc_bigint<2>(mul_ln1118_1151_fu_105252_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1152_fu_105273_p0() {
    mul_ln1118_1152_fu_105273_p0 =  (sc_lv<10>) (zext_ln1116_683_fu_103329_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1152_fu_105273_p1() {
    mul_ln1118_1152_fu_105273_p1 = tmp_1673_reg_138746.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1152_fu_105273_p2() {
    mul_ln1118_1152_fu_105273_p2 = (!mul_ln1118_1152_fu_105273_p0.read().is_01() || !mul_ln1118_1152_fu_105273_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1152_fu_105273_p0.read()) * sc_bigint<2>(mul_ln1118_1152_fu_105273_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1153_fu_105294_p0() {
    mul_ln1118_1153_fu_105294_p0 =  (sc_lv<10>) (zext_ln1116_684_fu_103353_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1153_fu_105294_p1() {
    mul_ln1118_1153_fu_105294_p1 = tmp_1674_reg_138751.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1153_fu_105294_p2() {
    mul_ln1118_1153_fu_105294_p2 = (!mul_ln1118_1153_fu_105294_p0.read().is_01() || !mul_ln1118_1153_fu_105294_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1153_fu_105294_p0.read()) * sc_bigint<2>(mul_ln1118_1153_fu_105294_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1154_fu_105303_p0() {
    mul_ln1118_1154_fu_105303_p0 =  (sc_lv<10>) (zext_ln1116_685_fu_103365_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1154_fu_105303_p1() {
    mul_ln1118_1154_fu_105303_p1 = tmp_1675_reg_138756.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1154_fu_105303_p2() {
    mul_ln1118_1154_fu_105303_p2 = (!mul_ln1118_1154_fu_105303_p0.read().is_01() || !mul_ln1118_1154_fu_105303_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1154_fu_105303_p0.read()) * sc_bigint<2>(mul_ln1118_1154_fu_105303_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1155_fu_105324_p0() {
    mul_ln1118_1155_fu_105324_p0 =  (sc_lv<10>) (zext_ln1116_686_fu_103389_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1155_fu_105324_p1() {
    mul_ln1118_1155_fu_105324_p1 = tmp_1676_reg_138761.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1155_fu_105324_p2() {
    mul_ln1118_1155_fu_105324_p2 = (!mul_ln1118_1155_fu_105324_p0.read().is_01() || !mul_ln1118_1155_fu_105324_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1155_fu_105324_p0.read()) * sc_bigint<2>(mul_ln1118_1155_fu_105324_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1156_fu_105345_p0() {
    mul_ln1118_1156_fu_105345_p0 =  (sc_lv<10>) (zext_ln1116_687_fu_103413_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1156_fu_105345_p1() {
    mul_ln1118_1156_fu_105345_p1 = tmp_1677_reg_138766.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1156_fu_105345_p2() {
    mul_ln1118_1156_fu_105345_p2 = (!mul_ln1118_1156_fu_105345_p0.read().is_01() || !mul_ln1118_1156_fu_105345_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1156_fu_105345_p0.read()) * sc_bigint<2>(mul_ln1118_1156_fu_105345_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1157_fu_105354_p0() {
    mul_ln1118_1157_fu_105354_p0 =  (sc_lv<10>) (zext_ln1116_688_fu_103425_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1157_fu_105354_p1() {
    mul_ln1118_1157_fu_105354_p1 = tmp_1678_reg_138771.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1157_fu_105354_p2() {
    mul_ln1118_1157_fu_105354_p2 = (!mul_ln1118_1157_fu_105354_p0.read().is_01() || !mul_ln1118_1157_fu_105354_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1157_fu_105354_p0.read()) * sc_bigint<2>(mul_ln1118_1157_fu_105354_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1158_fu_105375_p0() {
    mul_ln1118_1158_fu_105375_p0 =  (sc_lv<10>) (zext_ln1116_689_fu_103449_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1158_fu_105375_p1() {
    mul_ln1118_1158_fu_105375_p1 = tmp_1679_reg_138776.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1158_fu_105375_p2() {
    mul_ln1118_1158_fu_105375_p2 = (!mul_ln1118_1158_fu_105375_p0.read().is_01() || !mul_ln1118_1158_fu_105375_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1158_fu_105375_p0.read()) * sc_bigint<2>(mul_ln1118_1158_fu_105375_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1159_fu_105396_p0() {
    mul_ln1118_1159_fu_105396_p0 =  (sc_lv<10>) (zext_ln1116_690_fu_103473_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1159_fu_105396_p1() {
    mul_ln1118_1159_fu_105396_p1 = tmp_1680_reg_138781.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1159_fu_105396_p2() {
    mul_ln1118_1159_fu_105396_p2 = (!mul_ln1118_1159_fu_105396_p0.read().is_01() || !mul_ln1118_1159_fu_105396_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1159_fu_105396_p0.read()) * sc_bigint<2>(mul_ln1118_1159_fu_105396_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_115_fu_82227_p0() {
    mul_ln1118_115_fu_82227_p0 =  (sc_lv<10>) (zext_ln1116_114_fu_82221_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_115_fu_82227_p1() {
    mul_ln1118_115_fu_82227_p1 = tmp_223_reg_130381.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_115_fu_82227_p2() {
    mul_ln1118_115_fu_82227_p2 = (!mul_ln1118_115_fu_82227_p0.read().is_01() || !mul_ln1118_115_fu_82227_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_115_fu_82227_p0.read()) * sc_bigint<2>(mul_ln1118_115_fu_82227_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1160_fu_105417_p0() {
    mul_ln1118_1160_fu_105417_p0 =  (sc_lv<10>) (zext_ln1116_691_fu_103497_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1160_fu_105417_p1() {
    mul_ln1118_1160_fu_105417_p1 = tmp_1681_reg_138786.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1160_fu_105417_p2() {
    mul_ln1118_1160_fu_105417_p2 = (!mul_ln1118_1160_fu_105417_p0.read().is_01() || !mul_ln1118_1160_fu_105417_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1160_fu_105417_p0.read()) * sc_bigint<2>(mul_ln1118_1160_fu_105417_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1161_fu_105438_p0() {
    mul_ln1118_1161_fu_105438_p0 =  (sc_lv<10>) (zext_ln1116_692_fu_103521_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1161_fu_105438_p1() {
    mul_ln1118_1161_fu_105438_p1 = tmp_1682_reg_138791.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1161_fu_105438_p2() {
    mul_ln1118_1161_fu_105438_p2 = (!mul_ln1118_1161_fu_105438_p0.read().is_01() || !mul_ln1118_1161_fu_105438_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1161_fu_105438_p0.read()) * sc_bigint<2>(mul_ln1118_1161_fu_105438_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1162_fu_105447_p0() {
    mul_ln1118_1162_fu_105447_p0 =  (sc_lv<10>) (zext_ln1116_693_fu_103533_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1162_fu_105447_p1() {
    mul_ln1118_1162_fu_105447_p1 = tmp_1683_reg_138796.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1162_fu_105447_p2() {
    mul_ln1118_1162_fu_105447_p2 = (!mul_ln1118_1162_fu_105447_p0.read().is_01() || !mul_ln1118_1162_fu_105447_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1162_fu_105447_p0.read()) * sc_bigint<2>(mul_ln1118_1162_fu_105447_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1163_fu_105468_p0() {
    mul_ln1118_1163_fu_105468_p0 =  (sc_lv<10>) (zext_ln1116_694_fu_103557_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1163_fu_105468_p1() {
    mul_ln1118_1163_fu_105468_p1 = tmp_1684_reg_138801.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1163_fu_105468_p2() {
    mul_ln1118_1163_fu_105468_p2 = (!mul_ln1118_1163_fu_105468_p0.read().is_01() || !mul_ln1118_1163_fu_105468_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1163_fu_105468_p0.read()) * sc_bigint<2>(mul_ln1118_1163_fu_105468_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1164_fu_105489_p0() {
    mul_ln1118_1164_fu_105489_p0 =  (sc_lv<10>) (zext_ln1116_695_fu_103581_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1164_fu_105489_p1() {
    mul_ln1118_1164_fu_105489_p1 = tmp_1685_reg_138806.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1164_fu_105489_p2() {
    mul_ln1118_1164_fu_105489_p2 = (!mul_ln1118_1164_fu_105489_p0.read().is_01() || !mul_ln1118_1164_fu_105489_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1164_fu_105489_p0.read()) * sc_bigint<2>(mul_ln1118_1164_fu_105489_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1165_fu_105510_p0() {
    mul_ln1118_1165_fu_105510_p0 =  (sc_lv<10>) (zext_ln1116_696_fu_103605_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1165_fu_105510_p1() {
    mul_ln1118_1165_fu_105510_p1 = tmp_1686_reg_138811.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1165_fu_105510_p2() {
    mul_ln1118_1165_fu_105510_p2 = (!mul_ln1118_1165_fu_105510_p0.read().is_01() || !mul_ln1118_1165_fu_105510_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1165_fu_105510_p0.read()) * sc_bigint<2>(mul_ln1118_1165_fu_105510_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1166_fu_105531_p0() {
    mul_ln1118_1166_fu_105531_p0 =  (sc_lv<10>) (zext_ln1116_697_fu_103629_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1166_fu_105531_p1() {
    mul_ln1118_1166_fu_105531_p1 = tmp_1687_reg_138816.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1166_fu_105531_p2() {
    mul_ln1118_1166_fu_105531_p2 = (!mul_ln1118_1166_fu_105531_p0.read().is_01() || !mul_ln1118_1166_fu_105531_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1166_fu_105531_p0.read()) * sc_bigint<2>(mul_ln1118_1166_fu_105531_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1167_fu_105540_p0() {
    mul_ln1118_1167_fu_105540_p0 =  (sc_lv<10>) (zext_ln1116_698_fu_103641_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1167_fu_105540_p1() {
    mul_ln1118_1167_fu_105540_p1 = tmp_1688_reg_138821.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1167_fu_105540_p2() {
    mul_ln1118_1167_fu_105540_p2 = (!mul_ln1118_1167_fu_105540_p0.read().is_01() || !mul_ln1118_1167_fu_105540_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1167_fu_105540_p0.read()) * sc_bigint<2>(mul_ln1118_1167_fu_105540_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1168_fu_105561_p0() {
    mul_ln1118_1168_fu_105561_p0 =  (sc_lv<10>) (zext_ln1116_699_fu_103665_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1168_fu_105561_p1() {
    mul_ln1118_1168_fu_105561_p1 = tmp_1689_reg_138826.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1168_fu_105561_p2() {
    mul_ln1118_1168_fu_105561_p2 = (!mul_ln1118_1168_fu_105561_p0.read().is_01() || !mul_ln1118_1168_fu_105561_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1168_fu_105561_p0.read()) * sc_bigint<2>(mul_ln1118_1168_fu_105561_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1169_fu_105582_p0() {
    mul_ln1118_1169_fu_105582_p0 =  (sc_lv<10>) (zext_ln1116_700_fu_103689_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1169_fu_105582_p1() {
    mul_ln1118_1169_fu_105582_p1 = tmp_1690_reg_138831.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1169_fu_105582_p2() {
    mul_ln1118_1169_fu_105582_p2 = (!mul_ln1118_1169_fu_105582_p0.read().is_01() || !mul_ln1118_1169_fu_105582_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1169_fu_105582_p0.read()) * sc_bigint<2>(mul_ln1118_1169_fu_105582_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_116_fu_82251_p0() {
    mul_ln1118_116_fu_82251_p0 =  (sc_lv<10>) (zext_ln1116_115_fu_82245_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_116_fu_82251_p1() {
    mul_ln1118_116_fu_82251_p1 = tmp_225_reg_130391.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_116_fu_82251_p2() {
    mul_ln1118_116_fu_82251_p2 = (!mul_ln1118_116_fu_82251_p0.read().is_01() || !mul_ln1118_116_fu_82251_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_116_fu_82251_p0.read()) * sc_bigint<2>(mul_ln1118_116_fu_82251_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1170_fu_105603_p0() {
    mul_ln1118_1170_fu_105603_p0 =  (sc_lv<10>) (zext_ln1116_701_fu_103713_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1170_fu_105603_p1() {
    mul_ln1118_1170_fu_105603_p1 = tmp_1691_reg_138836.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1170_fu_105603_p2() {
    mul_ln1118_1170_fu_105603_p2 = (!mul_ln1118_1170_fu_105603_p0.read().is_01() || !mul_ln1118_1170_fu_105603_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1170_fu_105603_p0.read()) * sc_bigint<2>(mul_ln1118_1170_fu_105603_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1171_fu_105624_p0() {
    mul_ln1118_1171_fu_105624_p0 =  (sc_lv<10>) (zext_ln1116_702_fu_103737_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1171_fu_105624_p1() {
    mul_ln1118_1171_fu_105624_p1 = tmp_1692_reg_138841.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1171_fu_105624_p2() {
    mul_ln1118_1171_fu_105624_p2 = (!mul_ln1118_1171_fu_105624_p0.read().is_01() || !mul_ln1118_1171_fu_105624_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1171_fu_105624_p0.read()) * sc_bigint<2>(mul_ln1118_1171_fu_105624_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1172_fu_105633_p0() {
    mul_ln1118_1172_fu_105633_p0 =  (sc_lv<10>) (zext_ln1116_703_fu_103749_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1172_fu_105633_p1() {
    mul_ln1118_1172_fu_105633_p1 = tmp_1693_reg_138846.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1172_fu_105633_p2() {
    mul_ln1118_1172_fu_105633_p2 = (!mul_ln1118_1172_fu_105633_p0.read().is_01() || !mul_ln1118_1172_fu_105633_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1172_fu_105633_p0.read()) * sc_bigint<2>(mul_ln1118_1172_fu_105633_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1173_fu_105654_p0() {
    mul_ln1118_1173_fu_105654_p0 =  (sc_lv<10>) (zext_ln1116_704_fu_103773_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1173_fu_105654_p1() {
    mul_ln1118_1173_fu_105654_p1 = tmp_1694_reg_138851.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1173_fu_105654_p2() {
    mul_ln1118_1173_fu_105654_p2 = (!mul_ln1118_1173_fu_105654_p0.read().is_01() || !mul_ln1118_1173_fu_105654_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1173_fu_105654_p0.read()) * sc_bigint<2>(mul_ln1118_1173_fu_105654_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1174_fu_105675_p0() {
    mul_ln1118_1174_fu_105675_p0 =  (sc_lv<10>) (zext_ln1116_705_fu_103797_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1174_fu_105675_p1() {
    mul_ln1118_1174_fu_105675_p1 = tmp_1695_reg_138856.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1174_fu_105675_p2() {
    mul_ln1118_1174_fu_105675_p2 = (!mul_ln1118_1174_fu_105675_p0.read().is_01() || !mul_ln1118_1174_fu_105675_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1174_fu_105675_p0.read()) * sc_bigint<2>(mul_ln1118_1174_fu_105675_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1175_fu_105684_p0() {
    mul_ln1118_1175_fu_105684_p0 =  (sc_lv<10>) (zext_ln1116_706_fu_103809_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1175_fu_105684_p1() {
    mul_ln1118_1175_fu_105684_p1 = tmp_1696_reg_138861.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1175_fu_105684_p2() {
    mul_ln1118_1175_fu_105684_p2 = (!mul_ln1118_1175_fu_105684_p0.read().is_01() || !mul_ln1118_1175_fu_105684_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1175_fu_105684_p0.read()) * sc_bigint<2>(mul_ln1118_1175_fu_105684_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1176_fu_105705_p0() {
    mul_ln1118_1176_fu_105705_p0 =  (sc_lv<10>) (zext_ln1116_707_fu_103833_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1176_fu_105705_p1() {
    mul_ln1118_1176_fu_105705_p1 = tmp_1697_reg_138866.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1176_fu_105705_p2() {
    mul_ln1118_1176_fu_105705_p2 = (!mul_ln1118_1176_fu_105705_p0.read().is_01() || !mul_ln1118_1176_fu_105705_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1176_fu_105705_p0.read()) * sc_bigint<2>(mul_ln1118_1176_fu_105705_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1177_fu_105726_p0() {
    mul_ln1118_1177_fu_105726_p0 =  (sc_lv<10>) (zext_ln1116_708_fu_103857_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1177_fu_105726_p1() {
    mul_ln1118_1177_fu_105726_p1 = tmp_1698_reg_138871.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1177_fu_105726_p2() {
    mul_ln1118_1177_fu_105726_p2 = (!mul_ln1118_1177_fu_105726_p0.read().is_01() || !mul_ln1118_1177_fu_105726_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1177_fu_105726_p0.read()) * sc_bigint<2>(mul_ln1118_1177_fu_105726_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1178_fu_105735_p0() {
    mul_ln1118_1178_fu_105735_p0 =  (sc_lv<10>) (zext_ln1116_709_fu_103869_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1178_fu_105735_p1() {
    mul_ln1118_1178_fu_105735_p1 = tmp_1699_reg_138876.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1178_fu_105735_p2() {
    mul_ln1118_1178_fu_105735_p2 = (!mul_ln1118_1178_fu_105735_p0.read().is_01() || !mul_ln1118_1178_fu_105735_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1178_fu_105735_p0.read()) * sc_bigint<2>(mul_ln1118_1178_fu_105735_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1179_fu_105756_p0() {
    mul_ln1118_1179_fu_105756_p0 =  (sc_lv<10>) (zext_ln1116_710_fu_103893_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1179_fu_105756_p1() {
    mul_ln1118_1179_fu_105756_p1 = tmp_1700_reg_138881.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1179_fu_105756_p2() {
    mul_ln1118_1179_fu_105756_p2 = (!mul_ln1118_1179_fu_105756_p0.read().is_01() || !mul_ln1118_1179_fu_105756_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1179_fu_105756_p0.read()) * sc_bigint<2>(mul_ln1118_1179_fu_105756_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_117_fu_82263_p0() {
    mul_ln1118_117_fu_82263_p0 =  (sc_lv<10>) (zext_ln1116_116_fu_82257_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_117_fu_82263_p1() {
    mul_ln1118_117_fu_82263_p1 = tmp_227_reg_130401.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_117_fu_82263_p2() {
    mul_ln1118_117_fu_82263_p2 = (!mul_ln1118_117_fu_82263_p0.read().is_01() || !mul_ln1118_117_fu_82263_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_117_fu_82263_p0.read()) * sc_bigint<2>(mul_ln1118_117_fu_82263_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1180_fu_105969_p0() {
    mul_ln1118_1180_fu_105969_p0 =  (sc_lv<10>) (zext_ln1116_711_fu_104109_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1180_fu_105969_p1() {
    mul_ln1118_1180_fu_105969_p1 = tmp_1701_reg_138886.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1180_fu_105969_p2() {
    mul_ln1118_1180_fu_105969_p2 = (!mul_ln1118_1180_fu_105969_p0.read().is_01() || !mul_ln1118_1180_fu_105969_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1180_fu_105969_p0.read()) * sc_bigint<2>(mul_ln1118_1180_fu_105969_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1181_fu_105990_p0() {
    mul_ln1118_1181_fu_105990_p0 =  (sc_lv<10>) (zext_ln1116_712_fu_104133_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1181_fu_105990_p1() {
    mul_ln1118_1181_fu_105990_p1 = tmp_1702_reg_138891.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1181_fu_105990_p2() {
    mul_ln1118_1181_fu_105990_p2 = (!mul_ln1118_1181_fu_105990_p0.read().is_01() || !mul_ln1118_1181_fu_105990_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1181_fu_105990_p0.read()) * sc_bigint<2>(mul_ln1118_1181_fu_105990_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1182_fu_106011_p0() {
    mul_ln1118_1182_fu_106011_p0 =  (sc_lv<10>) (zext_ln1116_713_fu_104157_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1182_fu_106011_p1() {
    mul_ln1118_1182_fu_106011_p1 = tmp_1703_reg_138896.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1182_fu_106011_p2() {
    mul_ln1118_1182_fu_106011_p2 = (!mul_ln1118_1182_fu_106011_p0.read().is_01() || !mul_ln1118_1182_fu_106011_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1182_fu_106011_p0.read()) * sc_bigint<2>(mul_ln1118_1182_fu_106011_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1183_fu_106020_p0() {
    mul_ln1118_1183_fu_106020_p0 =  (sc_lv<10>) (zext_ln1116_714_fu_104169_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1183_fu_106020_p1() {
    mul_ln1118_1183_fu_106020_p1 = tmp_1704_reg_138901.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1183_fu_106020_p2() {
    mul_ln1118_1183_fu_106020_p2 = (!mul_ln1118_1183_fu_106020_p0.read().is_01() || !mul_ln1118_1183_fu_106020_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1183_fu_106020_p0.read()) * sc_bigint<2>(mul_ln1118_1183_fu_106020_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1184_fu_106041_p0() {
    mul_ln1118_1184_fu_106041_p0 =  (sc_lv<10>) (zext_ln1116_715_fu_104193_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1184_fu_106041_p1() {
    mul_ln1118_1184_fu_106041_p1 = tmp_1705_reg_138906.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1184_fu_106041_p2() {
    mul_ln1118_1184_fu_106041_p2 = (!mul_ln1118_1184_fu_106041_p0.read().is_01() || !mul_ln1118_1184_fu_106041_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1184_fu_106041_p0.read()) * sc_bigint<2>(mul_ln1118_1184_fu_106041_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1185_fu_106062_p0() {
    mul_ln1118_1185_fu_106062_p0 =  (sc_lv<10>) (zext_ln1116_716_fu_104217_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1185_fu_106062_p1() {
    mul_ln1118_1185_fu_106062_p1 = tmp_1706_reg_138911.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1185_fu_106062_p2() {
    mul_ln1118_1185_fu_106062_p2 = (!mul_ln1118_1185_fu_106062_p0.read().is_01() || !mul_ln1118_1185_fu_106062_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1185_fu_106062_p0.read()) * sc_bigint<2>(mul_ln1118_1185_fu_106062_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1186_fu_106083_p0() {
    mul_ln1118_1186_fu_106083_p0 =  (sc_lv<10>) (zext_ln1116_717_fu_104241_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1186_fu_106083_p1() {
    mul_ln1118_1186_fu_106083_p1 = tmp_1707_reg_138916.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1186_fu_106083_p2() {
    mul_ln1118_1186_fu_106083_p2 = (!mul_ln1118_1186_fu_106083_p0.read().is_01() || !mul_ln1118_1186_fu_106083_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1186_fu_106083_p0.read()) * sc_bigint<2>(mul_ln1118_1186_fu_106083_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1187_fu_106104_p0() {
    mul_ln1118_1187_fu_106104_p0 =  (sc_lv<10>) (zext_ln1116_718_fu_104265_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1187_fu_106104_p1() {
    mul_ln1118_1187_fu_106104_p1 = tmp_1708_reg_138921.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1187_fu_106104_p2() {
    mul_ln1118_1187_fu_106104_p2 = (!mul_ln1118_1187_fu_106104_p0.read().is_01() || !mul_ln1118_1187_fu_106104_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1187_fu_106104_p0.read()) * sc_bigint<2>(mul_ln1118_1187_fu_106104_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1188_fu_106113_p0() {
    mul_ln1118_1188_fu_106113_p0 =  (sc_lv<10>) (zext_ln1116_719_fu_104277_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1188_fu_106113_p1() {
    mul_ln1118_1188_fu_106113_p1 = tmp_1709_reg_138926.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1188_fu_106113_p2() {
    mul_ln1118_1188_fu_106113_p2 = (!mul_ln1118_1188_fu_106113_p0.read().is_01() || !mul_ln1118_1188_fu_106113_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1188_fu_106113_p0.read()) * sc_bigint<2>(mul_ln1118_1188_fu_106113_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1189_fu_106134_p0() {
    mul_ln1118_1189_fu_106134_p0 =  (sc_lv<10>) (zext_ln1116_720_fu_104301_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1189_fu_106134_p1() {
    mul_ln1118_1189_fu_106134_p1 = tmp_1710_reg_138931.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1189_fu_106134_p2() {
    mul_ln1118_1189_fu_106134_p2 = (!mul_ln1118_1189_fu_106134_p0.read().is_01() || !mul_ln1118_1189_fu_106134_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1189_fu_106134_p0.read()) * sc_bigint<2>(mul_ln1118_1189_fu_106134_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_118_fu_82287_p0() {
    mul_ln1118_118_fu_82287_p0 =  (sc_lv<10>) (zext_ln1116_117_fu_82281_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_118_fu_82287_p1() {
    mul_ln1118_118_fu_82287_p1 = tmp_229_reg_130411.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_118_fu_82287_p2() {
    mul_ln1118_118_fu_82287_p2 = (!mul_ln1118_118_fu_82287_p0.read().is_01() || !mul_ln1118_118_fu_82287_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_118_fu_82287_p0.read()) * sc_bigint<2>(mul_ln1118_118_fu_82287_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1190_fu_106155_p0() {
    mul_ln1118_1190_fu_106155_p0 =  (sc_lv<10>) (zext_ln1116_721_fu_104325_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1190_fu_106155_p1() {
    mul_ln1118_1190_fu_106155_p1 = tmp_1711_reg_138936.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1190_fu_106155_p2() {
    mul_ln1118_1190_fu_106155_p2 = (!mul_ln1118_1190_fu_106155_p0.read().is_01() || !mul_ln1118_1190_fu_106155_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1190_fu_106155_p0.read()) * sc_bigint<2>(mul_ln1118_1190_fu_106155_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1191_fu_106176_p0() {
    mul_ln1118_1191_fu_106176_p0 =  (sc_lv<10>) (zext_ln1116_722_fu_104349_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1191_fu_106176_p1() {
    mul_ln1118_1191_fu_106176_p1 = tmp_1712_reg_138941.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1191_fu_106176_p2() {
    mul_ln1118_1191_fu_106176_p2 = (!mul_ln1118_1191_fu_106176_p0.read().is_01() || !mul_ln1118_1191_fu_106176_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1191_fu_106176_p0.read()) * sc_bigint<2>(mul_ln1118_1191_fu_106176_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1192_fu_106197_p0() {
    mul_ln1118_1192_fu_106197_p0 =  (sc_lv<10>) (zext_ln1116_723_fu_104373_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1192_fu_106197_p1() {
    mul_ln1118_1192_fu_106197_p1 = tmp_1713_reg_138946.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1192_fu_106197_p2() {
    mul_ln1118_1192_fu_106197_p2 = (!mul_ln1118_1192_fu_106197_p0.read().is_01() || !mul_ln1118_1192_fu_106197_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1192_fu_106197_p0.read()) * sc_bigint<2>(mul_ln1118_1192_fu_106197_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1193_fu_106206_p0() {
    mul_ln1118_1193_fu_106206_p0 =  (sc_lv<10>) (zext_ln1116_724_fu_104385_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1193_fu_106206_p1() {
    mul_ln1118_1193_fu_106206_p1 = tmp_1714_reg_138951.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1193_fu_106206_p2() {
    mul_ln1118_1193_fu_106206_p2 = (!mul_ln1118_1193_fu_106206_p0.read().is_01() || !mul_ln1118_1193_fu_106206_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1193_fu_106206_p0.read()) * sc_bigint<2>(mul_ln1118_1193_fu_106206_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1194_fu_106227_p0() {
    mul_ln1118_1194_fu_106227_p0 =  (sc_lv<10>) (zext_ln1116_725_fu_104409_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1194_fu_106227_p1() {
    mul_ln1118_1194_fu_106227_p1 = tmp_1715_reg_138956.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1194_fu_106227_p2() {
    mul_ln1118_1194_fu_106227_p2 = (!mul_ln1118_1194_fu_106227_p0.read().is_01() || !mul_ln1118_1194_fu_106227_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1194_fu_106227_p0.read()) * sc_bigint<2>(mul_ln1118_1194_fu_106227_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1195_fu_106248_p0() {
    mul_ln1118_1195_fu_106248_p0 =  (sc_lv<10>) (zext_ln1116_726_fu_104433_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1195_fu_106248_p1() {
    mul_ln1118_1195_fu_106248_p1 = tmp_1716_reg_138961.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1195_fu_106248_p2() {
    mul_ln1118_1195_fu_106248_p2 = (!mul_ln1118_1195_fu_106248_p0.read().is_01() || !mul_ln1118_1195_fu_106248_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1195_fu_106248_p0.read()) * sc_bigint<2>(mul_ln1118_1195_fu_106248_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1196_fu_106257_p0() {
    mul_ln1118_1196_fu_106257_p0 =  (sc_lv<10>) (zext_ln1116_727_fu_104445_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1196_fu_106257_p1() {
    mul_ln1118_1196_fu_106257_p1 = tmp_1717_reg_138966.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1196_fu_106257_p2() {
    mul_ln1118_1196_fu_106257_p2 = (!mul_ln1118_1196_fu_106257_p0.read().is_01() || !mul_ln1118_1196_fu_106257_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1196_fu_106257_p0.read()) * sc_bigint<2>(mul_ln1118_1196_fu_106257_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1197_fu_106278_p0() {
    mul_ln1118_1197_fu_106278_p0 =  (sc_lv<10>) (zext_ln1116_728_fu_104469_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1197_fu_106278_p1() {
    mul_ln1118_1197_fu_106278_p1 = tmp_1718_reg_138971.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1197_fu_106278_p2() {
    mul_ln1118_1197_fu_106278_p2 = (!mul_ln1118_1197_fu_106278_p0.read().is_01() || !mul_ln1118_1197_fu_106278_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1197_fu_106278_p0.read()) * sc_bigint<2>(mul_ln1118_1197_fu_106278_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1198_fu_106302_p0() {
    mul_ln1118_1198_fu_106302_p0 =  (sc_lv<10>) (mul_ln1118_1198_fu_106302_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1198_fu_106302_p00() {
    mul_ln1118_1198_fu_106302_p00 = esl_zext<12,10>(trunc_ln77_756_reg_138976.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1198_fu_106302_p1() {
    mul_ln1118_1198_fu_106302_p1 = tmp_1719_reg_138981.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1198_fu_106302_p2() {
    mul_ln1118_1198_fu_106302_p2 = (!mul_ln1118_1198_fu_106302_p0.read().is_01() || !mul_ln1118_1198_fu_106302_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1198_fu_106302_p0.read()) * sc_bigint<2>(mul_ln1118_1198_fu_106302_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1199_fu_106314_p0() {
    mul_ln1118_1199_fu_106314_p0 =  (sc_lv<10>) (mul_ln1118_1199_fu_106314_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1199_fu_106314_p00() {
    mul_ln1118_1199_fu_106314_p00 = esl_zext<12,10>(trunc_ln77_757_reg_138986.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1199_fu_106314_p1() {
    mul_ln1118_1199_fu_106314_p1 = tmp_1720_reg_138991.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1199_fu_106314_p2() {
    mul_ln1118_1199_fu_106314_p2 = (!mul_ln1118_1199_fu_106314_p0.read().is_01() || !mul_ln1118_1199_fu_106314_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1199_fu_106314_p0.read()) * sc_bigint<2>(mul_ln1118_1199_fu_106314_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_119_fu_82311_p0() {
    mul_ln1118_119_fu_82311_p0 =  (sc_lv<10>) (zext_ln1116_118_fu_82305_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_119_fu_82311_p1() {
    mul_ln1118_119_fu_82311_p1 = tmp_231_reg_130421.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_119_fu_82311_p2() {
    mul_ln1118_119_fu_82311_p2 = (!mul_ln1118_119_fu_82311_p0.read().is_01() || !mul_ln1118_119_fu_82311_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_119_fu_82311_p0.read()) * sc_bigint<2>(mul_ln1118_119_fu_82311_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_11_fu_79839_p0() {
    mul_ln1118_11_fu_79839_p0 =  (sc_lv<10>) (mul_ln1118_11_fu_79839_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_11_fu_79839_p00() {
    mul_ln1118_11_fu_79839_p00 = esl_zext<12,10>(trunc_ln77_8_reg_129341.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_11_fu_79839_p1() {
    mul_ln1118_11_fu_79839_p1 = tmp_15_reg_129346.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_11_fu_79839_p2() {
    mul_ln1118_11_fu_79839_p2 = (!mul_ln1118_11_fu_79839_p0.read().is_01() || !mul_ln1118_11_fu_79839_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_11_fu_79839_p0.read()) * sc_bigint<2>(mul_ln1118_11_fu_79839_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1200_fu_106338_p0() {
    mul_ln1118_1200_fu_106338_p0 =  (sc_lv<10>) (mul_ln1118_1200_fu_106338_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1200_fu_106338_p00() {
    mul_ln1118_1200_fu_106338_p00 = esl_zext<12,10>(trunc_ln77_758_reg_138996.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1200_fu_106338_p1() {
    mul_ln1118_1200_fu_106338_p1 = tmp_1721_reg_139001.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1200_fu_106338_p2() {
    mul_ln1118_1200_fu_106338_p2 = (!mul_ln1118_1200_fu_106338_p0.read().is_01() || !mul_ln1118_1200_fu_106338_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1200_fu_106338_p0.read()) * sc_bigint<2>(mul_ln1118_1200_fu_106338_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1201_fu_106362_p0() {
    mul_ln1118_1201_fu_106362_p0 =  (sc_lv<10>) (mul_ln1118_1201_fu_106362_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1201_fu_106362_p00() {
    mul_ln1118_1201_fu_106362_p00 = esl_zext<12,10>(trunc_ln77_759_reg_139006.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1201_fu_106362_p1() {
    mul_ln1118_1201_fu_106362_p1 = tmp_1723_reg_139011.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1201_fu_106362_p2() {
    mul_ln1118_1201_fu_106362_p2 = (!mul_ln1118_1201_fu_106362_p0.read().is_01() || !mul_ln1118_1201_fu_106362_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1201_fu_106362_p0.read()) * sc_bigint<2>(mul_ln1118_1201_fu_106362_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1202_fu_106386_p0() {
    mul_ln1118_1202_fu_106386_p0 =  (sc_lv<10>) (mul_ln1118_1202_fu_106386_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1202_fu_106386_p00() {
    mul_ln1118_1202_fu_106386_p00 = esl_zext<12,10>(trunc_ln77_760_reg_139016.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1202_fu_106386_p1() {
    mul_ln1118_1202_fu_106386_p1 = tmp_1725_reg_139021.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1202_fu_106386_p2() {
    mul_ln1118_1202_fu_106386_p2 = (!mul_ln1118_1202_fu_106386_p0.read().is_01() || !mul_ln1118_1202_fu_106386_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1202_fu_106386_p0.read()) * sc_bigint<2>(mul_ln1118_1202_fu_106386_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1203_fu_106410_p0() {
    mul_ln1118_1203_fu_106410_p0 =  (sc_lv<10>) (mul_ln1118_1203_fu_106410_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1203_fu_106410_p00() {
    mul_ln1118_1203_fu_106410_p00 = esl_zext<12,10>(trunc_ln77_761_reg_139026.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1203_fu_106410_p1() {
    mul_ln1118_1203_fu_106410_p1 = tmp_1727_reg_139031.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1203_fu_106410_p2() {
    mul_ln1118_1203_fu_106410_p2 = (!mul_ln1118_1203_fu_106410_p0.read().is_01() || !mul_ln1118_1203_fu_106410_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1203_fu_106410_p0.read()) * sc_bigint<2>(mul_ln1118_1203_fu_106410_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1204_fu_106422_p0() {
    mul_ln1118_1204_fu_106422_p0 =  (sc_lv<10>) (mul_ln1118_1204_fu_106422_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1204_fu_106422_p00() {
    mul_ln1118_1204_fu_106422_p00 = esl_zext<12,10>(trunc_ln77_762_reg_139036.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1204_fu_106422_p1() {
    mul_ln1118_1204_fu_106422_p1 = tmp_1729_reg_139041.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1204_fu_106422_p2() {
    mul_ln1118_1204_fu_106422_p2 = (!mul_ln1118_1204_fu_106422_p0.read().is_01() || !mul_ln1118_1204_fu_106422_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1204_fu_106422_p0.read()) * sc_bigint<2>(mul_ln1118_1204_fu_106422_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1205_fu_106446_p0() {
    mul_ln1118_1205_fu_106446_p0 =  (sc_lv<10>) (mul_ln1118_1205_fu_106446_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1205_fu_106446_p00() {
    mul_ln1118_1205_fu_106446_p00 = esl_zext<12,10>(trunc_ln77_763_reg_139046.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1205_fu_106446_p1() {
    mul_ln1118_1205_fu_106446_p1 = tmp_1731_reg_139051.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1205_fu_106446_p2() {
    mul_ln1118_1205_fu_106446_p2 = (!mul_ln1118_1205_fu_106446_p0.read().is_01() || !mul_ln1118_1205_fu_106446_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1205_fu_106446_p0.read()) * sc_bigint<2>(mul_ln1118_1205_fu_106446_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1206_fu_106470_p0() {
    mul_ln1118_1206_fu_106470_p0 =  (sc_lv<10>) (mul_ln1118_1206_fu_106470_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1206_fu_106470_p00() {
    mul_ln1118_1206_fu_106470_p00 = esl_zext<12,10>(trunc_ln77_764_reg_139056.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1206_fu_106470_p1() {
    mul_ln1118_1206_fu_106470_p1 = tmp_1733_reg_139061.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1206_fu_106470_p2() {
    mul_ln1118_1206_fu_106470_p2 = (!mul_ln1118_1206_fu_106470_p0.read().is_01() || !mul_ln1118_1206_fu_106470_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1206_fu_106470_p0.read()) * sc_bigint<2>(mul_ln1118_1206_fu_106470_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1207_fu_106494_p0() {
    mul_ln1118_1207_fu_106494_p0 =  (sc_lv<10>) (mul_ln1118_1207_fu_106494_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1207_fu_106494_p00() {
    mul_ln1118_1207_fu_106494_p00 = esl_zext<12,10>(trunc_ln77_765_reg_139066.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1207_fu_106494_p1() {
    mul_ln1118_1207_fu_106494_p1 = tmp_1735_reg_139071.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1207_fu_106494_p2() {
    mul_ln1118_1207_fu_106494_p2 = (!mul_ln1118_1207_fu_106494_p0.read().is_01() || !mul_ln1118_1207_fu_106494_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1207_fu_106494_p0.read()) * sc_bigint<2>(mul_ln1118_1207_fu_106494_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1208_fu_106518_p0() {
    mul_ln1118_1208_fu_106518_p0 =  (sc_lv<10>) (mul_ln1118_1208_fu_106518_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1208_fu_106518_p00() {
    mul_ln1118_1208_fu_106518_p00 = esl_zext<12,10>(trunc_ln77_766_reg_139076.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1208_fu_106518_p1() {
    mul_ln1118_1208_fu_106518_p1 = tmp_1737_reg_139081.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1208_fu_106518_p2() {
    mul_ln1118_1208_fu_106518_p2 = (!mul_ln1118_1208_fu_106518_p0.read().is_01() || !mul_ln1118_1208_fu_106518_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1208_fu_106518_p0.read()) * sc_bigint<2>(mul_ln1118_1208_fu_106518_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1209_fu_106530_p0() {
    mul_ln1118_1209_fu_106530_p0 =  (sc_lv<10>) (mul_ln1118_1209_fu_106530_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1209_fu_106530_p00() {
    mul_ln1118_1209_fu_106530_p00 = esl_zext<12,10>(trunc_ln77_767_reg_139086.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1209_fu_106530_p1() {
    mul_ln1118_1209_fu_106530_p1 = tmp_1739_reg_139091.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1209_fu_106530_p2() {
    mul_ln1118_1209_fu_106530_p2 = (!mul_ln1118_1209_fu_106530_p0.read().is_01() || !mul_ln1118_1209_fu_106530_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1209_fu_106530_p0.read()) * sc_bigint<2>(mul_ln1118_1209_fu_106530_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_120_fu_82335_p0() {
    mul_ln1118_120_fu_82335_p0 =  (sc_lv<10>) (zext_ln1116_119_fu_82329_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_120_fu_82335_p1() {
    mul_ln1118_120_fu_82335_p1 = tmp_233_reg_130431.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_120_fu_82335_p2() {
    mul_ln1118_120_fu_82335_p2 = (!mul_ln1118_120_fu_82335_p0.read().is_01() || !mul_ln1118_120_fu_82335_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_120_fu_82335_p0.read()) * sc_bigint<2>(mul_ln1118_120_fu_82335_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1210_fu_106554_p0() {
    mul_ln1118_1210_fu_106554_p0 =  (sc_lv<10>) (mul_ln1118_1210_fu_106554_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1210_fu_106554_p00() {
    mul_ln1118_1210_fu_106554_p00 = esl_zext<12,10>(trunc_ln77_768_reg_139096.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1210_fu_106554_p1() {
    mul_ln1118_1210_fu_106554_p1 = tmp_1741_reg_139101.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1210_fu_106554_p2() {
    mul_ln1118_1210_fu_106554_p2 = (!mul_ln1118_1210_fu_106554_p0.read().is_01() || !mul_ln1118_1210_fu_106554_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1210_fu_106554_p0.read()) * sc_bigint<2>(mul_ln1118_1210_fu_106554_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1211_fu_106578_p0() {
    mul_ln1118_1211_fu_106578_p0 =  (sc_lv<10>) (mul_ln1118_1211_fu_106578_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1211_fu_106578_p00() {
    mul_ln1118_1211_fu_106578_p00 = esl_zext<12,10>(trunc_ln77_769_reg_139106.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1211_fu_106578_p1() {
    mul_ln1118_1211_fu_106578_p1 = tmp_1743_reg_139111.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1211_fu_106578_p2() {
    mul_ln1118_1211_fu_106578_p2 = (!mul_ln1118_1211_fu_106578_p0.read().is_01() || !mul_ln1118_1211_fu_106578_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1211_fu_106578_p0.read()) * sc_bigint<2>(mul_ln1118_1211_fu_106578_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1212_fu_106602_p0() {
    mul_ln1118_1212_fu_106602_p0 =  (sc_lv<10>) (mul_ln1118_1212_fu_106602_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1212_fu_106602_p00() {
    mul_ln1118_1212_fu_106602_p00 = esl_zext<12,10>(trunc_ln77_770_reg_139116.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1212_fu_106602_p1() {
    mul_ln1118_1212_fu_106602_p1 = tmp_1745_reg_139121.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1212_fu_106602_p2() {
    mul_ln1118_1212_fu_106602_p2 = (!mul_ln1118_1212_fu_106602_p0.read().is_01() || !mul_ln1118_1212_fu_106602_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1212_fu_106602_p0.read()) * sc_bigint<2>(mul_ln1118_1212_fu_106602_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1213_fu_106626_p0() {
    mul_ln1118_1213_fu_106626_p0 =  (sc_lv<10>) (mul_ln1118_1213_fu_106626_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1213_fu_106626_p00() {
    mul_ln1118_1213_fu_106626_p00 = esl_zext<12,10>(trunc_ln77_771_reg_139126.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1213_fu_106626_p1() {
    mul_ln1118_1213_fu_106626_p1 = tmp_1747_reg_139131.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1213_fu_106626_p2() {
    mul_ln1118_1213_fu_106626_p2 = (!mul_ln1118_1213_fu_106626_p0.read().is_01() || !mul_ln1118_1213_fu_106626_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1213_fu_106626_p0.read()) * sc_bigint<2>(mul_ln1118_1213_fu_106626_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1214_fu_106638_p0() {
    mul_ln1118_1214_fu_106638_p0 =  (sc_lv<10>) (mul_ln1118_1214_fu_106638_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1214_fu_106638_p00() {
    mul_ln1118_1214_fu_106638_p00 = esl_zext<12,10>(trunc_ln77_772_reg_139136.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1214_fu_106638_p1() {
    mul_ln1118_1214_fu_106638_p1 = tmp_1748_reg_139141.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1214_fu_106638_p2() {
    mul_ln1118_1214_fu_106638_p2 = (!mul_ln1118_1214_fu_106638_p0.read().is_01() || !mul_ln1118_1214_fu_106638_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1214_fu_106638_p0.read()) * sc_bigint<2>(mul_ln1118_1214_fu_106638_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1215_fu_106662_p0() {
    mul_ln1118_1215_fu_106662_p0 =  (sc_lv<10>) (mul_ln1118_1215_fu_106662_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1215_fu_106662_p00() {
    mul_ln1118_1215_fu_106662_p00 = esl_zext<12,10>(trunc_ln77_773_reg_139146.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1215_fu_106662_p1() {
    mul_ln1118_1215_fu_106662_p1 = tmp_1749_reg_139151.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1215_fu_106662_p2() {
    mul_ln1118_1215_fu_106662_p2 = (!mul_ln1118_1215_fu_106662_p0.read().is_01() || !mul_ln1118_1215_fu_106662_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1215_fu_106662_p0.read()) * sc_bigint<2>(mul_ln1118_1215_fu_106662_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1216_fu_106686_p0() {
    mul_ln1118_1216_fu_106686_p0 =  (sc_lv<10>) (mul_ln1118_1216_fu_106686_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1216_fu_106686_p00() {
    mul_ln1118_1216_fu_106686_p00 = esl_zext<12,10>(trunc_ln77_774_reg_139156.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1216_fu_106686_p1() {
    mul_ln1118_1216_fu_106686_p1 = tmp_1750_reg_139161.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1216_fu_106686_p2() {
    mul_ln1118_1216_fu_106686_p2 = (!mul_ln1118_1216_fu_106686_p0.read().is_01() || !mul_ln1118_1216_fu_106686_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1216_fu_106686_p0.read()) * sc_bigint<2>(mul_ln1118_1216_fu_106686_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1217_fu_106698_p0() {
    mul_ln1118_1217_fu_106698_p0 =  (sc_lv<10>) (mul_ln1118_1217_fu_106698_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1217_fu_106698_p00() {
    mul_ln1118_1217_fu_106698_p00 = esl_zext<12,10>(trunc_ln77_775_reg_139166.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1217_fu_106698_p1() {
    mul_ln1118_1217_fu_106698_p1 = tmp_1751_reg_139171.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1217_fu_106698_p2() {
    mul_ln1118_1217_fu_106698_p2 = (!mul_ln1118_1217_fu_106698_p0.read().is_01() || !mul_ln1118_1217_fu_106698_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1217_fu_106698_p0.read()) * sc_bigint<2>(mul_ln1118_1217_fu_106698_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1218_fu_106722_p0() {
    mul_ln1118_1218_fu_106722_p0 =  (sc_lv<10>) (mul_ln1118_1218_fu_106722_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1218_fu_106722_p00() {
    mul_ln1118_1218_fu_106722_p00 = esl_zext<12,10>(trunc_ln77_776_reg_139176.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1218_fu_106722_p1() {
    mul_ln1118_1218_fu_106722_p1 = tmp_1752_reg_139181.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1218_fu_106722_p2() {
    mul_ln1118_1218_fu_106722_p2 = (!mul_ln1118_1218_fu_106722_p0.read().is_01() || !mul_ln1118_1218_fu_106722_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1218_fu_106722_p0.read()) * sc_bigint<2>(mul_ln1118_1218_fu_106722_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1219_fu_106746_p0() {
    mul_ln1118_1219_fu_106746_p0 =  (sc_lv<10>) (mul_ln1118_1219_fu_106746_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1219_fu_106746_p00() {
    mul_ln1118_1219_fu_106746_p00 = esl_zext<12,10>(trunc_ln77_777_reg_139186.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1219_fu_106746_p1() {
    mul_ln1118_1219_fu_106746_p1 = tmp_1753_reg_139191.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1219_fu_106746_p2() {
    mul_ln1118_1219_fu_106746_p2 = (!mul_ln1118_1219_fu_106746_p0.read().is_01() || !mul_ln1118_1219_fu_106746_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1219_fu_106746_p0.read()) * sc_bigint<2>(mul_ln1118_1219_fu_106746_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_121_fu_82359_p0() {
    mul_ln1118_121_fu_82359_p0 =  (sc_lv<10>) (zext_ln1116_120_fu_82353_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_121_fu_82359_p1() {
    mul_ln1118_121_fu_82359_p1 = tmp_235_reg_130441.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_121_fu_82359_p2() {
    mul_ln1118_121_fu_82359_p2 = (!mul_ln1118_121_fu_82359_p0.read().is_01() || !mul_ln1118_121_fu_82359_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_121_fu_82359_p0.read()) * sc_bigint<2>(mul_ln1118_121_fu_82359_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1220_fu_106758_p0() {
    mul_ln1118_1220_fu_106758_p0 =  (sc_lv<10>) (mul_ln1118_1220_fu_106758_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1220_fu_106758_p00() {
    mul_ln1118_1220_fu_106758_p00 = esl_zext<12,10>(trunc_ln77_778_reg_139196.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1220_fu_106758_p1() {
    mul_ln1118_1220_fu_106758_p1 = tmp_1754_reg_139201.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1220_fu_106758_p2() {
    mul_ln1118_1220_fu_106758_p2 = (!mul_ln1118_1220_fu_106758_p0.read().is_01() || !mul_ln1118_1220_fu_106758_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1220_fu_106758_p0.read()) * sc_bigint<2>(mul_ln1118_1220_fu_106758_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1221_fu_106782_p0() {
    mul_ln1118_1221_fu_106782_p0 =  (sc_lv<10>) (mul_ln1118_1221_fu_106782_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1221_fu_106782_p00() {
    mul_ln1118_1221_fu_106782_p00 = esl_zext<12,10>(trunc_ln77_779_reg_139206.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1221_fu_106782_p1() {
    mul_ln1118_1221_fu_106782_p1 = tmp_1755_reg_139211.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1221_fu_106782_p2() {
    mul_ln1118_1221_fu_106782_p2 = (!mul_ln1118_1221_fu_106782_p0.read().is_01() || !mul_ln1118_1221_fu_106782_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1221_fu_106782_p0.read()) * sc_bigint<2>(mul_ln1118_1221_fu_106782_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1222_fu_106806_p0() {
    mul_ln1118_1222_fu_106806_p0 =  (sc_lv<10>) (mul_ln1118_1222_fu_106806_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1222_fu_106806_p00() {
    mul_ln1118_1222_fu_106806_p00 = esl_zext<12,10>(trunc_ln77_780_reg_139216.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1222_fu_106806_p1() {
    mul_ln1118_1222_fu_106806_p1 = tmp_1757_reg_139221.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1222_fu_106806_p2() {
    mul_ln1118_1222_fu_106806_p2 = (!mul_ln1118_1222_fu_106806_p0.read().is_01() || !mul_ln1118_1222_fu_106806_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1222_fu_106806_p0.read()) * sc_bigint<2>(mul_ln1118_1222_fu_106806_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1223_fu_106830_p0() {
    mul_ln1118_1223_fu_106830_p0 =  (sc_lv<10>) (mul_ln1118_1223_fu_106830_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1223_fu_106830_p00() {
    mul_ln1118_1223_fu_106830_p00 = esl_zext<12,10>(trunc_ln77_781_reg_139226.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1223_fu_106830_p1() {
    mul_ln1118_1223_fu_106830_p1 = tmp_1759_reg_139231.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1223_fu_106830_p2() {
    mul_ln1118_1223_fu_106830_p2 = (!mul_ln1118_1223_fu_106830_p0.read().is_01() || !mul_ln1118_1223_fu_106830_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1223_fu_106830_p0.read()) * sc_bigint<2>(mul_ln1118_1223_fu_106830_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1224_fu_106854_p0() {
    mul_ln1118_1224_fu_106854_p0 =  (sc_lv<10>) (mul_ln1118_1224_fu_106854_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1224_fu_106854_p00() {
    mul_ln1118_1224_fu_106854_p00 = esl_zext<12,10>(trunc_ln77_782_reg_139236.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1224_fu_106854_p1() {
    mul_ln1118_1224_fu_106854_p1 = tmp_1761_reg_139241.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1224_fu_106854_p2() {
    mul_ln1118_1224_fu_106854_p2 = (!mul_ln1118_1224_fu_106854_p0.read().is_01() || !mul_ln1118_1224_fu_106854_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1224_fu_106854_p0.read()) * sc_bigint<2>(mul_ln1118_1224_fu_106854_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1225_fu_106866_p0() {
    mul_ln1118_1225_fu_106866_p0 =  (sc_lv<10>) (mul_ln1118_1225_fu_106866_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1225_fu_106866_p00() {
    mul_ln1118_1225_fu_106866_p00 = esl_zext<12,10>(trunc_ln77_783_reg_139246.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1225_fu_106866_p1() {
    mul_ln1118_1225_fu_106866_p1 = tmp_1763_reg_139251.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1225_fu_106866_p2() {
    mul_ln1118_1225_fu_106866_p2 = (!mul_ln1118_1225_fu_106866_p0.read().is_01() || !mul_ln1118_1225_fu_106866_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1225_fu_106866_p0.read()) * sc_bigint<2>(mul_ln1118_1225_fu_106866_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1226_fu_106890_p0() {
    mul_ln1118_1226_fu_106890_p0 =  (sc_lv<10>) (mul_ln1118_1226_fu_106890_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1226_fu_106890_p00() {
    mul_ln1118_1226_fu_106890_p00 = esl_zext<12,10>(trunc_ln77_784_reg_139256.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1226_fu_106890_p1() {
    mul_ln1118_1226_fu_106890_p1 = tmp_1765_reg_139261.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1226_fu_106890_p2() {
    mul_ln1118_1226_fu_106890_p2 = (!mul_ln1118_1226_fu_106890_p0.read().is_01() || !mul_ln1118_1226_fu_106890_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1226_fu_106890_p0.read()) * sc_bigint<2>(mul_ln1118_1226_fu_106890_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1227_fu_106914_p0() {
    mul_ln1118_1227_fu_106914_p0 =  (sc_lv<10>) (mul_ln1118_1227_fu_106914_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1227_fu_106914_p00() {
    mul_ln1118_1227_fu_106914_p00 = esl_zext<12,10>(trunc_ln77_785_reg_139266.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1227_fu_106914_p1() {
    mul_ln1118_1227_fu_106914_p1 = tmp_1767_reg_139271.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1227_fu_106914_p2() {
    mul_ln1118_1227_fu_106914_p2 = (!mul_ln1118_1227_fu_106914_p0.read().is_01() || !mul_ln1118_1227_fu_106914_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1227_fu_106914_p0.read()) * sc_bigint<2>(mul_ln1118_1227_fu_106914_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1228_fu_106938_p0() {
    mul_ln1118_1228_fu_106938_p0 =  (sc_lv<10>) (mul_ln1118_1228_fu_106938_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1228_fu_106938_p00() {
    mul_ln1118_1228_fu_106938_p00 = esl_zext<12,10>(trunc_ln77_786_reg_139276.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1228_fu_106938_p1() {
    mul_ln1118_1228_fu_106938_p1 = tmp_1769_reg_139281.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1228_fu_106938_p2() {
    mul_ln1118_1228_fu_106938_p2 = (!mul_ln1118_1228_fu_106938_p0.read().is_01() || !mul_ln1118_1228_fu_106938_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1228_fu_106938_p0.read()) * sc_bigint<2>(mul_ln1118_1228_fu_106938_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1229_fu_106962_p0() {
    mul_ln1118_1229_fu_106962_p0 =  (sc_lv<10>) (mul_ln1118_1229_fu_106962_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1229_fu_106962_p00() {
    mul_ln1118_1229_fu_106962_p00 = esl_zext<12,10>(trunc_ln77_787_reg_139286.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1229_fu_106962_p1() {
    mul_ln1118_1229_fu_106962_p1 = tmp_1771_reg_139291.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1229_fu_106962_p2() {
    mul_ln1118_1229_fu_106962_p2 = (!mul_ln1118_1229_fu_106962_p0.read().is_01() || !mul_ln1118_1229_fu_106962_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_1229_fu_106962_p0.read()) * sc_bigint<2>(mul_ln1118_1229_fu_106962_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_122_fu_82371_p0() {
    mul_ln1118_122_fu_82371_p0 =  (sc_lv<10>) (zext_ln1116_121_fu_82365_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_122_fu_82371_p1() {
    mul_ln1118_122_fu_82371_p1 = tmp_237_reg_130451.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_122_fu_82371_p2() {
    mul_ln1118_122_fu_82371_p2 = (!mul_ln1118_122_fu_82371_p0.read().is_01() || !mul_ln1118_122_fu_82371_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_122_fu_82371_p0.read()) * sc_bigint<2>(mul_ln1118_122_fu_82371_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_1230_fu_106974_p0() {
    mul_ln1118_1230_fu_106974_p0 =  (sc_lv<10>) (mul_ln1118_1230_fu_106974_p00.read());
}

}


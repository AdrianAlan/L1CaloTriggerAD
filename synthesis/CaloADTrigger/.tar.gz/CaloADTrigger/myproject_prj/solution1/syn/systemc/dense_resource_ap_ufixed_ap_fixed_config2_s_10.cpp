#include "dense_resource_ap_ufixed_ap_fixed_config2_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_636_fu_93753_p1() {
    mul_ln1118_636_fu_93753_p1 = tmp_945_reg_134506.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_636_fu_93753_p2() {
    mul_ln1118_636_fu_93753_p2 = (!mul_ln1118_636_fu_93753_p0.read().is_01() || !mul_ln1118_636_fu_93753_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_636_fu_93753_p0.read()) * sc_bigint<2>(mul_ln1118_636_fu_93753_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_637_fu_93762_p0() {
    mul_ln1118_637_fu_93762_p0 =  (sc_lv<10>) (zext_ln1116_388_fu_91941_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_637_fu_93762_p1() {
    mul_ln1118_637_fu_93762_p1 = tmp_946_reg_134511.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_637_fu_93762_p2() {
    mul_ln1118_637_fu_93762_p2 = (!mul_ln1118_637_fu_93762_p0.read().is_01() || !mul_ln1118_637_fu_93762_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_637_fu_93762_p0.read()) * sc_bigint<2>(mul_ln1118_637_fu_93762_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_638_fu_93783_p0() {
    mul_ln1118_638_fu_93783_p0 =  (sc_lv<10>) (zext_ln1116_389_fu_91965_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_638_fu_93783_p1() {
    mul_ln1118_638_fu_93783_p1 = tmp_947_reg_134516.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_638_fu_93783_p2() {
    mul_ln1118_638_fu_93783_p2 = (!mul_ln1118_638_fu_93783_p0.read().is_01() || !mul_ln1118_638_fu_93783_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_638_fu_93783_p0.read()) * sc_bigint<2>(mul_ln1118_638_fu_93783_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_639_fu_93804_p0() {
    mul_ln1118_639_fu_93804_p0 =  (sc_lv<10>) (zext_ln1116_390_fu_91989_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_639_fu_93804_p1() {
    mul_ln1118_639_fu_93804_p1 = tmp_948_reg_134521.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_639_fu_93804_p2() {
    mul_ln1118_639_fu_93804_p2 = (!mul_ln1118_639_fu_93804_p0.read().is_01() || !mul_ln1118_639_fu_93804_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_639_fu_93804_p0.read()) * sc_bigint<2>(mul_ln1118_639_fu_93804_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_63_fu_80931_p0() {
    mul_ln1118_63_fu_80931_p0 =  (sc_lv<10>) (mul_ln1118_63_fu_80931_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_63_fu_80931_p00() {
    mul_ln1118_63_fu_80931_p00 = esl_zext<12,10>(trunc_ln77_60_reg_129861.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_63_fu_80931_p1() {
    mul_ln1118_63_fu_80931_p1 = tmp_119_reg_129866.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_63_fu_80931_p2() {
    mul_ln1118_63_fu_80931_p2 = (!mul_ln1118_63_fu_80931_p0.read().is_01() || !mul_ln1118_63_fu_80931_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_63_fu_80931_p0.read()) * sc_bigint<2>(mul_ln1118_63_fu_80931_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_640_fu_93825_p0() {
    mul_ln1118_640_fu_93825_p0 =  (sc_lv<10>) (zext_ln1116_391_fu_92013_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_640_fu_93825_p1() {
    mul_ln1118_640_fu_93825_p1 = tmp_949_reg_134526.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_640_fu_93825_p2() {
    mul_ln1118_640_fu_93825_p2 = (!mul_ln1118_640_fu_93825_p0.read().is_01() || !mul_ln1118_640_fu_93825_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_640_fu_93825_p0.read()) * sc_bigint<2>(mul_ln1118_640_fu_93825_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_641_fu_93846_p0() {
    mul_ln1118_641_fu_93846_p0 =  (sc_lv<10>) (zext_ln1116_392_fu_92037_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_641_fu_93846_p1() {
    mul_ln1118_641_fu_93846_p1 = tmp_950_reg_134531.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_641_fu_93846_p2() {
    mul_ln1118_641_fu_93846_p2 = (!mul_ln1118_641_fu_93846_p0.read().is_01() || !mul_ln1118_641_fu_93846_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_641_fu_93846_p0.read()) * sc_bigint<2>(mul_ln1118_641_fu_93846_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_642_fu_93858_p0() {
    mul_ln1118_642_fu_93858_p0 =  (sc_lv<10>) (zext_ln1116_422_fu_93852_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_642_fu_93858_p1() {
    mul_ln1118_642_fu_93858_p1 = tmp_952_reg_134541.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_642_fu_93858_p2() {
    mul_ln1118_642_fu_93858_p2 = (!mul_ln1118_642_fu_93858_p0.read().is_01() || !mul_ln1118_642_fu_93858_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_642_fu_93858_p0.read()) * sc_bigint<2>(mul_ln1118_642_fu_93858_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_643_fu_93882_p0() {
    mul_ln1118_643_fu_93882_p0 =  (sc_lv<10>) (zext_ln1116_423_fu_93876_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_643_fu_93882_p1() {
    mul_ln1118_643_fu_93882_p1 = tmp_954_reg_134551.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_643_fu_93882_p2() {
    mul_ln1118_643_fu_93882_p2 = (!mul_ln1118_643_fu_93882_p0.read().is_01() || !mul_ln1118_643_fu_93882_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_643_fu_93882_p0.read()) * sc_bigint<2>(mul_ln1118_643_fu_93882_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_644_fu_93906_p0() {
    mul_ln1118_644_fu_93906_p0 =  (sc_lv<10>) (zext_ln1116_424_fu_93900_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_644_fu_93906_p1() {
    mul_ln1118_644_fu_93906_p1 = tmp_956_reg_134561.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_644_fu_93906_p2() {
    mul_ln1118_644_fu_93906_p2 = (!mul_ln1118_644_fu_93906_p0.read().is_01() || !mul_ln1118_644_fu_93906_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_644_fu_93906_p0.read()) * sc_bigint<2>(mul_ln1118_644_fu_93906_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_645_fu_93930_p0() {
    mul_ln1118_645_fu_93930_p0 =  (sc_lv<10>) (zext_ln1116_425_fu_93924_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_645_fu_93930_p1() {
    mul_ln1118_645_fu_93930_p1 = tmp_958_reg_134571.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_645_fu_93930_p2() {
    mul_ln1118_645_fu_93930_p2 = (!mul_ln1118_645_fu_93930_p0.read().is_01() || !mul_ln1118_645_fu_93930_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_645_fu_93930_p0.read()) * sc_bigint<2>(mul_ln1118_645_fu_93930_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_646_fu_93954_p0() {
    mul_ln1118_646_fu_93954_p0 =  (sc_lv<10>) (zext_ln1116_426_fu_93948_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_646_fu_93954_p1() {
    mul_ln1118_646_fu_93954_p1 = tmp_960_reg_134581.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_646_fu_93954_p2() {
    mul_ln1118_646_fu_93954_p2 = (!mul_ln1118_646_fu_93954_p0.read().is_01() || !mul_ln1118_646_fu_93954_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_646_fu_93954_p0.read()) * sc_bigint<2>(mul_ln1118_646_fu_93954_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_647_fu_93966_p0() {
    mul_ln1118_647_fu_93966_p0 =  (sc_lv<10>) (zext_ln1116_427_fu_93960_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_647_fu_93966_p1() {
    mul_ln1118_647_fu_93966_p1 = tmp_962_reg_134591.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_647_fu_93966_p2() {
    mul_ln1118_647_fu_93966_p2 = (!mul_ln1118_647_fu_93966_p0.read().is_01() || !mul_ln1118_647_fu_93966_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_647_fu_93966_p0.read()) * sc_bigint<2>(mul_ln1118_647_fu_93966_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_648_fu_93990_p0() {
    mul_ln1118_648_fu_93990_p0 =  (sc_lv<10>) (zext_ln1116_428_fu_93984_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_648_fu_93990_p1() {
    mul_ln1118_648_fu_93990_p1 = tmp_964_reg_134601.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_648_fu_93990_p2() {
    mul_ln1118_648_fu_93990_p2 = (!mul_ln1118_648_fu_93990_p0.read().is_01() || !mul_ln1118_648_fu_93990_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_648_fu_93990_p0.read()) * sc_bigint<2>(mul_ln1118_648_fu_93990_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_649_fu_94014_p0() {
    mul_ln1118_649_fu_94014_p0 =  (sc_lv<10>) (zext_ln1116_429_fu_94008_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_649_fu_94014_p1() {
    mul_ln1118_649_fu_94014_p1 = tmp_966_reg_134611.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_649_fu_94014_p2() {
    mul_ln1118_649_fu_94014_p2 = (!mul_ln1118_649_fu_94014_p0.read().is_01() || !mul_ln1118_649_fu_94014_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_649_fu_94014_p0.read()) * sc_bigint<2>(mul_ln1118_649_fu_94014_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_64_fu_80955_p0() {
    mul_ln1118_64_fu_80955_p0 =  (sc_lv<10>) (mul_ln1118_64_fu_80955_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_64_fu_80955_p00() {
    mul_ln1118_64_fu_80955_p00 = esl_zext<12,10>(trunc_ln77_61_reg_129871.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_64_fu_80955_p1() {
    mul_ln1118_64_fu_80955_p1 = tmp_121_reg_129876.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_64_fu_80955_p2() {
    mul_ln1118_64_fu_80955_p2 = (!mul_ln1118_64_fu_80955_p0.read().is_01() || !mul_ln1118_64_fu_80955_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_64_fu_80955_p0.read()) * sc_bigint<2>(mul_ln1118_64_fu_80955_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_650_fu_94026_p0() {
    mul_ln1118_650_fu_94026_p0 =  (sc_lv<10>) (zext_ln1116_430_fu_94020_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_650_fu_94026_p1() {
    mul_ln1118_650_fu_94026_p1 = tmp_968_reg_134621.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_650_fu_94026_p2() {
    mul_ln1118_650_fu_94026_p2 = (!mul_ln1118_650_fu_94026_p0.read().is_01() || !mul_ln1118_650_fu_94026_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_650_fu_94026_p0.read()) * sc_bigint<2>(mul_ln1118_650_fu_94026_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_651_fu_94050_p0() {
    mul_ln1118_651_fu_94050_p0 =  (sc_lv<10>) (zext_ln1116_431_fu_94044_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_651_fu_94050_p1() {
    mul_ln1118_651_fu_94050_p1 = tmp_970_reg_134631.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_651_fu_94050_p2() {
    mul_ln1118_651_fu_94050_p2 = (!mul_ln1118_651_fu_94050_p0.read().is_01() || !mul_ln1118_651_fu_94050_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_651_fu_94050_p0.read()) * sc_bigint<2>(mul_ln1118_651_fu_94050_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_652_fu_94074_p0() {
    mul_ln1118_652_fu_94074_p0 =  (sc_lv<10>) (zext_ln1116_432_fu_94068_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_652_fu_94074_p1() {
    mul_ln1118_652_fu_94074_p1 = tmp_972_reg_134641.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_652_fu_94074_p2() {
    mul_ln1118_652_fu_94074_p2 = (!mul_ln1118_652_fu_94074_p0.read().is_01() || !mul_ln1118_652_fu_94074_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_652_fu_94074_p0.read()) * sc_bigint<2>(mul_ln1118_652_fu_94074_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_653_fu_94086_p0() {
    mul_ln1118_653_fu_94086_p0 =  (sc_lv<10>) (zext_ln1116_433_fu_94080_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_653_fu_94086_p1() {
    mul_ln1118_653_fu_94086_p1 = tmp_974_reg_134651.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_653_fu_94086_p2() {
    mul_ln1118_653_fu_94086_p2 = (!mul_ln1118_653_fu_94086_p0.read().is_01() || !mul_ln1118_653_fu_94086_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_653_fu_94086_p0.read()) * sc_bigint<2>(mul_ln1118_653_fu_94086_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_654_fu_94110_p0() {
    mul_ln1118_654_fu_94110_p0 =  (sc_lv<10>) (zext_ln1116_434_fu_94104_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_654_fu_94110_p1() {
    mul_ln1118_654_fu_94110_p1 = tmp_976_reg_134661.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_654_fu_94110_p2() {
    mul_ln1118_654_fu_94110_p2 = (!mul_ln1118_654_fu_94110_p0.read().is_01() || !mul_ln1118_654_fu_94110_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_654_fu_94110_p0.read()) * sc_bigint<2>(mul_ln1118_654_fu_94110_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_655_fu_94134_p0() {
    mul_ln1118_655_fu_94134_p0 =  (sc_lv<10>) (zext_ln1116_435_fu_94128_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_655_fu_94134_p1() {
    mul_ln1118_655_fu_94134_p1 = tmp_978_reg_134671.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_655_fu_94134_p2() {
    mul_ln1118_655_fu_94134_p2 = (!mul_ln1118_655_fu_94134_p0.read().is_01() || !mul_ln1118_655_fu_94134_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_655_fu_94134_p0.read()) * sc_bigint<2>(mul_ln1118_655_fu_94134_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_656_fu_94158_p0() {
    mul_ln1118_656_fu_94158_p0 =  (sc_lv<10>) (zext_ln1116_436_fu_94152_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_656_fu_94158_p1() {
    mul_ln1118_656_fu_94158_p1 = tmp_980_reg_134681.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_656_fu_94158_p2() {
    mul_ln1118_656_fu_94158_p2 = (!mul_ln1118_656_fu_94158_p0.read().is_01() || !mul_ln1118_656_fu_94158_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_656_fu_94158_p0.read()) * sc_bigint<2>(mul_ln1118_656_fu_94158_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_657_fu_94182_p0() {
    mul_ln1118_657_fu_94182_p0 =  (sc_lv<10>) (zext_ln1116_437_fu_94176_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_657_fu_94182_p1() {
    mul_ln1118_657_fu_94182_p1 = tmp_982_reg_134691.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_657_fu_94182_p2() {
    mul_ln1118_657_fu_94182_p2 = (!mul_ln1118_657_fu_94182_p0.read().is_01() || !mul_ln1118_657_fu_94182_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_657_fu_94182_p0.read()) * sc_bigint<2>(mul_ln1118_657_fu_94182_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_658_fu_94194_p0() {
    mul_ln1118_658_fu_94194_p0 =  (sc_lv<10>) (zext_ln1116_438_fu_94188_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_658_fu_94194_p1() {
    mul_ln1118_658_fu_94194_p1 = tmp_984_reg_134701.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_658_fu_94194_p2() {
    mul_ln1118_658_fu_94194_p2 = (!mul_ln1118_658_fu_94194_p0.read().is_01() || !mul_ln1118_658_fu_94194_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_658_fu_94194_p0.read()) * sc_bigint<2>(mul_ln1118_658_fu_94194_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_659_fu_94218_p0() {
    mul_ln1118_659_fu_94218_p0 =  (sc_lv<10>) (zext_ln1116_439_fu_94212_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_659_fu_94218_p1() {
    mul_ln1118_659_fu_94218_p1 = tmp_986_reg_134711.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_659_fu_94218_p2() {
    mul_ln1118_659_fu_94218_p2 = (!mul_ln1118_659_fu_94218_p0.read().is_01() || !mul_ln1118_659_fu_94218_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_659_fu_94218_p0.read()) * sc_bigint<2>(mul_ln1118_659_fu_94218_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_65_fu_80967_p0() {
    mul_ln1118_65_fu_80967_p0 =  (sc_lv<10>) (mul_ln1118_65_fu_80967_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_65_fu_80967_p00() {
    mul_ln1118_65_fu_80967_p00 = esl_zext<12,10>(trunc_ln77_62_reg_129881.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_65_fu_80967_p1() {
    mul_ln1118_65_fu_80967_p1 = tmp_123_reg_129886.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_65_fu_80967_p2() {
    mul_ln1118_65_fu_80967_p2 = (!mul_ln1118_65_fu_80967_p0.read().is_01() || !mul_ln1118_65_fu_80967_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_65_fu_80967_p0.read()) * sc_bigint<2>(mul_ln1118_65_fu_80967_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_660_fu_94242_p0() {
    mul_ln1118_660_fu_94242_p0 =  (sc_lv<10>) (zext_ln1116_440_fu_94236_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_660_fu_94242_p1() {
    mul_ln1118_660_fu_94242_p1 = tmp_987_reg_134721.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_660_fu_94242_p2() {
    mul_ln1118_660_fu_94242_p2 = (!mul_ln1118_660_fu_94242_p0.read().is_01() || !mul_ln1118_660_fu_94242_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_660_fu_94242_p0.read()) * sc_bigint<2>(mul_ln1118_660_fu_94242_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_661_fu_94266_p0() {
    mul_ln1118_661_fu_94266_p0 =  (sc_lv<10>) (zext_ln1116_441_fu_94260_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_661_fu_94266_p1() {
    mul_ln1118_661_fu_94266_p1 = tmp_988_reg_134731.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_661_fu_94266_p2() {
    mul_ln1118_661_fu_94266_p2 = (!mul_ln1118_661_fu_94266_p0.read().is_01() || !mul_ln1118_661_fu_94266_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_661_fu_94266_p0.read()) * sc_bigint<2>(mul_ln1118_661_fu_94266_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_662_fu_94290_p0() {
    mul_ln1118_662_fu_94290_p0 =  (sc_lv<10>) (zext_ln1116_442_fu_94284_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_662_fu_94290_p1() {
    mul_ln1118_662_fu_94290_p1 = tmp_989_reg_134741.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_662_fu_94290_p2() {
    mul_ln1118_662_fu_94290_p2 = (!mul_ln1118_662_fu_94290_p0.read().is_01() || !mul_ln1118_662_fu_94290_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_662_fu_94290_p0.read()) * sc_bigint<2>(mul_ln1118_662_fu_94290_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_663_fu_94302_p0() {
    mul_ln1118_663_fu_94302_p0 =  (sc_lv<10>) (zext_ln1116_443_fu_94296_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_663_fu_94302_p1() {
    mul_ln1118_663_fu_94302_p1 = tmp_990_reg_134751.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_663_fu_94302_p2() {
    mul_ln1118_663_fu_94302_p2 = (!mul_ln1118_663_fu_94302_p0.read().is_01() || !mul_ln1118_663_fu_94302_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_663_fu_94302_p0.read()) * sc_bigint<2>(mul_ln1118_663_fu_94302_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_664_fu_94326_p0() {
    mul_ln1118_664_fu_94326_p0 =  (sc_lv<10>) (zext_ln1116_444_fu_94320_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_664_fu_94326_p1() {
    mul_ln1118_664_fu_94326_p1 = tmp_991_reg_134761.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_664_fu_94326_p2() {
    mul_ln1118_664_fu_94326_p2 = (!mul_ln1118_664_fu_94326_p0.read().is_01() || !mul_ln1118_664_fu_94326_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_664_fu_94326_p0.read()) * sc_bigint<2>(mul_ln1118_664_fu_94326_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_665_fu_94350_p0() {
    mul_ln1118_665_fu_94350_p0 =  (sc_lv<10>) (zext_ln1116_445_fu_94344_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_665_fu_94350_p1() {
    mul_ln1118_665_fu_94350_p1 = tmp_992_reg_134771.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_665_fu_94350_p2() {
    mul_ln1118_665_fu_94350_p2 = (!mul_ln1118_665_fu_94350_p0.read().is_01() || !mul_ln1118_665_fu_94350_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_665_fu_94350_p0.read()) * sc_bigint<2>(mul_ln1118_665_fu_94350_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_666_fu_94374_p0() {
    mul_ln1118_666_fu_94374_p0 =  (sc_lv<10>) (zext_ln1116_446_fu_94368_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_666_fu_94374_p1() {
    mul_ln1118_666_fu_94374_p1 = tmp_993_reg_134781.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_666_fu_94374_p2() {
    mul_ln1118_666_fu_94374_p2 = (!mul_ln1118_666_fu_94374_p0.read().is_01() || !mul_ln1118_666_fu_94374_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_666_fu_94374_p0.read()) * sc_bigint<2>(mul_ln1118_666_fu_94374_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_667_fu_94398_p0() {
    mul_ln1118_667_fu_94398_p0 =  (sc_lv<10>) (zext_ln1116_447_fu_94392_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_667_fu_94398_p1() {
    mul_ln1118_667_fu_94398_p1 = tmp_994_reg_134791.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_667_fu_94398_p2() {
    mul_ln1118_667_fu_94398_p2 = (!mul_ln1118_667_fu_94398_p0.read().is_01() || !mul_ln1118_667_fu_94398_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_667_fu_94398_p0.read()) * sc_bigint<2>(mul_ln1118_667_fu_94398_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_668_fu_94410_p0() {
    mul_ln1118_668_fu_94410_p0 =  (sc_lv<10>) (zext_ln1116_448_fu_94404_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_668_fu_94410_p1() {
    mul_ln1118_668_fu_94410_p1 = tmp_995_reg_134801.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_668_fu_94410_p2() {
    mul_ln1118_668_fu_94410_p2 = (!mul_ln1118_668_fu_94410_p0.read().is_01() || !mul_ln1118_668_fu_94410_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_668_fu_94410_p0.read()) * sc_bigint<2>(mul_ln1118_668_fu_94410_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_669_fu_94434_p0() {
    mul_ln1118_669_fu_94434_p0 =  (sc_lv<10>) (zext_ln1116_449_fu_94428_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_669_fu_94434_p1() {
    mul_ln1118_669_fu_94434_p1 = tmp_996_reg_134811.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_669_fu_94434_p2() {
    mul_ln1118_669_fu_94434_p2 = (!mul_ln1118_669_fu_94434_p0.read().is_01() || !mul_ln1118_669_fu_94434_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_669_fu_94434_p0.read()) * sc_bigint<2>(mul_ln1118_669_fu_94434_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_66_fu_80991_p0() {
    mul_ln1118_66_fu_80991_p0 =  (sc_lv<10>) (mul_ln1118_66_fu_80991_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_66_fu_80991_p00() {
    mul_ln1118_66_fu_80991_p00 = esl_zext<12,10>(trunc_ln77_63_reg_129891.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_66_fu_80991_p1() {
    mul_ln1118_66_fu_80991_p1 = tmp_125_reg_129896.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_66_fu_80991_p2() {
    mul_ln1118_66_fu_80991_p2 = (!mul_ln1118_66_fu_80991_p0.read().is_01() || !mul_ln1118_66_fu_80991_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_66_fu_80991_p0.read()) * sc_bigint<2>(mul_ln1118_66_fu_80991_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_670_fu_94458_p0() {
    mul_ln1118_670_fu_94458_p0 =  (sc_lv<10>) (zext_ln1116_450_fu_94452_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_670_fu_94458_p1() {
    mul_ln1118_670_fu_94458_p1 = tmp_997_reg_134821.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_670_fu_94458_p2() {
    mul_ln1118_670_fu_94458_p2 = (!mul_ln1118_670_fu_94458_p0.read().is_01() || !mul_ln1118_670_fu_94458_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_670_fu_94458_p0.read()) * sc_bigint<2>(mul_ln1118_670_fu_94458_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_671_fu_94470_p0() {
    mul_ln1118_671_fu_94470_p0 =  (sc_lv<10>) (zext_ln1116_451_fu_94464_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_671_fu_94470_p1() {
    mul_ln1118_671_fu_94470_p1 = tmp_998_reg_134831.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_671_fu_94470_p2() {
    mul_ln1118_671_fu_94470_p2 = (!mul_ln1118_671_fu_94470_p0.read().is_01() || !mul_ln1118_671_fu_94470_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_671_fu_94470_p0.read()) * sc_bigint<2>(mul_ln1118_671_fu_94470_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_672_fu_94494_p0() {
    mul_ln1118_672_fu_94494_p0 =  (sc_lv<10>) (zext_ln1116_452_fu_94488_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_672_fu_94494_p1() {
    mul_ln1118_672_fu_94494_p1 = tmp_999_reg_134841.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_672_fu_94494_p2() {
    mul_ln1118_672_fu_94494_p2 = (!mul_ln1118_672_fu_94494_p0.read().is_01() || !mul_ln1118_672_fu_94494_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_672_fu_94494_p0.read()) * sc_bigint<2>(mul_ln1118_672_fu_94494_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_673_fu_94518_p0() {
    mul_ln1118_673_fu_94518_p0 =  (sc_lv<10>) (zext_ln1116_453_fu_94512_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_673_fu_94518_p1() {
    mul_ln1118_673_fu_94518_p1 = tmp_1000_reg_134851.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_673_fu_94518_p2() {
    mul_ln1118_673_fu_94518_p2 = (!mul_ln1118_673_fu_94518_p0.read().is_01() || !mul_ln1118_673_fu_94518_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_673_fu_94518_p0.read()) * sc_bigint<2>(mul_ln1118_673_fu_94518_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_674_fu_94530_p0() {
    mul_ln1118_674_fu_94530_p0 =  (sc_lv<10>) (zext_ln1116_454_fu_94524_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_674_fu_94530_p1() {
    mul_ln1118_674_fu_94530_p1 = tmp_1001_reg_134861.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_674_fu_94530_p2() {
    mul_ln1118_674_fu_94530_p2 = (!mul_ln1118_674_fu_94530_p0.read().is_01() || !mul_ln1118_674_fu_94530_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_674_fu_94530_p0.read()) * sc_bigint<2>(mul_ln1118_674_fu_94530_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_675_fu_94554_p0() {
    mul_ln1118_675_fu_94554_p0 =  (sc_lv<10>) (zext_ln1116_455_fu_94548_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_675_fu_94554_p1() {
    mul_ln1118_675_fu_94554_p1 = tmp_1002_reg_134871.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_675_fu_94554_p2() {
    mul_ln1118_675_fu_94554_p2 = (!mul_ln1118_675_fu_94554_p0.read().is_01() || !mul_ln1118_675_fu_94554_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_675_fu_94554_p0.read()) * sc_bigint<2>(mul_ln1118_675_fu_94554_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_676_fu_94770_p0() {
    mul_ln1118_676_fu_94770_p0 =  (sc_lv<10>) (zext_ln1116_456_fu_94764_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_676_fu_94770_p1() {
    mul_ln1118_676_fu_94770_p1 = tmp_1004_reg_134876.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_676_fu_94770_p2() {
    mul_ln1118_676_fu_94770_p2 = (!mul_ln1118_676_fu_94770_p0.read().is_01() || !mul_ln1118_676_fu_94770_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_676_fu_94770_p0.read()) * sc_bigint<2>(mul_ln1118_676_fu_94770_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_677_fu_94794_p0() {
    mul_ln1118_677_fu_94794_p0 =  (sc_lv<10>) (zext_ln1116_457_fu_94788_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_677_fu_94794_p1() {
    mul_ln1118_677_fu_94794_p1 = tmp_1006_reg_134886.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_677_fu_94794_p2() {
    mul_ln1118_677_fu_94794_p2 = (!mul_ln1118_677_fu_94794_p0.read().is_01() || !mul_ln1118_677_fu_94794_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_677_fu_94794_p0.read()) * sc_bigint<2>(mul_ln1118_677_fu_94794_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_678_fu_94818_p0() {
    mul_ln1118_678_fu_94818_p0 =  (sc_lv<10>) (zext_ln1116_458_fu_94812_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_678_fu_94818_p1() {
    mul_ln1118_678_fu_94818_p1 = tmp_1008_reg_134896.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_678_fu_94818_p2() {
    mul_ln1118_678_fu_94818_p2 = (!mul_ln1118_678_fu_94818_p0.read().is_01() || !mul_ln1118_678_fu_94818_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_678_fu_94818_p0.read()) * sc_bigint<2>(mul_ln1118_678_fu_94818_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_679_fu_94830_p0() {
    mul_ln1118_679_fu_94830_p0 =  (sc_lv<10>) (zext_ln1116_459_fu_94824_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_679_fu_94830_p1() {
    mul_ln1118_679_fu_94830_p1 = tmp_1010_reg_134906.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_679_fu_94830_p2() {
    mul_ln1118_679_fu_94830_p2 = (!mul_ln1118_679_fu_94830_p0.read().is_01() || !mul_ln1118_679_fu_94830_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_679_fu_94830_p0.read()) * sc_bigint<2>(mul_ln1118_679_fu_94830_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_67_fu_81015_p0() {
    mul_ln1118_67_fu_81015_p0 =  (sc_lv<10>) (mul_ln1118_67_fu_81015_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_67_fu_81015_p00() {
    mul_ln1118_67_fu_81015_p00 = esl_zext<12,10>(trunc_ln77_64_reg_129901.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_67_fu_81015_p1() {
    mul_ln1118_67_fu_81015_p1 = tmp_127_reg_129906.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_67_fu_81015_p2() {
    mul_ln1118_67_fu_81015_p2 = (!mul_ln1118_67_fu_81015_p0.read().is_01() || !mul_ln1118_67_fu_81015_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_67_fu_81015_p0.read()) * sc_bigint<2>(mul_ln1118_67_fu_81015_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_680_fu_94854_p0() {
    mul_ln1118_680_fu_94854_p0 =  (sc_lv<10>) (zext_ln1116_460_fu_94848_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_680_fu_94854_p1() {
    mul_ln1118_680_fu_94854_p1 = tmp_1011_reg_134916.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_680_fu_94854_p2() {
    mul_ln1118_680_fu_94854_p2 = (!mul_ln1118_680_fu_94854_p0.read().is_01() || !mul_ln1118_680_fu_94854_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_680_fu_94854_p0.read()) * sc_bigint<2>(mul_ln1118_680_fu_94854_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_681_fu_94878_p0() {
    mul_ln1118_681_fu_94878_p0 =  (sc_lv<10>) (zext_ln1116_461_fu_94872_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_681_fu_94878_p1() {
    mul_ln1118_681_fu_94878_p1 = tmp_1013_reg_134926.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_681_fu_94878_p2() {
    mul_ln1118_681_fu_94878_p2 = (!mul_ln1118_681_fu_94878_p0.read().is_01() || !mul_ln1118_681_fu_94878_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_681_fu_94878_p0.read()) * sc_bigint<2>(mul_ln1118_681_fu_94878_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_682_fu_94902_p0() {
    mul_ln1118_682_fu_94902_p0 =  (sc_lv<10>) (zext_ln1116_462_fu_94896_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_682_fu_94902_p1() {
    mul_ln1118_682_fu_94902_p1 = tmp_1015_reg_134936.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_682_fu_94902_p2() {
    mul_ln1118_682_fu_94902_p2 = (!mul_ln1118_682_fu_94902_p0.read().is_01() || !mul_ln1118_682_fu_94902_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_682_fu_94902_p0.read()) * sc_bigint<2>(mul_ln1118_682_fu_94902_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_683_fu_94926_p0() {
    mul_ln1118_683_fu_94926_p0 =  (sc_lv<10>) (zext_ln1116_463_fu_94920_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_683_fu_94926_p1() {
    mul_ln1118_683_fu_94926_p1 = tmp_1017_reg_134946.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_683_fu_94926_p2() {
    mul_ln1118_683_fu_94926_p2 = (!mul_ln1118_683_fu_94926_p0.read().is_01() || !mul_ln1118_683_fu_94926_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_683_fu_94926_p0.read()) * sc_bigint<2>(mul_ln1118_683_fu_94926_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_684_fu_94938_p0() {
    mul_ln1118_684_fu_94938_p0 =  (sc_lv<10>) (zext_ln1116_464_fu_94932_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_684_fu_94938_p1() {
    mul_ln1118_684_fu_94938_p1 = tmp_1018_reg_134956.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_684_fu_94938_p2() {
    mul_ln1118_684_fu_94938_p2 = (!mul_ln1118_684_fu_94938_p0.read().is_01() || !mul_ln1118_684_fu_94938_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_684_fu_94938_p0.read()) * sc_bigint<2>(mul_ln1118_684_fu_94938_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_685_fu_94962_p0() {
    mul_ln1118_685_fu_94962_p0 =  (sc_lv<10>) (zext_ln1116_465_fu_94956_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_685_fu_94962_p1() {
    mul_ln1118_685_fu_94962_p1 = tmp_1019_reg_134966.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_685_fu_94962_p2() {
    mul_ln1118_685_fu_94962_p2 = (!mul_ln1118_685_fu_94962_p0.read().is_01() || !mul_ln1118_685_fu_94962_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_685_fu_94962_p0.read()) * sc_bigint<2>(mul_ln1118_685_fu_94962_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_686_fu_94986_p0() {
    mul_ln1118_686_fu_94986_p0 =  (sc_lv<10>) (zext_ln1116_466_fu_94980_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_686_fu_94986_p1() {
    mul_ln1118_686_fu_94986_p1 = tmp_1021_reg_134976.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_686_fu_94986_p2() {
    mul_ln1118_686_fu_94986_p2 = (!mul_ln1118_686_fu_94986_p0.read().is_01() || !mul_ln1118_686_fu_94986_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_686_fu_94986_p0.read()) * sc_bigint<2>(mul_ln1118_686_fu_94986_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_687_fu_95010_p0() {
    mul_ln1118_687_fu_95010_p0 =  (sc_lv<10>) (zext_ln1116_467_fu_95004_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_687_fu_95010_p1() {
    mul_ln1118_687_fu_95010_p1 = tmp_1023_reg_134986.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_687_fu_95010_p2() {
    mul_ln1118_687_fu_95010_p2 = (!mul_ln1118_687_fu_95010_p0.read().is_01() || !mul_ln1118_687_fu_95010_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_687_fu_95010_p0.read()) * sc_bigint<2>(mul_ln1118_687_fu_95010_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_688_fu_95034_p0() {
    mul_ln1118_688_fu_95034_p0 =  (sc_lv<10>) (zext_ln1116_468_fu_95028_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_688_fu_95034_p1() {
    mul_ln1118_688_fu_95034_p1 = tmp_1025_reg_134996.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_688_fu_95034_p2() {
    mul_ln1118_688_fu_95034_p2 = (!mul_ln1118_688_fu_95034_p0.read().is_01() || !mul_ln1118_688_fu_95034_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_688_fu_95034_p0.read()) * sc_bigint<2>(mul_ln1118_688_fu_95034_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_689_fu_95046_p0() {
    mul_ln1118_689_fu_95046_p0 =  (sc_lv<10>) (zext_ln1116_469_fu_95040_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_689_fu_95046_p1() {
    mul_ln1118_689_fu_95046_p1 = tmp_1027_reg_135006.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_689_fu_95046_p2() {
    mul_ln1118_689_fu_95046_p2 = (!mul_ln1118_689_fu_95046_p0.read().is_01() || !mul_ln1118_689_fu_95046_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_689_fu_95046_p0.read()) * sc_bigint<2>(mul_ln1118_689_fu_95046_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_68_fu_81039_p0() {
    mul_ln1118_68_fu_81039_p0 =  (sc_lv<10>) (mul_ln1118_68_fu_81039_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_68_fu_81039_p00() {
    mul_ln1118_68_fu_81039_p00 = esl_zext<12,10>(trunc_ln77_65_reg_129911.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_68_fu_81039_p1() {
    mul_ln1118_68_fu_81039_p1 = tmp_129_reg_129916.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_68_fu_81039_p2() {
    mul_ln1118_68_fu_81039_p2 = (!mul_ln1118_68_fu_81039_p0.read().is_01() || !mul_ln1118_68_fu_81039_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_68_fu_81039_p0.read()) * sc_bigint<2>(mul_ln1118_68_fu_81039_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_690_fu_95070_p0() {
    mul_ln1118_690_fu_95070_p0 =  (sc_lv<10>) (zext_ln1116_470_fu_95064_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_690_fu_95070_p1() {
    mul_ln1118_690_fu_95070_p1 = tmp_1029_reg_135016.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_690_fu_95070_p2() {
    mul_ln1118_690_fu_95070_p2 = (!mul_ln1118_690_fu_95070_p0.read().is_01() || !mul_ln1118_690_fu_95070_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_690_fu_95070_p0.read()) * sc_bigint<2>(mul_ln1118_690_fu_95070_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_691_fu_95094_p0() {
    mul_ln1118_691_fu_95094_p0 =  (sc_lv<10>) (zext_ln1116_471_fu_95088_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_691_fu_95094_p1() {
    mul_ln1118_691_fu_95094_p1 = tmp_1031_reg_135026.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_691_fu_95094_p2() {
    mul_ln1118_691_fu_95094_p2 = (!mul_ln1118_691_fu_95094_p0.read().is_01() || !mul_ln1118_691_fu_95094_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_691_fu_95094_p0.read()) * sc_bigint<2>(mul_ln1118_691_fu_95094_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_692_fu_95106_p0() {
    mul_ln1118_692_fu_95106_p0 =  (sc_lv<10>) (zext_ln1116_472_fu_95100_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_692_fu_95106_p1() {
    mul_ln1118_692_fu_95106_p1 = tmp_1033_reg_135036.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_692_fu_95106_p2() {
    mul_ln1118_692_fu_95106_p2 = (!mul_ln1118_692_fu_95106_p0.read().is_01() || !mul_ln1118_692_fu_95106_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_692_fu_95106_p0.read()) * sc_bigint<2>(mul_ln1118_692_fu_95106_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_693_fu_95130_p0() {
    mul_ln1118_693_fu_95130_p0 =  (sc_lv<10>) (zext_ln1116_473_fu_95124_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_693_fu_95130_p1() {
    mul_ln1118_693_fu_95130_p1 = tmp_1034_reg_135046.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_693_fu_95130_p2() {
    mul_ln1118_693_fu_95130_p2 = (!mul_ln1118_693_fu_95130_p0.read().is_01() || !mul_ln1118_693_fu_95130_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_693_fu_95130_p0.read()) * sc_bigint<2>(mul_ln1118_693_fu_95130_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_694_fu_95154_p0() {
    mul_ln1118_694_fu_95154_p0 =  (sc_lv<10>) (zext_ln1116_474_fu_95148_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_694_fu_95154_p1() {
    mul_ln1118_694_fu_95154_p1 = tmp_1035_reg_135056.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_694_fu_95154_p2() {
    mul_ln1118_694_fu_95154_p2 = (!mul_ln1118_694_fu_95154_p0.read().is_01() || !mul_ln1118_694_fu_95154_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_694_fu_95154_p0.read()) * sc_bigint<2>(mul_ln1118_694_fu_95154_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_695_fu_95166_p0() {
    mul_ln1118_695_fu_95166_p0 =  (sc_lv<10>) (zext_ln1116_475_fu_95160_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_695_fu_95166_p1() {
    mul_ln1118_695_fu_95166_p1 = tmp_1036_reg_135066.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_695_fu_95166_p2() {
    mul_ln1118_695_fu_95166_p2 = (!mul_ln1118_695_fu_95166_p0.read().is_01() || !mul_ln1118_695_fu_95166_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_695_fu_95166_p0.read()) * sc_bigint<2>(mul_ln1118_695_fu_95166_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_696_fu_95190_p0() {
    mul_ln1118_696_fu_95190_p0 =  (sc_lv<10>) (zext_ln1116_476_fu_95184_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_696_fu_95190_p1() {
    mul_ln1118_696_fu_95190_p1 = tmp_1037_reg_135076.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_696_fu_95190_p2() {
    mul_ln1118_696_fu_95190_p2 = (!mul_ln1118_696_fu_95190_p0.read().is_01() || !mul_ln1118_696_fu_95190_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_696_fu_95190_p0.read()) * sc_bigint<2>(mul_ln1118_696_fu_95190_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_697_fu_95214_p0() {
    mul_ln1118_697_fu_95214_p0 =  (sc_lv<10>) (mul_ln1118_697_fu_95214_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_697_fu_95214_p00() {
    mul_ln1118_697_fu_95214_p00 = esl_zext<12,10>(trunc_ln77_475_reg_135081.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_697_fu_95214_p1() {
    mul_ln1118_697_fu_95214_p1 = tmp_1039_reg_135086.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_697_fu_95214_p2() {
    mul_ln1118_697_fu_95214_p2 = (!mul_ln1118_697_fu_95214_p0.read().is_01() || !mul_ln1118_697_fu_95214_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_697_fu_95214_p0.read()) * sc_bigint<2>(mul_ln1118_697_fu_95214_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_698_fu_95238_p0() {
    mul_ln1118_698_fu_95238_p0 =  (sc_lv<10>) (mul_ln1118_698_fu_95238_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_698_fu_95238_p00() {
    mul_ln1118_698_fu_95238_p00 = esl_zext<12,10>(trunc_ln77_476_reg_135091.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_698_fu_95238_p1() {
    mul_ln1118_698_fu_95238_p1 = tmp_1041_reg_135096.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_698_fu_95238_p2() {
    mul_ln1118_698_fu_95238_p2 = (!mul_ln1118_698_fu_95238_p0.read().is_01() || !mul_ln1118_698_fu_95238_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_698_fu_95238_p0.read()) * sc_bigint<2>(mul_ln1118_698_fu_95238_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_699_fu_95262_p0() {
    mul_ln1118_699_fu_95262_p0 =  (sc_lv<10>) (mul_ln1118_699_fu_95262_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_699_fu_95262_p00() {
    mul_ln1118_699_fu_95262_p00 = esl_zext<12,10>(trunc_ln77_477_reg_135101.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_699_fu_95262_p1() {
    mul_ln1118_699_fu_95262_p1 = tmp_1043_reg_135106.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_699_fu_95262_p2() {
    mul_ln1118_699_fu_95262_p2 = (!mul_ln1118_699_fu_95262_p0.read().is_01() || !mul_ln1118_699_fu_95262_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_699_fu_95262_p0.read()) * sc_bigint<2>(mul_ln1118_699_fu_95262_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_69_fu_81063_p0() {
    mul_ln1118_69_fu_81063_p0 =  (sc_lv<10>) (mul_ln1118_69_fu_81063_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_69_fu_81063_p00() {
    mul_ln1118_69_fu_81063_p00 = esl_zext<12,10>(trunc_ln77_66_reg_129921.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_69_fu_81063_p1() {
    mul_ln1118_69_fu_81063_p1 = tmp_131_reg_129926.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_69_fu_81063_p2() {
    mul_ln1118_69_fu_81063_p2 = (!mul_ln1118_69_fu_81063_p0.read().is_01() || !mul_ln1118_69_fu_81063_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_69_fu_81063_p0.read()) * sc_bigint<2>(mul_ln1118_69_fu_81063_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_6_fu_79731_p0() {
    mul_ln1118_6_fu_79731_p0 =  (sc_lv<10>) (mul_ln1118_6_fu_79731_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_6_fu_79731_p00() {
    mul_ln1118_6_fu_79731_p00 = esl_zext<12,10>(trunc_ln77_3_reg_129291.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_6_fu_79731_p1() {
    mul_ln1118_6_fu_79731_p1 = tmp_1_reg_129296.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_6_fu_79731_p2() {
    mul_ln1118_6_fu_79731_p2 = (!mul_ln1118_6_fu_79731_p0.read().is_01() || !mul_ln1118_6_fu_79731_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_6_fu_79731_p0.read()) * sc_bigint<2>(mul_ln1118_6_fu_79731_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_700_fu_95274_p0() {
    mul_ln1118_700_fu_95274_p0 =  (sc_lv<10>) (mul_ln1118_700_fu_95274_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_700_fu_95274_p00() {
    mul_ln1118_700_fu_95274_p00 = esl_zext<12,10>(trunc_ln77_478_reg_135111.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_700_fu_95274_p1() {
    mul_ln1118_700_fu_95274_p1 = tmp_1045_reg_135116.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_700_fu_95274_p2() {
    mul_ln1118_700_fu_95274_p2 = (!mul_ln1118_700_fu_95274_p0.read().is_01() || !mul_ln1118_700_fu_95274_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_700_fu_95274_p0.read()) * sc_bigint<2>(mul_ln1118_700_fu_95274_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_701_fu_95298_p0() {
    mul_ln1118_701_fu_95298_p0 =  (sc_lv<10>) (mul_ln1118_701_fu_95298_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_701_fu_95298_p00() {
    mul_ln1118_701_fu_95298_p00 = esl_zext<12,10>(trunc_ln77_479_reg_135121.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_701_fu_95298_p1() {
    mul_ln1118_701_fu_95298_p1 = tmp_1047_reg_135126.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_701_fu_95298_p2() {
    mul_ln1118_701_fu_95298_p2 = (!mul_ln1118_701_fu_95298_p0.read().is_01() || !mul_ln1118_701_fu_95298_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_701_fu_95298_p0.read()) * sc_bigint<2>(mul_ln1118_701_fu_95298_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_702_fu_95322_p0() {
    mul_ln1118_702_fu_95322_p0 =  (sc_lv<10>) (mul_ln1118_702_fu_95322_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_702_fu_95322_p00() {
    mul_ln1118_702_fu_95322_p00 = esl_zext<12,10>(trunc_ln77_480_reg_135131.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_702_fu_95322_p1() {
    mul_ln1118_702_fu_95322_p1 = tmp_1049_reg_135136.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_702_fu_95322_p2() {
    mul_ln1118_702_fu_95322_p2 = (!mul_ln1118_702_fu_95322_p0.read().is_01() || !mul_ln1118_702_fu_95322_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_702_fu_95322_p0.read()) * sc_bigint<2>(mul_ln1118_702_fu_95322_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_703_fu_95346_p0() {
    mul_ln1118_703_fu_95346_p0 =  (sc_lv<10>) (mul_ln1118_703_fu_95346_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_703_fu_95346_p00() {
    mul_ln1118_703_fu_95346_p00 = esl_zext<12,10>(trunc_ln77_481_reg_135141.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_703_fu_95346_p1() {
    mul_ln1118_703_fu_95346_p1 = tmp_1051_reg_135146.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_703_fu_95346_p2() {
    mul_ln1118_703_fu_95346_p2 = (!mul_ln1118_703_fu_95346_p0.read().is_01() || !mul_ln1118_703_fu_95346_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_703_fu_95346_p0.read()) * sc_bigint<2>(mul_ln1118_703_fu_95346_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_704_fu_95370_p0() {
    mul_ln1118_704_fu_95370_p0 =  (sc_lv<10>) (mul_ln1118_704_fu_95370_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_704_fu_95370_p00() {
    mul_ln1118_704_fu_95370_p00 = esl_zext<12,10>(trunc_ln77_482_reg_135151.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_704_fu_95370_p1() {
    mul_ln1118_704_fu_95370_p1 = tmp_1053_reg_135156.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_704_fu_95370_p2() {
    mul_ln1118_704_fu_95370_p2 = (!mul_ln1118_704_fu_95370_p0.read().is_01() || !mul_ln1118_704_fu_95370_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_704_fu_95370_p0.read()) * sc_bigint<2>(mul_ln1118_704_fu_95370_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_705_fu_95382_p0() {
    mul_ln1118_705_fu_95382_p0 =  (sc_lv<10>) (mul_ln1118_705_fu_95382_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_705_fu_95382_p00() {
    mul_ln1118_705_fu_95382_p00 = esl_zext<12,10>(trunc_ln77_483_reg_135161.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_705_fu_95382_p1() {
    mul_ln1118_705_fu_95382_p1 = tmp_1055_reg_135166.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_705_fu_95382_p2() {
    mul_ln1118_705_fu_95382_p2 = (!mul_ln1118_705_fu_95382_p0.read().is_01() || !mul_ln1118_705_fu_95382_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_705_fu_95382_p0.read()) * sc_bigint<2>(mul_ln1118_705_fu_95382_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_706_fu_95406_p0() {
    mul_ln1118_706_fu_95406_p0 =  (sc_lv<10>) (mul_ln1118_706_fu_95406_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_706_fu_95406_p00() {
    mul_ln1118_706_fu_95406_p00 = esl_zext<12,10>(trunc_ln77_484_reg_135171.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_706_fu_95406_p1() {
    mul_ln1118_706_fu_95406_p1 = tmp_1057_reg_135176.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_706_fu_95406_p2() {
    mul_ln1118_706_fu_95406_p2 = (!mul_ln1118_706_fu_95406_p0.read().is_01() || !mul_ln1118_706_fu_95406_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_706_fu_95406_p0.read()) * sc_bigint<2>(mul_ln1118_706_fu_95406_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_707_fu_95430_p0() {
    mul_ln1118_707_fu_95430_p0 =  (sc_lv<10>) (mul_ln1118_707_fu_95430_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_707_fu_95430_p00() {
    mul_ln1118_707_fu_95430_p00 = esl_zext<12,10>(trunc_ln77_485_reg_135181.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_707_fu_95430_p1() {
    mul_ln1118_707_fu_95430_p1 = tmp_1059_reg_135186.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_707_fu_95430_p2() {
    mul_ln1118_707_fu_95430_p2 = (!mul_ln1118_707_fu_95430_p0.read().is_01() || !mul_ln1118_707_fu_95430_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_707_fu_95430_p0.read()) * sc_bigint<2>(mul_ln1118_707_fu_95430_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_708_fu_95454_p0() {
    mul_ln1118_708_fu_95454_p0 =  (sc_lv<10>) (mul_ln1118_708_fu_95454_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_708_fu_95454_p00() {
    mul_ln1118_708_fu_95454_p00 = esl_zext<12,10>(trunc_ln77_486_reg_135191.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_708_fu_95454_p1() {
    mul_ln1118_708_fu_95454_p1 = tmp_1061_reg_135196.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_708_fu_95454_p2() {
    mul_ln1118_708_fu_95454_p2 = (!mul_ln1118_708_fu_95454_p0.read().is_01() || !mul_ln1118_708_fu_95454_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_708_fu_95454_p0.read()) * sc_bigint<2>(mul_ln1118_708_fu_95454_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_709_fu_95478_p0() {
    mul_ln1118_709_fu_95478_p0 =  (sc_lv<10>) (mul_ln1118_709_fu_95478_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_709_fu_95478_p00() {
    mul_ln1118_709_fu_95478_p00 = esl_zext<12,10>(trunc_ln77_487_reg_135201.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_709_fu_95478_p1() {
    mul_ln1118_709_fu_95478_p1 = tmp_1063_reg_135206.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_709_fu_95478_p2() {
    mul_ln1118_709_fu_95478_p2 = (!mul_ln1118_709_fu_95478_p0.read().is_01() || !mul_ln1118_709_fu_95478_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_709_fu_95478_p0.read()) * sc_bigint<2>(mul_ln1118_709_fu_95478_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_70_fu_81075_p0() {
    mul_ln1118_70_fu_81075_p0 =  (sc_lv<10>) (mul_ln1118_70_fu_81075_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_70_fu_81075_p00() {
    mul_ln1118_70_fu_81075_p00 = esl_zext<12,10>(trunc_ln77_67_reg_129931.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_70_fu_81075_p1() {
    mul_ln1118_70_fu_81075_p1 = tmp_133_reg_129936.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_70_fu_81075_p2() {
    mul_ln1118_70_fu_81075_p2 = (!mul_ln1118_70_fu_81075_p0.read().is_01() || !mul_ln1118_70_fu_81075_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_70_fu_81075_p0.read()) * sc_bigint<2>(mul_ln1118_70_fu_81075_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_710_fu_95490_p0() {
    mul_ln1118_710_fu_95490_p0 =  (sc_lv<10>) (mul_ln1118_710_fu_95490_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_710_fu_95490_p00() {
    mul_ln1118_710_fu_95490_p00 = esl_zext<12,10>(trunc_ln77_488_reg_135211.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_710_fu_95490_p1() {
    mul_ln1118_710_fu_95490_p1 = tmp_1064_reg_135216.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_710_fu_95490_p2() {
    mul_ln1118_710_fu_95490_p2 = (!mul_ln1118_710_fu_95490_p0.read().is_01() || !mul_ln1118_710_fu_95490_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_710_fu_95490_p0.read()) * sc_bigint<2>(mul_ln1118_710_fu_95490_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_711_fu_95514_p0() {
    mul_ln1118_711_fu_95514_p0 =  (sc_lv<10>) (mul_ln1118_711_fu_95514_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_711_fu_95514_p00() {
    mul_ln1118_711_fu_95514_p00 = esl_zext<12,10>(trunc_ln77_489_reg_135221.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_711_fu_95514_p1() {
    mul_ln1118_711_fu_95514_p1 = tmp_1065_reg_135226.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_711_fu_95514_p2() {
    mul_ln1118_711_fu_95514_p2 = (!mul_ln1118_711_fu_95514_p0.read().is_01() || !mul_ln1118_711_fu_95514_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_711_fu_95514_p0.read()) * sc_bigint<2>(mul_ln1118_711_fu_95514_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_712_fu_95538_p0() {
    mul_ln1118_712_fu_95538_p0 =  (sc_lv<10>) (mul_ln1118_712_fu_95538_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_712_fu_95538_p00() {
    mul_ln1118_712_fu_95538_p00 = esl_zext<12,10>(trunc_ln77_490_reg_135231.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_712_fu_95538_p1() {
    mul_ln1118_712_fu_95538_p1 = tmp_1066_reg_135236.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_712_fu_95538_p2() {
    mul_ln1118_712_fu_95538_p2 = (!mul_ln1118_712_fu_95538_p0.read().is_01() || !mul_ln1118_712_fu_95538_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_712_fu_95538_p0.read()) * sc_bigint<2>(mul_ln1118_712_fu_95538_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_713_fu_95550_p0() {
    mul_ln1118_713_fu_95550_p0 =  (sc_lv<10>) (mul_ln1118_713_fu_95550_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_713_fu_95550_p00() {
    mul_ln1118_713_fu_95550_p00 = esl_zext<12,10>(trunc_ln77_491_reg_135241.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_713_fu_95550_p1() {
    mul_ln1118_713_fu_95550_p1 = tmp_1067_reg_135246.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_713_fu_95550_p2() {
    mul_ln1118_713_fu_95550_p2 = (!mul_ln1118_713_fu_95550_p0.read().is_01() || !mul_ln1118_713_fu_95550_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_713_fu_95550_p0.read()) * sc_bigint<2>(mul_ln1118_713_fu_95550_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_714_fu_95574_p0() {
    mul_ln1118_714_fu_95574_p0 =  (sc_lv<10>) (mul_ln1118_714_fu_95574_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_714_fu_95574_p00() {
    mul_ln1118_714_fu_95574_p00 = esl_zext<12,10>(trunc_ln77_492_reg_135251.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_714_fu_95574_p1() {
    mul_ln1118_714_fu_95574_p1 = tmp_1068_reg_135256.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_714_fu_95574_p2() {
    mul_ln1118_714_fu_95574_p2 = (!mul_ln1118_714_fu_95574_p0.read().is_01() || !mul_ln1118_714_fu_95574_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_714_fu_95574_p0.read()) * sc_bigint<2>(mul_ln1118_714_fu_95574_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_715_fu_95598_p0() {
    mul_ln1118_715_fu_95598_p0 =  (sc_lv<10>) (mul_ln1118_715_fu_95598_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_715_fu_95598_p00() {
    mul_ln1118_715_fu_95598_p00 = esl_zext<12,10>(trunc_ln77_493_reg_135261.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_715_fu_95598_p1() {
    mul_ln1118_715_fu_95598_p1 = tmp_1069_reg_135266.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_715_fu_95598_p2() {
    mul_ln1118_715_fu_95598_p2 = (!mul_ln1118_715_fu_95598_p0.read().is_01() || !mul_ln1118_715_fu_95598_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_715_fu_95598_p0.read()) * sc_bigint<2>(mul_ln1118_715_fu_95598_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_716_fu_95610_p0() {
    mul_ln1118_716_fu_95610_p0 =  (sc_lv<10>) (mul_ln1118_716_fu_95610_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_716_fu_95610_p00() {
    mul_ln1118_716_fu_95610_p00 = esl_zext<12,10>(trunc_ln77_494_reg_135271.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_716_fu_95610_p1() {
    mul_ln1118_716_fu_95610_p1 = tmp_1070_reg_135276.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_716_fu_95610_p2() {
    mul_ln1118_716_fu_95610_p2 = (!mul_ln1118_716_fu_95610_p0.read().is_01() || !mul_ln1118_716_fu_95610_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_716_fu_95610_p0.read()) * sc_bigint<2>(mul_ln1118_716_fu_95610_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_717_fu_95634_p0() {
    mul_ln1118_717_fu_95634_p0 =  (sc_lv<10>) (mul_ln1118_717_fu_95634_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_717_fu_95634_p00() {
    mul_ln1118_717_fu_95634_p00 = esl_zext<12,10>(trunc_ln77_495_reg_135281.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_717_fu_95634_p1() {
    mul_ln1118_717_fu_95634_p1 = tmp_1071_reg_135286.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_717_fu_95634_p2() {
    mul_ln1118_717_fu_95634_p2 = (!mul_ln1118_717_fu_95634_p0.read().is_01() || !mul_ln1118_717_fu_95634_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_717_fu_95634_p0.read()) * sc_bigint<2>(mul_ln1118_717_fu_95634_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_718_fu_95658_p0() {
    mul_ln1118_718_fu_95658_p0 =  (sc_lv<10>) (mul_ln1118_718_fu_95658_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_718_fu_95658_p00() {
    mul_ln1118_718_fu_95658_p00 = esl_zext<12,10>(trunc_ln77_496_reg_135291.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_718_fu_95658_p1() {
    mul_ln1118_718_fu_95658_p1 = tmp_1073_reg_135296.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_718_fu_95658_p2() {
    mul_ln1118_718_fu_95658_p2 = (!mul_ln1118_718_fu_95658_p0.read().is_01() || !mul_ln1118_718_fu_95658_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_718_fu_95658_p0.read()) * sc_bigint<2>(mul_ln1118_718_fu_95658_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_719_fu_95682_p0() {
    mul_ln1118_719_fu_95682_p0 =  (sc_lv<10>) (mul_ln1118_719_fu_95682_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_719_fu_95682_p00() {
    mul_ln1118_719_fu_95682_p00 = esl_zext<12,10>(trunc_ln77_497_reg_135301.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_719_fu_95682_p1() {
    mul_ln1118_719_fu_95682_p1 = tmp_1075_reg_135306.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_719_fu_95682_p2() {
    mul_ln1118_719_fu_95682_p2 = (!mul_ln1118_719_fu_95682_p0.read().is_01() || !mul_ln1118_719_fu_95682_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_719_fu_95682_p0.read()) * sc_bigint<2>(mul_ln1118_719_fu_95682_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_71_fu_81099_p0() {
    mul_ln1118_71_fu_81099_p0 =  (sc_lv<10>) (mul_ln1118_71_fu_81099_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_71_fu_81099_p00() {
    mul_ln1118_71_fu_81099_p00 = esl_zext<12,10>(trunc_ln77_68_reg_129941.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_71_fu_81099_p1() {
    mul_ln1118_71_fu_81099_p1 = tmp_135_reg_129946.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_71_fu_81099_p2() {
    mul_ln1118_71_fu_81099_p2 = (!mul_ln1118_71_fu_81099_p0.read().is_01() || !mul_ln1118_71_fu_81099_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_71_fu_81099_p0.read()) * sc_bigint<2>(mul_ln1118_71_fu_81099_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_720_fu_95706_p0() {
    mul_ln1118_720_fu_95706_p0 =  (sc_lv<10>) (mul_ln1118_720_fu_95706_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_720_fu_95706_p00() {
    mul_ln1118_720_fu_95706_p00 = esl_zext<12,10>(trunc_ln77_498_reg_135311.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_720_fu_95706_p1() {
    mul_ln1118_720_fu_95706_p1 = tmp_1077_reg_135316.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_720_fu_95706_p2() {
    mul_ln1118_720_fu_95706_p2 = (!mul_ln1118_720_fu_95706_p0.read().is_01() || !mul_ln1118_720_fu_95706_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_720_fu_95706_p0.read()) * sc_bigint<2>(mul_ln1118_720_fu_95706_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_721_fu_95718_p0() {
    mul_ln1118_721_fu_95718_p0 =  (sc_lv<10>) (mul_ln1118_721_fu_95718_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_721_fu_95718_p00() {
    mul_ln1118_721_fu_95718_p00 = esl_zext<12,10>(trunc_ln77_499_reg_135321.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_721_fu_95718_p1() {
    mul_ln1118_721_fu_95718_p1 = tmp_1079_reg_135326.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_721_fu_95718_p2() {
    mul_ln1118_721_fu_95718_p2 = (!mul_ln1118_721_fu_95718_p0.read().is_01() || !mul_ln1118_721_fu_95718_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_721_fu_95718_p0.read()) * sc_bigint<2>(mul_ln1118_721_fu_95718_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_722_fu_95742_p0() {
    mul_ln1118_722_fu_95742_p0 =  (sc_lv<10>) (mul_ln1118_722_fu_95742_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_722_fu_95742_p00() {
    mul_ln1118_722_fu_95742_p00 = esl_zext<12,10>(trunc_ln77_500_reg_135331.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_722_fu_95742_p1() {
    mul_ln1118_722_fu_95742_p1 = tmp_1081_reg_135336.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_722_fu_95742_p2() {
    mul_ln1118_722_fu_95742_p2 = (!mul_ln1118_722_fu_95742_p0.read().is_01() || !mul_ln1118_722_fu_95742_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_722_fu_95742_p0.read()) * sc_bigint<2>(mul_ln1118_722_fu_95742_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_723_fu_95766_p0() {
    mul_ln1118_723_fu_95766_p0 =  (sc_lv<10>) (mul_ln1118_723_fu_95766_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_723_fu_95766_p00() {
    mul_ln1118_723_fu_95766_p00 = esl_zext<12,10>(trunc_ln77_501_reg_135341.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_723_fu_95766_p1() {
    mul_ln1118_723_fu_95766_p1 = tmp_1083_reg_135346.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_723_fu_95766_p2() {
    mul_ln1118_723_fu_95766_p2 = (!mul_ln1118_723_fu_95766_p0.read().is_01() || !mul_ln1118_723_fu_95766_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_723_fu_95766_p0.read()) * sc_bigint<2>(mul_ln1118_723_fu_95766_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_724_fu_95790_p0() {
    mul_ln1118_724_fu_95790_p0 =  (sc_lv<10>) (mul_ln1118_724_fu_95790_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_724_fu_95790_p00() {
    mul_ln1118_724_fu_95790_p00 = esl_zext<12,10>(trunc_ln77_502_reg_135351.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_724_fu_95790_p1() {
    mul_ln1118_724_fu_95790_p1 = tmp_1085_reg_135356.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_724_fu_95790_p2() {
    mul_ln1118_724_fu_95790_p2 = (!mul_ln1118_724_fu_95790_p0.read().is_01() || !mul_ln1118_724_fu_95790_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_724_fu_95790_p0.read()) * sc_bigint<2>(mul_ln1118_724_fu_95790_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_725_fu_95814_p0() {
    mul_ln1118_725_fu_95814_p0 =  (sc_lv<10>) (mul_ln1118_725_fu_95814_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_725_fu_95814_p00() {
    mul_ln1118_725_fu_95814_p00 = esl_zext<12,10>(trunc_ln77_503_reg_135361.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_725_fu_95814_p1() {
    mul_ln1118_725_fu_95814_p1 = tmp_1087_reg_135366.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_725_fu_95814_p2() {
    mul_ln1118_725_fu_95814_p2 = (!mul_ln1118_725_fu_95814_p0.read().is_01() || !mul_ln1118_725_fu_95814_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_725_fu_95814_p0.read()) * sc_bigint<2>(mul_ln1118_725_fu_95814_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_726_fu_95823_p0() {
    mul_ln1118_726_fu_95823_p0 =  (sc_lv<10>) (zext_ln1116_422_fu_93852_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_726_fu_95823_p1() {
    mul_ln1118_726_fu_95823_p1 = tmp_1088_reg_135371.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_726_fu_95823_p2() {
    mul_ln1118_726_fu_95823_p2 = (!mul_ln1118_726_fu_95823_p0.read().is_01() || !mul_ln1118_726_fu_95823_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_726_fu_95823_p0.read()) * sc_bigint<2>(mul_ln1118_726_fu_95823_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_727_fu_95844_p0() {
    mul_ln1118_727_fu_95844_p0 =  (sc_lv<10>) (zext_ln1116_423_fu_93876_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_727_fu_95844_p1() {
    mul_ln1118_727_fu_95844_p1 = tmp_1089_reg_135376.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_727_fu_95844_p2() {
    mul_ln1118_727_fu_95844_p2 = (!mul_ln1118_727_fu_95844_p0.read().is_01() || !mul_ln1118_727_fu_95844_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_727_fu_95844_p0.read()) * sc_bigint<2>(mul_ln1118_727_fu_95844_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_728_fu_95865_p0() {
    mul_ln1118_728_fu_95865_p0 =  (sc_lv<10>) (zext_ln1116_424_fu_93900_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_728_fu_95865_p1() {
    mul_ln1118_728_fu_95865_p1 = tmp_1090_reg_135381.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_728_fu_95865_p2() {
    mul_ln1118_728_fu_95865_p2 = (!mul_ln1118_728_fu_95865_p0.read().is_01() || !mul_ln1118_728_fu_95865_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_728_fu_95865_p0.read()) * sc_bigint<2>(mul_ln1118_728_fu_95865_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_729_fu_95886_p0() {
    mul_ln1118_729_fu_95886_p0 =  (sc_lv<10>) (zext_ln1116_425_fu_93924_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_729_fu_95886_p1() {
    mul_ln1118_729_fu_95886_p1 = tmp_1091_reg_135386.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_729_fu_95886_p2() {
    mul_ln1118_729_fu_95886_p2 = (!mul_ln1118_729_fu_95886_p0.read().is_01() || !mul_ln1118_729_fu_95886_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_729_fu_95886_p0.read()) * sc_bigint<2>(mul_ln1118_729_fu_95886_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_72_fu_81123_p0() {
    mul_ln1118_72_fu_81123_p0 =  (sc_lv<10>) (mul_ln1118_72_fu_81123_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_72_fu_81123_p00() {
    mul_ln1118_72_fu_81123_p00 = esl_zext<12,10>(trunc_ln77_69_reg_129951.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_72_fu_81123_p1() {
    mul_ln1118_72_fu_81123_p1 = tmp_137_reg_129956.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_72_fu_81123_p2() {
    mul_ln1118_72_fu_81123_p2 = (!mul_ln1118_72_fu_81123_p0.read().is_01() || !mul_ln1118_72_fu_81123_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_72_fu_81123_p0.read()) * sc_bigint<2>(mul_ln1118_72_fu_81123_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_730_fu_95907_p0() {
    mul_ln1118_730_fu_95907_p0 =  (sc_lv<10>) (zext_ln1116_426_fu_93948_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_730_fu_95907_p1() {
    mul_ln1118_730_fu_95907_p1 = tmp_1092_reg_135391.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_730_fu_95907_p2() {
    mul_ln1118_730_fu_95907_p2 = (!mul_ln1118_730_fu_95907_p0.read().is_01() || !mul_ln1118_730_fu_95907_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_730_fu_95907_p0.read()) * sc_bigint<2>(mul_ln1118_730_fu_95907_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_731_fu_95916_p0() {
    mul_ln1118_731_fu_95916_p0 =  (sc_lv<10>) (zext_ln1116_427_fu_93960_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_731_fu_95916_p1() {
    mul_ln1118_731_fu_95916_p1 = tmp_1093_reg_135396.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_731_fu_95916_p2() {
    mul_ln1118_731_fu_95916_p2 = (!mul_ln1118_731_fu_95916_p0.read().is_01() || !mul_ln1118_731_fu_95916_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_731_fu_95916_p0.read()) * sc_bigint<2>(mul_ln1118_731_fu_95916_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_732_fu_95937_p0() {
    mul_ln1118_732_fu_95937_p0 =  (sc_lv<10>) (zext_ln1116_428_fu_93984_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_732_fu_95937_p1() {
    mul_ln1118_732_fu_95937_p1 = tmp_1094_reg_135401.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_732_fu_95937_p2() {
    mul_ln1118_732_fu_95937_p2 = (!mul_ln1118_732_fu_95937_p0.read().is_01() || !mul_ln1118_732_fu_95937_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_732_fu_95937_p0.read()) * sc_bigint<2>(mul_ln1118_732_fu_95937_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_733_fu_95958_p0() {
    mul_ln1118_733_fu_95958_p0 =  (sc_lv<10>) (zext_ln1116_429_fu_94008_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_733_fu_95958_p1() {
    mul_ln1118_733_fu_95958_p1 = tmp_1095_reg_135406.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_733_fu_95958_p2() {
    mul_ln1118_733_fu_95958_p2 = (!mul_ln1118_733_fu_95958_p0.read().is_01() || !mul_ln1118_733_fu_95958_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_733_fu_95958_p0.read()) * sc_bigint<2>(mul_ln1118_733_fu_95958_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_734_fu_95967_p0() {
    mul_ln1118_734_fu_95967_p0 =  (sc_lv<10>) (zext_ln1116_430_fu_94020_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_734_fu_95967_p1() {
    mul_ln1118_734_fu_95967_p1 = tmp_1096_reg_135411.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_734_fu_95967_p2() {
    mul_ln1118_734_fu_95967_p2 = (!mul_ln1118_734_fu_95967_p0.read().is_01() || !mul_ln1118_734_fu_95967_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_734_fu_95967_p0.read()) * sc_bigint<2>(mul_ln1118_734_fu_95967_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_735_fu_95988_p0() {
    mul_ln1118_735_fu_95988_p0 =  (sc_lv<10>) (zext_ln1116_431_fu_94044_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_735_fu_95988_p1() {
    mul_ln1118_735_fu_95988_p1 = tmp_1097_reg_135416.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_735_fu_95988_p2() {
    mul_ln1118_735_fu_95988_p2 = (!mul_ln1118_735_fu_95988_p0.read().is_01() || !mul_ln1118_735_fu_95988_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_735_fu_95988_p0.read()) * sc_bigint<2>(mul_ln1118_735_fu_95988_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_736_fu_96009_p0() {
    mul_ln1118_736_fu_96009_p0 =  (sc_lv<10>) (zext_ln1116_432_fu_94068_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_736_fu_96009_p1() {
    mul_ln1118_736_fu_96009_p1 = tmp_1098_reg_135421.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_736_fu_96009_p2() {
    mul_ln1118_736_fu_96009_p2 = (!mul_ln1118_736_fu_96009_p0.read().is_01() || !mul_ln1118_736_fu_96009_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_736_fu_96009_p0.read()) * sc_bigint<2>(mul_ln1118_736_fu_96009_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_737_fu_96018_p0() {
    mul_ln1118_737_fu_96018_p0 =  (sc_lv<10>) (zext_ln1116_433_fu_94080_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_737_fu_96018_p1() {
    mul_ln1118_737_fu_96018_p1 = tmp_1099_reg_135426.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_737_fu_96018_p2() {
    mul_ln1118_737_fu_96018_p2 = (!mul_ln1118_737_fu_96018_p0.read().is_01() || !mul_ln1118_737_fu_96018_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_737_fu_96018_p0.read()) * sc_bigint<2>(mul_ln1118_737_fu_96018_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_738_fu_96039_p0() {
    mul_ln1118_738_fu_96039_p0 =  (sc_lv<10>) (zext_ln1116_434_fu_94104_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_738_fu_96039_p1() {
    mul_ln1118_738_fu_96039_p1 = tmp_1100_reg_135431.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_738_fu_96039_p2() {
    mul_ln1118_738_fu_96039_p2 = (!mul_ln1118_738_fu_96039_p0.read().is_01() || !mul_ln1118_738_fu_96039_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_738_fu_96039_p0.read()) * sc_bigint<2>(mul_ln1118_738_fu_96039_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_739_fu_96060_p0() {
    mul_ln1118_739_fu_96060_p0 =  (sc_lv<10>) (zext_ln1116_435_fu_94128_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_739_fu_96060_p1() {
    mul_ln1118_739_fu_96060_p1 = tmp_1101_reg_135436.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_739_fu_96060_p2() {
    mul_ln1118_739_fu_96060_p2 = (!mul_ln1118_739_fu_96060_p0.read().is_01() || !mul_ln1118_739_fu_96060_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_739_fu_96060_p0.read()) * sc_bigint<2>(mul_ln1118_739_fu_96060_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_73_fu_81147_p0() {
    mul_ln1118_73_fu_81147_p0 =  (sc_lv<10>) (mul_ln1118_73_fu_81147_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_73_fu_81147_p00() {
    mul_ln1118_73_fu_81147_p00 = esl_zext<12,10>(trunc_ln77_70_reg_129961.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_73_fu_81147_p1() {
    mul_ln1118_73_fu_81147_p1 = tmp_139_reg_129966.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_73_fu_81147_p2() {
    mul_ln1118_73_fu_81147_p2 = (!mul_ln1118_73_fu_81147_p0.read().is_01() || !mul_ln1118_73_fu_81147_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_73_fu_81147_p0.read()) * sc_bigint<2>(mul_ln1118_73_fu_81147_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_740_fu_96081_p0() {
    mul_ln1118_740_fu_96081_p0 =  (sc_lv<10>) (zext_ln1116_436_fu_94152_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_740_fu_96081_p1() {
    mul_ln1118_740_fu_96081_p1 = tmp_1102_reg_135441.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_740_fu_96081_p2() {
    mul_ln1118_740_fu_96081_p2 = (!mul_ln1118_740_fu_96081_p0.read().is_01() || !mul_ln1118_740_fu_96081_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_740_fu_96081_p0.read()) * sc_bigint<2>(mul_ln1118_740_fu_96081_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_741_fu_96102_p0() {
    mul_ln1118_741_fu_96102_p0 =  (sc_lv<10>) (zext_ln1116_437_fu_94176_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_741_fu_96102_p1() {
    mul_ln1118_741_fu_96102_p1 = tmp_1103_reg_135446.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_741_fu_96102_p2() {
    mul_ln1118_741_fu_96102_p2 = (!mul_ln1118_741_fu_96102_p0.read().is_01() || !mul_ln1118_741_fu_96102_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_741_fu_96102_p0.read()) * sc_bigint<2>(mul_ln1118_741_fu_96102_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_742_fu_96111_p0() {
    mul_ln1118_742_fu_96111_p0 =  (sc_lv<10>) (zext_ln1116_438_fu_94188_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_742_fu_96111_p1() {
    mul_ln1118_742_fu_96111_p1 = tmp_1104_reg_135451.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_742_fu_96111_p2() {
    mul_ln1118_742_fu_96111_p2 = (!mul_ln1118_742_fu_96111_p0.read().is_01() || !mul_ln1118_742_fu_96111_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_742_fu_96111_p0.read()) * sc_bigint<2>(mul_ln1118_742_fu_96111_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_743_fu_96132_p0() {
    mul_ln1118_743_fu_96132_p0 =  (sc_lv<10>) (zext_ln1116_439_fu_94212_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_743_fu_96132_p1() {
    mul_ln1118_743_fu_96132_p1 = tmp_1105_reg_135456.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_743_fu_96132_p2() {
    mul_ln1118_743_fu_96132_p2 = (!mul_ln1118_743_fu_96132_p0.read().is_01() || !mul_ln1118_743_fu_96132_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_743_fu_96132_p0.read()) * sc_bigint<2>(mul_ln1118_743_fu_96132_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_744_fu_96153_p0() {
    mul_ln1118_744_fu_96153_p0 =  (sc_lv<10>) (zext_ln1116_440_fu_94236_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_744_fu_96153_p1() {
    mul_ln1118_744_fu_96153_p1 = tmp_1106_reg_135461.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_744_fu_96153_p2() {
    mul_ln1118_744_fu_96153_p2 = (!mul_ln1118_744_fu_96153_p0.read().is_01() || !mul_ln1118_744_fu_96153_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_744_fu_96153_p0.read()) * sc_bigint<2>(mul_ln1118_744_fu_96153_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_745_fu_96174_p0() {
    mul_ln1118_745_fu_96174_p0 =  (sc_lv<10>) (zext_ln1116_441_fu_94260_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_745_fu_96174_p1() {
    mul_ln1118_745_fu_96174_p1 = tmp_1107_reg_135466.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_745_fu_96174_p2() {
    mul_ln1118_745_fu_96174_p2 = (!mul_ln1118_745_fu_96174_p0.read().is_01() || !mul_ln1118_745_fu_96174_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_745_fu_96174_p0.read()) * sc_bigint<2>(mul_ln1118_745_fu_96174_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_746_fu_96195_p0() {
    mul_ln1118_746_fu_96195_p0 =  (sc_lv<10>) (zext_ln1116_442_fu_94284_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_746_fu_96195_p1() {
    mul_ln1118_746_fu_96195_p1 = tmp_1108_reg_135471.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_746_fu_96195_p2() {
    mul_ln1118_746_fu_96195_p2 = (!mul_ln1118_746_fu_96195_p0.read().is_01() || !mul_ln1118_746_fu_96195_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_746_fu_96195_p0.read()) * sc_bigint<2>(mul_ln1118_746_fu_96195_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_747_fu_96204_p0() {
    mul_ln1118_747_fu_96204_p0 =  (sc_lv<10>) (zext_ln1116_443_fu_94296_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_747_fu_96204_p1() {
    mul_ln1118_747_fu_96204_p1 = tmp_1109_reg_135476.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_747_fu_96204_p2() {
    mul_ln1118_747_fu_96204_p2 = (!mul_ln1118_747_fu_96204_p0.read().is_01() || !mul_ln1118_747_fu_96204_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_747_fu_96204_p0.read()) * sc_bigint<2>(mul_ln1118_747_fu_96204_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_748_fu_96225_p0() {
    mul_ln1118_748_fu_96225_p0 =  (sc_lv<10>) (zext_ln1116_444_fu_94320_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_748_fu_96225_p1() {
    mul_ln1118_748_fu_96225_p1 = tmp_1110_reg_135481.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_748_fu_96225_p2() {
    mul_ln1118_748_fu_96225_p2 = (!mul_ln1118_748_fu_96225_p0.read().is_01() || !mul_ln1118_748_fu_96225_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_748_fu_96225_p0.read()) * sc_bigint<2>(mul_ln1118_748_fu_96225_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_749_fu_96246_p0() {
    mul_ln1118_749_fu_96246_p0 =  (sc_lv<10>) (zext_ln1116_445_fu_94344_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_749_fu_96246_p1() {
    mul_ln1118_749_fu_96246_p1 = tmp_1111_reg_135486.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_749_fu_96246_p2() {
    mul_ln1118_749_fu_96246_p2 = (!mul_ln1118_749_fu_96246_p0.read().is_01() || !mul_ln1118_749_fu_96246_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_749_fu_96246_p0.read()) * sc_bigint<2>(mul_ln1118_749_fu_96246_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_74_fu_81171_p0() {
    mul_ln1118_74_fu_81171_p0 =  (sc_lv<10>) (mul_ln1118_74_fu_81171_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_74_fu_81171_p00() {
    mul_ln1118_74_fu_81171_p00 = esl_zext<12,10>(trunc_ln77_71_reg_129971.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_74_fu_81171_p1() {
    mul_ln1118_74_fu_81171_p1 = tmp_141_reg_129976.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_74_fu_81171_p2() {
    mul_ln1118_74_fu_81171_p2 = (!mul_ln1118_74_fu_81171_p0.read().is_01() || !mul_ln1118_74_fu_81171_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_74_fu_81171_p0.read()) * sc_bigint<2>(mul_ln1118_74_fu_81171_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_750_fu_96267_p0() {
    mul_ln1118_750_fu_96267_p0 =  (sc_lv<10>) (zext_ln1116_446_fu_94368_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_750_fu_96267_p1() {
    mul_ln1118_750_fu_96267_p1 = tmp_1112_reg_135491.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_750_fu_96267_p2() {
    mul_ln1118_750_fu_96267_p2 = (!mul_ln1118_750_fu_96267_p0.read().is_01() || !mul_ln1118_750_fu_96267_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_750_fu_96267_p0.read()) * sc_bigint<2>(mul_ln1118_750_fu_96267_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_751_fu_96288_p0() {
    mul_ln1118_751_fu_96288_p0 =  (sc_lv<10>) (zext_ln1116_447_fu_94392_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_751_fu_96288_p1() {
    mul_ln1118_751_fu_96288_p1 = tmp_1113_reg_135496.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_751_fu_96288_p2() {
    mul_ln1118_751_fu_96288_p2 = (!mul_ln1118_751_fu_96288_p0.read().is_01() || !mul_ln1118_751_fu_96288_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_751_fu_96288_p0.read()) * sc_bigint<2>(mul_ln1118_751_fu_96288_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_752_fu_96297_p0() {
    mul_ln1118_752_fu_96297_p0 =  (sc_lv<10>) (zext_ln1116_448_fu_94404_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_752_fu_96297_p1() {
    mul_ln1118_752_fu_96297_p1 = tmp_1114_reg_135501.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_752_fu_96297_p2() {
    mul_ln1118_752_fu_96297_p2 = (!mul_ln1118_752_fu_96297_p0.read().is_01() || !mul_ln1118_752_fu_96297_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_752_fu_96297_p0.read()) * sc_bigint<2>(mul_ln1118_752_fu_96297_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_753_fu_96318_p0() {
    mul_ln1118_753_fu_96318_p0 =  (sc_lv<10>) (zext_ln1116_449_fu_94428_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_753_fu_96318_p1() {
    mul_ln1118_753_fu_96318_p1 = tmp_1115_reg_135506.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_753_fu_96318_p2() {
    mul_ln1118_753_fu_96318_p2 = (!mul_ln1118_753_fu_96318_p0.read().is_01() || !mul_ln1118_753_fu_96318_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_753_fu_96318_p0.read()) * sc_bigint<2>(mul_ln1118_753_fu_96318_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_754_fu_96339_p0() {
    mul_ln1118_754_fu_96339_p0 =  (sc_lv<10>) (zext_ln1116_450_fu_94452_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_754_fu_96339_p1() {
    mul_ln1118_754_fu_96339_p1 = tmp_1116_reg_135511.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_754_fu_96339_p2() {
    mul_ln1118_754_fu_96339_p2 = (!mul_ln1118_754_fu_96339_p0.read().is_01() || !mul_ln1118_754_fu_96339_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_754_fu_96339_p0.read()) * sc_bigint<2>(mul_ln1118_754_fu_96339_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_755_fu_96348_p0() {
    mul_ln1118_755_fu_96348_p0 =  (sc_lv<10>) (zext_ln1116_451_fu_94464_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_755_fu_96348_p1() {
    mul_ln1118_755_fu_96348_p1 = tmp_1117_reg_135516.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_755_fu_96348_p2() {
    mul_ln1118_755_fu_96348_p2 = (!mul_ln1118_755_fu_96348_p0.read().is_01() || !mul_ln1118_755_fu_96348_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_755_fu_96348_p0.read()) * sc_bigint<2>(mul_ln1118_755_fu_96348_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_756_fu_96369_p0() {
    mul_ln1118_756_fu_96369_p0 =  (sc_lv<10>) (zext_ln1116_452_fu_94488_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_756_fu_96369_p1() {
    mul_ln1118_756_fu_96369_p1 = tmp_1118_reg_135521.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_756_fu_96369_p2() {
    mul_ln1118_756_fu_96369_p2 = (!mul_ln1118_756_fu_96369_p0.read().is_01() || !mul_ln1118_756_fu_96369_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_756_fu_96369_p0.read()) * sc_bigint<2>(mul_ln1118_756_fu_96369_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_757_fu_96390_p0() {
    mul_ln1118_757_fu_96390_p0 =  (sc_lv<10>) (zext_ln1116_453_fu_94512_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_757_fu_96390_p1() {
    mul_ln1118_757_fu_96390_p1 = tmp_1119_reg_135526.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_757_fu_96390_p2() {
    mul_ln1118_757_fu_96390_p2 = (!mul_ln1118_757_fu_96390_p0.read().is_01() || !mul_ln1118_757_fu_96390_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_757_fu_96390_p0.read()) * sc_bigint<2>(mul_ln1118_757_fu_96390_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_758_fu_96399_p0() {
    mul_ln1118_758_fu_96399_p0 =  (sc_lv<10>) (zext_ln1116_454_fu_94524_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_758_fu_96399_p1() {
    mul_ln1118_758_fu_96399_p1 = tmp_1120_reg_135531.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_758_fu_96399_p2() {
    mul_ln1118_758_fu_96399_p2 = (!mul_ln1118_758_fu_96399_p0.read().is_01() || !mul_ln1118_758_fu_96399_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_758_fu_96399_p0.read()) * sc_bigint<2>(mul_ln1118_758_fu_96399_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_759_fu_96420_p0() {
    mul_ln1118_759_fu_96420_p0 =  (sc_lv<10>) (zext_ln1116_455_fu_94548_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_759_fu_96420_p1() {
    mul_ln1118_759_fu_96420_p1 = tmp_1121_reg_135536.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_759_fu_96420_p2() {
    mul_ln1118_759_fu_96420_p2 = (!mul_ln1118_759_fu_96420_p0.read().is_01() || !mul_ln1118_759_fu_96420_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_759_fu_96420_p0.read()) * sc_bigint<2>(mul_ln1118_759_fu_96420_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_75_fu_81183_p0() {
    mul_ln1118_75_fu_81183_p0 =  (sc_lv<10>) (mul_ln1118_75_fu_81183_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_75_fu_81183_p00() {
    mul_ln1118_75_fu_81183_p00 = esl_zext<12,10>(trunc_ln77_72_reg_129981.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_75_fu_81183_p1() {
    mul_ln1118_75_fu_81183_p1 = tmp_143_reg_129986.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_75_fu_81183_p2() {
    mul_ln1118_75_fu_81183_p2 = (!mul_ln1118_75_fu_81183_p0.read().is_01() || !mul_ln1118_75_fu_81183_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_75_fu_81183_p0.read()) * sc_bigint<2>(mul_ln1118_75_fu_81183_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_760_fu_96633_p0() {
    mul_ln1118_760_fu_96633_p0 =  (sc_lv<10>) (zext_ln1116_456_fu_94764_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_760_fu_96633_p1() {
    mul_ln1118_760_fu_96633_p1 = tmp_1122_reg_135541.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_760_fu_96633_p2() {
    mul_ln1118_760_fu_96633_p2 = (!mul_ln1118_760_fu_96633_p0.read().is_01() || !mul_ln1118_760_fu_96633_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_760_fu_96633_p0.read()) * sc_bigint<2>(mul_ln1118_760_fu_96633_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_761_fu_96654_p0() {
    mul_ln1118_761_fu_96654_p0 =  (sc_lv<10>) (zext_ln1116_457_fu_94788_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_761_fu_96654_p1() {
    mul_ln1118_761_fu_96654_p1 = tmp_1123_reg_135546.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_761_fu_96654_p2() {
    mul_ln1118_761_fu_96654_p2 = (!mul_ln1118_761_fu_96654_p0.read().is_01() || !mul_ln1118_761_fu_96654_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_761_fu_96654_p0.read()) * sc_bigint<2>(mul_ln1118_761_fu_96654_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_762_fu_96675_p0() {
    mul_ln1118_762_fu_96675_p0 =  (sc_lv<10>) (zext_ln1116_458_fu_94812_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_762_fu_96675_p1() {
    mul_ln1118_762_fu_96675_p1 = tmp_1124_reg_135551.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_762_fu_96675_p2() {
    mul_ln1118_762_fu_96675_p2 = (!mul_ln1118_762_fu_96675_p0.read().is_01() || !mul_ln1118_762_fu_96675_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_762_fu_96675_p0.read()) * sc_bigint<2>(mul_ln1118_762_fu_96675_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_763_fu_96684_p0() {
    mul_ln1118_763_fu_96684_p0 =  (sc_lv<10>) (zext_ln1116_459_fu_94824_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_763_fu_96684_p1() {
    mul_ln1118_763_fu_96684_p1 = tmp_1125_reg_135556.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_763_fu_96684_p2() {
    mul_ln1118_763_fu_96684_p2 = (!mul_ln1118_763_fu_96684_p0.read().is_01() || !mul_ln1118_763_fu_96684_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_763_fu_96684_p0.read()) * sc_bigint<2>(mul_ln1118_763_fu_96684_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_764_fu_96705_p0() {
    mul_ln1118_764_fu_96705_p0 =  (sc_lv<10>) (zext_ln1116_460_fu_94848_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_764_fu_96705_p1() {
    mul_ln1118_764_fu_96705_p1 = tmp_1126_reg_135561.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_764_fu_96705_p2() {
    mul_ln1118_764_fu_96705_p2 = (!mul_ln1118_764_fu_96705_p0.read().is_01() || !mul_ln1118_764_fu_96705_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_764_fu_96705_p0.read()) * sc_bigint<2>(mul_ln1118_764_fu_96705_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_765_fu_96726_p0() {
    mul_ln1118_765_fu_96726_p0 =  (sc_lv<10>) (zext_ln1116_461_fu_94872_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_765_fu_96726_p1() {
    mul_ln1118_765_fu_96726_p1 = tmp_1127_reg_135566.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_765_fu_96726_p2() {
    mul_ln1118_765_fu_96726_p2 = (!mul_ln1118_765_fu_96726_p0.read().is_01() || !mul_ln1118_765_fu_96726_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_765_fu_96726_p0.read()) * sc_bigint<2>(mul_ln1118_765_fu_96726_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_766_fu_96747_p0() {
    mul_ln1118_766_fu_96747_p0 =  (sc_lv<10>) (zext_ln1116_462_fu_94896_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_766_fu_96747_p1() {
    mul_ln1118_766_fu_96747_p1 = tmp_1128_reg_135571.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_766_fu_96747_p2() {
    mul_ln1118_766_fu_96747_p2 = (!mul_ln1118_766_fu_96747_p0.read().is_01() || !mul_ln1118_766_fu_96747_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_766_fu_96747_p0.read()) * sc_bigint<2>(mul_ln1118_766_fu_96747_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_767_fu_96768_p0() {
    mul_ln1118_767_fu_96768_p0 =  (sc_lv<10>) (zext_ln1116_463_fu_94920_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_767_fu_96768_p1() {
    mul_ln1118_767_fu_96768_p1 = tmp_1129_reg_135576.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_767_fu_96768_p2() {
    mul_ln1118_767_fu_96768_p2 = (!mul_ln1118_767_fu_96768_p0.read().is_01() || !mul_ln1118_767_fu_96768_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_767_fu_96768_p0.read()) * sc_bigint<2>(mul_ln1118_767_fu_96768_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_768_fu_96777_p0() {
    mul_ln1118_768_fu_96777_p0 =  (sc_lv<10>) (zext_ln1116_464_fu_94932_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_768_fu_96777_p1() {
    mul_ln1118_768_fu_96777_p1 = tmp_1130_reg_135581.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_768_fu_96777_p2() {
    mul_ln1118_768_fu_96777_p2 = (!mul_ln1118_768_fu_96777_p0.read().is_01() || !mul_ln1118_768_fu_96777_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_768_fu_96777_p0.read()) * sc_bigint<2>(mul_ln1118_768_fu_96777_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_769_fu_96798_p0() {
    mul_ln1118_769_fu_96798_p0 =  (sc_lv<10>) (zext_ln1116_465_fu_94956_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_769_fu_96798_p1() {
    mul_ln1118_769_fu_96798_p1 = tmp_1131_reg_135586.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_769_fu_96798_p2() {
    mul_ln1118_769_fu_96798_p2 = (!mul_ln1118_769_fu_96798_p0.read().is_01() || !mul_ln1118_769_fu_96798_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_769_fu_96798_p0.read()) * sc_bigint<2>(mul_ln1118_769_fu_96798_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_76_fu_81207_p0() {
    mul_ln1118_76_fu_81207_p0 =  (sc_lv<10>) (mul_ln1118_76_fu_81207_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_76_fu_81207_p00() {
    mul_ln1118_76_fu_81207_p00 = esl_zext<12,10>(trunc_ln77_73_reg_129991.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_76_fu_81207_p1() {
    mul_ln1118_76_fu_81207_p1 = tmp_145_reg_129996.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_76_fu_81207_p2() {
    mul_ln1118_76_fu_81207_p2 = (!mul_ln1118_76_fu_81207_p0.read().is_01() || !mul_ln1118_76_fu_81207_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_76_fu_81207_p0.read()) * sc_bigint<2>(mul_ln1118_76_fu_81207_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_770_fu_96819_p0() {
    mul_ln1118_770_fu_96819_p0 =  (sc_lv<10>) (zext_ln1116_466_fu_94980_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_770_fu_96819_p1() {
    mul_ln1118_770_fu_96819_p1 = tmp_1132_reg_135591.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_770_fu_96819_p2() {
    mul_ln1118_770_fu_96819_p2 = (!mul_ln1118_770_fu_96819_p0.read().is_01() || !mul_ln1118_770_fu_96819_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_770_fu_96819_p0.read()) * sc_bigint<2>(mul_ln1118_770_fu_96819_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_771_fu_96840_p0() {
    mul_ln1118_771_fu_96840_p0 =  (sc_lv<10>) (zext_ln1116_467_fu_95004_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_771_fu_96840_p1() {
    mul_ln1118_771_fu_96840_p1 = tmp_1133_reg_135596.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_771_fu_96840_p2() {
    mul_ln1118_771_fu_96840_p2 = (!mul_ln1118_771_fu_96840_p0.read().is_01() || !mul_ln1118_771_fu_96840_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_771_fu_96840_p0.read()) * sc_bigint<2>(mul_ln1118_771_fu_96840_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_772_fu_96861_p0() {
    mul_ln1118_772_fu_96861_p0 =  (sc_lv<10>) (zext_ln1116_468_fu_95028_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_772_fu_96861_p1() {
    mul_ln1118_772_fu_96861_p1 = tmp_1134_reg_135601.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_772_fu_96861_p2() {
    mul_ln1118_772_fu_96861_p2 = (!mul_ln1118_772_fu_96861_p0.read().is_01() || !mul_ln1118_772_fu_96861_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_772_fu_96861_p0.read()) * sc_bigint<2>(mul_ln1118_772_fu_96861_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_773_fu_96870_p0() {
    mul_ln1118_773_fu_96870_p0 =  (sc_lv<10>) (zext_ln1116_469_fu_95040_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_773_fu_96870_p1() {
    mul_ln1118_773_fu_96870_p1 = tmp_1135_reg_135606.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_773_fu_96870_p2() {
    mul_ln1118_773_fu_96870_p2 = (!mul_ln1118_773_fu_96870_p0.read().is_01() || !mul_ln1118_773_fu_96870_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_773_fu_96870_p0.read()) * sc_bigint<2>(mul_ln1118_773_fu_96870_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_774_fu_96891_p0() {
    mul_ln1118_774_fu_96891_p0 =  (sc_lv<10>) (zext_ln1116_470_fu_95064_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_774_fu_96891_p1() {
    mul_ln1118_774_fu_96891_p1 = tmp_1136_reg_135611.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_774_fu_96891_p2() {
    mul_ln1118_774_fu_96891_p2 = (!mul_ln1118_774_fu_96891_p0.read().is_01() || !mul_ln1118_774_fu_96891_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_774_fu_96891_p0.read()) * sc_bigint<2>(mul_ln1118_774_fu_96891_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_775_fu_96912_p0() {
    mul_ln1118_775_fu_96912_p0 =  (sc_lv<10>) (zext_ln1116_471_fu_95088_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_775_fu_96912_p1() {
    mul_ln1118_775_fu_96912_p1 = tmp_1137_reg_135616.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_775_fu_96912_p2() {
    mul_ln1118_775_fu_96912_p2 = (!mul_ln1118_775_fu_96912_p0.read().is_01() || !mul_ln1118_775_fu_96912_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_775_fu_96912_p0.read()) * sc_bigint<2>(mul_ln1118_775_fu_96912_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_776_fu_96921_p0() {
    mul_ln1118_776_fu_96921_p0 =  (sc_lv<10>) (zext_ln1116_472_fu_95100_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_776_fu_96921_p1() {
    mul_ln1118_776_fu_96921_p1 = tmp_1138_reg_135621.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_776_fu_96921_p2() {
    mul_ln1118_776_fu_96921_p2 = (!mul_ln1118_776_fu_96921_p0.read().is_01() || !mul_ln1118_776_fu_96921_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_776_fu_96921_p0.read()) * sc_bigint<2>(mul_ln1118_776_fu_96921_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_777_fu_96942_p0() {
    mul_ln1118_777_fu_96942_p0 =  (sc_lv<10>) (zext_ln1116_473_fu_95124_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_777_fu_96942_p1() {
    mul_ln1118_777_fu_96942_p1 = tmp_1139_reg_135626.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_777_fu_96942_p2() {
    mul_ln1118_777_fu_96942_p2 = (!mul_ln1118_777_fu_96942_p0.read().is_01() || !mul_ln1118_777_fu_96942_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_777_fu_96942_p0.read()) * sc_bigint<2>(mul_ln1118_777_fu_96942_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_778_fu_96963_p0() {
    mul_ln1118_778_fu_96963_p0 =  (sc_lv<10>) (zext_ln1116_474_fu_95148_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_778_fu_96963_p1() {
    mul_ln1118_778_fu_96963_p1 = tmp_1140_reg_135631.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_778_fu_96963_p2() {
    mul_ln1118_778_fu_96963_p2 = (!mul_ln1118_778_fu_96963_p0.read().is_01() || !mul_ln1118_778_fu_96963_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_778_fu_96963_p0.read()) * sc_bigint<2>(mul_ln1118_778_fu_96963_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_779_fu_96972_p0() {
    mul_ln1118_779_fu_96972_p0 =  (sc_lv<10>) (zext_ln1116_475_fu_95160_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_779_fu_96972_p1() {
    mul_ln1118_779_fu_96972_p1 = tmp_1141_reg_135636.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_779_fu_96972_p2() {
    mul_ln1118_779_fu_96972_p2 = (!mul_ln1118_779_fu_96972_p0.read().is_01() || !mul_ln1118_779_fu_96972_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_779_fu_96972_p0.read()) * sc_bigint<2>(mul_ln1118_779_fu_96972_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_77_fu_81231_p0() {
    mul_ln1118_77_fu_81231_p0 =  (sc_lv<10>) (mul_ln1118_77_fu_81231_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_77_fu_81231_p00() {
    mul_ln1118_77_fu_81231_p00 = esl_zext<12,10>(trunc_ln77_74_reg_130001.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_77_fu_81231_p1() {
    mul_ln1118_77_fu_81231_p1 = tmp_147_reg_130006.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_77_fu_81231_p2() {
    mul_ln1118_77_fu_81231_p2 = (!mul_ln1118_77_fu_81231_p0.read().is_01() || !mul_ln1118_77_fu_81231_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_77_fu_81231_p0.read()) * sc_bigint<2>(mul_ln1118_77_fu_81231_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_780_fu_96993_p0() {
    mul_ln1118_780_fu_96993_p0 =  (sc_lv<10>) (zext_ln1116_476_fu_95184_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_780_fu_96993_p1() {
    mul_ln1118_780_fu_96993_p1 = tmp_1142_reg_135641.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_780_fu_96993_p2() {
    mul_ln1118_780_fu_96993_p2 = (!mul_ln1118_780_fu_96993_p0.read().is_01() || !mul_ln1118_780_fu_96993_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_780_fu_96993_p0.read()) * sc_bigint<2>(mul_ln1118_780_fu_96993_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_781_fu_97017_p0() {
    mul_ln1118_781_fu_97017_p0 =  (sc_lv<10>) (zext_ln1116_506_fu_97011_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_781_fu_97017_p1() {
    mul_ln1118_781_fu_97017_p1 = tmp_1144_reg_135651.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_781_fu_97017_p2() {
    mul_ln1118_781_fu_97017_p2 = (!mul_ln1118_781_fu_97017_p0.read().is_01() || !mul_ln1118_781_fu_97017_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_781_fu_97017_p0.read()) * sc_bigint<2>(mul_ln1118_781_fu_97017_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_782_fu_97041_p0() {
    mul_ln1118_782_fu_97041_p0 =  (sc_lv<10>) (zext_ln1116_507_fu_97035_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_782_fu_97041_p1() {
    mul_ln1118_782_fu_97041_p1 = tmp_1146_reg_135661.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_782_fu_97041_p2() {
    mul_ln1118_782_fu_97041_p2 = (!mul_ln1118_782_fu_97041_p0.read().is_01() || !mul_ln1118_782_fu_97041_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_782_fu_97041_p0.read()) * sc_bigint<2>(mul_ln1118_782_fu_97041_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_783_fu_97065_p0() {
    mul_ln1118_783_fu_97065_p0 =  (sc_lv<10>) (zext_ln1116_508_fu_97059_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_783_fu_97065_p1() {
    mul_ln1118_783_fu_97065_p1 = tmp_1148_reg_135671.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_783_fu_97065_p2() {
    mul_ln1118_783_fu_97065_p2 = (!mul_ln1118_783_fu_97065_p0.read().is_01() || !mul_ln1118_783_fu_97065_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_783_fu_97065_p0.read()) * sc_bigint<2>(mul_ln1118_783_fu_97065_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_784_fu_97077_p0() {
    mul_ln1118_784_fu_97077_p0 =  (sc_lv<10>) (zext_ln1116_509_fu_97071_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_784_fu_97077_p1() {
    mul_ln1118_784_fu_97077_p1 = tmp_1150_reg_135681.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_784_fu_97077_p2() {
    mul_ln1118_784_fu_97077_p2 = (!mul_ln1118_784_fu_97077_p0.read().is_01() || !mul_ln1118_784_fu_97077_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_784_fu_97077_p0.read()) * sc_bigint<2>(mul_ln1118_784_fu_97077_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_785_fu_97101_p0() {
    mul_ln1118_785_fu_97101_p0 =  (sc_lv<10>) (zext_ln1116_510_fu_97095_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_785_fu_97101_p1() {
    mul_ln1118_785_fu_97101_p1 = tmp_1152_reg_135691.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_785_fu_97101_p2() {
    mul_ln1118_785_fu_97101_p2 = (!mul_ln1118_785_fu_97101_p0.read().is_01() || !mul_ln1118_785_fu_97101_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_785_fu_97101_p0.read()) * sc_bigint<2>(mul_ln1118_785_fu_97101_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_786_fu_97125_p0() {
    mul_ln1118_786_fu_97125_p0 =  (sc_lv<10>) (zext_ln1116_511_fu_97119_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_786_fu_97125_p1() {
    mul_ln1118_786_fu_97125_p1 = tmp_1154_reg_135701.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_786_fu_97125_p2() {
    mul_ln1118_786_fu_97125_p2 = (!mul_ln1118_786_fu_97125_p0.read().is_01() || !mul_ln1118_786_fu_97125_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_786_fu_97125_p0.read()) * sc_bigint<2>(mul_ln1118_786_fu_97125_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_787_fu_97149_p0() {
    mul_ln1118_787_fu_97149_p0 =  (sc_lv<10>) (zext_ln1116_512_fu_97143_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_787_fu_97149_p1() {
    mul_ln1118_787_fu_97149_p1 = tmp_1156_reg_135711.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_787_fu_97149_p2() {
    mul_ln1118_787_fu_97149_p2 = (!mul_ln1118_787_fu_97149_p0.read().is_01() || !mul_ln1118_787_fu_97149_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_787_fu_97149_p0.read()) * sc_bigint<2>(mul_ln1118_787_fu_97149_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_788_fu_97173_p0() {
    mul_ln1118_788_fu_97173_p0 =  (sc_lv<10>) (zext_ln1116_513_fu_97167_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_788_fu_97173_p1() {
    mul_ln1118_788_fu_97173_p1 = tmp_1158_reg_135721.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_788_fu_97173_p2() {
    mul_ln1118_788_fu_97173_p2 = (!mul_ln1118_788_fu_97173_p0.read().is_01() || !mul_ln1118_788_fu_97173_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_788_fu_97173_p0.read()) * sc_bigint<2>(mul_ln1118_788_fu_97173_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_789_fu_97185_p0() {
    mul_ln1118_789_fu_97185_p0 =  (sc_lv<10>) (zext_ln1116_514_fu_97179_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_789_fu_97185_p1() {
    mul_ln1118_789_fu_97185_p1 = tmp_1160_reg_135731.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_789_fu_97185_p2() {
    mul_ln1118_789_fu_97185_p2 = (!mul_ln1118_789_fu_97185_p0.read().is_01() || !mul_ln1118_789_fu_97185_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_789_fu_97185_p0.read()) * sc_bigint<2>(mul_ln1118_789_fu_97185_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_78_fu_81255_p0() {
    mul_ln1118_78_fu_81255_p0 =  (sc_lv<10>) (mul_ln1118_78_fu_81255_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_78_fu_81255_p00() {
    mul_ln1118_78_fu_81255_p00 = esl_zext<12,10>(trunc_ln77_75_reg_130011.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_78_fu_81255_p1() {
    mul_ln1118_78_fu_81255_p1 = tmp_149_reg_130016.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_78_fu_81255_p2() {
    mul_ln1118_78_fu_81255_p2 = (!mul_ln1118_78_fu_81255_p0.read().is_01() || !mul_ln1118_78_fu_81255_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_78_fu_81255_p0.read()) * sc_bigint<2>(mul_ln1118_78_fu_81255_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_790_fu_97209_p0() {
    mul_ln1118_790_fu_97209_p0 =  (sc_lv<10>) (zext_ln1116_515_fu_97203_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_790_fu_97209_p1() {
    mul_ln1118_790_fu_97209_p1 = tmp_1162_reg_135741.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_790_fu_97209_p2() {
    mul_ln1118_790_fu_97209_p2 = (!mul_ln1118_790_fu_97209_p0.read().is_01() || !mul_ln1118_790_fu_97209_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_790_fu_97209_p0.read()) * sc_bigint<2>(mul_ln1118_790_fu_97209_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_791_fu_97233_p0() {
    mul_ln1118_791_fu_97233_p0 =  (sc_lv<10>) (zext_ln1116_516_fu_97227_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_791_fu_97233_p1() {
    mul_ln1118_791_fu_97233_p1 = tmp_1164_reg_135751.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_791_fu_97233_p2() {
    mul_ln1118_791_fu_97233_p2 = (!mul_ln1118_791_fu_97233_p0.read().is_01() || !mul_ln1118_791_fu_97233_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_791_fu_97233_p0.read()) * sc_bigint<2>(mul_ln1118_791_fu_97233_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_792_fu_97257_p0() {
    mul_ln1118_792_fu_97257_p0 =  (sc_lv<10>) (zext_ln1116_517_fu_97251_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_792_fu_97257_p1() {
    mul_ln1118_792_fu_97257_p1 = tmp_1166_reg_135761.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_792_fu_97257_p2() {
    mul_ln1118_792_fu_97257_p2 = (!mul_ln1118_792_fu_97257_p0.read().is_01() || !mul_ln1118_792_fu_97257_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_792_fu_97257_p0.read()) * sc_bigint<2>(mul_ln1118_792_fu_97257_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_793_fu_97281_p0() {
    mul_ln1118_793_fu_97281_p0 =  (sc_lv<10>) (zext_ln1116_518_fu_97275_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_793_fu_97281_p1() {
    mul_ln1118_793_fu_97281_p1 = tmp_1168_reg_135771.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_793_fu_97281_p2() {
    mul_ln1118_793_fu_97281_p2 = (!mul_ln1118_793_fu_97281_p0.read().is_01() || !mul_ln1118_793_fu_97281_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_793_fu_97281_p0.read()) * sc_bigint<2>(mul_ln1118_793_fu_97281_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_794_fu_97293_p0() {
    mul_ln1118_794_fu_97293_p0 =  (sc_lv<10>) (zext_ln1116_519_fu_97287_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_794_fu_97293_p1() {
    mul_ln1118_794_fu_97293_p1 = tmp_1169_reg_135781.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_794_fu_97293_p2() {
    mul_ln1118_794_fu_97293_p2 = (!mul_ln1118_794_fu_97293_p0.read().is_01() || !mul_ln1118_794_fu_97293_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_794_fu_97293_p0.read()) * sc_bigint<2>(mul_ln1118_794_fu_97293_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_795_fu_97317_p0() {
    mul_ln1118_795_fu_97317_p0 =  (sc_lv<10>) (zext_ln1116_520_fu_97311_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_795_fu_97317_p1() {
    mul_ln1118_795_fu_97317_p1 = tmp_1170_reg_135791.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_795_fu_97317_p2() {
    mul_ln1118_795_fu_97317_p2 = (!mul_ln1118_795_fu_97317_p0.read().is_01() || !mul_ln1118_795_fu_97317_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_795_fu_97317_p0.read()) * sc_bigint<2>(mul_ln1118_795_fu_97317_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_796_fu_97341_p0() {
    mul_ln1118_796_fu_97341_p0 =  (sc_lv<10>) (zext_ln1116_521_fu_97335_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_796_fu_97341_p1() {
    mul_ln1118_796_fu_97341_p1 = tmp_1171_reg_135801.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_796_fu_97341_p2() {
    mul_ln1118_796_fu_97341_p2 = (!mul_ln1118_796_fu_97341_p0.read().is_01() || !mul_ln1118_796_fu_97341_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_796_fu_97341_p0.read()) * sc_bigint<2>(mul_ln1118_796_fu_97341_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_797_fu_97353_p0() {
    mul_ln1118_797_fu_97353_p0 =  (sc_lv<10>) (zext_ln1116_522_fu_97347_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_797_fu_97353_p1() {
    mul_ln1118_797_fu_97353_p1 = tmp_1172_reg_135811.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_797_fu_97353_p2() {
    mul_ln1118_797_fu_97353_p2 = (!mul_ln1118_797_fu_97353_p0.read().is_01() || !mul_ln1118_797_fu_97353_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_797_fu_97353_p0.read()) * sc_bigint<2>(mul_ln1118_797_fu_97353_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_798_fu_97377_p0() {
    mul_ln1118_798_fu_97377_p0 =  (sc_lv<10>) (zext_ln1116_523_fu_97371_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_798_fu_97377_p1() {
    mul_ln1118_798_fu_97377_p1 = tmp_1173_reg_135821.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_798_fu_97377_p2() {
    mul_ln1118_798_fu_97377_p2 = (!mul_ln1118_798_fu_97377_p0.read().is_01() || !mul_ln1118_798_fu_97377_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_798_fu_97377_p0.read()) * sc_bigint<2>(mul_ln1118_798_fu_97377_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_799_fu_97401_p0() {
    mul_ln1118_799_fu_97401_p0 =  (sc_lv<10>) (zext_ln1116_524_fu_97395_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_799_fu_97401_p1() {
    mul_ln1118_799_fu_97401_p1 = tmp_1174_reg_135831.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_799_fu_97401_p2() {
    mul_ln1118_799_fu_97401_p2 = (!mul_ln1118_799_fu_97401_p0.read().is_01() || !mul_ln1118_799_fu_97401_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_799_fu_97401_p0.read()) * sc_bigint<2>(mul_ln1118_799_fu_97401_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_79_fu_81279_p0() {
    mul_ln1118_79_fu_81279_p0 =  (sc_lv<10>) (mul_ln1118_79_fu_81279_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_79_fu_81279_p00() {
    mul_ln1118_79_fu_81279_p00 = esl_zext<12,10>(trunc_ln77_76_reg_130021.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_79_fu_81279_p1() {
    mul_ln1118_79_fu_81279_p1 = tmp_151_reg_130026.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_79_fu_81279_p2() {
    mul_ln1118_79_fu_81279_p2 = (!mul_ln1118_79_fu_81279_p0.read().is_01() || !mul_ln1118_79_fu_81279_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_79_fu_81279_p0.read()) * sc_bigint<2>(mul_ln1118_79_fu_81279_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_7_fu_79743_p0() {
    mul_ln1118_7_fu_79743_p0 =  (sc_lv<10>) (mul_ln1118_7_fu_79743_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_7_fu_79743_p00() {
    mul_ln1118_7_fu_79743_p00 = esl_zext<12,10>(trunc_ln77_4_reg_129301.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_7_fu_79743_p1() {
    mul_ln1118_7_fu_79743_p1 = tmp_3_reg_129306.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_7_fu_79743_p2() {
    mul_ln1118_7_fu_79743_p2 = (!mul_ln1118_7_fu_79743_p0.read().is_01() || !mul_ln1118_7_fu_79743_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_7_fu_79743_p0.read()) * sc_bigint<2>(mul_ln1118_7_fu_79743_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_800_fu_97413_p0() {
    mul_ln1118_800_fu_97413_p0 =  (sc_lv<10>) (zext_ln1116_525_fu_97407_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_800_fu_97413_p1() {
    mul_ln1118_800_fu_97413_p1 = tmp_1175_reg_135841.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_800_fu_97413_p2() {
    mul_ln1118_800_fu_97413_p2 = (!mul_ln1118_800_fu_97413_p0.read().is_01() || !mul_ln1118_800_fu_97413_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_800_fu_97413_p0.read()) * sc_bigint<2>(mul_ln1118_800_fu_97413_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_801_fu_97437_p0() {
    mul_ln1118_801_fu_97437_p0 =  (sc_lv<10>) (zext_ln1116_526_fu_97431_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_801_fu_97437_p1() {
    mul_ln1118_801_fu_97437_p1 = tmp_1176_reg_135851.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_801_fu_97437_p2() {
    mul_ln1118_801_fu_97437_p2 = (!mul_ln1118_801_fu_97437_p0.read().is_01() || !mul_ln1118_801_fu_97437_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_801_fu_97437_p0.read()) * sc_bigint<2>(mul_ln1118_801_fu_97437_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_802_fu_97461_p0() {
    mul_ln1118_802_fu_97461_p0 =  (sc_lv<10>) (zext_ln1116_527_fu_97455_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_802_fu_97461_p1() {
    mul_ln1118_802_fu_97461_p1 = tmp_1178_reg_135861.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_802_fu_97461_p2() {
    mul_ln1118_802_fu_97461_p2 = (!mul_ln1118_802_fu_97461_p0.read().is_01() || !mul_ln1118_802_fu_97461_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_802_fu_97461_p0.read()) * sc_bigint<2>(mul_ln1118_802_fu_97461_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_803_fu_97485_p0() {
    mul_ln1118_803_fu_97485_p0 =  (sc_lv<10>) (zext_ln1116_528_fu_97479_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_803_fu_97485_p1() {
    mul_ln1118_803_fu_97485_p1 = tmp_1180_reg_135871.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_803_fu_97485_p2() {
    mul_ln1118_803_fu_97485_p2 = (!mul_ln1118_803_fu_97485_p0.read().is_01() || !mul_ln1118_803_fu_97485_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_803_fu_97485_p0.read()) * sc_bigint<2>(mul_ln1118_803_fu_97485_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_804_fu_97509_p0() {
    mul_ln1118_804_fu_97509_p0 =  (sc_lv<10>) (zext_ln1116_529_fu_97503_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_804_fu_97509_p1() {
    mul_ln1118_804_fu_97509_p1 = tmp_1182_reg_135881.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_804_fu_97509_p2() {
    mul_ln1118_804_fu_97509_p2 = (!mul_ln1118_804_fu_97509_p0.read().is_01() || !mul_ln1118_804_fu_97509_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_804_fu_97509_p0.read()) * sc_bigint<2>(mul_ln1118_804_fu_97509_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_805_fu_97521_p0() {
    mul_ln1118_805_fu_97521_p0 =  (sc_lv<10>) (zext_ln1116_530_fu_97515_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_805_fu_97521_p1() {
    mul_ln1118_805_fu_97521_p1 = tmp_1184_reg_135891.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_805_fu_97521_p2() {
    mul_ln1118_805_fu_97521_p2 = (!mul_ln1118_805_fu_97521_p0.read().is_01() || !mul_ln1118_805_fu_97521_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_805_fu_97521_p0.read()) * sc_bigint<2>(mul_ln1118_805_fu_97521_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_806_fu_97545_p0() {
    mul_ln1118_806_fu_97545_p0 =  (sc_lv<10>) (zext_ln1116_531_fu_97539_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_806_fu_97545_p1() {
    mul_ln1118_806_fu_97545_p1 = tmp_1186_reg_135901.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_806_fu_97545_p2() {
    mul_ln1118_806_fu_97545_p2 = (!mul_ln1118_806_fu_97545_p0.read().is_01() || !mul_ln1118_806_fu_97545_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_806_fu_97545_p0.read()) * sc_bigint<2>(mul_ln1118_806_fu_97545_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_807_fu_97569_p0() {
    mul_ln1118_807_fu_97569_p0 =  (sc_lv<10>) (zext_ln1116_532_fu_97563_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_807_fu_97569_p1() {
    mul_ln1118_807_fu_97569_p1 = tmp_1188_reg_135911.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_807_fu_97569_p2() {
    mul_ln1118_807_fu_97569_p2 = (!mul_ln1118_807_fu_97569_p0.read().is_01() || !mul_ln1118_807_fu_97569_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_807_fu_97569_p0.read()) * sc_bigint<2>(mul_ln1118_807_fu_97569_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_808_fu_97593_p0() {
    mul_ln1118_808_fu_97593_p0 =  (sc_lv<10>) (zext_ln1116_533_fu_97587_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_808_fu_97593_p1() {
    mul_ln1118_808_fu_97593_p1 = tmp_1190_reg_135921.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_808_fu_97593_p2() {
    mul_ln1118_808_fu_97593_p2 = (!mul_ln1118_808_fu_97593_p0.read().is_01() || !mul_ln1118_808_fu_97593_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_808_fu_97593_p0.read()) * sc_bigint<2>(mul_ln1118_808_fu_97593_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_809_fu_97617_p0() {
    mul_ln1118_809_fu_97617_p0 =  (sc_lv<10>) (zext_ln1116_534_fu_97611_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_809_fu_97617_p1() {
    mul_ln1118_809_fu_97617_p1 = tmp_1192_reg_135931.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_809_fu_97617_p2() {
    mul_ln1118_809_fu_97617_p2 = (!mul_ln1118_809_fu_97617_p0.read().is_01() || !mul_ln1118_809_fu_97617_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_809_fu_97617_p0.read()) * sc_bigint<2>(mul_ln1118_809_fu_97617_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_80_fu_81291_p0() {
    mul_ln1118_80_fu_81291_p0 =  (sc_lv<10>) (mul_ln1118_80_fu_81291_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_80_fu_81291_p00() {
    mul_ln1118_80_fu_81291_p00 = esl_zext<12,10>(trunc_ln77_77_reg_130031.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_80_fu_81291_p1() {
    mul_ln1118_80_fu_81291_p1 = tmp_153_reg_130036.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_80_fu_81291_p2() {
    mul_ln1118_80_fu_81291_p2 = (!mul_ln1118_80_fu_81291_p0.read().is_01() || !mul_ln1118_80_fu_81291_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_80_fu_81291_p0.read()) * sc_bigint<2>(mul_ln1118_80_fu_81291_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_810_fu_97629_p0() {
    mul_ln1118_810_fu_97629_p0 =  (sc_lv<10>) (zext_ln1116_535_fu_97623_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_810_fu_97629_p1() {
    mul_ln1118_810_fu_97629_p1 = tmp_1194_reg_135941.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_810_fu_97629_p2() {
    mul_ln1118_810_fu_97629_p2 = (!mul_ln1118_810_fu_97629_p0.read().is_01() || !mul_ln1118_810_fu_97629_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_810_fu_97629_p0.read()) * sc_bigint<2>(mul_ln1118_810_fu_97629_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_811_fu_97653_p0() {
    mul_ln1118_811_fu_97653_p0 =  (sc_lv<10>) (zext_ln1116_536_fu_97647_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_811_fu_97653_p1() {
    mul_ln1118_811_fu_97653_p1 = tmp_1196_reg_135951.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_811_fu_97653_p2() {
    mul_ln1118_811_fu_97653_p2 = (!mul_ln1118_811_fu_97653_p0.read().is_01() || !mul_ln1118_811_fu_97653_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_811_fu_97653_p0.read()) * sc_bigint<2>(mul_ln1118_811_fu_97653_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_812_fu_97677_p0() {
    mul_ln1118_812_fu_97677_p0 =  (sc_lv<10>) (zext_ln1116_537_fu_97671_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_812_fu_97677_p1() {
    mul_ln1118_812_fu_97677_p1 = tmp_1198_reg_135961.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_812_fu_97677_p2() {
    mul_ln1118_812_fu_97677_p2 = (!mul_ln1118_812_fu_97677_p0.read().is_01() || !mul_ln1118_812_fu_97677_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_812_fu_97677_p0.read()) * sc_bigint<2>(mul_ln1118_812_fu_97677_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_813_fu_97701_p0() {
    mul_ln1118_813_fu_97701_p0 =  (sc_lv<10>) (zext_ln1116_538_fu_97695_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_813_fu_97701_p1() {
    mul_ln1118_813_fu_97701_p1 = tmp_1200_reg_135971.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_813_fu_97701_p2() {
    mul_ln1118_813_fu_97701_p2 = (!mul_ln1118_813_fu_97701_p0.read().is_01() || !mul_ln1118_813_fu_97701_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_813_fu_97701_p0.read()) * sc_bigint<2>(mul_ln1118_813_fu_97701_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_814_fu_97725_p0() {
    mul_ln1118_814_fu_97725_p0 =  (sc_lv<10>) (zext_ln1116_539_fu_97719_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_814_fu_97725_p1() {
    mul_ln1118_814_fu_97725_p1 = tmp_1202_reg_135981.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_814_fu_97725_p2() {
    mul_ln1118_814_fu_97725_p2 = (!mul_ln1118_814_fu_97725_p0.read().is_01() || !mul_ln1118_814_fu_97725_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_814_fu_97725_p0.read()) * sc_bigint<2>(mul_ln1118_814_fu_97725_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_815_fu_97737_p0() {
    mul_ln1118_815_fu_97737_p0 =  (sc_lv<10>) (zext_ln1116_540_fu_97731_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_815_fu_97737_p1() {
    mul_ln1118_815_fu_97737_p1 = tmp_1204_reg_135991.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_815_fu_97737_p2() {
    mul_ln1118_815_fu_97737_p2 = (!mul_ln1118_815_fu_97737_p0.read().is_01() || !mul_ln1118_815_fu_97737_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_815_fu_97737_p0.read()) * sc_bigint<2>(mul_ln1118_815_fu_97737_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_816_fu_97761_p0() {
    mul_ln1118_816_fu_97761_p0 =  (sc_lv<10>) (zext_ln1116_541_fu_97755_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_816_fu_97761_p1() {
    mul_ln1118_816_fu_97761_p1 = tmp_1206_reg_136001.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_816_fu_97761_p2() {
    mul_ln1118_816_fu_97761_p2 = (!mul_ln1118_816_fu_97761_p0.read().is_01() || !mul_ln1118_816_fu_97761_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_816_fu_97761_p0.read()) * sc_bigint<2>(mul_ln1118_816_fu_97761_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_817_fu_97785_p0() {
    mul_ln1118_817_fu_97785_p0 =  (sc_lv<10>) (zext_ln1116_542_fu_97779_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_817_fu_97785_p1() {
    mul_ln1118_817_fu_97785_p1 = tmp_1208_reg_136011.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_817_fu_97785_p2() {
    mul_ln1118_817_fu_97785_p2 = (!mul_ln1118_817_fu_97785_p0.read().is_01() || !mul_ln1118_817_fu_97785_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_817_fu_97785_p0.read()) * sc_bigint<2>(mul_ln1118_817_fu_97785_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_818_fu_97797_p0() {
    mul_ln1118_818_fu_97797_p0 =  (sc_lv<10>) (zext_ln1116_543_fu_97791_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_818_fu_97797_p1() {
    mul_ln1118_818_fu_97797_p1 = tmp_1210_reg_136021.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_818_fu_97797_p2() {
    mul_ln1118_818_fu_97797_p2 = (!mul_ln1118_818_fu_97797_p0.read().is_01() || !mul_ln1118_818_fu_97797_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_818_fu_97797_p0.read()) * sc_bigint<2>(mul_ln1118_818_fu_97797_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_819_fu_97821_p0() {
    mul_ln1118_819_fu_97821_p0 =  (sc_lv<10>) (zext_ln1116_544_fu_97815_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_819_fu_97821_p1() {
    mul_ln1118_819_fu_97821_p1 = tmp_1212_reg_136031.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_819_fu_97821_p2() {
    mul_ln1118_819_fu_97821_p2 = (!mul_ln1118_819_fu_97821_p0.read().is_01() || !mul_ln1118_819_fu_97821_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_819_fu_97821_p0.read()) * sc_bigint<2>(mul_ln1118_819_fu_97821_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_81_fu_81315_p0() {
    mul_ln1118_81_fu_81315_p0 =  (sc_lv<10>) (mul_ln1118_81_fu_81315_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_81_fu_81315_p00() {
    mul_ln1118_81_fu_81315_p00 = esl_zext<12,10>(trunc_ln77_78_reg_130041.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_81_fu_81315_p1() {
    mul_ln1118_81_fu_81315_p1 = tmp_155_reg_130046.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_81_fu_81315_p2() {
    mul_ln1118_81_fu_81315_p2 = (!mul_ln1118_81_fu_81315_p0.read().is_01() || !mul_ln1118_81_fu_81315_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_81_fu_81315_p0.read()) * sc_bigint<2>(mul_ln1118_81_fu_81315_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_820_fu_97845_p0() {
    mul_ln1118_820_fu_97845_p0 =  (sc_lv<10>) (zext_ln1116_545_fu_97839_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_820_fu_97845_p1() {
    mul_ln1118_820_fu_97845_p1 = tmp_1214_reg_136041.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_820_fu_97845_p2() {
    mul_ln1118_820_fu_97845_p2 = (!mul_ln1118_820_fu_97845_p0.read().is_01() || !mul_ln1118_820_fu_97845_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_820_fu_97845_p0.read()) * sc_bigint<2>(mul_ln1118_820_fu_97845_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_821_fu_97857_p0() {
    mul_ln1118_821_fu_97857_p0 =  (sc_lv<10>) (zext_ln1116_546_fu_97851_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_821_fu_97857_p1() {
    mul_ln1118_821_fu_97857_p1 = tmp_1216_reg_136051.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_821_fu_97857_p2() {
    mul_ln1118_821_fu_97857_p2 = (!mul_ln1118_821_fu_97857_p0.read().is_01() || !mul_ln1118_821_fu_97857_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_821_fu_97857_p0.read()) * sc_bigint<2>(mul_ln1118_821_fu_97857_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_822_fu_97881_p0() {
    mul_ln1118_822_fu_97881_p0 =  (sc_lv<10>) (zext_ln1116_547_fu_97875_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_822_fu_97881_p1() {
    mul_ln1118_822_fu_97881_p1 = tmp_1218_reg_136061.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_822_fu_97881_p2() {
    mul_ln1118_822_fu_97881_p2 = (!mul_ln1118_822_fu_97881_p0.read().is_01() || !mul_ln1118_822_fu_97881_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_822_fu_97881_p0.read()) * sc_bigint<2>(mul_ln1118_822_fu_97881_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_823_fu_97905_p0() {
    mul_ln1118_823_fu_97905_p0 =  (sc_lv<10>) (zext_ln1116_548_fu_97899_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_823_fu_97905_p1() {
    mul_ln1118_823_fu_97905_p1 = tmp_1220_reg_136071.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_823_fu_97905_p2() {
    mul_ln1118_823_fu_97905_p2 = (!mul_ln1118_823_fu_97905_p0.read().is_01() || !mul_ln1118_823_fu_97905_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_823_fu_97905_p0.read()) * sc_bigint<2>(mul_ln1118_823_fu_97905_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_824_fu_97929_p0() {
    mul_ln1118_824_fu_97929_p0 =  (sc_lv<10>) (zext_ln1116_549_fu_97923_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_824_fu_97929_p1() {
    mul_ln1118_824_fu_97929_p1 = tmp_1222_reg_136081.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_824_fu_97929_p2() {
    mul_ln1118_824_fu_97929_p2 = (!mul_ln1118_824_fu_97929_p0.read().is_01() || !mul_ln1118_824_fu_97929_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_824_fu_97929_p0.read()) * sc_bigint<2>(mul_ln1118_824_fu_97929_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_825_fu_97953_p0() {
    mul_ln1118_825_fu_97953_p0 =  (sc_lv<10>) (zext_ln1116_550_fu_97947_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_825_fu_97953_p1() {
    mul_ln1118_825_fu_97953_p1 = tmp_1224_reg_136091.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_825_fu_97953_p2() {
    mul_ln1118_825_fu_97953_p2 = (!mul_ln1118_825_fu_97953_p0.read().is_01() || !mul_ln1118_825_fu_97953_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_825_fu_97953_p0.read()) * sc_bigint<2>(mul_ln1118_825_fu_97953_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_826_fu_97965_p0() {
    mul_ln1118_826_fu_97965_p0 =  (sc_lv<10>) (zext_ln1116_551_fu_97959_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_826_fu_97965_p1() {
    mul_ln1118_826_fu_97965_p1 = tmp_1226_reg_136101.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_826_fu_97965_p2() {
    mul_ln1118_826_fu_97965_p2 = (!mul_ln1118_826_fu_97965_p0.read().is_01() || !mul_ln1118_826_fu_97965_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_826_fu_97965_p0.read()) * sc_bigint<2>(mul_ln1118_826_fu_97965_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_827_fu_97989_p0() {
    mul_ln1118_827_fu_97989_p0 =  (sc_lv<10>) (zext_ln1116_552_fu_97983_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_827_fu_97989_p1() {
    mul_ln1118_827_fu_97989_p1 = tmp_1228_reg_136111.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_827_fu_97989_p2() {
    mul_ln1118_827_fu_97989_p2 = (!mul_ln1118_827_fu_97989_p0.read().is_01() || !mul_ln1118_827_fu_97989_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_827_fu_97989_p0.read()) * sc_bigint<2>(mul_ln1118_827_fu_97989_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_828_fu_98013_p0() {
    mul_ln1118_828_fu_98013_p0 =  (sc_lv<10>) (zext_ln1116_553_fu_98007_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_828_fu_98013_p1() {
    mul_ln1118_828_fu_98013_p1 = tmp_1229_reg_136121.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_828_fu_98013_p2() {
    mul_ln1118_828_fu_98013_p2 = (!mul_ln1118_828_fu_98013_p0.read().is_01() || !mul_ln1118_828_fu_98013_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_828_fu_98013_p0.read()) * sc_bigint<2>(mul_ln1118_828_fu_98013_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_829_fu_98037_p0() {
    mul_ln1118_829_fu_98037_p0 =  (sc_lv<10>) (zext_ln1116_554_fu_98031_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_829_fu_98037_p1() {
    mul_ln1118_829_fu_98037_p1 = tmp_1230_reg_136131.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_829_fu_98037_p2() {
    mul_ln1118_829_fu_98037_p2 = (!mul_ln1118_829_fu_98037_p0.read().is_01() || !mul_ln1118_829_fu_98037_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_829_fu_98037_p0.read()) * sc_bigint<2>(mul_ln1118_829_fu_98037_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_82_fu_81339_p0() {
    mul_ln1118_82_fu_81339_p0 =  (sc_lv<10>) (mul_ln1118_82_fu_81339_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_82_fu_81339_p00() {
    mul_ln1118_82_fu_81339_p00 = esl_zext<12,10>(trunc_ln77_79_reg_130051.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_82_fu_81339_p1() {
    mul_ln1118_82_fu_81339_p1 = tmp_157_reg_130056.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_82_fu_81339_p2() {
    mul_ln1118_82_fu_81339_p2 = (!mul_ln1118_82_fu_81339_p0.read().is_01() || !mul_ln1118_82_fu_81339_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_82_fu_81339_p0.read()) * sc_bigint<2>(mul_ln1118_82_fu_81339_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_830_fu_98061_p0() {
    mul_ln1118_830_fu_98061_p0 =  (sc_lv<10>) (zext_ln1116_555_fu_98055_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_830_fu_98061_p1() {
    mul_ln1118_830_fu_98061_p1 = tmp_1231_reg_136141.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_830_fu_98061_p2() {
    mul_ln1118_830_fu_98061_p2 = (!mul_ln1118_830_fu_98061_p0.read().is_01() || !mul_ln1118_830_fu_98061_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_830_fu_98061_p0.read()) * sc_bigint<2>(mul_ln1118_830_fu_98061_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_831_fu_98073_p0() {
    mul_ln1118_831_fu_98073_p0 =  (sc_lv<10>) (zext_ln1116_556_fu_98067_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_831_fu_98073_p1() {
    mul_ln1118_831_fu_98073_p1 = tmp_1232_reg_136151.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_831_fu_98073_p2() {
    mul_ln1118_831_fu_98073_p2 = (!mul_ln1118_831_fu_98073_p0.read().is_01() || !mul_ln1118_831_fu_98073_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_831_fu_98073_p0.read()) * sc_bigint<2>(mul_ln1118_831_fu_98073_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_832_fu_98097_p0() {
    mul_ln1118_832_fu_98097_p0 =  (sc_lv<10>) (zext_ln1116_557_fu_98091_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_832_fu_98097_p1() {
    mul_ln1118_832_fu_98097_p1 = tmp_1233_reg_136161.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_832_fu_98097_p2() {
    mul_ln1118_832_fu_98097_p2 = (!mul_ln1118_832_fu_98097_p0.read().is_01() || !mul_ln1118_832_fu_98097_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_832_fu_98097_p0.read()) * sc_bigint<2>(mul_ln1118_832_fu_98097_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_833_fu_98121_p0() {
    mul_ln1118_833_fu_98121_p0 =  (sc_lv<10>) (zext_ln1116_558_fu_98115_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_833_fu_98121_p1() {
    mul_ln1118_833_fu_98121_p1 = tmp_1234_reg_136171.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_833_fu_98121_p2() {
    mul_ln1118_833_fu_98121_p2 = (!mul_ln1118_833_fu_98121_p0.read().is_01() || !mul_ln1118_833_fu_98121_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_833_fu_98121_p0.read()) * sc_bigint<2>(mul_ln1118_833_fu_98121_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_834_fu_98145_p0() {
    mul_ln1118_834_fu_98145_p0 =  (sc_lv<10>) (zext_ln1116_559_fu_98139_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_834_fu_98145_p1() {
    mul_ln1118_834_fu_98145_p1 = tmp_1235_reg_136181.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_834_fu_98145_p2() {
    mul_ln1118_834_fu_98145_p2 = (!mul_ln1118_834_fu_98145_p0.read().is_01() || !mul_ln1118_834_fu_98145_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_834_fu_98145_p0.read()) * sc_bigint<2>(mul_ln1118_834_fu_98145_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_835_fu_98169_p0() {
    mul_ln1118_835_fu_98169_p0 =  (sc_lv<10>) (zext_ln1116_560_fu_98163_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_835_fu_98169_p1() {
    mul_ln1118_835_fu_98169_p1 = tmp_1236_reg_136191.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_835_fu_98169_p2() {
    mul_ln1118_835_fu_98169_p2 = (!mul_ln1118_835_fu_98169_p0.read().is_01() || !mul_ln1118_835_fu_98169_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_835_fu_98169_p0.read()) * sc_bigint<2>(mul_ln1118_835_fu_98169_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_836_fu_98181_p0() {
    mul_ln1118_836_fu_98181_p0 =  (sc_lv<10>) (mul_ln1118_836_fu_98181_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_836_fu_98181_p00() {
    mul_ln1118_836_fu_98181_p00 = esl_zext<12,10>(trunc_ln77_559_reg_136196.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_836_fu_98181_p1() {
    mul_ln1118_836_fu_98181_p1 = tmp_1237_reg_136201.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_836_fu_98181_p2() {
    mul_ln1118_836_fu_98181_p2 = (!mul_ln1118_836_fu_98181_p0.read().is_01() || !mul_ln1118_836_fu_98181_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_836_fu_98181_p0.read()) * sc_bigint<2>(mul_ln1118_836_fu_98181_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_837_fu_98205_p0() {
    mul_ln1118_837_fu_98205_p0 =  (sc_lv<10>) (mul_ln1118_837_fu_98205_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_837_fu_98205_p00() {
    mul_ln1118_837_fu_98205_p00 = esl_zext<12,10>(trunc_ln77_560_reg_136206.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_837_fu_98205_p1() {
    mul_ln1118_837_fu_98205_p1 = tmp_1238_reg_136211.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_837_fu_98205_p2() {
    mul_ln1118_837_fu_98205_p2 = (!mul_ln1118_837_fu_98205_p0.read().is_01() || !mul_ln1118_837_fu_98205_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_837_fu_98205_p0.read()) * sc_bigint<2>(mul_ln1118_837_fu_98205_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_838_fu_98229_p0() {
    mul_ln1118_838_fu_98229_p0 =  (sc_lv<10>) (mul_ln1118_838_fu_98229_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_838_fu_98229_p00() {
    mul_ln1118_838_fu_98229_p00 = esl_zext<12,10>(trunc_ln77_561_reg_136216.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_838_fu_98229_p1() {
    mul_ln1118_838_fu_98229_p1 = tmp_1239_reg_136221.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_838_fu_98229_p2() {
    mul_ln1118_838_fu_98229_p2 = (!mul_ln1118_838_fu_98229_p0.read().is_01() || !mul_ln1118_838_fu_98229_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_838_fu_98229_p0.read()) * sc_bigint<2>(mul_ln1118_838_fu_98229_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_839_fu_98241_p0() {
    mul_ln1118_839_fu_98241_p0 =  (sc_lv<10>) (mul_ln1118_839_fu_98241_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_839_fu_98241_p00() {
    mul_ln1118_839_fu_98241_p00 = esl_zext<12,10>(trunc_ln77_562_reg_136226.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_839_fu_98241_p1() {
    mul_ln1118_839_fu_98241_p1 = tmp_1240_reg_136231.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_839_fu_98241_p2() {
    mul_ln1118_839_fu_98241_p2 = (!mul_ln1118_839_fu_98241_p0.read().is_01() || !mul_ln1118_839_fu_98241_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_839_fu_98241_p0.read()) * sc_bigint<2>(mul_ln1118_839_fu_98241_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_83_fu_81351_p0() {
    mul_ln1118_83_fu_81351_p0 =  (sc_lv<10>) (mul_ln1118_83_fu_81351_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_83_fu_81351_p00() {
    mul_ln1118_83_fu_81351_p00 = esl_zext<12,10>(trunc_ln77_80_reg_130061.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_83_fu_81351_p1() {
    mul_ln1118_83_fu_81351_p1 = tmp_159_reg_130066.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_83_fu_81351_p2() {
    mul_ln1118_83_fu_81351_p2 = (!mul_ln1118_83_fu_81351_p0.read().is_01() || !mul_ln1118_83_fu_81351_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_83_fu_81351_p0.read()) * sc_bigint<2>(mul_ln1118_83_fu_81351_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_840_fu_98265_p0() {
    mul_ln1118_840_fu_98265_p0 =  (sc_lv<10>) (mul_ln1118_840_fu_98265_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_840_fu_98265_p00() {
    mul_ln1118_840_fu_98265_p00 = esl_zext<12,10>(trunc_ln77_563_reg_136236.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_840_fu_98265_p1() {
    mul_ln1118_840_fu_98265_p1 = tmp_1241_reg_136241.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_840_fu_98265_p2() {
    mul_ln1118_840_fu_98265_p2 = (!mul_ln1118_840_fu_98265_p0.read().is_01() || !mul_ln1118_840_fu_98265_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_840_fu_98265_p0.read()) * sc_bigint<2>(mul_ln1118_840_fu_98265_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_841_fu_98289_p0() {
    mul_ln1118_841_fu_98289_p0 =  (sc_lv<10>) (mul_ln1118_841_fu_98289_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_841_fu_98289_p00() {
    mul_ln1118_841_fu_98289_p00 = esl_zext<12,10>(trunc_ln77_564_reg_136246.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_841_fu_98289_p1() {
    mul_ln1118_841_fu_98289_p1 = tmp_1242_reg_136251.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_841_fu_98289_p2() {
    mul_ln1118_841_fu_98289_p2 = (!mul_ln1118_841_fu_98289_p0.read().is_01() || !mul_ln1118_841_fu_98289_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_841_fu_98289_p0.read()) * sc_bigint<2>(mul_ln1118_841_fu_98289_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_842_fu_98301_p0() {
    mul_ln1118_842_fu_98301_p0 =  (sc_lv<10>) (mul_ln1118_842_fu_98301_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_842_fu_98301_p00() {
    mul_ln1118_842_fu_98301_p00 = esl_zext<12,10>(trunc_ln77_565_reg_136256.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_842_fu_98301_p1() {
    mul_ln1118_842_fu_98301_p1 = tmp_1243_reg_136261.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_842_fu_98301_p2() {
    mul_ln1118_842_fu_98301_p2 = (!mul_ln1118_842_fu_98301_p0.read().is_01() || !mul_ln1118_842_fu_98301_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_842_fu_98301_p0.read()) * sc_bigint<2>(mul_ln1118_842_fu_98301_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_843_fu_98325_p0() {
    mul_ln1118_843_fu_98325_p0 =  (sc_lv<10>) (mul_ln1118_843_fu_98325_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_843_fu_98325_p00() {
    mul_ln1118_843_fu_98325_p00 = esl_zext<12,10>(trunc_ln77_566_reg_136266.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_843_fu_98325_p1() {
    mul_ln1118_843_fu_98325_p1 = tmp_1244_reg_136271.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_843_fu_98325_p2() {
    mul_ln1118_843_fu_98325_p2 = (!mul_ln1118_843_fu_98325_p0.read().is_01() || !mul_ln1118_843_fu_98325_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_843_fu_98325_p0.read()) * sc_bigint<2>(mul_ln1118_843_fu_98325_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_844_fu_98541_p0() {
    mul_ln1118_844_fu_98541_p0 =  (sc_lv<10>) (mul_ln1118_844_fu_98541_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_844_fu_98541_p00() {
    mul_ln1118_844_fu_98541_p00 = esl_zext<12,10>(trunc_ln77_567_reg_127461_pp0_iter2_reg.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_844_fu_98541_p1() {
    mul_ln1118_844_fu_98541_p1 = tmp_1246_reg_136276.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_844_fu_98541_p2() {
    mul_ln1118_844_fu_98541_p2 = (!mul_ln1118_844_fu_98541_p0.read().is_01() || !mul_ln1118_844_fu_98541_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_844_fu_98541_p0.read()) * sc_bigint<2>(mul_ln1118_844_fu_98541_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_845_fu_98565_p0() {
    mul_ln1118_845_fu_98565_p0 =  (sc_lv<10>) (mul_ln1118_845_fu_98565_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_845_fu_98565_p00() {
    mul_ln1118_845_fu_98565_p00 = esl_zext<12,10>(trunc_ln77_568_reg_136281.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_845_fu_98565_p1() {
    mul_ln1118_845_fu_98565_p1 = tmp_1248_reg_136286.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_845_fu_98565_p2() {
    mul_ln1118_845_fu_98565_p2 = (!mul_ln1118_845_fu_98565_p0.read().is_01() || !mul_ln1118_845_fu_98565_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_845_fu_98565_p0.read()) * sc_bigint<2>(mul_ln1118_845_fu_98565_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_846_fu_98589_p0() {
    mul_ln1118_846_fu_98589_p0 =  (sc_lv<10>) (mul_ln1118_846_fu_98589_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_846_fu_98589_p00() {
    mul_ln1118_846_fu_98589_p00 = esl_zext<12,10>(trunc_ln77_569_reg_136291.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_846_fu_98589_p1() {
    mul_ln1118_846_fu_98589_p1 = tmp_1250_reg_136296.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_846_fu_98589_p2() {
    mul_ln1118_846_fu_98589_p2 = (!mul_ln1118_846_fu_98589_p0.read().is_01() || !mul_ln1118_846_fu_98589_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_846_fu_98589_p0.read()) * sc_bigint<2>(mul_ln1118_846_fu_98589_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_847_fu_98601_p0() {
    mul_ln1118_847_fu_98601_p0 =  (sc_lv<10>) (mul_ln1118_847_fu_98601_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_847_fu_98601_p00() {
    mul_ln1118_847_fu_98601_p00 = esl_zext<12,10>(trunc_ln77_570_reg_136301.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_847_fu_98601_p1() {
    mul_ln1118_847_fu_98601_p1 = tmp_1252_reg_136306.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_847_fu_98601_p2() {
    mul_ln1118_847_fu_98601_p2 = (!mul_ln1118_847_fu_98601_p0.read().is_01() || !mul_ln1118_847_fu_98601_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_847_fu_98601_p0.read()) * sc_bigint<2>(mul_ln1118_847_fu_98601_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_848_fu_98625_p0() {
    mul_ln1118_848_fu_98625_p0 =  (sc_lv<10>) (mul_ln1118_848_fu_98625_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_848_fu_98625_p00() {
    mul_ln1118_848_fu_98625_p00 = esl_zext<12,10>(trunc_ln77_571_reg_136311.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_848_fu_98625_p1() {
    mul_ln1118_848_fu_98625_p1 = tmp_1253_reg_136316.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_848_fu_98625_p2() {
    mul_ln1118_848_fu_98625_p2 = (!mul_ln1118_848_fu_98625_p0.read().is_01() || !mul_ln1118_848_fu_98625_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_848_fu_98625_p0.read()) * sc_bigint<2>(mul_ln1118_848_fu_98625_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_849_fu_98649_p0() {
    mul_ln1118_849_fu_98649_p0 =  (sc_lv<10>) (mul_ln1118_849_fu_98649_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_849_fu_98649_p00() {
    mul_ln1118_849_fu_98649_p00 = esl_zext<12,10>(trunc_ln77_572_reg_136321.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_849_fu_98649_p1() {
    mul_ln1118_849_fu_98649_p1 = tmp_1255_reg_136326.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_849_fu_98649_p2() {
    mul_ln1118_849_fu_98649_p2 = (!mul_ln1118_849_fu_98649_p0.read().is_01() || !mul_ln1118_849_fu_98649_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_849_fu_98649_p0.read()) * sc_bigint<2>(mul_ln1118_849_fu_98649_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_84_fu_81375_p0() {
    mul_ln1118_84_fu_81375_p0 =  (sc_lv<10>) (mul_ln1118_84_fu_81375_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_84_fu_81375_p00() {
    mul_ln1118_84_fu_81375_p00 = esl_zext<12,10>(trunc_ln77_81_reg_130071.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_84_fu_81375_p1() {
    mul_ln1118_84_fu_81375_p1 = tmp_161_reg_130076.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_84_fu_81375_p2() {
    mul_ln1118_84_fu_81375_p2 = (!mul_ln1118_84_fu_81375_p0.read().is_01() || !mul_ln1118_84_fu_81375_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_84_fu_81375_p0.read()) * sc_bigint<2>(mul_ln1118_84_fu_81375_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_850_fu_98673_p0() {
    mul_ln1118_850_fu_98673_p0 =  (sc_lv<10>) (mul_ln1118_850_fu_98673_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_850_fu_98673_p00() {
    mul_ln1118_850_fu_98673_p00 = esl_zext<12,10>(trunc_ln77_573_reg_136331.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_850_fu_98673_p1() {
    mul_ln1118_850_fu_98673_p1 = tmp_1257_reg_136336.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_850_fu_98673_p2() {
    mul_ln1118_850_fu_98673_p2 = (!mul_ln1118_850_fu_98673_p0.read().is_01() || !mul_ln1118_850_fu_98673_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_850_fu_98673_p0.read()) * sc_bigint<2>(mul_ln1118_850_fu_98673_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_851_fu_98697_p0() {
    mul_ln1118_851_fu_98697_p0 =  (sc_lv<10>) (mul_ln1118_851_fu_98697_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_851_fu_98697_p00() {
    mul_ln1118_851_fu_98697_p00 = esl_zext<12,10>(trunc_ln77_574_reg_136341.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_851_fu_98697_p1() {
    mul_ln1118_851_fu_98697_p1 = tmp_1259_reg_136346.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_851_fu_98697_p2() {
    mul_ln1118_851_fu_98697_p2 = (!mul_ln1118_851_fu_98697_p0.read().is_01() || !mul_ln1118_851_fu_98697_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_851_fu_98697_p0.read()) * sc_bigint<2>(mul_ln1118_851_fu_98697_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_852_fu_98709_p0() {
    mul_ln1118_852_fu_98709_p0 =  (sc_lv<10>) (mul_ln1118_852_fu_98709_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_852_fu_98709_p00() {
    mul_ln1118_852_fu_98709_p00 = esl_zext<12,10>(trunc_ln77_575_reg_136351.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_852_fu_98709_p1() {
    mul_ln1118_852_fu_98709_p1 = tmp_1260_reg_136356.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_852_fu_98709_p2() {
    mul_ln1118_852_fu_98709_p2 = (!mul_ln1118_852_fu_98709_p0.read().is_01() || !mul_ln1118_852_fu_98709_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_852_fu_98709_p0.read()) * sc_bigint<2>(mul_ln1118_852_fu_98709_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_853_fu_98733_p0() {
    mul_ln1118_853_fu_98733_p0 =  (sc_lv<10>) (mul_ln1118_853_fu_98733_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_853_fu_98733_p00() {
    mul_ln1118_853_fu_98733_p00 = esl_zext<12,10>(trunc_ln77_576_reg_136361.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_853_fu_98733_p1() {
    mul_ln1118_853_fu_98733_p1 = tmp_1261_reg_136366.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_853_fu_98733_p2() {
    mul_ln1118_853_fu_98733_p2 = (!mul_ln1118_853_fu_98733_p0.read().is_01() || !mul_ln1118_853_fu_98733_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_853_fu_98733_p0.read()) * sc_bigint<2>(mul_ln1118_853_fu_98733_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_854_fu_98757_p0() {
    mul_ln1118_854_fu_98757_p0 =  (sc_lv<10>) (mul_ln1118_854_fu_98757_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_854_fu_98757_p00() {
    mul_ln1118_854_fu_98757_p00 = esl_zext<12,10>(trunc_ln77_577_reg_136371.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_854_fu_98757_p1() {
    mul_ln1118_854_fu_98757_p1 = tmp_1263_reg_136376.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_854_fu_98757_p2() {
    mul_ln1118_854_fu_98757_p2 = (!mul_ln1118_854_fu_98757_p0.read().is_01() || !mul_ln1118_854_fu_98757_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_854_fu_98757_p0.read()) * sc_bigint<2>(mul_ln1118_854_fu_98757_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_855_fu_98781_p0() {
    mul_ln1118_855_fu_98781_p0 =  (sc_lv<10>) (mul_ln1118_855_fu_98781_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_855_fu_98781_p00() {
    mul_ln1118_855_fu_98781_p00 = esl_zext<12,10>(trunc_ln77_578_reg_136381.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_855_fu_98781_p1() {
    mul_ln1118_855_fu_98781_p1 = tmp_1265_reg_136386.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_855_fu_98781_p2() {
    mul_ln1118_855_fu_98781_p2 = (!mul_ln1118_855_fu_98781_p0.read().is_01() || !mul_ln1118_855_fu_98781_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_855_fu_98781_p0.read()) * sc_bigint<2>(mul_ln1118_855_fu_98781_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_856_fu_98805_p0() {
    mul_ln1118_856_fu_98805_p0 =  (sc_lv<10>) (mul_ln1118_856_fu_98805_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_856_fu_98805_p00() {
    mul_ln1118_856_fu_98805_p00 = esl_zext<12,10>(trunc_ln77_579_reg_136391.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_856_fu_98805_p1() {
    mul_ln1118_856_fu_98805_p1 = tmp_1267_reg_136396.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_856_fu_98805_p2() {
    mul_ln1118_856_fu_98805_p2 = (!mul_ln1118_856_fu_98805_p0.read().is_01() || !mul_ln1118_856_fu_98805_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_856_fu_98805_p0.read()) * sc_bigint<2>(mul_ln1118_856_fu_98805_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_857_fu_98817_p0() {
    mul_ln1118_857_fu_98817_p0 =  (sc_lv<10>) (mul_ln1118_857_fu_98817_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_857_fu_98817_p00() {
    mul_ln1118_857_fu_98817_p00 = esl_zext<12,10>(trunc_ln77_580_reg_136401.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_857_fu_98817_p1() {
    mul_ln1118_857_fu_98817_p1 = tmp_1269_reg_136406.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_857_fu_98817_p2() {
    mul_ln1118_857_fu_98817_p2 = (!mul_ln1118_857_fu_98817_p0.read().is_01() || !mul_ln1118_857_fu_98817_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_857_fu_98817_p0.read()) * sc_bigint<2>(mul_ln1118_857_fu_98817_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_858_fu_98841_p0() {
    mul_ln1118_858_fu_98841_p0 =  (sc_lv<10>) (mul_ln1118_858_fu_98841_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_858_fu_98841_p00() {
    mul_ln1118_858_fu_98841_p00 = esl_zext<12,10>(trunc_ln77_581_reg_136411.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_858_fu_98841_p1() {
    mul_ln1118_858_fu_98841_p1 = tmp_1271_reg_136416.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_858_fu_98841_p2() {
    mul_ln1118_858_fu_98841_p2 = (!mul_ln1118_858_fu_98841_p0.read().is_01() || !mul_ln1118_858_fu_98841_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_858_fu_98841_p0.read()) * sc_bigint<2>(mul_ln1118_858_fu_98841_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_859_fu_98865_p0() {
    mul_ln1118_859_fu_98865_p0 =  (sc_lv<10>) (mul_ln1118_859_fu_98865_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_859_fu_98865_p00() {
    mul_ln1118_859_fu_98865_p00 = esl_zext<12,10>(trunc_ln77_582_reg_136421.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_859_fu_98865_p1() {
    mul_ln1118_859_fu_98865_p1 = tmp_1273_reg_136426.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_859_fu_98865_p2() {
    mul_ln1118_859_fu_98865_p2 = (!mul_ln1118_859_fu_98865_p0.read().is_01() || !mul_ln1118_859_fu_98865_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_859_fu_98865_p0.read()) * sc_bigint<2>(mul_ln1118_859_fu_98865_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_85_fu_81399_p0() {
    mul_ln1118_85_fu_81399_p0 =  (sc_lv<10>) (mul_ln1118_85_fu_81399_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_85_fu_81399_p00() {
    mul_ln1118_85_fu_81399_p00 = esl_zext<12,10>(trunc_ln77_82_reg_130081.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_85_fu_81399_p1() {
    mul_ln1118_85_fu_81399_p1 = tmp_163_reg_130086.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_85_fu_81399_p2() {
    mul_ln1118_85_fu_81399_p2 = (!mul_ln1118_85_fu_81399_p0.read().is_01() || !mul_ln1118_85_fu_81399_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_85_fu_81399_p0.read()) * sc_bigint<2>(mul_ln1118_85_fu_81399_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_860_fu_98877_p0() {
    mul_ln1118_860_fu_98877_p0 =  (sc_lv<10>) (mul_ln1118_860_fu_98877_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_860_fu_98877_p00() {
    mul_ln1118_860_fu_98877_p00 = esl_zext<12,10>(trunc_ln77_583_reg_136431.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_860_fu_98877_p1() {
    mul_ln1118_860_fu_98877_p1 = tmp_1275_reg_136436.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_860_fu_98877_p2() {
    mul_ln1118_860_fu_98877_p2 = (!mul_ln1118_860_fu_98877_p0.read().is_01() || !mul_ln1118_860_fu_98877_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_860_fu_98877_p0.read()) * sc_bigint<2>(mul_ln1118_860_fu_98877_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_861_fu_98901_p0() {
    mul_ln1118_861_fu_98901_p0 =  (sc_lv<10>) (mul_ln1118_861_fu_98901_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_861_fu_98901_p00() {
    mul_ln1118_861_fu_98901_p00 = esl_zext<12,10>(trunc_ln77_584_reg_136441.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_861_fu_98901_p1() {
    mul_ln1118_861_fu_98901_p1 = tmp_1276_reg_136446.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_861_fu_98901_p2() {
    mul_ln1118_861_fu_98901_p2 = (!mul_ln1118_861_fu_98901_p0.read().is_01() || !mul_ln1118_861_fu_98901_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_861_fu_98901_p0.read()) * sc_bigint<2>(mul_ln1118_861_fu_98901_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_862_fu_98925_p0() {
    mul_ln1118_862_fu_98925_p0 =  (sc_lv<10>) (mul_ln1118_862_fu_98925_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_862_fu_98925_p00() {
    mul_ln1118_862_fu_98925_p00 = esl_zext<12,10>(trunc_ln77_585_reg_136451.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_862_fu_98925_p1() {
    mul_ln1118_862_fu_98925_p1 = tmp_1277_reg_136456.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_862_fu_98925_p2() {
    mul_ln1118_862_fu_98925_p2 = (!mul_ln1118_862_fu_98925_p0.read().is_01() || !mul_ln1118_862_fu_98925_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_862_fu_98925_p0.read()) * sc_bigint<2>(mul_ln1118_862_fu_98925_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_863_fu_98937_p0() {
    mul_ln1118_863_fu_98937_p0 =  (sc_lv<10>) (mul_ln1118_863_fu_98937_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_863_fu_98937_p00() {
    mul_ln1118_863_fu_98937_p00 = esl_zext<12,10>(trunc_ln77_586_reg_136461.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_863_fu_98937_p1() {
    mul_ln1118_863_fu_98937_p1 = tmp_1278_reg_136466.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_863_fu_98937_p2() {
    mul_ln1118_863_fu_98937_p2 = (!mul_ln1118_863_fu_98937_p0.read().is_01() || !mul_ln1118_863_fu_98937_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_863_fu_98937_p0.read()) * sc_bigint<2>(mul_ln1118_863_fu_98937_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_864_fu_98961_p0() {
    mul_ln1118_864_fu_98961_p0 =  (sc_lv<10>) (mul_ln1118_864_fu_98961_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_864_fu_98961_p00() {
    mul_ln1118_864_fu_98961_p00 = esl_zext<12,10>(trunc_ln77_587_reg_136471.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_864_fu_98961_p1() {
    mul_ln1118_864_fu_98961_p1 = tmp_1279_reg_136476.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_864_fu_98961_p2() {
    mul_ln1118_864_fu_98961_p2 = (!mul_ln1118_864_fu_98961_p0.read().is_01() || !mul_ln1118_864_fu_98961_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_864_fu_98961_p0.read()) * sc_bigint<2>(mul_ln1118_864_fu_98961_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_865_fu_98982_p0() {
    mul_ln1118_865_fu_98982_p0 =  (sc_lv<10>) (zext_ln1116_506_fu_97011_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_865_fu_98982_p1() {
    mul_ln1118_865_fu_98982_p1 = tmp_1280_reg_136481.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_865_fu_98982_p2() {
    mul_ln1118_865_fu_98982_p2 = (!mul_ln1118_865_fu_98982_p0.read().is_01() || !mul_ln1118_865_fu_98982_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_865_fu_98982_p0.read()) * sc_bigint<2>(mul_ln1118_865_fu_98982_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_866_fu_99003_p0() {
    mul_ln1118_866_fu_99003_p0 =  (sc_lv<10>) (zext_ln1116_507_fu_97035_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_866_fu_99003_p1() {
    mul_ln1118_866_fu_99003_p1 = tmp_1281_reg_136486.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_866_fu_99003_p2() {
    mul_ln1118_866_fu_99003_p2 = (!mul_ln1118_866_fu_99003_p0.read().is_01() || !mul_ln1118_866_fu_99003_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_866_fu_99003_p0.read()) * sc_bigint<2>(mul_ln1118_866_fu_99003_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_867_fu_99024_p0() {
    mul_ln1118_867_fu_99024_p0 =  (sc_lv<10>) (zext_ln1116_508_fu_97059_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_867_fu_99024_p1() {
    mul_ln1118_867_fu_99024_p1 = tmp_1282_reg_136491.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_867_fu_99024_p2() {
    mul_ln1118_867_fu_99024_p2 = (!mul_ln1118_867_fu_99024_p0.read().is_01() || !mul_ln1118_867_fu_99024_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_867_fu_99024_p0.read()) * sc_bigint<2>(mul_ln1118_867_fu_99024_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_868_fu_99033_p0() {
    mul_ln1118_868_fu_99033_p0 =  (sc_lv<10>) (zext_ln1116_509_fu_97071_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_868_fu_99033_p1() {
    mul_ln1118_868_fu_99033_p1 = tmp_1283_reg_136496.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_868_fu_99033_p2() {
    mul_ln1118_868_fu_99033_p2 = (!mul_ln1118_868_fu_99033_p0.read().is_01() || !mul_ln1118_868_fu_99033_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_868_fu_99033_p0.read()) * sc_bigint<2>(mul_ln1118_868_fu_99033_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_869_fu_99054_p0() {
    mul_ln1118_869_fu_99054_p0 =  (sc_lv<10>) (zext_ln1116_510_fu_97095_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_869_fu_99054_p1() {
    mul_ln1118_869_fu_99054_p1 = tmp_1284_reg_136501.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_869_fu_99054_p2() {
    mul_ln1118_869_fu_99054_p2 = (!mul_ln1118_869_fu_99054_p0.read().is_01() || !mul_ln1118_869_fu_99054_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_869_fu_99054_p0.read()) * sc_bigint<2>(mul_ln1118_869_fu_99054_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_86_fu_81411_p0() {
    mul_ln1118_86_fu_81411_p0 =  (sc_lv<10>) (mul_ln1118_86_fu_81411_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_86_fu_81411_p00() {
    mul_ln1118_86_fu_81411_p00 = esl_zext<12,10>(trunc_ln77_83_reg_130091.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_86_fu_81411_p1() {
    mul_ln1118_86_fu_81411_p1 = tmp_165_reg_130096.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_86_fu_81411_p2() {
    mul_ln1118_86_fu_81411_p2 = (!mul_ln1118_86_fu_81411_p0.read().is_01() || !mul_ln1118_86_fu_81411_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_86_fu_81411_p0.read()) * sc_bigint<2>(mul_ln1118_86_fu_81411_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_870_fu_99075_p0() {
    mul_ln1118_870_fu_99075_p0 =  (sc_lv<10>) (zext_ln1116_511_fu_97119_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_870_fu_99075_p1() {
    mul_ln1118_870_fu_99075_p1 = tmp_1285_reg_136506.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_870_fu_99075_p2() {
    mul_ln1118_870_fu_99075_p2 = (!mul_ln1118_870_fu_99075_p0.read().is_01() || !mul_ln1118_870_fu_99075_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_870_fu_99075_p0.read()) * sc_bigint<2>(mul_ln1118_870_fu_99075_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_871_fu_99096_p0() {
    mul_ln1118_871_fu_99096_p0 =  (sc_lv<10>) (zext_ln1116_512_fu_97143_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_871_fu_99096_p1() {
    mul_ln1118_871_fu_99096_p1 = tmp_1286_reg_136511.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_871_fu_99096_p2() {
    mul_ln1118_871_fu_99096_p2 = (!mul_ln1118_871_fu_99096_p0.read().is_01() || !mul_ln1118_871_fu_99096_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_871_fu_99096_p0.read()) * sc_bigint<2>(mul_ln1118_871_fu_99096_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_872_fu_99117_p0() {
    mul_ln1118_872_fu_99117_p0 =  (sc_lv<10>) (zext_ln1116_513_fu_97167_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_872_fu_99117_p1() {
    mul_ln1118_872_fu_99117_p1 = tmp_1287_reg_136516.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_872_fu_99117_p2() {
    mul_ln1118_872_fu_99117_p2 = (!mul_ln1118_872_fu_99117_p0.read().is_01() || !mul_ln1118_872_fu_99117_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_872_fu_99117_p0.read()) * sc_bigint<2>(mul_ln1118_872_fu_99117_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_873_fu_99126_p0() {
    mul_ln1118_873_fu_99126_p0 =  (sc_lv<10>) (zext_ln1116_514_fu_97179_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_873_fu_99126_p1() {
    mul_ln1118_873_fu_99126_p1 = tmp_1288_reg_136521.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_873_fu_99126_p2() {
    mul_ln1118_873_fu_99126_p2 = (!mul_ln1118_873_fu_99126_p0.read().is_01() || !mul_ln1118_873_fu_99126_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_873_fu_99126_p0.read()) * sc_bigint<2>(mul_ln1118_873_fu_99126_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_874_fu_99147_p0() {
    mul_ln1118_874_fu_99147_p0 =  (sc_lv<10>) (zext_ln1116_515_fu_97203_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_874_fu_99147_p1() {
    mul_ln1118_874_fu_99147_p1 = tmp_1289_reg_136526.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_874_fu_99147_p2() {
    mul_ln1118_874_fu_99147_p2 = (!mul_ln1118_874_fu_99147_p0.read().is_01() || !mul_ln1118_874_fu_99147_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_874_fu_99147_p0.read()) * sc_bigint<2>(mul_ln1118_874_fu_99147_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_875_fu_99168_p0() {
    mul_ln1118_875_fu_99168_p0 =  (sc_lv<10>) (zext_ln1116_516_fu_97227_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_875_fu_99168_p1() {
    mul_ln1118_875_fu_99168_p1 = tmp_1290_reg_136531.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_875_fu_99168_p2() {
    mul_ln1118_875_fu_99168_p2 = (!mul_ln1118_875_fu_99168_p0.read().is_01() || !mul_ln1118_875_fu_99168_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_875_fu_99168_p0.read()) * sc_bigint<2>(mul_ln1118_875_fu_99168_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_876_fu_99189_p0() {
    mul_ln1118_876_fu_99189_p0 =  (sc_lv<10>) (zext_ln1116_517_fu_97251_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_876_fu_99189_p1() {
    mul_ln1118_876_fu_99189_p1 = tmp_1291_reg_136536.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_876_fu_99189_p2() {
    mul_ln1118_876_fu_99189_p2 = (!mul_ln1118_876_fu_99189_p0.read().is_01() || !mul_ln1118_876_fu_99189_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_876_fu_99189_p0.read()) * sc_bigint<2>(mul_ln1118_876_fu_99189_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_877_fu_99210_p0() {
    mul_ln1118_877_fu_99210_p0 =  (sc_lv<10>) (zext_ln1116_518_fu_97275_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_877_fu_99210_p1() {
    mul_ln1118_877_fu_99210_p1 = tmp_1292_reg_136541.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_877_fu_99210_p2() {
    mul_ln1118_877_fu_99210_p2 = (!mul_ln1118_877_fu_99210_p0.read().is_01() || !mul_ln1118_877_fu_99210_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_877_fu_99210_p0.read()) * sc_bigint<2>(mul_ln1118_877_fu_99210_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_878_fu_99219_p0() {
    mul_ln1118_878_fu_99219_p0 =  (sc_lv<10>) (zext_ln1116_519_fu_97287_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_878_fu_99219_p1() {
    mul_ln1118_878_fu_99219_p1 = tmp_1293_reg_136546.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_878_fu_99219_p2() {
    mul_ln1118_878_fu_99219_p2 = (!mul_ln1118_878_fu_99219_p0.read().is_01() || !mul_ln1118_878_fu_99219_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_878_fu_99219_p0.read()) * sc_bigint<2>(mul_ln1118_878_fu_99219_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_879_fu_99240_p0() {
    mul_ln1118_879_fu_99240_p0 =  (sc_lv<10>) (zext_ln1116_520_fu_97311_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_879_fu_99240_p1() {
    mul_ln1118_879_fu_99240_p1 = tmp_1294_reg_136551.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_879_fu_99240_p2() {
    mul_ln1118_879_fu_99240_p2 = (!mul_ln1118_879_fu_99240_p0.read().is_01() || !mul_ln1118_879_fu_99240_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_879_fu_99240_p0.read()) * sc_bigint<2>(mul_ln1118_879_fu_99240_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_87_fu_81435_p0() {
    mul_ln1118_87_fu_81435_p0 =  (sc_lv<10>) (zext_ln1116_86_fu_81429_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_87_fu_81435_p1() {
    mul_ln1118_87_fu_81435_p1 = tmp_167_reg_130106.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_87_fu_81435_p2() {
    mul_ln1118_87_fu_81435_p2 = (!mul_ln1118_87_fu_81435_p0.read().is_01() || !mul_ln1118_87_fu_81435_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_87_fu_81435_p0.read()) * sc_bigint<2>(mul_ln1118_87_fu_81435_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_880_fu_99261_p0() {
    mul_ln1118_880_fu_99261_p0 =  (sc_lv<10>) (zext_ln1116_521_fu_97335_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_880_fu_99261_p1() {
    mul_ln1118_880_fu_99261_p1 = tmp_1295_reg_136556.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_880_fu_99261_p2() {
    mul_ln1118_880_fu_99261_p2 = (!mul_ln1118_880_fu_99261_p0.read().is_01() || !mul_ln1118_880_fu_99261_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_880_fu_99261_p0.read()) * sc_bigint<2>(mul_ln1118_880_fu_99261_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_881_fu_99270_p0() {
    mul_ln1118_881_fu_99270_p0 =  (sc_lv<10>) (zext_ln1116_522_fu_97347_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_881_fu_99270_p1() {
    mul_ln1118_881_fu_99270_p1 = tmp_1296_reg_136561.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_881_fu_99270_p2() {
    mul_ln1118_881_fu_99270_p2 = (!mul_ln1118_881_fu_99270_p0.read().is_01() || !mul_ln1118_881_fu_99270_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_881_fu_99270_p0.read()) * sc_bigint<2>(mul_ln1118_881_fu_99270_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_882_fu_99291_p0() {
    mul_ln1118_882_fu_99291_p0 =  (sc_lv<10>) (zext_ln1116_523_fu_97371_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_882_fu_99291_p1() {
    mul_ln1118_882_fu_99291_p1 = tmp_1297_reg_136566.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_882_fu_99291_p2() {
    mul_ln1118_882_fu_99291_p2 = (!mul_ln1118_882_fu_99291_p0.read().is_01() || !mul_ln1118_882_fu_99291_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_882_fu_99291_p0.read()) * sc_bigint<2>(mul_ln1118_882_fu_99291_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_883_fu_99312_p0() {
    mul_ln1118_883_fu_99312_p0 =  (sc_lv<10>) (zext_ln1116_524_fu_97395_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_883_fu_99312_p1() {
    mul_ln1118_883_fu_99312_p1 = tmp_1298_reg_136571.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_883_fu_99312_p2() {
    mul_ln1118_883_fu_99312_p2 = (!mul_ln1118_883_fu_99312_p0.read().is_01() || !mul_ln1118_883_fu_99312_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_883_fu_99312_p0.read()) * sc_bigint<2>(mul_ln1118_883_fu_99312_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_884_fu_99321_p0() {
    mul_ln1118_884_fu_99321_p0 =  (sc_lv<10>) (zext_ln1116_525_fu_97407_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_884_fu_99321_p1() {
    mul_ln1118_884_fu_99321_p1 = tmp_1299_reg_136576.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_884_fu_99321_p2() {
    mul_ln1118_884_fu_99321_p2 = (!mul_ln1118_884_fu_99321_p0.read().is_01() || !mul_ln1118_884_fu_99321_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_884_fu_99321_p0.read()) * sc_bigint<2>(mul_ln1118_884_fu_99321_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_885_fu_99342_p0() {
    mul_ln1118_885_fu_99342_p0 =  (sc_lv<10>) (zext_ln1116_526_fu_97431_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_885_fu_99342_p1() {
    mul_ln1118_885_fu_99342_p1 = tmp_1300_reg_136581.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_885_fu_99342_p2() {
    mul_ln1118_885_fu_99342_p2 = (!mul_ln1118_885_fu_99342_p0.read().is_01() || !mul_ln1118_885_fu_99342_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_885_fu_99342_p0.read()) * sc_bigint<2>(mul_ln1118_885_fu_99342_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_886_fu_99363_p0() {
    mul_ln1118_886_fu_99363_p0 =  (sc_lv<10>) (zext_ln1116_527_fu_97455_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_886_fu_99363_p1() {
    mul_ln1118_886_fu_99363_p1 = tmp_1301_reg_136586.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_886_fu_99363_p2() {
    mul_ln1118_886_fu_99363_p2 = (!mul_ln1118_886_fu_99363_p0.read().is_01() || !mul_ln1118_886_fu_99363_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_886_fu_99363_p0.read()) * sc_bigint<2>(mul_ln1118_886_fu_99363_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_887_fu_99384_p0() {
    mul_ln1118_887_fu_99384_p0 =  (sc_lv<10>) (zext_ln1116_528_fu_97479_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_887_fu_99384_p1() {
    mul_ln1118_887_fu_99384_p1 = tmp_1302_reg_136591.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_887_fu_99384_p2() {
    mul_ln1118_887_fu_99384_p2 = (!mul_ln1118_887_fu_99384_p0.read().is_01() || !mul_ln1118_887_fu_99384_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_887_fu_99384_p0.read()) * sc_bigint<2>(mul_ln1118_887_fu_99384_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_888_fu_99405_p0() {
    mul_ln1118_888_fu_99405_p0 =  (sc_lv<10>) (zext_ln1116_529_fu_97503_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_888_fu_99405_p1() {
    mul_ln1118_888_fu_99405_p1 = tmp_1303_reg_136596.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_888_fu_99405_p2() {
    mul_ln1118_888_fu_99405_p2 = (!mul_ln1118_888_fu_99405_p0.read().is_01() || !mul_ln1118_888_fu_99405_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_888_fu_99405_p0.read()) * sc_bigint<2>(mul_ln1118_888_fu_99405_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_889_fu_99414_p0() {
    mul_ln1118_889_fu_99414_p0 =  (sc_lv<10>) (zext_ln1116_530_fu_97515_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_889_fu_99414_p1() {
    mul_ln1118_889_fu_99414_p1 = tmp_1304_reg_136601.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_889_fu_99414_p2() {
    mul_ln1118_889_fu_99414_p2 = (!mul_ln1118_889_fu_99414_p0.read().is_01() || !mul_ln1118_889_fu_99414_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_889_fu_99414_p0.read()) * sc_bigint<2>(mul_ln1118_889_fu_99414_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_88_fu_81651_p0() {
    mul_ln1118_88_fu_81651_p0 =  (sc_lv<10>) (zext_ln1116_87_fu_81645_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_88_fu_81651_p1() {
    mul_ln1118_88_fu_81651_p1 = tmp_169_reg_130111.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_88_fu_81651_p2() {
    mul_ln1118_88_fu_81651_p2 = (!mul_ln1118_88_fu_81651_p0.read().is_01() || !mul_ln1118_88_fu_81651_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_88_fu_81651_p0.read()) * sc_bigint<2>(mul_ln1118_88_fu_81651_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_890_fu_99435_p0() {
    mul_ln1118_890_fu_99435_p0 =  (sc_lv<10>) (zext_ln1116_531_fu_97539_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_890_fu_99435_p1() {
    mul_ln1118_890_fu_99435_p1 = tmp_1305_reg_136606.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_890_fu_99435_p2() {
    mul_ln1118_890_fu_99435_p2 = (!mul_ln1118_890_fu_99435_p0.read().is_01() || !mul_ln1118_890_fu_99435_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_890_fu_99435_p0.read()) * sc_bigint<2>(mul_ln1118_890_fu_99435_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_891_fu_99456_p0() {
    mul_ln1118_891_fu_99456_p0 =  (sc_lv<10>) (zext_ln1116_532_fu_97563_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_891_fu_99456_p1() {
    mul_ln1118_891_fu_99456_p1 = tmp_1306_reg_136611.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_891_fu_99456_p2() {
    mul_ln1118_891_fu_99456_p2 = (!mul_ln1118_891_fu_99456_p0.read().is_01() || !mul_ln1118_891_fu_99456_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_891_fu_99456_p0.read()) * sc_bigint<2>(mul_ln1118_891_fu_99456_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_892_fu_99477_p0() {
    mul_ln1118_892_fu_99477_p0 =  (sc_lv<10>) (zext_ln1116_533_fu_97587_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_892_fu_99477_p1() {
    mul_ln1118_892_fu_99477_p1 = tmp_1307_reg_136616.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_892_fu_99477_p2() {
    mul_ln1118_892_fu_99477_p2 = (!mul_ln1118_892_fu_99477_p0.read().is_01() || !mul_ln1118_892_fu_99477_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_892_fu_99477_p0.read()) * sc_bigint<2>(mul_ln1118_892_fu_99477_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_893_fu_99498_p0() {
    mul_ln1118_893_fu_99498_p0 =  (sc_lv<10>) (zext_ln1116_534_fu_97611_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_893_fu_99498_p1() {
    mul_ln1118_893_fu_99498_p1 = tmp_1308_reg_136621.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_893_fu_99498_p2() {
    mul_ln1118_893_fu_99498_p2 = (!mul_ln1118_893_fu_99498_p0.read().is_01() || !mul_ln1118_893_fu_99498_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_893_fu_99498_p0.read()) * sc_bigint<2>(mul_ln1118_893_fu_99498_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_894_fu_99507_p0() {
    mul_ln1118_894_fu_99507_p0 =  (sc_lv<10>) (zext_ln1116_535_fu_97623_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_894_fu_99507_p1() {
    mul_ln1118_894_fu_99507_p1 = tmp_1309_reg_136626.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_894_fu_99507_p2() {
    mul_ln1118_894_fu_99507_p2 = (!mul_ln1118_894_fu_99507_p0.read().is_01() || !mul_ln1118_894_fu_99507_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_894_fu_99507_p0.read()) * sc_bigint<2>(mul_ln1118_894_fu_99507_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_895_fu_99528_p0() {
    mul_ln1118_895_fu_99528_p0 =  (sc_lv<10>) (zext_ln1116_536_fu_97647_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_895_fu_99528_p1() {
    mul_ln1118_895_fu_99528_p1 = tmp_1310_reg_136631.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_895_fu_99528_p2() {
    mul_ln1118_895_fu_99528_p2 = (!mul_ln1118_895_fu_99528_p0.read().is_01() || !mul_ln1118_895_fu_99528_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_895_fu_99528_p0.read()) * sc_bigint<2>(mul_ln1118_895_fu_99528_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_896_fu_99549_p0() {
    mul_ln1118_896_fu_99549_p0 =  (sc_lv<10>) (zext_ln1116_537_fu_97671_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_896_fu_99549_p1() {
    mul_ln1118_896_fu_99549_p1 = tmp_1311_reg_136636.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_896_fu_99549_p2() {
    mul_ln1118_896_fu_99549_p2 = (!mul_ln1118_896_fu_99549_p0.read().is_01() || !mul_ln1118_896_fu_99549_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_896_fu_99549_p0.read()) * sc_bigint<2>(mul_ln1118_896_fu_99549_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_897_fu_99570_p0() {
    mul_ln1118_897_fu_99570_p0 =  (sc_lv<10>) (zext_ln1116_538_fu_97695_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_897_fu_99570_p1() {
    mul_ln1118_897_fu_99570_p1 = tmp_1312_reg_136641.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_897_fu_99570_p2() {
    mul_ln1118_897_fu_99570_p2 = (!mul_ln1118_897_fu_99570_p0.read().is_01() || !mul_ln1118_897_fu_99570_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_897_fu_99570_p0.read()) * sc_bigint<2>(mul_ln1118_897_fu_99570_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_898_fu_99591_p0() {
    mul_ln1118_898_fu_99591_p0 =  (sc_lv<10>) (zext_ln1116_539_fu_97719_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_898_fu_99591_p1() {
    mul_ln1118_898_fu_99591_p1 = tmp_1313_reg_136646.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_898_fu_99591_p2() {
    mul_ln1118_898_fu_99591_p2 = (!mul_ln1118_898_fu_99591_p0.read().is_01() || !mul_ln1118_898_fu_99591_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_898_fu_99591_p0.read()) * sc_bigint<2>(mul_ln1118_898_fu_99591_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_899_fu_99600_p0() {
    mul_ln1118_899_fu_99600_p0 =  (sc_lv<10>) (zext_ln1116_540_fu_97731_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_899_fu_99600_p1() {
    mul_ln1118_899_fu_99600_p1 = tmp_1314_reg_136651.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_899_fu_99600_p2() {
    mul_ln1118_899_fu_99600_p2 = (!mul_ln1118_899_fu_99600_p0.read().is_01() || !mul_ln1118_899_fu_99600_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_899_fu_99600_p0.read()) * sc_bigint<2>(mul_ln1118_899_fu_99600_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_89_fu_81675_p0() {
    mul_ln1118_89_fu_81675_p0 =  (sc_lv<10>) (zext_ln1116_88_fu_81669_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_89_fu_81675_p1() {
    mul_ln1118_89_fu_81675_p1 = tmp_171_reg_130121.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_89_fu_81675_p2() {
    mul_ln1118_89_fu_81675_p2 = (!mul_ln1118_89_fu_81675_p0.read().is_01() || !mul_ln1118_89_fu_81675_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_89_fu_81675_p0.read()) * sc_bigint<2>(mul_ln1118_89_fu_81675_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_8_fu_79767_p0() {
    mul_ln1118_8_fu_79767_p0 =  (sc_lv<10>) (mul_ln1118_8_fu_79767_p00.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_8_fu_79767_p00() {
    mul_ln1118_8_fu_79767_p00 = esl_zext<12,10>(trunc_ln77_5_reg_129311.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_8_fu_79767_p1() {
    mul_ln1118_8_fu_79767_p1 = tmp_5_reg_129316.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_8_fu_79767_p2() {
    mul_ln1118_8_fu_79767_p2 = (!mul_ln1118_8_fu_79767_p0.read().is_01() || !mul_ln1118_8_fu_79767_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_8_fu_79767_p0.read()) * sc_bigint<2>(mul_ln1118_8_fu_79767_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_900_fu_99621_p0() {
    mul_ln1118_900_fu_99621_p0 =  (sc_lv<10>) (zext_ln1116_541_fu_97755_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_900_fu_99621_p1() {
    mul_ln1118_900_fu_99621_p1 = tmp_1315_reg_136656.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_900_fu_99621_p2() {
    mul_ln1118_900_fu_99621_p2 = (!mul_ln1118_900_fu_99621_p0.read().is_01() || !mul_ln1118_900_fu_99621_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_900_fu_99621_p0.read()) * sc_bigint<2>(mul_ln1118_900_fu_99621_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_901_fu_99642_p0() {
    mul_ln1118_901_fu_99642_p0 =  (sc_lv<10>) (zext_ln1116_542_fu_97779_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_901_fu_99642_p1() {
    mul_ln1118_901_fu_99642_p1 = tmp_1316_reg_136661.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_901_fu_99642_p2() {
    mul_ln1118_901_fu_99642_p2 = (!mul_ln1118_901_fu_99642_p0.read().is_01() || !mul_ln1118_901_fu_99642_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_901_fu_99642_p0.read()) * sc_bigint<2>(mul_ln1118_901_fu_99642_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_902_fu_99651_p0() {
    mul_ln1118_902_fu_99651_p0 =  (sc_lv<10>) (zext_ln1116_543_fu_97791_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_902_fu_99651_p1() {
    mul_ln1118_902_fu_99651_p1 = tmp_1317_reg_136666.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_902_fu_99651_p2() {
    mul_ln1118_902_fu_99651_p2 = (!mul_ln1118_902_fu_99651_p0.read().is_01() || !mul_ln1118_902_fu_99651_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_902_fu_99651_p0.read()) * sc_bigint<2>(mul_ln1118_902_fu_99651_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_903_fu_99672_p0() {
    mul_ln1118_903_fu_99672_p0 =  (sc_lv<10>) (zext_ln1116_544_fu_97815_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_903_fu_99672_p1() {
    mul_ln1118_903_fu_99672_p1 = tmp_1318_reg_136671.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_903_fu_99672_p2() {
    mul_ln1118_903_fu_99672_p2 = (!mul_ln1118_903_fu_99672_p0.read().is_01() || !mul_ln1118_903_fu_99672_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_903_fu_99672_p0.read()) * sc_bigint<2>(mul_ln1118_903_fu_99672_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_904_fu_99693_p0() {
    mul_ln1118_904_fu_99693_p0 =  (sc_lv<10>) (zext_ln1116_545_fu_97839_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_904_fu_99693_p1() {
    mul_ln1118_904_fu_99693_p1 = tmp_1319_reg_136676.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_904_fu_99693_p2() {
    mul_ln1118_904_fu_99693_p2 = (!mul_ln1118_904_fu_99693_p0.read().is_01() || !mul_ln1118_904_fu_99693_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_904_fu_99693_p0.read()) * sc_bigint<2>(mul_ln1118_904_fu_99693_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_905_fu_99702_p0() {
    mul_ln1118_905_fu_99702_p0 =  (sc_lv<10>) (zext_ln1116_546_fu_97851_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_905_fu_99702_p1() {
    mul_ln1118_905_fu_99702_p1 = tmp_1320_reg_136681.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_905_fu_99702_p2() {
    mul_ln1118_905_fu_99702_p2 = (!mul_ln1118_905_fu_99702_p0.read().is_01() || !mul_ln1118_905_fu_99702_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_905_fu_99702_p0.read()) * sc_bigint<2>(mul_ln1118_905_fu_99702_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_906_fu_99723_p0() {
    mul_ln1118_906_fu_99723_p0 =  (sc_lv<10>) (zext_ln1116_547_fu_97875_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_906_fu_99723_p1() {
    mul_ln1118_906_fu_99723_p1 = tmp_1321_reg_136686.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_906_fu_99723_p2() {
    mul_ln1118_906_fu_99723_p2 = (!mul_ln1118_906_fu_99723_p0.read().is_01() || !mul_ln1118_906_fu_99723_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_906_fu_99723_p0.read()) * sc_bigint<2>(mul_ln1118_906_fu_99723_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_907_fu_99744_p0() {
    mul_ln1118_907_fu_99744_p0 =  (sc_lv<10>) (zext_ln1116_548_fu_97899_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_907_fu_99744_p1() {
    mul_ln1118_907_fu_99744_p1 = tmp_1322_reg_136691.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_907_fu_99744_p2() {
    mul_ln1118_907_fu_99744_p2 = (!mul_ln1118_907_fu_99744_p0.read().is_01() || !mul_ln1118_907_fu_99744_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_907_fu_99744_p0.read()) * sc_bigint<2>(mul_ln1118_907_fu_99744_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_908_fu_99765_p0() {
    mul_ln1118_908_fu_99765_p0 =  (sc_lv<10>) (zext_ln1116_549_fu_97923_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_908_fu_99765_p1() {
    mul_ln1118_908_fu_99765_p1 = tmp_1323_reg_136696.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_908_fu_99765_p2() {
    mul_ln1118_908_fu_99765_p2 = (!mul_ln1118_908_fu_99765_p0.read().is_01() || !mul_ln1118_908_fu_99765_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_908_fu_99765_p0.read()) * sc_bigint<2>(mul_ln1118_908_fu_99765_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_909_fu_99786_p0() {
    mul_ln1118_909_fu_99786_p0 =  (sc_lv<10>) (zext_ln1116_550_fu_97947_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_909_fu_99786_p1() {
    mul_ln1118_909_fu_99786_p1 = tmp_1324_reg_136701.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_909_fu_99786_p2() {
    mul_ln1118_909_fu_99786_p2 = (!mul_ln1118_909_fu_99786_p0.read().is_01() || !mul_ln1118_909_fu_99786_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_909_fu_99786_p0.read()) * sc_bigint<2>(mul_ln1118_909_fu_99786_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_90_fu_81699_p0() {
    mul_ln1118_90_fu_81699_p0 =  (sc_lv<10>) (zext_ln1116_89_fu_81693_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_90_fu_81699_p1() {
    mul_ln1118_90_fu_81699_p1 = tmp_173_reg_130131.read();
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_90_fu_81699_p2() {
    mul_ln1118_90_fu_81699_p2 = (!mul_ln1118_90_fu_81699_p0.read().is_01() || !mul_ln1118_90_fu_81699_p1.read().is_01())? sc_lv<12>(): sc_biguint<10>(mul_ln1118_90_fu_81699_p0.read()) * sc_bigint<2>(mul_ln1118_90_fu_81699_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_config2_s::thread_mul_ln1118_910_fu_99795_p0() {
    mul_ln1118_910_fu_99795_p0 =  (sc_lv<10>) (zext_ln1116_551_fu_97959_p1.read());
}

}


//Numpy array shape [1]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 1

#ifndef B10_H_
#define B10_H_

#ifndef __SYNTHESIS__
conv2d_2_bias_t b10[1];
#else
conv2d_2_bias_t b10[1] = {0.0000000000};
#endif

#endif

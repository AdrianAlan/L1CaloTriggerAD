//Numpy array shape [15]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 15

#ifndef B3_H_
#define B3_H_

#ifndef __SYNTHESIS__
bias3_t b3[15];
#else
bias3_t b3[15] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#endif

#endif

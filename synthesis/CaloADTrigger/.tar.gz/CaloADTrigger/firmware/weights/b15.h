//Numpy array shape [10]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 10

#ifndef B15_H_
#define B15_H_

#ifndef __SYNTHESIS__
conv2d_4_bias_t b15[10];
#else
conv2d_4_bias_t b15[10] = {0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000};
#endif

#endif

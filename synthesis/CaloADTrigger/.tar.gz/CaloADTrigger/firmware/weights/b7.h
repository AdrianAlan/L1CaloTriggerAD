//Numpy array shape [1]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 1

#ifndef B7_H_
#define B7_H_

#ifndef __SYNTHESIS__
bias7_t b7[1];
#else
bias7_t b7[1] = {0};
#endif

#endif

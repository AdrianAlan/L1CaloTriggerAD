//Numpy array shape [5]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 5

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
conv2d_3_bias_t b11[5];
#else
conv2d_3_bias_t b11[5] = {0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000};
#endif

#endif

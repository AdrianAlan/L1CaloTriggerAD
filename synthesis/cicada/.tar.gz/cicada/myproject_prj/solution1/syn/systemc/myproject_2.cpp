#include "myproject.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void myproject::thread_ap_clk_no_reset_() {
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_0_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_0_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_0_V = ap_sync_channel_write_layer3_out_0_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_100_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_100_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_100_V = ap_sync_channel_write_layer3_out_100_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_101_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_101_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_101_V = ap_sync_channel_write_layer3_out_101_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_102_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_102_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_102_V = ap_sync_channel_write_layer3_out_102_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_103_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_103_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_103_V = ap_sync_channel_write_layer3_out_103_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_104_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_104_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_104_V = ap_sync_channel_write_layer3_out_104_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_105_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_105_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_105_V = ap_sync_channel_write_layer3_out_105_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_106_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_106_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_106_V = ap_sync_channel_write_layer3_out_106_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_107_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_107_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_107_V = ap_sync_channel_write_layer3_out_107_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_108_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_108_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_108_V = ap_sync_channel_write_layer3_out_108_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_109_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_109_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_109_V = ap_sync_channel_write_layer3_out_109_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_10_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_10_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_10_V = ap_sync_channel_write_layer3_out_10_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_110_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_110_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_110_V = ap_sync_channel_write_layer3_out_110_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_111_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_111_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_111_V = ap_sync_channel_write_layer3_out_111_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_112_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_112_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_112_V = ap_sync_channel_write_layer3_out_112_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_113_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_113_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_113_V = ap_sync_channel_write_layer3_out_113_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_114_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_114_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_114_V = ap_sync_channel_write_layer3_out_114_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_115_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_115_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_115_V = ap_sync_channel_write_layer3_out_115_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_116_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_116_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_116_V = ap_sync_channel_write_layer3_out_116_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_117_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_117_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_117_V = ap_sync_channel_write_layer3_out_117_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_118_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_118_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_118_V = ap_sync_channel_write_layer3_out_118_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_119_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_119_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_119_V = ap_sync_channel_write_layer3_out_119_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_11_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_11_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_11_V = ap_sync_channel_write_layer3_out_11_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_120_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_120_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_120_V = ap_sync_channel_write_layer3_out_120_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_121_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_121_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_121_V = ap_sync_channel_write_layer3_out_121_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_122_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_122_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_122_V = ap_sync_channel_write_layer3_out_122_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_123_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_123_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_123_V = ap_sync_channel_write_layer3_out_123_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_124_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_124_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_124_V = ap_sync_channel_write_layer3_out_124_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_125_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_125_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_125_V = ap_sync_channel_write_layer3_out_125_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_126_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_126_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_126_V = ap_sync_channel_write_layer3_out_126_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_127_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_127_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_127_V = ap_sync_channel_write_layer3_out_127_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_128_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_128_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_128_V = ap_sync_channel_write_layer3_out_128_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_129_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_129_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_129_V = ap_sync_channel_write_layer3_out_129_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_12_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_12_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_12_V = ap_sync_channel_write_layer3_out_12_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_130_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_130_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_130_V = ap_sync_channel_write_layer3_out_130_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_131_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_131_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_131_V = ap_sync_channel_write_layer3_out_131_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_132_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_132_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_132_V = ap_sync_channel_write_layer3_out_132_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_133_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_133_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_133_V = ap_sync_channel_write_layer3_out_133_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_134_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_134_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_134_V = ap_sync_channel_write_layer3_out_134_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_135_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_135_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_135_V = ap_sync_channel_write_layer3_out_135_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_136_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_136_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_136_V = ap_sync_channel_write_layer3_out_136_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_137_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_137_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_137_V = ap_sync_channel_write_layer3_out_137_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_138_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_138_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_138_V = ap_sync_channel_write_layer3_out_138_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_139_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_139_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_139_V = ap_sync_channel_write_layer3_out_139_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_13_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_13_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_13_V = ap_sync_channel_write_layer3_out_13_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_140_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_140_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_140_V = ap_sync_channel_write_layer3_out_140_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_141_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_141_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_141_V = ap_sync_channel_write_layer3_out_141_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_142_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_142_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_142_V = ap_sync_channel_write_layer3_out_142_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_143_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_143_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_143_V = ap_sync_channel_write_layer3_out_143_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_14_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_14_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_14_V = ap_sync_channel_write_layer3_out_14_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_15_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_15_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_15_V = ap_sync_channel_write_layer3_out_15_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_16_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_16_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_16_V = ap_sync_channel_write_layer3_out_16_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_17_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_17_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_17_V = ap_sync_channel_write_layer3_out_17_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_18_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_18_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_18_V = ap_sync_channel_write_layer3_out_18_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_19_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_19_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_19_V = ap_sync_channel_write_layer3_out_19_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_1_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_1_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_1_V = ap_sync_channel_write_layer3_out_1_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_20_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_20_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_20_V = ap_sync_channel_write_layer3_out_20_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_21_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_21_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_21_V = ap_sync_channel_write_layer3_out_21_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_22_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_22_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_22_V = ap_sync_channel_write_layer3_out_22_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_23_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_23_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_23_V = ap_sync_channel_write_layer3_out_23_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_24_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_24_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_24_V = ap_sync_channel_write_layer3_out_24_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_25_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_25_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_25_V = ap_sync_channel_write_layer3_out_25_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_26_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_26_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_26_V = ap_sync_channel_write_layer3_out_26_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_27_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_27_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_27_V = ap_sync_channel_write_layer3_out_27_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_28_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_28_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_28_V = ap_sync_channel_write_layer3_out_28_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_29_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_29_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_29_V = ap_sync_channel_write_layer3_out_29_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_2_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_2_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_2_V = ap_sync_channel_write_layer3_out_2_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_30_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_30_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_30_V = ap_sync_channel_write_layer3_out_30_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_31_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_31_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_31_V = ap_sync_channel_write_layer3_out_31_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_32_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_32_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_32_V = ap_sync_channel_write_layer3_out_32_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_33_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_33_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_33_V = ap_sync_channel_write_layer3_out_33_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_34_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_34_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_34_V = ap_sync_channel_write_layer3_out_34_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_35_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_35_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_35_V = ap_sync_channel_write_layer3_out_35_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_36_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_36_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_36_V = ap_sync_channel_write_layer3_out_36_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_37_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_37_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_37_V = ap_sync_channel_write_layer3_out_37_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_38_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_38_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_38_V = ap_sync_channel_write_layer3_out_38_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_39_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_39_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_39_V = ap_sync_channel_write_layer3_out_39_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_3_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_3_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_3_V = ap_sync_channel_write_layer3_out_3_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_40_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_40_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_40_V = ap_sync_channel_write_layer3_out_40_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_41_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_41_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_41_V = ap_sync_channel_write_layer3_out_41_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_42_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_42_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_42_V = ap_sync_channel_write_layer3_out_42_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_43_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_43_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_43_V = ap_sync_channel_write_layer3_out_43_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_44_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_44_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_44_V = ap_sync_channel_write_layer3_out_44_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_45_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_45_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_45_V = ap_sync_channel_write_layer3_out_45_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_46_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_46_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_46_V = ap_sync_channel_write_layer3_out_46_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_47_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_47_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_47_V = ap_sync_channel_write_layer3_out_47_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_48_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_48_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_48_V = ap_sync_channel_write_layer3_out_48_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_49_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_49_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_49_V = ap_sync_channel_write_layer3_out_49_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_4_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_4_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_4_V = ap_sync_channel_write_layer3_out_4_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_50_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_50_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_50_V = ap_sync_channel_write_layer3_out_50_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_51_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_51_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_51_V = ap_sync_channel_write_layer3_out_51_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_52_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_52_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_52_V = ap_sync_channel_write_layer3_out_52_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_53_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_53_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_53_V = ap_sync_channel_write_layer3_out_53_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_54_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_54_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_54_V = ap_sync_channel_write_layer3_out_54_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_55_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_55_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_55_V = ap_sync_channel_write_layer3_out_55_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_56_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_56_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_56_V = ap_sync_channel_write_layer3_out_56_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_57_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_57_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_57_V = ap_sync_channel_write_layer3_out_57_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_58_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_58_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_58_V = ap_sync_channel_write_layer3_out_58_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_59_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_59_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_59_V = ap_sync_channel_write_layer3_out_59_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_5_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_5_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_5_V = ap_sync_channel_write_layer3_out_5_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_60_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_60_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_60_V = ap_sync_channel_write_layer3_out_60_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_61_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_61_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_61_V = ap_sync_channel_write_layer3_out_61_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_62_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_62_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_62_V = ap_sync_channel_write_layer3_out_62_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_63_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_63_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_63_V = ap_sync_channel_write_layer3_out_63_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_64_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_64_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_64_V = ap_sync_channel_write_layer3_out_64_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_65_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_65_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_65_V = ap_sync_channel_write_layer3_out_65_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_66_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_66_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_66_V = ap_sync_channel_write_layer3_out_66_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_67_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_67_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_67_V = ap_sync_channel_write_layer3_out_67_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_68_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_68_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_68_V = ap_sync_channel_write_layer3_out_68_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_69_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_69_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_69_V = ap_sync_channel_write_layer3_out_69_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_6_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_6_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_6_V = ap_sync_channel_write_layer3_out_6_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_70_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_70_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_70_V = ap_sync_channel_write_layer3_out_70_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_71_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_71_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_71_V = ap_sync_channel_write_layer3_out_71_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_72_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_72_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_72_V = ap_sync_channel_write_layer3_out_72_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_73_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_73_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_73_V = ap_sync_channel_write_layer3_out_73_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_74_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_74_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_74_V = ap_sync_channel_write_layer3_out_74_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_75_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_75_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_75_V = ap_sync_channel_write_layer3_out_75_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_76_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_76_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_76_V = ap_sync_channel_write_layer3_out_76_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_77_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_77_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_77_V = ap_sync_channel_write_layer3_out_77_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_78_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_78_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_78_V = ap_sync_channel_write_layer3_out_78_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_79_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_79_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_79_V = ap_sync_channel_write_layer3_out_79_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_7_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_7_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_7_V = ap_sync_channel_write_layer3_out_7_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_80_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_80_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_80_V = ap_sync_channel_write_layer3_out_80_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_81_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_81_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_81_V = ap_sync_channel_write_layer3_out_81_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_82_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_82_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_82_V = ap_sync_channel_write_layer3_out_82_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_83_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_83_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_83_V = ap_sync_channel_write_layer3_out_83_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_84_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_84_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_84_V = ap_sync_channel_write_layer3_out_84_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_85_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_85_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_85_V = ap_sync_channel_write_layer3_out_85_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_86_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_86_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_86_V = ap_sync_channel_write_layer3_out_86_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_87_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_87_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_87_V = ap_sync_channel_write_layer3_out_87_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_88_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_88_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_88_V = ap_sync_channel_write_layer3_out_88_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_89_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_89_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_89_V = ap_sync_channel_write_layer3_out_89_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_8_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_8_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_8_V = ap_sync_channel_write_layer3_out_8_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_90_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_90_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_90_V = ap_sync_channel_write_layer3_out_90_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_91_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_91_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_91_V = ap_sync_channel_write_layer3_out_91_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_92_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_92_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_92_V = ap_sync_channel_write_layer3_out_92_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_93_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_93_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_93_V = ap_sync_channel_write_layer3_out_93_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_94_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_94_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_94_V = ap_sync_channel_write_layer3_out_94_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_95_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_95_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_95_V = ap_sync_channel_write_layer3_out_95_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_96_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_96_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_96_V = ap_sync_channel_write_layer3_out_96_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_97_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_97_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_97_V = ap_sync_channel_write_layer3_out_97_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_98_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_98_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_98_V = ap_sync_channel_write_layer3_out_98_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_99_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_99_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_99_V = ap_sync_channel_write_layer3_out_99_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer3_out_9_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_done.read() & 
             conv_2d_cl_ap_uint_10_ap_fixed_20_8_5_3_0_config3_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer3_out_9_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer3_out_9_V = ap_sync_channel_write_layer3_out_9_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_0_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_0_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_0_V = ap_sync_channel_write_layer5_out_0_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_100_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_100_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_100_V = ap_sync_channel_write_layer5_out_100_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_101_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_101_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_101_V = ap_sync_channel_write_layer5_out_101_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_102_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_102_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_102_V = ap_sync_channel_write_layer5_out_102_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_103_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_103_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_103_V = ap_sync_channel_write_layer5_out_103_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_104_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_104_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_104_V = ap_sync_channel_write_layer5_out_104_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_105_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_105_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_105_V = ap_sync_channel_write_layer5_out_105_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_106_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_106_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_106_V = ap_sync_channel_write_layer5_out_106_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_107_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_107_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_107_V = ap_sync_channel_write_layer5_out_107_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_108_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_108_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_108_V = ap_sync_channel_write_layer5_out_108_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_109_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_109_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_109_V = ap_sync_channel_write_layer5_out_109_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_10_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_10_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_10_V = ap_sync_channel_write_layer5_out_10_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_110_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_110_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_110_V = ap_sync_channel_write_layer5_out_110_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_111_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_111_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_111_V = ap_sync_channel_write_layer5_out_111_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_112_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_112_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_112_V = ap_sync_channel_write_layer5_out_112_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_113_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_113_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_113_V = ap_sync_channel_write_layer5_out_113_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_114_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_114_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_114_V = ap_sync_channel_write_layer5_out_114_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_115_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_115_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_115_V = ap_sync_channel_write_layer5_out_115_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_116_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_116_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_116_V = ap_sync_channel_write_layer5_out_116_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_117_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_117_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_117_V = ap_sync_channel_write_layer5_out_117_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_118_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_118_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_118_V = ap_sync_channel_write_layer5_out_118_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_119_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_119_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_119_V = ap_sync_channel_write_layer5_out_119_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_11_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_11_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_11_V = ap_sync_channel_write_layer5_out_11_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_120_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_120_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_120_V = ap_sync_channel_write_layer5_out_120_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_121_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_121_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_121_V = ap_sync_channel_write_layer5_out_121_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_122_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_122_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_122_V = ap_sync_channel_write_layer5_out_122_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_123_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_123_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_123_V = ap_sync_channel_write_layer5_out_123_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_124_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_124_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_124_V = ap_sync_channel_write_layer5_out_124_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_125_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_125_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_125_V = ap_sync_channel_write_layer5_out_125_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_126_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_126_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_126_V = ap_sync_channel_write_layer5_out_126_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_127_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_127_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_127_V = ap_sync_channel_write_layer5_out_127_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_128_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_128_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_128_V = ap_sync_channel_write_layer5_out_128_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_129_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_129_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_129_V = ap_sync_channel_write_layer5_out_129_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_12_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_12_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_12_V = ap_sync_channel_write_layer5_out_12_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_130_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_130_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_130_V = ap_sync_channel_write_layer5_out_130_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_131_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_131_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_131_V = ap_sync_channel_write_layer5_out_131_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_132_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_132_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_132_V = ap_sync_channel_write_layer5_out_132_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_133_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_133_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_133_V = ap_sync_channel_write_layer5_out_133_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_134_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_134_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_134_V = ap_sync_channel_write_layer5_out_134_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_135_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_135_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_135_V = ap_sync_channel_write_layer5_out_135_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_136_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_136_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_136_V = ap_sync_channel_write_layer5_out_136_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_137_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_137_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_137_V = ap_sync_channel_write_layer5_out_137_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_138_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_138_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_138_V = ap_sync_channel_write_layer5_out_138_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_139_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_139_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_139_V = ap_sync_channel_write_layer5_out_139_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_13_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_13_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_13_V = ap_sync_channel_write_layer5_out_13_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_140_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_140_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_140_V = ap_sync_channel_write_layer5_out_140_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_141_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_141_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_141_V = ap_sync_channel_write_layer5_out_141_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_142_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_142_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_142_V = ap_sync_channel_write_layer5_out_142_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_143_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_143_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_143_V = ap_sync_channel_write_layer5_out_143_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_14_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_14_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_14_V = ap_sync_channel_write_layer5_out_14_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_15_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_15_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_15_V = ap_sync_channel_write_layer5_out_15_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_16_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_16_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_16_V = ap_sync_channel_write_layer5_out_16_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_17_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_17_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_17_V = ap_sync_channel_write_layer5_out_17_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_18_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_18_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_18_V = ap_sync_channel_write_layer5_out_18_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_19_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_19_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_19_V = ap_sync_channel_write_layer5_out_19_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_1_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_1_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_1_V = ap_sync_channel_write_layer5_out_1_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_20_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_20_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_20_V = ap_sync_channel_write_layer5_out_20_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_21_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_21_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_21_V = ap_sync_channel_write_layer5_out_21_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_22_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_22_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_22_V = ap_sync_channel_write_layer5_out_22_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_23_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_23_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_23_V = ap_sync_channel_write_layer5_out_23_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_24_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_24_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_24_V = ap_sync_channel_write_layer5_out_24_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_25_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_25_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_25_V = ap_sync_channel_write_layer5_out_25_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_26_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_26_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_26_V = ap_sync_channel_write_layer5_out_26_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_27_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_27_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_27_V = ap_sync_channel_write_layer5_out_27_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_28_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_28_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_28_V = ap_sync_channel_write_layer5_out_28_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_29_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_29_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_29_V = ap_sync_channel_write_layer5_out_29_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_2_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_2_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_2_V = ap_sync_channel_write_layer5_out_2_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_30_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_30_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_30_V = ap_sync_channel_write_layer5_out_30_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_31_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_31_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_31_V = ap_sync_channel_write_layer5_out_31_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_32_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_32_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_32_V = ap_sync_channel_write_layer5_out_32_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_33_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_33_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_33_V = ap_sync_channel_write_layer5_out_33_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_34_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_34_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_34_V = ap_sync_channel_write_layer5_out_34_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_35_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_35_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_35_V = ap_sync_channel_write_layer5_out_35_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_36_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_36_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_36_V = ap_sync_channel_write_layer5_out_36_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_37_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_37_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_37_V = ap_sync_channel_write_layer5_out_37_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_38_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_38_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_38_V = ap_sync_channel_write_layer5_out_38_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_39_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_39_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_39_V = ap_sync_channel_write_layer5_out_39_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_3_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_3_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_3_V = ap_sync_channel_write_layer5_out_3_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_40_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_40_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_40_V = ap_sync_channel_write_layer5_out_40_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_41_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_41_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_41_V = ap_sync_channel_write_layer5_out_41_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_42_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_42_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_42_V = ap_sync_channel_write_layer5_out_42_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_43_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_43_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_43_V = ap_sync_channel_write_layer5_out_43_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_44_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_44_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_44_V = ap_sync_channel_write_layer5_out_44_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_45_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_45_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_45_V = ap_sync_channel_write_layer5_out_45_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_46_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_46_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_46_V = ap_sync_channel_write_layer5_out_46_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_47_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_47_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_47_V = ap_sync_channel_write_layer5_out_47_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_48_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_48_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_48_V = ap_sync_channel_write_layer5_out_48_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_49_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_49_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_49_V = ap_sync_channel_write_layer5_out_49_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_4_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_4_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_4_V = ap_sync_channel_write_layer5_out_4_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_50_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_50_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_50_V = ap_sync_channel_write_layer5_out_50_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_51_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_51_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_51_V = ap_sync_channel_write_layer5_out_51_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_52_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_52_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_52_V = ap_sync_channel_write_layer5_out_52_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_53_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_53_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_53_V = ap_sync_channel_write_layer5_out_53_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_54_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_54_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_54_V = ap_sync_channel_write_layer5_out_54_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_55_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_55_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_55_V = ap_sync_channel_write_layer5_out_55_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_56_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_56_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_56_V = ap_sync_channel_write_layer5_out_56_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_57_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_57_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_57_V = ap_sync_channel_write_layer5_out_57_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_58_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_58_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_58_V = ap_sync_channel_write_layer5_out_58_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_59_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_59_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_59_V = ap_sync_channel_write_layer5_out_59_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_5_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_5_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_5_V = ap_sync_channel_write_layer5_out_5_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_60_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_60_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_60_V = ap_sync_channel_write_layer5_out_60_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_61_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_61_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_61_V = ap_sync_channel_write_layer5_out_61_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_62_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_62_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_62_V = ap_sync_channel_write_layer5_out_62_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_63_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_63_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_63_V = ap_sync_channel_write_layer5_out_63_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_64_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_64_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_64_V = ap_sync_channel_write_layer5_out_64_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_65_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_65_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_65_V = ap_sync_channel_write_layer5_out_65_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_66_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_66_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_66_V = ap_sync_channel_write_layer5_out_66_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_67_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_67_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_67_V = ap_sync_channel_write_layer5_out_67_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_68_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_68_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_68_V = ap_sync_channel_write_layer5_out_68_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_69_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_69_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_69_V = ap_sync_channel_write_layer5_out_69_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_6_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_6_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_6_V = ap_sync_channel_write_layer5_out_6_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_70_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_70_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_70_V = ap_sync_channel_write_layer5_out_70_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_71_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_71_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_71_V = ap_sync_channel_write_layer5_out_71_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_72_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_72_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_72_V = ap_sync_channel_write_layer5_out_72_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_73_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_73_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_73_V = ap_sync_channel_write_layer5_out_73_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_74_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_74_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_74_V = ap_sync_channel_write_layer5_out_74_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_75_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_75_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_75_V = ap_sync_channel_write_layer5_out_75_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_76_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_76_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_76_V = ap_sync_channel_write_layer5_out_76_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_77_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_77_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_77_V = ap_sync_channel_write_layer5_out_77_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_78_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_78_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_78_V = ap_sync_channel_write_layer5_out_78_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_79_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_79_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_79_V = ap_sync_channel_write_layer5_out_79_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_7_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_7_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_7_V = ap_sync_channel_write_layer5_out_7_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_80_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_80_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_80_V = ap_sync_channel_write_layer5_out_80_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_81_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_81_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_81_V = ap_sync_channel_write_layer5_out_81_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_82_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_82_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_82_V = ap_sync_channel_write_layer5_out_82_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_83_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_83_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_83_V = ap_sync_channel_write_layer5_out_83_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_84_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_84_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_84_V = ap_sync_channel_write_layer5_out_84_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_85_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_85_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_85_V = ap_sync_channel_write_layer5_out_85_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_86_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_86_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_86_V = ap_sync_channel_write_layer5_out_86_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_87_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_87_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_87_V = ap_sync_channel_write_layer5_out_87_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_88_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_88_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_88_V = ap_sync_channel_write_layer5_out_88_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_89_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_89_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_89_V = ap_sync_channel_write_layer5_out_89_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_8_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_8_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_8_V = ap_sync_channel_write_layer5_out_8_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_90_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_90_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_90_V = ap_sync_channel_write_layer5_out_90_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_91_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_91_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_91_V = ap_sync_channel_write_layer5_out_91_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_92_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_92_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_92_V = ap_sync_channel_write_layer5_out_92_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_93_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_93_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_93_V = ap_sync_channel_write_layer5_out_93_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_94_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_94_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_94_V = ap_sync_channel_write_layer5_out_94_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_95_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_95_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_95_V = ap_sync_channel_write_layer5_out_95_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_96_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_96_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_96_V = ap_sync_channel_write_layer5_out_96_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_97_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_97_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_97_V = ap_sync_channel_write_layer5_out_97_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_98_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_98_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_98_V = ap_sync_channel_write_layer5_out_98_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_99_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_99_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_99_V = ap_sync_channel_write_layer5_out_99_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer5_out_9_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer5_out_9_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer5_out_9_V = ap_sync_channel_write_layer5_out_9_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_0_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_0_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_0_V = ap_sync_channel_write_layer7_out_0_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_10_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_10_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_10_V = ap_sync_channel_write_layer7_out_10_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_11_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_11_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_11_V = ap_sync_channel_write_layer7_out_11_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_12_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_12_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_12_V = ap_sync_channel_write_layer7_out_12_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_13_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_13_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_13_V = ap_sync_channel_write_layer7_out_13_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_14_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_14_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_14_V = ap_sync_channel_write_layer7_out_14_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_15_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_15_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_15_V = ap_sync_channel_write_layer7_out_15_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_16_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_16_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_16_V = ap_sync_channel_write_layer7_out_16_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_17_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_17_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_17_V = ap_sync_channel_write_layer7_out_17_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_18_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_18_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_18_V = ap_sync_channel_write_layer7_out_18_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_19_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_19_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_19_V = ap_sync_channel_write_layer7_out_19_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_1_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_1_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_1_V = ap_sync_channel_write_layer7_out_1_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_2_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_2_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_2_V = ap_sync_channel_write_layer7_out_2_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_3_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_3_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_3_V = ap_sync_channel_write_layer7_out_3_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_4_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_4_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_4_V = ap_sync_channel_write_layer7_out_4_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_5_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_5_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_5_V = ap_sync_channel_write_layer7_out_5_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_6_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_6_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_6_V = ap_sync_channel_write_layer7_out_6_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_7_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_7_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_7_V = ap_sync_channel_write_layer7_out_7_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_8_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_8_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_8_V = ap_sync_channel_write_layer7_out_8_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer7_out_9_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_done.read() & 
             dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer7_out_9_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer7_out_9_V = ap_sync_channel_write_layer7_out_9_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_0_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_0_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_0_V = ap_sync_channel_write_layer9_out_0_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_10_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_10_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_10_V = ap_sync_channel_write_layer9_out_10_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_11_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_11_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_11_V = ap_sync_channel_write_layer9_out_11_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_12_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_12_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_12_V = ap_sync_channel_write_layer9_out_12_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_13_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_13_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_13_V = ap_sync_channel_write_layer9_out_13_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_14_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_14_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_14_V = ap_sync_channel_write_layer9_out_14_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_15_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_15_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_15_V = ap_sync_channel_write_layer9_out_15_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_16_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_16_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_16_V = ap_sync_channel_write_layer9_out_16_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_17_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_17_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_17_V = ap_sync_channel_write_layer9_out_17_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_18_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_18_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_18_V = ap_sync_channel_write_layer9_out_18_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_19_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_19_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_19_V = ap_sync_channel_write_layer9_out_19_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_1_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_1_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_1_V = ap_sync_channel_write_layer9_out_1_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_2_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_2_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_2_V = ap_sync_channel_write_layer9_out_2_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_3_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_3_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_3_V = ap_sync_channel_write_layer9_out_3_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_4_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_4_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_4_V = ap_sync_channel_write_layer9_out_4_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_5_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_5_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_5_V = ap_sync_channel_write_layer9_out_5_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_6_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_6_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_6_V = ap_sync_channel_write_layer9_out_6_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_7_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_7_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_7_V = ap_sync_channel_write_layer9_out_7_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_8_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_8_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_8_V = ap_sync_channel_write_layer9_out_8_V.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_sync_reg_channel_write_layer9_out_9_V = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, (relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_done.read() & 
             relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config9_U0_ap_continue.read()))) {
            ap_sync_reg_channel_write_layer9_out_9_V = ap_const_logic_0;
        } else {
            ap_sync_reg_channel_write_layer9_out_9_V = ap_sync_channel_write_layer9_out_9_V.read();
        }
    }
}

}


#include "conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_77_fu_6445_p1() {
    zext_ln731_77_fu_6445_p1 = esl_zext<19,16>(shl_ln731_32_fu_6437_p3.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_80_fu_6466_p1() {
    zext_ln731_80_fu_6466_p1 = esl_zext<19,16>(shl_ln731_33_fu_6458_p3.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_83_fu_6487_p1() {
    zext_ln731_83_fu_6487_p1 = esl_zext<19,16>(shl_ln731_34_fu_6479_p3.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_84_fu_4871_p1() {
    zext_ln731_84_fu_4871_p1 = esl_zext<16,10>(data_buf_i_0_3_reg_96238.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_85_fu_6498_p1() {
    zext_ln731_85_fu_6498_p1 = esl_zext<19,18>(shl_ln731_35_fu_6491_p3.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_86_fu_4874_p1() {
    zext_ln731_86_fu_4874_p1 = esl_zext<16,10>(data_buf_i_1_3_reg_96305.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_87_fu_6521_p1() {
    zext_ln731_87_fu_6521_p1 = esl_zext<19,18>(shl_ln731_36_fu_6514_p3.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_88_fu_4877_p1() {
    zext_ln731_88_fu_4877_p1 = esl_zext<16,10>(data_buf_i_2_3_reg_96372.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_89_fu_6544_p1() {
    zext_ln731_89_fu_6544_p1 = esl_zext<19,18>(shl_ln731_37_fu_6537_p3.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_8_fu_5932_p1() {
    zext_ln731_8_fu_5932_p1 = esl_zext<18,17>(shl_ln731_2_fu_5925_p3.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_90_fu_4880_p1() {
    zext_ln731_90_fu_4880_p1 = esl_zext<16,10>(data_buf_i_3_3_reg_96439.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_91_fu_6567_p1() {
    zext_ln731_91_fu_6567_p1 = esl_zext<19,18>(shl_ln731_38_fu_6560_p3.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_92_fu_4883_p1() {
    zext_ln731_92_fu_4883_p1 = esl_zext<16,10>(data_buf_i_4_3_reg_96506.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_93_fu_6590_p1() {
    zext_ln731_93_fu_6590_p1 = esl_zext<19,18>(shl_ln731_39_fu_6583_p3.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_94_fu_4886_p1() {
    zext_ln731_94_fu_4886_p1 = esl_zext<16,10>(data_buf_i_5_3_reg_96573.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_95_fu_6613_p1() {
    zext_ln731_95_fu_6613_p1 = esl_zext<19,18>(shl_ln731_40_fu_6606_p3.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_96_fu_4889_p1() {
    zext_ln731_96_fu_4889_p1 = esl_zext<16,10>(data_buf_i_6_3_reg_96640.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_97_fu_6636_p1() {
    zext_ln731_97_fu_6636_p1 = esl_zext<19,18>(shl_ln731_41_fu_6629_p3.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_98_fu_4892_p1() {
    zext_ln731_98_fu_4892_p1 = esl_zext<16,10>(data_buf_i_7_3_reg_96707.read());
}

void conv_2d_cl_ap_uint_10_ap_fixed_15_8_5_3_0_config3_s::thread_zext_ln731_99_fu_6659_p1() {
    zext_ln731_99_fu_6659_p1 = esl_zext<19,18>(shl_ln731_42_fu_6652_p3.read());
}

}


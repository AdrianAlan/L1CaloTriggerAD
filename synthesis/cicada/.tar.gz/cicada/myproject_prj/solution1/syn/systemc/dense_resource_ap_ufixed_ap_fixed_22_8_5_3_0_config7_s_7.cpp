#include "dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_694_fu_56329_p4() {
    trunc_ln708_694_fu_56329_p4 = mul_ln1118_678_reg_74652.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_695_fu_56342_p4() {
    trunc_ln708_695_fu_56342_p4 = mul_ln1118_679_reg_74657.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_696_fu_56355_p4() {
    trunc_ln708_696_fu_56355_p4 = mul_ln1118_680_reg_74662.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_697_fu_56368_p4() {
    trunc_ln708_697_fu_56368_p4 = mul_ln1118_681_reg_74667.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_698_fu_56381_p4() {
    trunc_ln708_698_fu_56381_p4 = mul_ln1118_682_reg_74672.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_699_fu_56394_p4() {
    trunc_ln708_699_fu_56394_p4 = mul_ln1118_683_reg_74677.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_69_fu_45552_p4() {
    trunc_ln708_69_fu_45552_p4 = mul_ln1118_53_reg_71527.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_700_fu_56407_p4() {
    trunc_ln708_700_fu_56407_p4 = mul_ln1118_684_reg_74682.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_701_fu_56420_p4() {
    trunc_ln708_701_fu_56420_p4 = mul_ln1118_685_reg_74687.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_702_fu_56433_p4() {
    trunc_ln708_702_fu_56433_p4 = mul_ln1118_686_reg_74692.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_703_fu_56446_p4() {
    trunc_ln708_703_fu_56446_p4 = mul_ln1118_687_reg_74697.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_704_fu_56615_p4() {
    trunc_ln708_704_fu_56615_p4 = mul_ln1118_688_reg_74702.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_705_fu_56628_p4() {
    trunc_ln708_705_fu_56628_p4 = mul_ln1118_689_reg_74707.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_706_fu_56641_p4() {
    trunc_ln708_706_fu_56641_p4 = mul_ln1118_690_reg_74712.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_707_fu_56654_p4() {
    trunc_ln708_707_fu_56654_p4 = mul_ln1118_691_reg_74717.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_708_fu_56667_p4() {
    trunc_ln708_708_fu_56667_p4 = mul_ln1118_692_reg_74722.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_709_fu_56680_p4() {
    trunc_ln708_709_fu_56680_p4 = mul_ln1118_693_reg_74727.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_70_fu_45565_p4() {
    trunc_ln708_70_fu_45565_p4 = mul_ln1118_54_reg_71532.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_710_fu_56693_p4() {
    trunc_ln708_710_fu_56693_p4 = mul_ln1118_694_reg_74732.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_711_fu_56706_p4() {
    trunc_ln708_711_fu_56706_p4 = mul_ln1118_695_reg_74737.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_712_fu_56719_p4() {
    trunc_ln708_712_fu_56719_p4 = mul_ln1118_696_reg_74742.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_713_fu_56732_p4() {
    trunc_ln708_713_fu_56732_p4 = mul_ln1118_697_reg_74747.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_714_fu_56745_p4() {
    trunc_ln708_714_fu_56745_p4 = mul_ln1118_698_reg_74752.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_715_fu_56758_p4() {
    trunc_ln708_715_fu_56758_p4 = mul_ln1118_699_reg_74757.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_716_fu_56771_p4() {
    trunc_ln708_716_fu_56771_p4 = mul_ln1118_700_reg_74762.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_717_fu_56784_p4() {
    trunc_ln708_717_fu_56784_p4 = mul_ln1118_701_reg_74767.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_718_fu_56797_p4() {
    trunc_ln708_718_fu_56797_p4 = mul_ln1118_702_reg_74772.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_719_fu_56810_p4() {
    trunc_ln708_719_fu_56810_p4 = mul_ln1118_703_reg_74777.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_71_fu_45578_p4() {
    trunc_ln708_71_fu_45578_p4 = mul_ln1118_55_reg_71537.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_720_fu_56823_p4() {
    trunc_ln708_720_fu_56823_p4 = mul_ln1118_704_reg_74782.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_721_fu_56836_p4() {
    trunc_ln708_721_fu_56836_p4 = mul_ln1118_705_reg_74787.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_722_fu_56849_p4() {
    trunc_ln708_722_fu_56849_p4 = mul_ln1118_706_reg_74792.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_723_fu_56862_p4() {
    trunc_ln708_723_fu_56862_p4 = mul_ln1118_707_reg_74797.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_724_fu_56875_p4() {
    trunc_ln708_724_fu_56875_p4 = mul_ln1118_708_reg_74802.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_725_fu_56888_p4() {
    trunc_ln708_725_fu_56888_p4 = mul_ln1118_709_reg_74807.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_726_fu_56901_p4() {
    trunc_ln708_726_fu_56901_p4 = mul_ln1118_710_reg_74812.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_727_fu_56914_p4() {
    trunc_ln708_727_fu_56914_p4 = mul_ln1118_711_reg_74817.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_728_fu_56927_p4() {
    trunc_ln708_728_fu_56927_p4 = mul_ln1118_712_reg_74822.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_729_fu_56940_p4() {
    trunc_ln708_729_fu_56940_p4 = mul_ln1118_713_reg_74827.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_72_fu_45591_p4() {
    trunc_ln708_72_fu_45591_p4 = mul_ln1118_56_reg_71542.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_730_fu_56953_p4() {
    trunc_ln708_730_fu_56953_p4 = mul_ln1118_714_reg_74832.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_731_fu_56966_p4() {
    trunc_ln708_731_fu_56966_p4 = mul_ln1118_715_reg_74837.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_732_fu_56979_p4() {
    trunc_ln708_732_fu_56979_p4 = mul_ln1118_716_reg_74842.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_733_fu_56992_p4() {
    trunc_ln708_733_fu_56992_p4 = mul_ln1118_717_reg_74847.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_734_fu_57005_p4() {
    trunc_ln708_734_fu_57005_p4 = mul_ln1118_718_reg_74852.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_735_fu_57018_p4() {
    trunc_ln708_735_fu_57018_p4 = mul_ln1118_719_reg_74857.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_736_fu_57031_p4() {
    trunc_ln708_736_fu_57031_p4 = mul_ln1118_720_reg_74862.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_737_fu_57044_p4() {
    trunc_ln708_737_fu_57044_p4 = mul_ln1118_721_reg_74867.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_738_fu_57057_p4() {
    trunc_ln708_738_fu_57057_p4 = mul_ln1118_722_reg_74872.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_739_fu_57070_p4() {
    trunc_ln708_739_fu_57070_p4 = mul_ln1118_723_reg_74877.read().range(28, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_73_fu_45604_p4() {
    trunc_ln708_73_fu_45604_p4 = mul_ln1118_57_reg_71547.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_74_fu_45617_p4() {
    trunc_ln708_74_fu_45617_p4 = mul_ln1118_58_reg_71552.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_75_fu_45630_p4() {
    trunc_ln708_75_fu_45630_p4 = mul_ln1118_59_reg_71557.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_76_fu_45643_p4() {
    trunc_ln708_76_fu_45643_p4 = mul_ln1118_60_reg_71562.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_77_fu_45656_p4() {
    trunc_ln708_77_fu_45656_p4 = mul_ln1118_61_reg_71567.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_78_fu_45669_p4() {
    trunc_ln708_78_fu_45669_p4 = mul_ln1118_62_reg_71572.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_79_fu_45682_p4() {
    trunc_ln708_79_fu_45682_p4 = mul_ln1118_63_reg_71577.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_80_fu_45695_p4() {
    trunc_ln708_80_fu_45695_p4 = mul_ln1118_64_reg_71582.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_81_fu_45708_p4() {
    trunc_ln708_81_fu_45708_p4 = mul_ln1118_65_reg_71587.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_82_fu_45721_p4() {
    trunc_ln708_82_fu_45721_p4 = mul_ln1118_66_reg_71592.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_83_fu_45734_p4() {
    trunc_ln708_83_fu_45734_p4 = mul_ln1118_67_reg_71597.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_84_fu_45747_p4() {
    trunc_ln708_84_fu_45747_p4 = mul_ln1118_68_reg_71602.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_85_fu_45760_p4() {
    trunc_ln708_85_fu_45760_p4 = mul_ln1118_69_reg_71607.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_86_fu_45773_p4() {
    trunc_ln708_86_fu_45773_p4 = mul_ln1118_70_reg_71612.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_87_fu_45786_p4() {
    trunc_ln708_87_fu_45786_p4 = mul_ln1118_71_reg_71617.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_88_fu_45799_p4() {
    trunc_ln708_88_fu_45799_p4 = mul_ln1118_72_reg_71622.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_89_fu_45812_p4() {
    trunc_ln708_89_fu_45812_p4 = mul_ln1118_73_reg_71627.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_90_fu_45825_p4() {
    trunc_ln708_90_fu_45825_p4 = mul_ln1118_74_reg_71632.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_91_fu_45838_p4() {
    trunc_ln708_91_fu_45838_p4 = mul_ln1118_75_reg_71637.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_92_fu_46007_p4() {
    trunc_ln708_92_fu_46007_p4 = mul_ln1118_76_reg_71642.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_93_fu_46020_p4() {
    trunc_ln708_93_fu_46020_p4 = mul_ln1118_77_reg_71647.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_94_fu_46033_p4() {
    trunc_ln708_94_fu_46033_p4 = mul_ln1118_78_reg_71652.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_95_fu_46046_p4() {
    trunc_ln708_95_fu_46046_p4 = mul_ln1118_79_reg_71657.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_96_fu_46059_p4() {
    trunc_ln708_96_fu_46059_p4 = mul_ln1118_80_reg_71662.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_97_fu_46072_p4() {
    trunc_ln708_97_fu_46072_p4 = mul_ln1118_81_reg_71667.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_98_fu_46085_p4() {
    trunc_ln708_98_fu_46085_p4 = mul_ln1118_82_reg_71672.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_99_fu_46098_p4() {
    trunc_ln708_99_fu_46098_p4 = mul_ln1118_83_reg_71677.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln708_s_fu_44772_p4() {
    trunc_ln708_s_fu_44772_p4 = mul_ln1118_5_reg_71287.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln77_fu_8199_p1() {
    trunc_ln77_fu_8199_p1 = w7_V_q0.read().range(16-1, 0);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_trunc_ln_fu_44759_p4() {
    trunc_ln_fu_44759_p4 = mul_ln1118_reg_71282.read().range(31, 11);
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_w7_V_address0() {
    w7_V_address0 =  (sc_lv<2>) (zext_ln77_fu_8161_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_w7_V_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0_11001.read()))) {
        w7_V_ce0 = ap_const_logic_1;
    } else {
        w7_V_ce0 = ap_const_logic_0;
    }
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_w_index_fu_8166_p2() {
    w_index_fu_8166_p2 = (!ap_const_lv2_1.is_01() || !ap_phi_mux_w_index43_phi_fu_4123_p6.read().is_01())? sc_lv<2>(): (sc_biguint<2>(ap_const_lv2_1) + sc_biguint<2>(ap_phi_mux_w_index43_phi_fu_4123_p6.read()));
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_zext_ln64_fu_8157_p1() {
    zext_ln64_fu_8157_p1 = esl_zext<3,2>(ap_phi_mux_w_index43_phi_fu_4123_p6.read());
}

void dense_resource_ap_ufixed_ap_fixed_22_8_5_3_0_config7_s::thread_zext_ln77_fu_8161_p1() {
    zext_ln77_fu_8161_p1 = esl_zext<64,2>(ap_phi_mux_w_index43_phi_fu_4123_p6.read());
}

}


#include "dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_467_fu_50596_p4() {
    trunc_ln708_467_fu_50596_p4 = mul_ln1118_327_reg_74383.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_468_fu_50813_p4() {
    trunc_ln708_468_fu_50813_p4 = mul_ln1118_328_reg_74388.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_469_fu_50826_p4() {
    trunc_ln708_469_fu_50826_p4 = mul_ln1118_329_reg_74393.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_470_fu_50839_p4() {
    trunc_ln708_470_fu_50839_p4 = mul_ln1118_330_reg_74398.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_471_fu_50852_p4() {
    trunc_ln708_471_fu_50852_p4 = mul_ln1118_331_reg_74403.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_472_fu_50865_p4() {
    trunc_ln708_472_fu_50865_p4 = mul_ln1118_332_reg_74408.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_473_fu_50878_p4() {
    trunc_ln708_473_fu_50878_p4 = mul_ln1118_333_reg_74413.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_474_fu_50891_p4() {
    trunc_ln708_474_fu_50891_p4 = mul_ln1118_334_reg_74418.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_475_fu_50904_p4() {
    trunc_ln708_475_fu_50904_p4 = mul_ln1118_335_reg_74423.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_476_fu_50917_p4() {
    trunc_ln708_476_fu_50917_p4 = mul_ln1118_336_reg_74428.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_477_fu_50930_p4() {
    trunc_ln708_477_fu_50930_p4 = mul_ln1118_337_reg_74433.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_478_fu_50943_p4() {
    trunc_ln708_478_fu_50943_p4 = mul_ln1118_338_reg_74438.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_479_fu_50956_p4() {
    trunc_ln708_479_fu_50956_p4 = mul_ln1118_339_reg_74443.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_480_fu_50969_p4() {
    trunc_ln708_480_fu_50969_p4 = mul_ln1118_340_reg_74448.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_481_fu_50982_p4() {
    trunc_ln708_481_fu_50982_p4 = mul_ln1118_341_reg_74453.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_482_fu_50995_p4() {
    trunc_ln708_482_fu_50995_p4 = mul_ln1118_342_reg_74458.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_483_fu_51008_p4() {
    trunc_ln708_483_fu_51008_p4 = mul_ln1118_343_reg_74463.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_484_fu_51021_p4() {
    trunc_ln708_484_fu_51021_p4 = mul_ln1118_344_reg_74468.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_485_fu_51034_p4() {
    trunc_ln708_485_fu_51034_p4 = mul_ln1118_345_reg_74473.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_486_fu_51047_p4() {
    trunc_ln708_486_fu_51047_p4 = mul_ln1118_346_reg_74478.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_487_fu_51060_p4() {
    trunc_ln708_487_fu_51060_p4 = mul_ln1118_347_reg_74483.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_488_fu_51073_p4() {
    trunc_ln708_488_fu_51073_p4 = mul_ln1118_348_reg_74488.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_489_fu_51086_p4() {
    trunc_ln708_489_fu_51086_p4 = mul_ln1118_349_reg_74493.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_490_fu_51099_p4() {
    trunc_ln708_490_fu_51099_p4 = mul_ln1118_350_reg_74498.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_491_fu_51112_p4() {
    trunc_ln708_491_fu_51112_p4 = mul_ln1118_351_reg_74503.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_492_fu_51125_p4() {
    trunc_ln708_492_fu_51125_p4 = mul_ln1118_352_reg_74508.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_493_fu_51138_p4() {
    trunc_ln708_493_fu_51138_p4 = mul_ln1118_353_reg_74513.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_494_fu_51151_p4() {
    trunc_ln708_494_fu_51151_p4 = mul_ln1118_354_reg_74518.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_495_fu_51164_p4() {
    trunc_ln708_495_fu_51164_p4 = mul_ln1118_355_reg_74523.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_496_fu_51177_p4() {
    trunc_ln708_496_fu_51177_p4 = mul_ln1118_356_reg_74528.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_497_fu_51190_p4() {
    trunc_ln708_497_fu_51190_p4 = mul_ln1118_357_reg_74533.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_498_fu_51203_p4() {
    trunc_ln708_498_fu_51203_p4 = mul_ln1118_358_reg_74538.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_499_fu_51216_p4() {
    trunc_ln708_499_fu_51216_p4 = mul_ln1118_359_reg_74543.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_500_fu_51229_p4() {
    trunc_ln708_500_fu_51229_p4 = mul_ln1118_360_reg_74548.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_501_fu_51242_p4() {
    trunc_ln708_501_fu_51242_p4 = mul_ln1118_361_reg_74553.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_502_fu_51255_p4() {
    trunc_ln708_502_fu_51255_p4 = mul_ln1118_362_reg_74558.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_503_fu_51268_p4() {
    trunc_ln708_503_fu_51268_p4 = mul_ln1118_363_reg_74563.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_504_fu_51485_p4() {
    trunc_ln708_504_fu_51485_p4 = mul_ln1118_364_reg_74568.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_505_fu_51498_p4() {
    trunc_ln708_505_fu_51498_p4 = mul_ln1118_365_reg_74573.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_506_fu_51511_p4() {
    trunc_ln708_506_fu_51511_p4 = mul_ln1118_366_reg_74578.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_507_fu_51524_p4() {
    trunc_ln708_507_fu_51524_p4 = mul_ln1118_367_reg_74583.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_508_fu_51537_p4() {
    trunc_ln708_508_fu_51537_p4 = mul_ln1118_368_reg_74588.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_509_fu_51550_p4() {
    trunc_ln708_509_fu_51550_p4 = mul_ln1118_369_reg_74593.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_510_fu_51563_p4() {
    trunc_ln708_510_fu_51563_p4 = mul_ln1118_370_reg_74598.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_511_fu_51576_p4() {
    trunc_ln708_511_fu_51576_p4 = mul_ln1118_371_reg_74603.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_512_fu_51589_p4() {
    trunc_ln708_512_fu_51589_p4 = mul_ln1118_372_reg_74608.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_513_fu_51602_p4() {
    trunc_ln708_513_fu_51602_p4 = mul_ln1118_373_reg_74613.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_514_fu_51615_p4() {
    trunc_ln708_514_fu_51615_p4 = mul_ln1118_374_reg_74618.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_515_fu_51628_p4() {
    trunc_ln708_515_fu_51628_p4 = mul_ln1118_375_reg_74623.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_516_fu_51641_p4() {
    trunc_ln708_516_fu_51641_p4 = mul_ln1118_376_reg_74628.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_517_fu_51654_p4() {
    trunc_ln708_517_fu_51654_p4 = mul_ln1118_377_reg_74633.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_518_fu_51667_p4() {
    trunc_ln708_518_fu_51667_p4 = mul_ln1118_378_reg_74638.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_519_fu_51680_p4() {
    trunc_ln708_519_fu_51680_p4 = mul_ln1118_379_reg_74643.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_520_fu_51693_p4() {
    trunc_ln708_520_fu_51693_p4 = mul_ln1118_380_reg_74648.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_521_fu_51706_p4() {
    trunc_ln708_521_fu_51706_p4 = mul_ln1118_381_reg_74653.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_522_fu_51719_p4() {
    trunc_ln708_522_fu_51719_p4 = mul_ln1118_382_reg_74658.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_523_fu_51732_p4() {
    trunc_ln708_523_fu_51732_p4 = mul_ln1118_383_reg_74663.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_524_fu_51745_p4() {
    trunc_ln708_524_fu_51745_p4 = mul_ln1118_384_reg_74668.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_525_fu_51758_p4() {
    trunc_ln708_525_fu_51758_p4 = mul_ln1118_385_reg_74673.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_526_fu_51771_p4() {
    trunc_ln708_526_fu_51771_p4 = mul_ln1118_386_reg_74678.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_527_fu_51784_p4() {
    trunc_ln708_527_fu_51784_p4 = mul_ln1118_387_reg_74683.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_528_fu_51797_p4() {
    trunc_ln708_528_fu_51797_p4 = mul_ln1118_388_reg_74688.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_529_fu_51810_p4() {
    trunc_ln708_529_fu_51810_p4 = mul_ln1118_389_reg_74693.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_530_fu_51823_p4() {
    trunc_ln708_530_fu_51823_p4 = mul_ln1118_390_reg_74698.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_531_fu_51836_p4() {
    trunc_ln708_531_fu_51836_p4 = mul_ln1118_391_reg_74703.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_532_fu_51849_p4() {
    trunc_ln708_532_fu_51849_p4 = mul_ln1118_392_reg_74708.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_533_fu_51862_p4() {
    trunc_ln708_533_fu_51862_p4 = mul_ln1118_393_reg_74713.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_534_fu_51875_p4() {
    trunc_ln708_534_fu_51875_p4 = mul_ln1118_394_reg_74718.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_535_fu_51888_p4() {
    trunc_ln708_535_fu_51888_p4 = mul_ln1118_395_reg_74723.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_536_fu_51901_p4() {
    trunc_ln708_536_fu_51901_p4 = mul_ln1118_396_reg_74728.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_537_fu_51914_p4() {
    trunc_ln708_537_fu_51914_p4 = mul_ln1118_397_reg_74733.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_538_fu_51927_p4() {
    trunc_ln708_538_fu_51927_p4 = mul_ln1118_398_reg_74738.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_539_fu_51940_p4() {
    trunc_ln708_539_fu_51940_p4 = mul_ln1118_399_reg_74743.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_540_fu_52157_p4() {
    trunc_ln708_540_fu_52157_p4 = mul_ln1118_400_reg_74748.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_541_fu_52170_p4() {
    trunc_ln708_541_fu_52170_p4 = mul_ln1118_401_reg_74753.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_542_fu_52183_p4() {
    trunc_ln708_542_fu_52183_p4 = mul_ln1118_402_reg_74758.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_543_fu_52196_p4() {
    trunc_ln708_543_fu_52196_p4 = mul_ln1118_403_reg_74763.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_544_fu_52209_p4() {
    trunc_ln708_544_fu_52209_p4 = mul_ln1118_404_reg_74768.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_545_fu_52222_p4() {
    trunc_ln708_545_fu_52222_p4 = mul_ln1118_405_reg_74773.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_546_fu_52235_p4() {
    trunc_ln708_546_fu_52235_p4 = mul_ln1118_406_reg_74778.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_547_fu_52248_p4() {
    trunc_ln708_547_fu_52248_p4 = mul_ln1118_407_reg_74783.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_548_fu_52261_p4() {
    trunc_ln708_548_fu_52261_p4 = mul_ln1118_408_reg_74788.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_549_fu_52274_p4() {
    trunc_ln708_549_fu_52274_p4 = mul_ln1118_409_reg_74793.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_550_fu_52287_p4() {
    trunc_ln708_550_fu_52287_p4 = mul_ln1118_410_reg_74798.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_551_fu_52300_p4() {
    trunc_ln708_551_fu_52300_p4 = mul_ln1118_411_reg_74803.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_552_fu_52313_p4() {
    trunc_ln708_552_fu_52313_p4 = mul_ln1118_412_reg_74808.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_553_fu_52326_p4() {
    trunc_ln708_553_fu_52326_p4 = mul_ln1118_413_reg_74813.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_554_fu_52339_p4() {
    trunc_ln708_554_fu_52339_p4 = mul_ln1118_414_reg_74818.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_555_fu_52352_p4() {
    trunc_ln708_555_fu_52352_p4 = mul_ln1118_415_reg_74823.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_556_fu_52365_p4() {
    trunc_ln708_556_fu_52365_p4 = mul_ln1118_416_reg_74828.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_557_fu_52378_p4() {
    trunc_ln708_557_fu_52378_p4 = mul_ln1118_417_reg_74833.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_558_fu_52391_p4() {
    trunc_ln708_558_fu_52391_p4 = mul_ln1118_418_reg_74838.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_559_fu_52404_p4() {
    trunc_ln708_559_fu_52404_p4 = mul_ln1118_419_reg_74843.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_560_fu_52417_p4() {
    trunc_ln708_560_fu_52417_p4 = mul_ln1118_420_reg_74848.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_561_fu_52430_p4() {
    trunc_ln708_561_fu_52430_p4 = mul_ln1118_421_reg_74853.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_562_fu_52443_p4() {
    trunc_ln708_562_fu_52443_p4 = mul_ln1118_422_reg_74858.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_563_fu_52456_p4() {
    trunc_ln708_563_fu_52456_p4 = mul_ln1118_423_reg_74863.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_564_fu_52469_p4() {
    trunc_ln708_564_fu_52469_p4 = mul_ln1118_424_reg_74868.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_565_fu_52482_p4() {
    trunc_ln708_565_fu_52482_p4 = mul_ln1118_425_reg_74873.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_566_fu_52495_p4() {
    trunc_ln708_566_fu_52495_p4 = mul_ln1118_426_reg_74878.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_567_fu_52508_p4() {
    trunc_ln708_567_fu_52508_p4 = mul_ln1118_427_reg_74883.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_568_fu_52521_p4() {
    trunc_ln708_568_fu_52521_p4 = mul_ln1118_428_reg_74888.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_569_fu_52534_p4() {
    trunc_ln708_569_fu_52534_p4 = mul_ln1118_429_reg_74893.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_570_fu_52547_p4() {
    trunc_ln708_570_fu_52547_p4 = mul_ln1118_430_reg_74898.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_571_fu_52560_p4() {
    trunc_ln708_571_fu_52560_p4 = mul_ln1118_431_reg_74903.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_572_fu_52573_p4() {
    trunc_ln708_572_fu_52573_p4 = mul_ln1118_432_reg_74908.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_573_fu_52586_p4() {
    trunc_ln708_573_fu_52586_p4 = mul_ln1118_433_reg_74913.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_574_fu_52599_p4() {
    trunc_ln708_574_fu_52599_p4 = mul_ln1118_434_reg_74918.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_575_fu_52612_p4() {
    trunc_ln708_575_fu_52612_p4 = mul_ln1118_435_reg_74923.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_576_fu_52829_p4() {
    trunc_ln708_576_fu_52829_p4 = mul_ln1118_436_reg_74928.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_577_fu_52842_p4() {
    trunc_ln708_577_fu_52842_p4 = mul_ln1118_437_reg_74933.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_578_fu_52855_p4() {
    trunc_ln708_578_fu_52855_p4 = mul_ln1118_438_reg_74938.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_579_fu_52868_p4() {
    trunc_ln708_579_fu_52868_p4 = mul_ln1118_439_reg_74943.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_580_fu_52881_p4() {
    trunc_ln708_580_fu_52881_p4 = mul_ln1118_440_reg_74948.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_581_fu_52894_p4() {
    trunc_ln708_581_fu_52894_p4 = mul_ln1118_441_reg_74953.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_582_fu_52907_p4() {
    trunc_ln708_582_fu_52907_p4 = mul_ln1118_442_reg_74958.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_583_fu_52920_p4() {
    trunc_ln708_583_fu_52920_p4 = mul_ln1118_443_reg_74963.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_584_fu_52933_p4() {
    trunc_ln708_584_fu_52933_p4 = mul_ln1118_444_reg_74968.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_585_fu_52946_p4() {
    trunc_ln708_585_fu_52946_p4 = mul_ln1118_445_reg_74973.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_586_fu_52959_p4() {
    trunc_ln708_586_fu_52959_p4 = mul_ln1118_446_reg_74978.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_587_fu_52972_p4() {
    trunc_ln708_587_fu_52972_p4 = mul_ln1118_447_reg_74983.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_588_fu_52985_p4() {
    trunc_ln708_588_fu_52985_p4 = mul_ln1118_448_reg_74988.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_589_fu_52998_p4() {
    trunc_ln708_589_fu_52998_p4 = mul_ln1118_449_reg_74993.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_590_fu_53011_p4() {
    trunc_ln708_590_fu_53011_p4 = mul_ln1118_450_reg_74998.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_591_fu_53024_p4() {
    trunc_ln708_591_fu_53024_p4 = mul_ln1118_451_reg_75003.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_592_fu_53037_p4() {
    trunc_ln708_592_fu_53037_p4 = mul_ln1118_452_reg_75008.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_593_fu_53050_p4() {
    trunc_ln708_593_fu_53050_p4 = mul_ln1118_453_reg_75013.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_594_fu_53063_p4() {
    trunc_ln708_594_fu_53063_p4 = mul_ln1118_454_reg_75018.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_595_fu_53076_p4() {
    trunc_ln708_595_fu_53076_p4 = mul_ln1118_455_reg_75023.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_596_fu_53089_p4() {
    trunc_ln708_596_fu_53089_p4 = mul_ln1118_456_reg_75028.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_597_fu_53102_p4() {
    trunc_ln708_597_fu_53102_p4 = mul_ln1118_457_reg_75033.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_598_fu_53115_p4() {
    trunc_ln708_598_fu_53115_p4 = mul_ln1118_458_reg_75038.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_599_fu_53128_p4() {
    trunc_ln708_599_fu_53128_p4 = mul_ln1118_459_reg_75043.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_600_fu_53141_p4() {
    trunc_ln708_600_fu_53141_p4 = mul_ln1118_460_reg_75048.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_601_fu_53154_p4() {
    trunc_ln708_601_fu_53154_p4 = mul_ln1118_461_reg_75053.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_602_fu_53167_p4() {
    trunc_ln708_602_fu_53167_p4 = mul_ln1118_462_reg_75058.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_603_fu_53180_p4() {
    trunc_ln708_603_fu_53180_p4 = mul_ln1118_463_reg_75063.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_604_fu_53193_p4() {
    trunc_ln708_604_fu_53193_p4 = mul_ln1118_464_reg_75068.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_605_fu_53206_p4() {
    trunc_ln708_605_fu_53206_p4 = mul_ln1118_465_reg_75073.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_606_fu_53219_p4() {
    trunc_ln708_606_fu_53219_p4 = mul_ln1118_466_reg_75078.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_607_fu_53232_p4() {
    trunc_ln708_607_fu_53232_p4 = mul_ln1118_467_reg_75083.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_608_fu_53245_p4() {
    trunc_ln708_608_fu_53245_p4 = mul_ln1118_468_reg_75088.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_609_fu_53258_p4() {
    trunc_ln708_609_fu_53258_p4 = mul_ln1118_469_reg_75093.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_610_fu_53271_p4() {
    trunc_ln708_610_fu_53271_p4 = mul_ln1118_470_reg_75098.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_611_fu_53284_p4() {
    trunc_ln708_611_fu_53284_p4 = mul_ln1118_471_reg_75103.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_612_fu_53501_p4() {
    trunc_ln708_612_fu_53501_p4 = mul_ln1118_472_reg_75108.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_613_fu_53514_p4() {
    trunc_ln708_613_fu_53514_p4 = mul_ln1118_473_reg_75113.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_614_fu_53527_p4() {
    trunc_ln708_614_fu_53527_p4 = mul_ln1118_474_reg_75118.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_615_fu_53540_p4() {
    trunc_ln708_615_fu_53540_p4 = mul_ln1118_475_reg_75123.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_616_fu_53553_p4() {
    trunc_ln708_616_fu_53553_p4 = mul_ln1118_476_reg_75128.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_617_fu_53566_p4() {
    trunc_ln708_617_fu_53566_p4 = mul_ln1118_477_reg_75133.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_618_fu_53579_p4() {
    trunc_ln708_618_fu_53579_p4 = mul_ln1118_478_reg_75138.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_619_fu_53592_p4() {
    trunc_ln708_619_fu_53592_p4 = mul_ln1118_479_reg_75143.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_620_fu_53605_p4() {
    trunc_ln708_620_fu_53605_p4 = mul_ln1118_480_reg_75148.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_621_fu_53618_p4() {
    trunc_ln708_621_fu_53618_p4 = mul_ln1118_481_reg_75153.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_622_fu_53631_p4() {
    trunc_ln708_622_fu_53631_p4 = mul_ln1118_482_reg_75158.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_623_fu_53644_p4() {
    trunc_ln708_623_fu_53644_p4 = mul_ln1118_483_reg_75163.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_624_fu_53657_p4() {
    trunc_ln708_624_fu_53657_p4 = mul_ln1118_484_reg_75168.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_625_fu_53670_p4() {
    trunc_ln708_625_fu_53670_p4 = mul_ln1118_485_reg_75173.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_626_fu_53683_p4() {
    trunc_ln708_626_fu_53683_p4 = mul_ln1118_486_reg_75178.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_627_fu_53696_p4() {
    trunc_ln708_627_fu_53696_p4 = mul_ln1118_487_reg_75183.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_628_fu_53709_p4() {
    trunc_ln708_628_fu_53709_p4 = mul_ln1118_488_reg_75188.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_629_fu_53722_p4() {
    trunc_ln708_629_fu_53722_p4 = mul_ln1118_489_reg_75193.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_630_fu_53735_p4() {
    trunc_ln708_630_fu_53735_p4 = mul_ln1118_490_reg_75198.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_631_fu_53748_p4() {
    trunc_ln708_631_fu_53748_p4 = mul_ln1118_491_reg_75203.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_632_fu_53761_p4() {
    trunc_ln708_632_fu_53761_p4 = mul_ln1118_492_reg_75208.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_633_fu_53774_p4() {
    trunc_ln708_633_fu_53774_p4 = mul_ln1118_493_reg_75213.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_634_fu_53787_p4() {
    trunc_ln708_634_fu_53787_p4 = mul_ln1118_494_reg_75218.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_635_fu_53800_p4() {
    trunc_ln708_635_fu_53800_p4 = mul_ln1118_495_reg_75223.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_636_fu_53813_p4() {
    trunc_ln708_636_fu_53813_p4 = mul_ln1118_496_reg_75228.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_637_fu_53826_p4() {
    trunc_ln708_637_fu_53826_p4 = mul_ln1118_497_reg_75233.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_638_fu_53839_p4() {
    trunc_ln708_638_fu_53839_p4 = mul_ln1118_498_reg_75238.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_639_fu_53852_p4() {
    trunc_ln708_639_fu_53852_p4 = mul_ln1118_499_reg_75243.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_640_fu_53865_p4() {
    trunc_ln708_640_fu_53865_p4 = mul_ln1118_500_reg_75248.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_641_fu_53878_p4() {
    trunc_ln708_641_fu_53878_p4 = mul_ln1118_501_reg_75253.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_642_fu_53891_p4() {
    trunc_ln708_642_fu_53891_p4 = mul_ln1118_502_reg_75258.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_643_fu_53904_p4() {
    trunc_ln708_643_fu_53904_p4 = mul_ln1118_503_reg_75263.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_644_fu_53917_p4() {
    trunc_ln708_644_fu_53917_p4 = mul_ln1118_504_reg_75268.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_645_fu_53930_p4() {
    trunc_ln708_645_fu_53930_p4 = mul_ln1118_505_reg_75273.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_646_fu_53943_p4() {
    trunc_ln708_646_fu_53943_p4 = mul_ln1118_506_reg_75278.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_647_fu_53956_p4() {
    trunc_ln708_647_fu_53956_p4 = mul_ln1118_507_reg_75283.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_648_fu_54173_p4() {
    trunc_ln708_648_fu_54173_p4 = mul_ln1118_508_reg_75288.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_649_fu_54186_p4() {
    trunc_ln708_649_fu_54186_p4 = mul_ln1118_509_reg_75293.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_650_fu_54199_p4() {
    trunc_ln708_650_fu_54199_p4 = mul_ln1118_510_reg_75298.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_651_fu_54212_p4() {
    trunc_ln708_651_fu_54212_p4 = mul_ln1118_511_reg_75303.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_652_fu_54225_p4() {
    trunc_ln708_652_fu_54225_p4 = mul_ln1118_512_reg_75308.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_653_fu_54238_p4() {
    trunc_ln708_653_fu_54238_p4 = mul_ln1118_513_reg_75313.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_654_fu_54251_p4() {
    trunc_ln708_654_fu_54251_p4 = mul_ln1118_514_reg_75318.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_655_fu_54264_p4() {
    trunc_ln708_655_fu_54264_p4 = mul_ln1118_515_reg_75323.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_656_fu_54277_p4() {
    trunc_ln708_656_fu_54277_p4 = mul_ln1118_516_reg_75328.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_657_fu_54290_p4() {
    trunc_ln708_657_fu_54290_p4 = mul_ln1118_517_reg_75333.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_658_fu_54303_p4() {
    trunc_ln708_658_fu_54303_p4 = mul_ln1118_518_reg_75338.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_659_fu_54316_p4() {
    trunc_ln708_659_fu_54316_p4 = mul_ln1118_519_reg_75343.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_660_fu_54329_p4() {
    trunc_ln708_660_fu_54329_p4 = mul_ln1118_520_reg_75348.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_661_fu_54342_p4() {
    trunc_ln708_661_fu_54342_p4 = mul_ln1118_521_reg_75353.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_662_fu_54355_p4() {
    trunc_ln708_662_fu_54355_p4 = mul_ln1118_522_reg_75358.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_663_fu_54368_p4() {
    trunc_ln708_663_fu_54368_p4 = mul_ln1118_523_reg_75363.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_664_fu_54381_p4() {
    trunc_ln708_664_fu_54381_p4 = mul_ln1118_524_reg_75368.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_665_fu_54394_p4() {
    trunc_ln708_665_fu_54394_p4 = mul_ln1118_525_reg_75373.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_666_fu_54407_p4() {
    trunc_ln708_666_fu_54407_p4 = mul_ln1118_526_reg_75378.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_667_fu_54420_p4() {
    trunc_ln708_667_fu_54420_p4 = mul_ln1118_527_reg_75383.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_668_fu_54433_p4() {
    trunc_ln708_668_fu_54433_p4 = mul_ln1118_528_reg_75388.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_669_fu_54446_p4() {
    trunc_ln708_669_fu_54446_p4 = mul_ln1118_529_reg_75393.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_670_fu_54459_p4() {
    trunc_ln708_670_fu_54459_p4 = mul_ln1118_530_reg_75398.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_671_fu_54472_p4() {
    trunc_ln708_671_fu_54472_p4 = mul_ln1118_531_reg_75403.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_672_fu_54485_p4() {
    trunc_ln708_672_fu_54485_p4 = mul_ln1118_532_reg_75408.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_673_fu_54498_p4() {
    trunc_ln708_673_fu_54498_p4 = mul_ln1118_533_reg_75413.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_674_fu_54511_p4() {
    trunc_ln708_674_fu_54511_p4 = mul_ln1118_534_reg_75418.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_675_fu_54524_p4() {
    trunc_ln708_675_fu_54524_p4 = mul_ln1118_535_reg_75423.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_676_fu_54537_p4() {
    trunc_ln708_676_fu_54537_p4 = mul_ln1118_536_reg_75428.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_677_fu_54550_p4() {
    trunc_ln708_677_fu_54550_p4 = mul_ln1118_537_reg_75433.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_678_fu_54563_p4() {
    trunc_ln708_678_fu_54563_p4 = mul_ln1118_538_reg_75438.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_679_fu_54576_p4() {
    trunc_ln708_679_fu_54576_p4 = mul_ln1118_539_reg_75443.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_680_fu_54589_p4() {
    trunc_ln708_680_fu_54589_p4 = mul_ln1118_540_reg_75448.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_681_fu_54602_p4() {
    trunc_ln708_681_fu_54602_p4 = mul_ln1118_541_reg_75453.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_682_fu_54615_p4() {
    trunc_ln708_682_fu_54615_p4 = mul_ln1118_542_reg_75458.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_683_fu_54628_p4() {
    trunc_ln708_683_fu_54628_p4 = mul_ln1118_543_reg_75463.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_684_fu_54845_p4() {
    trunc_ln708_684_fu_54845_p4 = mul_ln1118_544_reg_75468.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_685_fu_54858_p4() {
    trunc_ln708_685_fu_54858_p4 = mul_ln1118_545_reg_75473.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_686_fu_54871_p4() {
    trunc_ln708_686_fu_54871_p4 = mul_ln1118_546_reg_75478.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_687_fu_54884_p4() {
    trunc_ln708_687_fu_54884_p4 = mul_ln1118_547_reg_75483.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_688_fu_54897_p4() {
    trunc_ln708_688_fu_54897_p4 = mul_ln1118_548_reg_75488.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_689_fu_54910_p4() {
    trunc_ln708_689_fu_54910_p4 = mul_ln1118_549_reg_75493.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_690_fu_54923_p4() {
    trunc_ln708_690_fu_54923_p4 = mul_ln1118_550_reg_75498.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_691_fu_54936_p4() {
    trunc_ln708_691_fu_54936_p4 = mul_ln1118_551_reg_75503.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_692_fu_54949_p4() {
    trunc_ln708_692_fu_54949_p4 = mul_ln1118_552_reg_75508.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_693_fu_54962_p4() {
    trunc_ln708_693_fu_54962_p4 = mul_ln1118_553_reg_75513.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_694_fu_54975_p4() {
    trunc_ln708_694_fu_54975_p4 = mul_ln1118_554_reg_75518.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_695_fu_54988_p4() {
    trunc_ln708_695_fu_54988_p4 = mul_ln1118_555_reg_75523.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_696_fu_55001_p4() {
    trunc_ln708_696_fu_55001_p4 = mul_ln1118_556_reg_75528.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_697_fu_55014_p4() {
    trunc_ln708_697_fu_55014_p4 = mul_ln1118_557_reg_75533.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_698_fu_55027_p4() {
    trunc_ln708_698_fu_55027_p4 = mul_ln1118_558_reg_75538.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_699_fu_55040_p4() {
    trunc_ln708_699_fu_55040_p4 = mul_ln1118_559_reg_75543.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_700_fu_55053_p4() {
    trunc_ln708_700_fu_55053_p4 = mul_ln1118_560_reg_75548.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_701_fu_55066_p4() {
    trunc_ln708_701_fu_55066_p4 = mul_ln1118_561_reg_75553.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_702_fu_55079_p4() {
    trunc_ln708_702_fu_55079_p4 = mul_ln1118_562_reg_75558.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_703_fu_55092_p4() {
    trunc_ln708_703_fu_55092_p4 = mul_ln1118_563_reg_75563.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_704_fu_55105_p4() {
    trunc_ln708_704_fu_55105_p4 = mul_ln1118_564_reg_75568.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_705_fu_55118_p4() {
    trunc_ln708_705_fu_55118_p4 = mul_ln1118_565_reg_75573.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_706_fu_55131_p4() {
    trunc_ln708_706_fu_55131_p4 = mul_ln1118_566_reg_75578.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_707_fu_55144_p4() {
    trunc_ln708_707_fu_55144_p4 = mul_ln1118_567_reg_75583.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_708_fu_55157_p4() {
    trunc_ln708_708_fu_55157_p4 = mul_ln1118_568_reg_75588.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_709_fu_55170_p4() {
    trunc_ln708_709_fu_55170_p4 = mul_ln1118_569_reg_75593.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_710_fu_55183_p4() {
    trunc_ln708_710_fu_55183_p4 = mul_ln1118_570_reg_75598.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_711_fu_55196_p4() {
    trunc_ln708_711_fu_55196_p4 = mul_ln1118_571_reg_75603.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_712_fu_55209_p4() {
    trunc_ln708_712_fu_55209_p4 = mul_ln1118_572_reg_75608.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_713_fu_55222_p4() {
    trunc_ln708_713_fu_55222_p4 = mul_ln1118_573_reg_75613.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_714_fu_55235_p4() {
    trunc_ln708_714_fu_55235_p4 = mul_ln1118_574_reg_75618.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_715_fu_55248_p4() {
    trunc_ln708_715_fu_55248_p4 = mul_ln1118_575_reg_75623.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_716_fu_55261_p4() {
    trunc_ln708_716_fu_55261_p4 = mul_ln1118_576_reg_75628.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_717_fu_55274_p4() {
    trunc_ln708_717_fu_55274_p4 = mul_ln1118_577_reg_75633.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_718_fu_55287_p4() {
    trunc_ln708_718_fu_55287_p4 = mul_ln1118_578_reg_75638.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_719_fu_55300_p4() {
    trunc_ln708_719_fu_55300_p4 = mul_ln1118_579_reg_75643.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_720_fu_55517_p4() {
    trunc_ln708_720_fu_55517_p4 = mul_ln1118_580_reg_75648.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_721_fu_55530_p4() {
    trunc_ln708_721_fu_55530_p4 = mul_ln1118_581_reg_75653.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_722_fu_55543_p4() {
    trunc_ln708_722_fu_55543_p4 = mul_ln1118_582_reg_75658.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_723_fu_55556_p4() {
    trunc_ln708_723_fu_55556_p4 = mul_ln1118_583_reg_75663.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_724_fu_55569_p4() {
    trunc_ln708_724_fu_55569_p4 = mul_ln1118_584_reg_75668.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_725_fu_55582_p4() {
    trunc_ln708_725_fu_55582_p4 = mul_ln1118_585_reg_75673.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_726_fu_55595_p4() {
    trunc_ln708_726_fu_55595_p4 = mul_ln1118_586_reg_75678.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_727_fu_55608_p4() {
    trunc_ln708_727_fu_55608_p4 = mul_ln1118_587_reg_75683.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_728_fu_55621_p4() {
    trunc_ln708_728_fu_55621_p4 = mul_ln1118_588_reg_75688.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_729_fu_55634_p4() {
    trunc_ln708_729_fu_55634_p4 = mul_ln1118_589_reg_75693.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_730_fu_55647_p4() {
    trunc_ln708_730_fu_55647_p4 = mul_ln1118_590_reg_75698.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_731_fu_55660_p4() {
    trunc_ln708_731_fu_55660_p4 = mul_ln1118_591_reg_75703.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_732_fu_55673_p4() {
    trunc_ln708_732_fu_55673_p4 = mul_ln1118_592_reg_75708.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_733_fu_55686_p4() {
    trunc_ln708_733_fu_55686_p4 = mul_ln1118_593_reg_75713.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_734_fu_55699_p4() {
    trunc_ln708_734_fu_55699_p4 = mul_ln1118_594_reg_75718.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_735_fu_55712_p4() {
    trunc_ln708_735_fu_55712_p4 = mul_ln1118_595_reg_75723.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_736_fu_55725_p4() {
    trunc_ln708_736_fu_55725_p4 = mul_ln1118_596_reg_75728.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_737_fu_55738_p4() {
    trunc_ln708_737_fu_55738_p4 = mul_ln1118_597_reg_75733.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_738_fu_55751_p4() {
    trunc_ln708_738_fu_55751_p4 = mul_ln1118_598_reg_75738.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_739_fu_55764_p4() {
    trunc_ln708_739_fu_55764_p4 = mul_ln1118_599_reg_75743.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_740_fu_55777_p4() {
    trunc_ln708_740_fu_55777_p4 = mul_ln1118_600_reg_75748.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_741_fu_55790_p4() {
    trunc_ln708_741_fu_55790_p4 = mul_ln1118_601_reg_75753.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_742_fu_55803_p4() {
    trunc_ln708_742_fu_55803_p4 = mul_ln1118_602_reg_75758.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_743_fu_55816_p4() {
    trunc_ln708_743_fu_55816_p4 = mul_ln1118_603_reg_75763.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_744_fu_55829_p4() {
    trunc_ln708_744_fu_55829_p4 = mul_ln1118_604_reg_75768.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_745_fu_55842_p4() {
    trunc_ln708_745_fu_55842_p4 = mul_ln1118_605_reg_75773.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_746_fu_55855_p4() {
    trunc_ln708_746_fu_55855_p4 = mul_ln1118_606_reg_75778.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_747_fu_55868_p4() {
    trunc_ln708_747_fu_55868_p4 = mul_ln1118_607_reg_75783.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_748_fu_55881_p4() {
    trunc_ln708_748_fu_55881_p4 = mul_ln1118_608_reg_75788.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_749_fu_55894_p4() {
    trunc_ln708_749_fu_55894_p4 = mul_ln1118_609_reg_75793.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_750_fu_55907_p4() {
    trunc_ln708_750_fu_55907_p4 = mul_ln1118_610_reg_75798.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_751_fu_55920_p4() {
    trunc_ln708_751_fu_55920_p4 = mul_ln1118_611_reg_75803.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_752_fu_55933_p4() {
    trunc_ln708_752_fu_55933_p4 = mul_ln1118_612_reg_75808.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_753_fu_55946_p4() {
    trunc_ln708_753_fu_55946_p4 = mul_ln1118_613_reg_75813.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_754_fu_55959_p4() {
    trunc_ln708_754_fu_55959_p4 = mul_ln1118_614_reg_75818.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_755_fu_55972_p4() {
    trunc_ln708_755_fu_55972_p4 = mul_ln1118_615_reg_75823.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_756_fu_56189_p4() {
    trunc_ln708_756_fu_56189_p4 = mul_ln1118_616_reg_75828.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_757_fu_56202_p4() {
    trunc_ln708_757_fu_56202_p4 = mul_ln1118_617_reg_75833.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_758_fu_56215_p4() {
    trunc_ln708_758_fu_56215_p4 = mul_ln1118_618_reg_75838.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_759_fu_56228_p4() {
    trunc_ln708_759_fu_56228_p4 = mul_ln1118_619_reg_75843.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_760_fu_56241_p4() {
    trunc_ln708_760_fu_56241_p4 = mul_ln1118_620_reg_75848.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_761_fu_56254_p4() {
    trunc_ln708_761_fu_56254_p4 = mul_ln1118_621_reg_75853.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_762_fu_56267_p4() {
    trunc_ln708_762_fu_56267_p4 = mul_ln1118_622_reg_75858.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_763_fu_56280_p4() {
    trunc_ln708_763_fu_56280_p4 = mul_ln1118_623_reg_75863.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_764_fu_56293_p4() {
    trunc_ln708_764_fu_56293_p4 = mul_ln1118_624_reg_75868.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_765_fu_56306_p4() {
    trunc_ln708_765_fu_56306_p4 = mul_ln1118_625_reg_75873.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_766_fu_56319_p4() {
    trunc_ln708_766_fu_56319_p4 = mul_ln1118_626_reg_75878.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_767_fu_56332_p4() {
    trunc_ln708_767_fu_56332_p4 = mul_ln1118_627_reg_75883.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_768_fu_56345_p4() {
    trunc_ln708_768_fu_56345_p4 = mul_ln1118_628_reg_75888.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_769_fu_56358_p4() {
    trunc_ln708_769_fu_56358_p4 = mul_ln1118_629_reg_75893.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_770_fu_56371_p4() {
    trunc_ln708_770_fu_56371_p4 = mul_ln1118_630_reg_75898.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_771_fu_56384_p4() {
    trunc_ln708_771_fu_56384_p4 = mul_ln1118_631_reg_75903.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_772_fu_56397_p4() {
    trunc_ln708_772_fu_56397_p4 = mul_ln1118_632_reg_75908.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_773_fu_56410_p4() {
    trunc_ln708_773_fu_56410_p4 = mul_ln1118_633_reg_75913.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_774_fu_56423_p4() {
    trunc_ln708_774_fu_56423_p4 = mul_ln1118_634_reg_75918.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_775_fu_56436_p4() {
    trunc_ln708_775_fu_56436_p4 = mul_ln1118_635_reg_75923.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_776_fu_56449_p4() {
    trunc_ln708_776_fu_56449_p4 = mul_ln1118_636_reg_75928.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_777_fu_56462_p4() {
    trunc_ln708_777_fu_56462_p4 = mul_ln1118_637_reg_75933.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_778_fu_56475_p4() {
    trunc_ln708_778_fu_56475_p4 = mul_ln1118_638_reg_75938.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_779_fu_56488_p4() {
    trunc_ln708_779_fu_56488_p4 = mul_ln1118_639_reg_75943.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_780_fu_56501_p4() {
    trunc_ln708_780_fu_56501_p4 = mul_ln1118_640_reg_75948.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_781_fu_56514_p4() {
    trunc_ln708_781_fu_56514_p4 = mul_ln1118_641_reg_75953.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_782_fu_56527_p4() {
    trunc_ln708_782_fu_56527_p4 = mul_ln1118_642_reg_75958.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_783_fu_56540_p4() {
    trunc_ln708_783_fu_56540_p4 = mul_ln1118_643_reg_75963.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_784_fu_56553_p4() {
    trunc_ln708_784_fu_56553_p4 = mul_ln1118_644_reg_75968.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_785_fu_56566_p4() {
    trunc_ln708_785_fu_56566_p4 = mul_ln1118_645_reg_75973.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_786_fu_56579_p4() {
    trunc_ln708_786_fu_56579_p4 = mul_ln1118_646_reg_75978.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_787_fu_56592_p4() {
    trunc_ln708_787_fu_56592_p4 = mul_ln1118_647_reg_75983.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_788_fu_56605_p4() {
    trunc_ln708_788_fu_56605_p4 = mul_ln1118_648_reg_75988.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_789_fu_56618_p4() {
    trunc_ln708_789_fu_56618_p4 = mul_ln1118_649_reg_75993.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_790_fu_56631_p4() {
    trunc_ln708_790_fu_56631_p4 = mul_ln1118_650_reg_75998.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_791_fu_56644_p4() {
    trunc_ln708_791_fu_56644_p4 = mul_ln1118_651_reg_76003.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_792_fu_56861_p4() {
    trunc_ln708_792_fu_56861_p4 = mul_ln1118_652_reg_76008.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_793_fu_56874_p4() {
    trunc_ln708_793_fu_56874_p4 = mul_ln1118_653_reg_76013.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_794_fu_56887_p4() {
    trunc_ln708_794_fu_56887_p4 = mul_ln1118_654_reg_76018.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_795_fu_56900_p4() {
    trunc_ln708_795_fu_56900_p4 = mul_ln1118_655_reg_76023.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_796_fu_56913_p4() {
    trunc_ln708_796_fu_56913_p4 = mul_ln1118_656_reg_76028.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_797_fu_56926_p4() {
    trunc_ln708_797_fu_56926_p4 = mul_ln1118_657_reg_76033.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_798_fu_56939_p4() {
    trunc_ln708_798_fu_56939_p4 = mul_ln1118_658_reg_76038.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_799_fu_56952_p4() {
    trunc_ln708_799_fu_56952_p4 = mul_ln1118_659_reg_76043.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_800_fu_56965_p4() {
    trunc_ln708_800_fu_56965_p4 = mul_ln1118_660_reg_76048.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_801_fu_56978_p4() {
    trunc_ln708_801_fu_56978_p4 = mul_ln1118_661_reg_76053.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_802_fu_56991_p4() {
    trunc_ln708_802_fu_56991_p4 = mul_ln1118_662_reg_76058.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_803_fu_57004_p4() {
    trunc_ln708_803_fu_57004_p4 = mul_ln1118_663_reg_76063.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_804_fu_57017_p4() {
    trunc_ln708_804_fu_57017_p4 = mul_ln1118_664_reg_76068.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_805_fu_57030_p4() {
    trunc_ln708_805_fu_57030_p4 = mul_ln1118_665_reg_76073.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_806_fu_57043_p4() {
    trunc_ln708_806_fu_57043_p4 = mul_ln1118_666_reg_76078.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_807_fu_57056_p4() {
    trunc_ln708_807_fu_57056_p4 = mul_ln1118_667_reg_76083.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_808_fu_57069_p4() {
    trunc_ln708_808_fu_57069_p4 = mul_ln1118_668_reg_76088.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_809_fu_57082_p4() {
    trunc_ln708_809_fu_57082_p4 = mul_ln1118_669_reg_76093.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_810_fu_57095_p4() {
    trunc_ln708_810_fu_57095_p4 = mul_ln1118_670_reg_76098.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_811_fu_57108_p4() {
    trunc_ln708_811_fu_57108_p4 = mul_ln1118_671_reg_76103.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_812_fu_57121_p4() {
    trunc_ln708_812_fu_57121_p4 = mul_ln1118_672_reg_76108.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_813_fu_57134_p4() {
    trunc_ln708_813_fu_57134_p4 = mul_ln1118_673_reg_76113.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_814_fu_57147_p4() {
    trunc_ln708_814_fu_57147_p4 = mul_ln1118_674_reg_76118.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_815_fu_57160_p4() {
    trunc_ln708_815_fu_57160_p4 = mul_ln1118_675_reg_76123.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_816_fu_57173_p4() {
    trunc_ln708_816_fu_57173_p4 = mul_ln1118_676_reg_76128.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_817_fu_57186_p4() {
    trunc_ln708_817_fu_57186_p4 = mul_ln1118_677_reg_76133.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_818_fu_57199_p4() {
    trunc_ln708_818_fu_57199_p4 = mul_ln1118_678_reg_76138.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_819_fu_57212_p4() {
    trunc_ln708_819_fu_57212_p4 = mul_ln1118_679_reg_76143.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_820_fu_57225_p4() {
    trunc_ln708_820_fu_57225_p4 = mul_ln1118_680_reg_76148.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_821_fu_57238_p4() {
    trunc_ln708_821_fu_57238_p4 = mul_ln1118_681_reg_76153.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_822_fu_57251_p4() {
    trunc_ln708_822_fu_57251_p4 = mul_ln1118_682_reg_76158.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_823_fu_57264_p4() {
    trunc_ln708_823_fu_57264_p4 = mul_ln1118_683_reg_76163.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_824_fu_57277_p4() {
    trunc_ln708_824_fu_57277_p4 = mul_ln1118_684_reg_76168.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_825_fu_57290_p4() {
    trunc_ln708_825_fu_57290_p4 = mul_ln1118_685_reg_76173.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_826_fu_57303_p4() {
    trunc_ln708_826_fu_57303_p4 = mul_ln1118_686_reg_76178.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_827_fu_57316_p4() {
    trunc_ln708_827_fu_57316_p4 = mul_ln1118_687_reg_76183.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_828_fu_57533_p4() {
    trunc_ln708_828_fu_57533_p4 = mul_ln1118_688_reg_76188.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_829_fu_57546_p4() {
    trunc_ln708_829_fu_57546_p4 = mul_ln1118_689_reg_76193.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_830_fu_57559_p4() {
    trunc_ln708_830_fu_57559_p4 = mul_ln1118_690_reg_76198.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_831_fu_57572_p4() {
    trunc_ln708_831_fu_57572_p4 = mul_ln1118_691_reg_76203.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_832_fu_57585_p4() {
    trunc_ln708_832_fu_57585_p4 = mul_ln1118_692_reg_76208.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_833_fu_57598_p4() {
    trunc_ln708_833_fu_57598_p4 = mul_ln1118_693_reg_76213.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_834_fu_57611_p4() {
    trunc_ln708_834_fu_57611_p4 = mul_ln1118_694_reg_76218.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_835_fu_57624_p4() {
    trunc_ln708_835_fu_57624_p4 = mul_ln1118_695_reg_76223.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_836_fu_57637_p4() {
    trunc_ln708_836_fu_57637_p4 = mul_ln1118_696_reg_76228.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_837_fu_57650_p4() {
    trunc_ln708_837_fu_57650_p4 = mul_ln1118_697_reg_76233.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_838_fu_57663_p4() {
    trunc_ln708_838_fu_57663_p4 = mul_ln1118_698_reg_76238.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_839_fu_57676_p4() {
    trunc_ln708_839_fu_57676_p4 = mul_ln1118_699_reg_76243.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_840_fu_57689_p4() {
    trunc_ln708_840_fu_57689_p4 = mul_ln1118_700_reg_76248.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_841_fu_57702_p4() {
    trunc_ln708_841_fu_57702_p4 = mul_ln1118_701_reg_76253.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_842_fu_57715_p4() {
    trunc_ln708_842_fu_57715_p4 = mul_ln1118_702_reg_76258.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_843_fu_57728_p4() {
    trunc_ln708_843_fu_57728_p4 = mul_ln1118_703_reg_76263.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_844_fu_57741_p4() {
    trunc_ln708_844_fu_57741_p4 = mul_ln1118_704_reg_76268.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_845_fu_57754_p4() {
    trunc_ln708_845_fu_57754_p4 = mul_ln1118_705_reg_76273.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_846_fu_57767_p4() {
    trunc_ln708_846_fu_57767_p4 = mul_ln1118_706_reg_76278.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_847_fu_57780_p4() {
    trunc_ln708_847_fu_57780_p4 = mul_ln1118_707_reg_76283.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_848_fu_57793_p4() {
    trunc_ln708_848_fu_57793_p4 = mul_ln1118_708_reg_76288.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_849_fu_57806_p4() {
    trunc_ln708_849_fu_57806_p4 = mul_ln1118_709_reg_76293.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_850_fu_57819_p4() {
    trunc_ln708_850_fu_57819_p4 = mul_ln1118_710_reg_76298.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_851_fu_57832_p4() {
    trunc_ln708_851_fu_57832_p4 = mul_ln1118_711_reg_76303.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_852_fu_57845_p4() {
    trunc_ln708_852_fu_57845_p4 = mul_ln1118_712_reg_76308.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_853_fu_57858_p4() {
    trunc_ln708_853_fu_57858_p4 = mul_ln1118_713_reg_76313.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_854_fu_57871_p4() {
    trunc_ln708_854_fu_57871_p4 = mul_ln1118_714_reg_76318.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_855_fu_57884_p4() {
    trunc_ln708_855_fu_57884_p4 = mul_ln1118_715_reg_76323.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_856_fu_57897_p4() {
    trunc_ln708_856_fu_57897_p4 = mul_ln1118_716_reg_76328.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_857_fu_57910_p4() {
    trunc_ln708_857_fu_57910_p4 = mul_ln1118_717_reg_76333.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_858_fu_57923_p4() {
    trunc_ln708_858_fu_57923_p4 = mul_ln1118_718_reg_76338.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_859_fu_57936_p4() {
    trunc_ln708_859_fu_57936_p4 = mul_ln1118_719_reg_76343.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_860_fu_57949_p4() {
    trunc_ln708_860_fu_57949_p4 = mul_ln1118_720_reg_76348.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_861_fu_57962_p4() {
    trunc_ln708_861_fu_57962_p4 = mul_ln1118_721_reg_76353.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_862_fu_57975_p4() {
    trunc_ln708_862_fu_57975_p4 = mul_ln1118_722_reg_76358.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_863_fu_57988_p4() {
    trunc_ln708_863_fu_57988_p4 = mul_ln1118_723_reg_76363.read().range(21, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln708_s_fu_44778_p4() {
    trunc_ln708_s_fu_44778_p4 = mul_ln1118_5_reg_72773.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln77_fu_8205_p1() {
    trunc_ln77_fu_8205_p1 = w7_V_q0.read().range(14-1, 0);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_trunc_ln_fu_44765_p4() {
    trunc_ln_fu_44765_p4 = mul_ln1118_reg_72768.read().range(23, 4);
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_w7_V_address0() {
    w7_V_address0 =  (sc_lv<2>) (zext_ln77_fu_8167_p1.read());
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_w7_V_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0_11001.read()))) {
        w7_V_ce0 = ap_const_logic_1;
    } else {
        w7_V_ce0 = ap_const_logic_0;
    }
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_w_index_fu_8172_p2() {
    w_index_fu_8172_p2 = (!ap_const_lv2_1.is_01() || !ap_phi_mux_w_index43_phi_fu_4129_p6.read().is_01())? sc_lv<2>(): (sc_biguint<2>(ap_const_lv2_1) + sc_biguint<2>(ap_phi_mux_w_index43_phi_fu_4129_p6.read()));
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_zext_ln64_fu_8163_p1() {
    zext_ln64_fu_8163_p1 = esl_zext<3,2>(ap_phi_mux_w_index43_phi_fu_4129_p6.read());
}

void dense_resource_ap_ufixed_ap_fixed_14_8_5_3_0_config7_s::thread_zext_ln77_fu_8167_p1() {
    zext_ln77_fu_8167_p1 = esl_zext<64,2>(ap_phi_mux_w_index43_phi_fu_4129_p6.read());
}

}


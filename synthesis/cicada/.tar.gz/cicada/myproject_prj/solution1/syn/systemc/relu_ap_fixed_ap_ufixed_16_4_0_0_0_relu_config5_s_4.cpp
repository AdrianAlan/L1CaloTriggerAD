#include "relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_s::thread_trunc_ln703_8_fu_1522_p1() {
    trunc_ln703_8_fu_1522_p1 = data_8_V_read.read().range(16-1, 0);
}

void relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_s::thread_trunc_ln703_90_fu_4966_p1() {
    trunc_ln703_90_fu_4966_p1 = data_90_V_read.read().range(16-1, 0);
}

void relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_s::thread_trunc_ln703_91_fu_5008_p1() {
    trunc_ln703_91_fu_5008_p1 = data_91_V_read.read().range(16-1, 0);
}

void relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_s::thread_trunc_ln703_92_fu_5050_p1() {
    trunc_ln703_92_fu_5050_p1 = data_92_V_read.read().range(16-1, 0);
}

void relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_s::thread_trunc_ln703_93_fu_5092_p1() {
    trunc_ln703_93_fu_5092_p1 = data_93_V_read.read().range(16-1, 0);
}

void relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_s::thread_trunc_ln703_94_fu_5134_p1() {
    trunc_ln703_94_fu_5134_p1 = data_94_V_read.read().range(16-1, 0);
}

void relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_s::thread_trunc_ln703_95_fu_5176_p1() {
    trunc_ln703_95_fu_5176_p1 = data_95_V_read.read().range(16-1, 0);
}

void relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_s::thread_trunc_ln703_96_fu_5218_p1() {
    trunc_ln703_96_fu_5218_p1 = data_96_V_read.read().range(16-1, 0);
}

void relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_s::thread_trunc_ln703_97_fu_5260_p1() {
    trunc_ln703_97_fu_5260_p1 = data_97_V_read.read().range(16-1, 0);
}

void relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_s::thread_trunc_ln703_98_fu_5302_p1() {
    trunc_ln703_98_fu_5302_p1 = data_98_V_read.read().range(16-1, 0);
}

void relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_s::thread_trunc_ln703_99_fu_5344_p1() {
    trunc_ln703_99_fu_5344_p1 = data_99_V_read.read().range(16-1, 0);
}

void relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_s::thread_trunc_ln703_9_fu_1564_p1() {
    trunc_ln703_9_fu_1564_p1 = data_9_V_read.read().range(16-1, 0);
}

void relu_ap_fixed_ap_ufixed_16_4_0_0_0_relu_config5_s::thread_trunc_ln703_fu_1186_p1() {
    trunc_ln703_fu_1186_p1 = data_0_V_read.read().range(16-1, 0);
}

}

